<?php

// @ this file will just provide some more translations that you have in your frontend

__("Featured Artists");
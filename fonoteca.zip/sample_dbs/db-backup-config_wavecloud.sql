DROP TABLE IF EXISTS activity;

CREATE TABLE `activity` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_user` int(10) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `details` longtext NOT NULL,
  `date` datetime DEFAULT NULL,
  `target_user_id` int(10) DEFAULT NULL,
  `target_track_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=latin1;

INSERT INTO activity VALUES("1","1","add_user","a:1:{s:7:\"id_user\";i:1;}","2015-04-05");
INSERT INTO activity VALUES("2","1","add_track","a:1:{s:8:\"track_id\";i:1;}","2015-04-05");
INSERT INTO activity VALUES("3","1","add_track","a:1:{s:8:\"track_id\";i:2;}","2015-04-05");
INSERT INTO activity VALUES("4","1","add_track","a:1:{s:8:\"track_id\";i:3;}","2015-04-05");
INSERT INTO activity VALUES("5","0","add_track","a:1:{s:8:\"track_id\";i:4;}","2015-09-25");
INSERT INTO activity VALUES("6","2","add_user","a:1:{s:7:\"id_user\";i:2;}","2015-09-25");
INSERT INTO activity VALUES("7","3","add_user","a:1:{s:7:\"id_user\";i:3;}","2015-09-25");
INSERT INTO activity VALUES("8","4","add_user","a:1:{s:7:\"id_user\";i:4;}","2015-09-25");
INSERT INTO activity VALUES("9","0","add_track","a:1:{s:8:\"track_id\";i:5;}","2015-10-04");
INSERT INTO activity VALUES("10","0","add_track","a:1:{s:8:\"track_id\";i:6;}","2015-10-04");
INSERT INTO activity VALUES("11","5","add_user","a:1:{s:7:\"id_user\";i:5;}","2015-10-05");
INSERT INTO activity VALUES("12","6","add_user","a:1:{s:7:\"id_user\";i:6;}","2015-10-05");
INSERT INTO activity VALUES("13","7","add_user","a:1:{s:7:\"id_user\";i:7;}","2015-10-05");
INSERT INTO activity VALUES("14","0","add_track","a:1:{s:8:\"track_id\";i:7;}","2015-10-13");
INSERT INTO activity VALUES("15","0","add_track","a:1:{s:8:\"track_id\";i:8;}","2015-10-21");
INSERT INTO activity VALUES("16","0","add_track","a:1:{s:8:\"track_id\";i:9;}","2015-10-21");
INSERT INTO activity VALUES("17","0","add_track","a:1:{s:8:\"track_id\";i:10;}","2015-10-21");
INSERT INTO activity VALUES("18","8","add_user","a:1:{s:7:\"id_user\";i:8;}","2015-10-21");
INSERT INTO activity VALUES("19","8","add_track","a:1:{s:8:\"track_id\";i:11;}","2015-10-22");
INSERT INTO activity VALUES("20","4","add_track","a:1:{s:8:\"track_id\";i:12;}","2015-10-22");
INSERT INTO activity VALUES("21","4","add_track","a:1:{s:8:\"track_id\";i:13;}","2015-10-24");
INSERT INTO activity VALUES("22","0","add_track","a:1:{s:8:\"track_id\";i:14;}","2015-11-01");
INSERT INTO activity VALUES("23","9","add_user","a:1:{s:7:\"id_user\";i:9;}","2015-11-02");
INSERT INTO activity VALUES("24","10","add_user","a:1:{s:7:\"id_user\";i:10;}","2015-11-02");
INSERT INTO activity VALUES("25","11","add_user","a:1:{s:7:\"id_user\";i:11;}","2015-11-02");
INSERT INTO activity VALUES("26","12","add_user","a:1:{s:7:\"id_user\";i:12;}","2015-11-02");
INSERT INTO activity VALUES("27","13","add_user","a:1:{s:7:\"id_user\";i:13;}","2015-11-02");
INSERT INTO activity VALUES("28","14","add_user","a:1:{s:7:\"id_user\";i:14;}","2015-11-02");
INSERT INTO activity VALUES("29","15","add_user","a:1:{s:7:\"id_user\";i:15;}","2015-11-02");
INSERT INTO activity VALUES("30","16","add_user","a:1:{s:7:\"id_user\";i:16;}","2015-11-02");
INSERT INTO activity VALUES("31","17","add_user","a:1:{s:7:\"id_user\";i:17;}","2015-11-02");
INSERT INTO activity VALUES("32","18","add_user","a:1:{s:7:\"id_user\";i:18;}","2015-11-02");
INSERT INTO activity VALUES("33","19","add_user","a:1:{s:7:\"id_user\";i:19;}","2015-11-02");
INSERT INTO activity VALUES("34","4","add_track","a:1:{s:8:\"track_id\";i:15;}","2015-11-04");
INSERT INTO activity VALUES("35","14","add_track","a:1:{s:8:\"track_id\";i:16;}","2015-11-10");
INSERT INTO activity VALUES("36","14","add_track","a:1:{s:8:\"track_id\";i:17;}","2015-11-10");
INSERT INTO activity VALUES("37","20","add_user","a:1:{s:7:\"id_user\";i:20;}","2015-11-11");
INSERT INTO activity VALUES("38","20","add_track","a:1:{s:8:\"track_id\";i:18;}","2015-11-11");
INSERT INTO activity VALUES("39","20","add_track","a:1:{s:8:\"track_id\";i:19;}","2015-11-11");
INSERT INTO activity VALUES("40","20","add_track","a:1:{s:8:\"track_id\";i:20;}","2015-11-11");
INSERT INTO activity VALUES("41","14","add_track","a:1:{s:8:\"track_id\";i:21;}","2015-11-14");
INSERT INTO activity VALUES("42","21","add_user","a:1:{s:7:\"id_user\";i:21;}","2015-11-14");
INSERT INTO activity VALUES("43","21","add_track","a:1:{s:8:\"track_id\";i:22;}","2015-11-14");
INSERT INTO activity VALUES("44","14","add_track","a:1:{s:8:\"track_id\";i:23;}","2015-11-14");
INSERT INTO activity VALUES("45","5","add_track","a:1:{s:8:\"track_id\";i:24;}","2015-11-15");
INSERT INTO activity VALUES("46","5","add_track","a:1:{s:8:\"track_id\";i:25;}","2015-11-15");
INSERT INTO activity VALUES("73","0","purchase","a:4:{s:8:\"mc_gross\";s:5:\"10.00\";s:9:\"item_name\";s:11:\"Pro Account\";s:11:\"item_number\";s:10:\"proaccount\";s:11:\"payer_email\";s:29:\"soundportal-buyer-1@gmail.com\";}","2015-12-10");
INSERT INTO activity VALUES("74","0","purchase","a:4:{s:8:\"mc_gross\";s:5:\"10.00\";s:9:\"item_name\";s:11:\"Pro Account\";s:11:\"item_number\";s:10:\"proaccount\";s:11:\"payer_email\";s:29:\"soundportal-buyer-1@gmail.com\";}","2015-12-10");
INSERT INTO activity VALUES("75","0","purchase","a:4:{s:8:\"mc_gross\";s:5:\"10.00\";s:9:\"item_name\";s:11:\"Pro Account\";s:11:\"item_number\";s:10:\"proaccount\";s:11:\"payer_email\";s:29:\"soundportal-buyer-1@gmail.com\";}","2015-12-10");
INSERT INTO activity VALUES("76","0","purchase","a:4:{s:8:\"mc_gross\";s:5:\"10.00\";s:9:\"item_name\";s:11:\"Pro Account\";s:11:\"item_number\";s:10:\"proaccount\";s:11:\"payer_email\";s:29:\"soundportal-buyer-1@gmail.com\";}","2015-12-10");
INSERT INTO activity VALUES("77","0","purchase","a:4:{s:8:\"mc_gross\";s:5:\"10.00\";s:9:\"item_name\";s:11:\"Pro Account\";s:11:\"item_number\";s:10:\"proaccount\";s:11:\"payer_email\";s:29:\"soundportal-buyer-1@gmail.com\";}","2015-12-10");
INSERT INTO activity VALUES("78","0","purchase","a:4:{s:8:\"mc_gross\";s:5:\"10.00\";s:9:\"item_name\";s:11:\"Pro Account\";s:11:\"item_number\";s:10:\"proaccount\";s:11:\"payer_email\";s:29:\"soundportal-buyer-1@gmail.com\";}","2015-12-10");
INSERT INTO activity VALUES("79","5","add_track","a:1:{s:8:\"track_id\";i:26;}","2015-12-27");
INSERT INTO activity VALUES("80","5","add_track","a:1:{s:8:\"track_id\";i:27;}","2015-12-27");
INSERT INTO activity VALUES("81","5","add_track","a:1:{s:8:\"track_id\";i:28;}","2015-12-27");
INSERT INTO activity VALUES("82","5","add_track","a:1:{s:8:\"track_id\";i:29;}","2015-12-27");
INSERT INTO activity VALUES("83","5","add_track","a:1:{s:8:\"track_id\";i:26;}","2016-02-14");
INSERT INTO activity VALUES("84","5","add_track","a:1:{s:8:\"track_id\";i:28;}","2016-02-27");
INSERT INTO activity VALUES("85","5","add_track","a:1:{s:8:\"track_id\";i:29;}","2016-02-27");
INSERT INTO activity VALUES("86","5","add_track","a:1:{s:8:\"track_id\";i:30;}","2016-02-27");
INSERT INTO activity VALUES("87","5","add_track","a:1:{s:8:\"track_id\";i:31;}","2016-02-27");
INSERT INTO activity VALUES("88","5","add_track","a:1:{s:8:\"track_id\";i:32;}","2016-02-28");
INSERT INTO activity VALUES("89","5","add_track","a:1:{s:8:\"track_id\";i:33;}","2016-02-28");
INSERT INTO activity VALUES("90","5","add_track","a:1:{s:8:\"track_id\";i:34;}","2016-02-28");
INSERT INTO activity VALUES("91","22","add_user","a:1:{s:7:\"id_user\";i:22;}","2016-02-28");
INSERT INTO activity VALUES("92","5","add_track","a:1:{s:8:\"track_id\";i:26;}","2016-02-29");
INSERT INTO activity VALUES("93","5","add_track","a:1:{s:8:\"track_id\";i:27;}","2016-02-29");



DROP TABLE IF EXISTS apconfigs;

CREATE TABLE `apconfigs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `author_id` varchar(255) NOT NULL,
  `published_date` date NOT NULL,
  `content` longtext NOT NULL,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO apconfigs VALUES("1","1","2015-10-11","skin_ap=skin-wave&settings_backup_type=simple&disable_volume=on&enable_embed_button=on&playfrom=0&colorhighlight=111111&skinwave_dynamicwaves=off&skinwave_enablespectrum=off&skinwave_enablereflect=on&skinwave_comments_enable=on&skinwave_mode=normal&enable_alternate_layout=off","skinwave");
INSERT INTO apconfigs VALUES("2","5","2015-12-05","skin_ap=skin-silver&settings_backup_type=simple&disable_volume=default&enable_embed_button=off&playfrom=&colorhighlight=&skinwave_dynamicwaves=off&skinwave_enablespectrum=off&skinwave_enablereflect=on&skinwave_comments_enable=off&skinwave_mode=normal&enable_alternate_layout=off","skinsilver");



DROP TABLE IF EXISTS comments;

CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `author_id` int(11) NOT NULL,
  `published_date` date NOT NULL,
  `for_type` varchar(255) NOT NULL,
  `track_id` int(11) NOT NULL COMMENT 'foreign',
  `content` longtext NOT NULL,
  `position` double NOT NULL,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

INSERT INTO comments VALUES("3","5","2015-11-23","track","24","vezaigrija","15.396188565697091","","");
INSERT INTO comments VALUES("4","5","2015-11-25","track","24","I don\'t know about you, but I\'m feeling 22...  I don\'t know about you, but I\'m feeling 22...  I don\'t know about you, but I\'m feeling 22...  I don\'t know about you, but I\'m feeling 22... ","46.18856569709127","","");
INSERT INTO comments VALUES("12","0","2015-11-25","track","24","o sa rupem boxele","35.30591775325978","unpezvivo@gmail.com","");
INSERT INTO comments VALUES("20","0","2015-12-06","track","24","test5","0","test@gmail.com","test");
INSERT INTO comments VALUES("21","0","2015-12-06","track","24","test6","0","rad@gmail.com","rad");



DROP TABLE IF EXISTS dzspgb_templates;

CREATE TABLE `dzspgb_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `template_name` varchar(255) NOT NULL,
  `template_data` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO dzspgb_templates VALUES("2","pro_illustration","dzspgb%5Btype%5D=Row&dzspgb%5B0%5D%5Bextra_classes%5D=row-features&dzspgb%5B0%5D%5B0%5D%5Btype%5D=row_part&dzspgb%5B0%5D%5B0%5D%5Bpart%5D=1.3&dzspgb%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=%3Ch4%3EBigger+Upload+Limit%3C%2Fh4%3E&dzspgb%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=text&dzspgb%5B0%5D%5B0%5D%5B1%5D%5Bimage%5D=upload%2Ffeat1.png&dzspgb%5B0%5D%5B0%5D%5B1%5D%5Bextra_classes%5D=test&dzspgb%5B0%5D%5B0%5D%5B1%5D%5Btype_element%5D=image&dzspgb%5B0%5D%5B0%5D%5B2%5D%5Btext%5D=%3Cp%3E%3Cem%3E%3C%2Fem%3E%3C%2Fp%3E%0A%3Cp%3E%3Cem%3E%3C%2Fem%3E%3C%2Fp%3E%0A%3Cp%3E%3Cem%3E%3C%2Fem%3E%3Cem%3EUpload+has+a+bigger+cap+with+PRO+user+privileges.+Submit+more+tracks!+Normal+users+have+a+lower+number+of+tracks+limit.%3C%2Fem%3E%3C%2Fp%3E&dzspgb%5B0%5D%5B0%5D%5B2%5D%5Btype_element%5D=text&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstyle%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bapconfig%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bids%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=artist_query&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Baudioplayer_style%5D=style_default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=audioplayer&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=breakout_final&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=breakout_first&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcheckout_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=checkout&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btrack_id%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=comments&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btrack_id%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=cover_image&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bdivider_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=divider&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bheader_style%5D=style-default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bmenu_select%5D=none&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=header&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bimage%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=image&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=messages&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=messages_friends&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bnr_columns%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem%5D%5Btype%5D=multipleitems&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem2%5D%5Btype%5D=multipleitems2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem3%5D%5Btype%5D=multipleitems3&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem4%5D%5Btype%5D=multipleitems4&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=pricing_table&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstyle%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bpagination%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bapconfig%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Blimit_posts%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bquery_query%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=query&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bregister_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=register&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem%5D%5Btype%5D=multipleitems&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=slider&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btemplate_id%5D=1&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=templates&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=text&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bupload_style%5D=style_default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=upload&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=user&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Busersettings_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=usersettings&dzspgb%5B0%5D%5B1%5D%5Btype%5D=row_part&dzspgb%5B0%5D%5B1%5D%5Bpart%5D=1.3&dzspgb%5B0%5D%5B1%5D%5B0%5D%5Btext%5D=%3Ch4%3EUnlimited+Playlists%3C%2Fh4%3E&dzspgb%5B0%5D%5B1%5D%5B0%5D%5Btype_element%5D=text&dzspgb%5B0%5D%5B1%5D%5B1%5D%5Bimage%5D=upload%2Ffeat2.png&dzspgb%5B0%5D%5B1%5D%5B1%5D%5Bextra_classes%5D=&dzspgb%5B0%5D%5B1%5D%5B1%5D%5Btype_element%5D=image&dzspgb%5B0%5D%5B1%5D%5B2%5D%5Btext%5D=%3Cp%3E%3Cem%3E%3C%2Fem%3E%3C%2Fp%3E%0A%3Cp%3E%3Cem%3E%3C%2Fem%3E%3C%2Fp%3E%0A%3Cp%3E%3Cem%3ECreate+unlimited+playlsits+being+a+PRO%7Breplacequotquot%7D+member%2C+either+Public+or+Private.+Normal+users+have+a+limit+of+4+playlists.%3C%2Fem%3E%3C%2Fp%3E%0A%3Cp%3E%3Ca+class%3D%22%7Breplacequotquot%7Dajax-link%7Breplacequotquot%7D%22+href%3D%22%7Breplacequotquot%7Dindex.php%3Fpage%3Dpage%26amp%3Bpage_id%3D29%7Breplacequotquot%7D%22%3EView+Pricing%3C%2Fa%3E%3C%2Fp%3E&dzspgb%5B0%5D%5B1%5D%5B2%5D%5Btype_element%5D=text&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstyle%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bapconfig%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bids%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=artist_query&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Baudioplayer_style%5D=style_default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=audioplayer&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=breakout_final&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=breakout_first&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcheckout_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=checkout&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btrack_id%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=comments&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btrack_id%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=cover_image&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bdivider_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=divider&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bheader_style%5D=style-default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bmenu_select%5D=none&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=header&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bimage%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=image&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=messages&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=messages_friends&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bnr_columns%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem%5D%5Btype%5D=multipleitems&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem2%5D%5Btype%5D=multipleitems2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem3%5D%5Btype%5D=multipleitems3&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem4%5D%5Btype%5D=multipleitems4&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=pricing_table&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstyle%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bpagination%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bapconfig%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Blimit_posts%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bquery_query%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=query&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bregister_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=register&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem%5D%5Btype%5D=multipleitems&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=slider&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btemplate_id%5D=1&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=templates&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=text&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bupload_style%5D=style_default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=upload&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=user&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Busersettings_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=usersettings&dzspgb%5B0%5D%5B2%5D%5Btype%5D=row_part&dzspgb%5B0%5D%5B2%5D%5Bpart%5D=1.3&dzspgb%5B0%5D%5B2%5D%5B0%5D%5Btext%5D=%3Ch4%3EPRO+Badge%3C%2Fh4%3E&dzspgb%5B0%5D%5B2%5D%5B0%5D%5Btype_element%5D=text&dzspgb%5B0%5D%5B2%5D%5B1%5D%5Bimage%5D=upload%2Ffeat3.png&dzspgb%5B0%5D%5B2%5D%5B1%5D%5Bextra_classes%5D=&dzspgb%5B0%5D%5B2%5D%5B1%5D%5Btype_element%5D=image&dzspgb%5B0%5D%5B2%5D%5B2%5D%5Btext%5D=%3Cp%3E%3C%2Fp%3E%0A%3Cp%3E%3C%2Fp%3E%0A%3Cp%3E%3Cem%3EPRO+members+have+the+estinguished+PRO+badge+that+make+them+stand+out.+This+badge+will+appear+after+the+user+name.%3C%2Fem%3E%3C%2Fp%3E&dzspgb%5B0%5D%5B2%5D%5B2%5D%5Btype_element%5D=text&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstyle%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bapconfig%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bids%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=artist_query&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Baudioplayer_style%5D=style_default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=audioplayer&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=breakout_final&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=breakout_first&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcheckout_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=checkout&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btrack_id%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=comments&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btrack_id%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=cover_image&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bdivider_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=divider&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bheader_style%5D=style-default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bmenu_select%5D=none&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=header&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bimage%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=image&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=messages&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=messages_friends&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bnr_columns%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem%5D%5Btype%5D=multipleitems&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem2%5D%5Btype%5D=multipleitems2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem3%5D%5Btype%5D=multipleitems3&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem4%5D%5Btype%5D=multipleitems4&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=pricing_table&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstyle%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bpagination%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bapconfig%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Blimit_posts%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bquery_query%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=query&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bregister_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=register&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem%5D%5Btype%5D=multipleitems&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=slider&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btemplate_id%5D=1&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=templates&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=text&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bupload_style%5D=style_default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=upload&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=user&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Busersettings_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=usersettings&dzspgb%5B0%5D%5B0%5D%5B0%5D%5Btype%5D=element");
INSERT INTO dzspgb_templates VALUES("10","general_template","dzspgb%5Btype%5D=Full&dzspgb%5B0%5D%5Bextra_classes%5D=mcon-mainmenu&dzspgb%5B0%5D%5B0%5D%5Bextra_classes%5D=&dzspgb%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&dzspgb%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype%5D=row_part&dzspgb%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bpart%5D=1.1&dzspgb%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&dzspgb%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bheader_style%5D=style-default&dzspgb%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bmenu_select%5D=1&dzspgb%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=header&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Baudioplayer_style%5D=style_default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=audioplayer&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=breakout_final&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=breakout_first&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcheckout_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=checkout&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bdivider_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=divider&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bheader_style%5D=style-default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bmenu_select%5D=none&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=header&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstyle%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bapconfig%5D=1&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=query&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bregister_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=register&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem%5D%5Btype%5D=multipleitems&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=slider&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btemplate%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btemplate_id%5D=1&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=templates&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=text&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bupload_style%5D=style_default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=upload&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=user&dzspgb%5B0%5D%5B0%5D%5B0%5D%5Btype%5D=element&dzspgb%5B0%5D%5B0%5D%5Btype%5D=element&dzspgb%5B0%5D%5Btype%5D=section&dzspgb%5B1%5D%5Bextra_classes%5D=content-section&dzspgb%5B1%5D%5B0%5D%5Bextra_classes%5D=content-container&dzspgb%5B1%5D%5B0%5D%5Bis_content%5D=on&dzspgb%5B1%5D%5B0%5D%5Btype%5D=container&dzspgb%5B1%5D%5B1%5D%5Bextra_classes%5D=&dzspgb%5B1%5D%5B1%5D%5B0%5D%5Bextra_classes%5D=&dzspgb%5B1%5D%5B1%5D%5B0%5D%5B0%5D%5Btype%5D=row_part&dzspgb%5B1%5D%5B1%5D%5B0%5D%5B0%5D%5Bpart%5D=1.1&dzspgb%5B1%5D%5B1%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&dzspgb%5B1%5D%5B1%5D%5B0%5D%5B0%5D%5B0%5D%5Bheader_style%5D=style-footer-menu&dzspgb%5B1%5D%5B1%5D%5B0%5D%5B0%5D%5B0%5D%5Bmenu_select%5D=2&dzspgb%5B1%5D%5B1%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=header&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Baudioplayer_style%5D=style_default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=audioplayer&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=breakout_final&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=breakout_first&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcheckout_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=checkout&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bdivider_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=divider&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bheader_style%5D=style-default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bmenu_select%5D=none&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=header&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstyle%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bapconfig%5D=1&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=query&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bregister_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=register&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem%5D%5Btype%5D=multipleitems&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=slider&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btemplate%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btemplate_id%5D=1&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=templates&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=text&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bupload_style%5D=style_default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=upload&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=user&dzspgb%5B1%5D%5B1%5D%5B0%5D%5Btype%5D=element&dzspgb%5B1%5D%5B1%5D%5Btype%5D=element&dzspgb%5B1%5D%5Btype%5D=section");
INSERT INTO dzspgb_templates VALUES("11","sidebar_stream","dzspgb%5Btype%5D=Row&dzspgb%5B0%5D%5Bextra_classes%5D=&dzspgb%5B0%5D%5B0%5D%5Btype%5D=row_part&dzspgb%5B0%5D%5B0%5D%5Bpart%5D=1.1&dzspgb%5B0%5D%5B0%5D%5B0%5D%5Bdivider_height%5D=30&dzspgb%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=divider&dzspgb%5B0%5D%5B0%5D%5B1%5D%5Btext%5D=%3Ch3+class%3D%7Breplacequotquot%7Dwidget-title%7Breplacequotquot%7D%3EMost+Liked%3C%2Fh3%3E&dzspgb%5B0%5D%5B0%5D%5B1%5D%5Bkill_tinymce%5D=off&dzspgb%5B0%5D%5B0%5D%5B1%5D%5Btype_element%5D=text&dzspgb%5B0%5D%5B0%5D%5B2%5D%5Bstyle%5D=list&dzspgb%5B0%5D%5B0%5D%5B2%5D%5Bquery_type%5D=auto&dzspgb%5B0%5D%5B0%5D%5B2%5D%5Bpagination%5D=auto&dzspgb%5B0%5D%5B0%5D%5B2%5D%5Bapconfig%5D=2&dzspgb%5B0%5D%5B0%5D%5B2%5D%5Blimit_posts%5D=5&dzspgb%5B0%5D%5B0%5D%5B2%5D%5Bquery_query%5D=&dzspgb%5B0%5D%5B0%5D%5B2%5D%5Bextra_classes%5D=&dzspgb%5B0%5D%5B0%5D%5B2%5D%5Bpost_type%5D=&dzspgb%5B0%5D%5B0%5D%5B2%5D%5Btype_element%5D=query&dzspgb%5B0%5D%5B0%5D%5B3%5D%5Btext%5D=%3Ch3+class%3D%7Breplacequotquot%7Dwidget-title%7Breplacequotquot%7D%3EFeatured+Artists%3C%2Fh3%3E&dzspgb%5B0%5D%5B0%5D%5B3%5D%5Bkill_tinymce%5D=off&dzspgb%5B0%5D%5B0%5D%5B3%5D%5Btype_element%5D=text&dzspgb%5B0%5D%5B0%5D%5B4%5D%5Bstyle%5D=thumbs&dzspgb%5B0%5D%5B0%5D%5B4%5D%5Btype%5D=auto&dzspgb%5B0%5D%5B0%5D%5B4%5D%5Bapconfig%5D=2&dzspgb%5B0%5D%5B0%5D%5B4%5D%5Bids%5D=21%2C5%2C14%2C20&dzspgb%5B0%5D%5B0%5D%5B4%5D%5Btype_element%5D=artist_query&dzspgb%5B0%5D%5B0%5D%5B5%5D%5Bdivider_height%5D=10&dzspgb%5B0%5D%5B0%5D%5B5%5D%5Btype_element%5D=divider&dzspgb%5B0%5D%5B0%5D%5B6%5D%5Btext%5D=%3Ch3+class%3D%7Breplacequotquot%7Dwidget-title%7Breplacequotquot%7D%3EAd+Space%3C%2Fh3%3E&dzspgb%5B0%5D%5B0%5D%5B6%5D%5Bkill_tinymce%5D=off&dzspgb%5B0%5D%5B0%5D%5B6%5D%5Btype_element%5D=text&dzspgb%5B0%5D%5B0%5D%5B7%5D%5Bimage%5D=upload%2Fadspace_1.png&dzspgb%5B0%5D%5B0%5D%5B7%5D%5Bextra_classes%5D=&dzspgb%5B0%5D%5B0%5D%5B7%5D%5Btype_element%5D=image&dzspgb%5B0%5D%5B0%5D%5B8%5D%5Bdivider_height%5D=10&dzspgb%5B0%5D%5B0%5D%5B8%5D%5Btype_element%5D=divider&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstyle%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bapconfig%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bids%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=artist_query&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bnr_columns%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Baudio_track%5D%5Btype%5D=multipleitems&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=audio_playlist&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Baudioplayer_style%5D=style_default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=audioplayer&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=breakout_final&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=breakout_first&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcover_image%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bvideo%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=calendar&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcheckout_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=checkout&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btrack_id%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=comments&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btrack_id%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=cover_image&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bdivider_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=divider&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcover_image%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bvideo%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=events&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bflickr_username%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bflickr_api_key%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=gallery&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bheader_style%5D=style-default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bmenu_select%5D=none&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=header&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bimage%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=image&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Blogin_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=login&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=messages&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=messages_friends&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=new_section&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bnr_columns%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem%5D%5Btype%5D=multipleitems&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem2%5D%5Btype%5D=multipleitems2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem3%5D%5Btype%5D=multipleitems3&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem4%5D%5Btype%5D=multipleitems4&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=pricing_table&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstyle%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bquery_type%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bpagination%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bapconfig%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Blimit_posts%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bquery_query%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bpost_type%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=query&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bregister_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=register&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem%5D%5Btype%5D=multipleitems&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=slider&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btemplate_id%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=templates&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bkill_tinymce%5D=off&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=text&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bupload_style%5D=style_default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=upload&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=user&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Busersettings_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=usersettings&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcover_image%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bvideo%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_text%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=videoplayer&dzspgb%5B0%5D%5B0%5D%5B0%5D%5Btype%5D=element");



DROP TABLE IF EXISTS likes;

CREATE TABLE `likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `track_id` int(11) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO likes VALUES("1","4","14","::1","2015-11-03");
INSERT INTO likes VALUES("2","4","17","::1","2015-11-11");
INSERT INTO likes VALUES("3","5","17","::1","2015-11-16");



DROP TABLE IF EXISTS menus;

CREATE TABLE `menus` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `author_id` int(11) NOT NULL,
  `published_date` date NOT NULL,
  `content` longtext NOT NULL,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO menus VALUES("1","1","2015-10-06","[{\"visibility_type\":\"always\",\"content\":\"\",\"type\":\"menupage\",\"label\":\"Explore\",\"id\":20},{\"visibility_type\":\"always\",\"content\":\"\",\"type\":\"menupage\",\"label\":\"Page Upload\",\"id\":18}]","test21");
INSERT INTO menus VALUES("2","1","2015-10-25","[{\"visibility_type\":\"always\",\"content\":\"<span class={replacequotquot}copyright-text{replacequotquot}>© copyright DZS 2015</span><br> \",\"type\":\"customhtml\",\"label\":\"Custom HTML\",\"id\":0},{\"visibility_type\":\"always\",\"content\":\"\",\"type\":\"menupage\",\"label\":\"Legal\",\"id\":31},{\"content\":\"Cookies\",\"type\":\"menupage\",\"label\":\"Legal\",\"id\":31},{\"content\":\"Privacy Policy\",\"type\":\"menupage\",\"label\":\"Legal\",\"id\":31}]","footer-menu");
INSERT INTO menus VALUES("3","1","2015-10-28","","test2");



DROP TABLE IF EXISTS messages;

CREATE TABLE `messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `author_id` int(10) unsigned NOT NULL,
  `id_receiver` int(10) unsigned NOT NULL,
  `published_date` date NOT NULL,
  `content` longtext NOT NULL,
  `read_status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;

INSERT INTO messages VALUES("13","5","4","2015-10-29","Lorem Ipsum &lt;br&gt; test","unread");
INSERT INTO messages VALUES("14","5","4","2015-10-29","Lorem Ipsum &amp;lt;br&amp;gt;","unread");
INSERT INTO messages VALUES("15","5","4","2015-10-29","Lorem Ipsum  &lt;br&gt; test","unread");
INSERT INTO messages VALUES("16","5","4","2015-10-29","Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor ","unread");
INSERT INTO messages VALUES("17","5","4","2015-10-29","Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor","unread");
INSERT INTO messages VALUES("18","5","4","2015-10-29","Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor test21321 ","unread");
INSERT INTO messages VALUES("19","5","4","2015-10-29","Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor test21321 1000","unread");
INSERT INTO messages VALUES("20","5","4","2015-10-29","Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor test21321 10001","unread");
INSERT INTO messages VALUES("21","5","4","2015-10-29","1002 Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor test21321 10001","unread");
INSERT INTO messages VALUES("22","5","4","2015-10-29","1002 1002 Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor Lorem Ipsum dolor test21321 10001","unread");
INSERT INTO messages VALUES("23","5","4","2015-10-29","all night","unread");
INSERT INTO messages VALUES("24","5","4","2015-10-29","scroll to me pliz","unread");
INSERT INTO messages VALUES("25","5","4","2015-10-29","nice","unread");
INSERT INTO messages VALUES("26","4","5","2015-10-31","Virtus Pro","unread");
INSERT INTO messages VALUES("27","5","4","2015-11-01","test","unread");
INSERT INTO messages VALUES("28","5","4","2015-11-01","test","unread");
INSERT INTO messages VALUES("29","5","4","2015-11-01","test2","unread");
INSERT INTO messages VALUES("30","5","4","2015-11-01","test","unread");
INSERT INTO messages VALUES("31","5","4","2015-11-01","test3","unread");
INSERT INTO messages VALUES("32","5","4","2015-11-01","test23","unread");
INSERT INTO messages VALUES("33","5","4","2015-11-01","test4","unread");
INSERT INTO messages VALUES("34","5","4","2015-11-01","tes5","unread");
INSERT INTO messages VALUES("35","5","4","2015-11-01","test1000","unread");
INSERT INTO messages VALUES("36","5","4","2015-11-01","test1001","unread");
INSERT INTO messages VALUES("37","5","4","2015-11-01","test1002","unread");
INSERT INTO messages VALUES("38","5","4","2015-11-01","test1003","unread");
INSERT INTO messages VALUES("39","5","4","2015-11-01","test10004","unread");
INSERT INTO messages VALUES("40","5","4","2015-11-01","test10005","unread");
INSERT INTO messages VALUES("41","4","8","2015-11-01","Tascheti","unread");
INSERT INTO messages VALUES("42","4","8","2015-11-01","So far from &lt;br&gt; typycal","unread");
INSERT INTO messages VALUES("43","5","8","2015-11-01","vezai grija vezaigrija","unread");
INSERT INTO messages VALUES("44","4","5","2015-11-02","vez\' ai grij","unread");



DROP TABLE IF EXISTS pages;

CREATE TABLE `pages` (
  `id` int(255) unsigned NOT NULL AUTO_INCREMENT,
  `author_id` int(255) NOT NULL,
  `published_date` date NOT NULL,
  `content` longtext NOT NULL,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

INSERT INTO pages VALUES("18","1","2015-09-25","[dzspgb_row][dzspgb_row_part part=\"1.1\"][dzspgb_element divider_height=\"32\" type_element=\"divider\"][/dzspgb_element][dzspgb_element text=\"\" upload_style=\"style_default\" type_element=\"upload\"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row]","Upload");
INSERT INTO pages VALUES("19","1","2015-09-26","[dzspgb_row][dzspgb_row_part part=\"3.4\"][dzspgb_element divider_height=\"30\" is_negative=\"\" type_element=\"divider\"][/dzspgb_element][dzspgb_element style=\"auto\" query_type=\"auto\" pagination=\"scroll\" apconfig=\"1\" limit_posts=\"3\" query_query=\"\" extra_classes=\"\" post_type=\"\" type_element=\"query\"][/dzspgb_element][/dzspgb_row_part][dzspgb_row_part part=\"1.4\"][dzspgb_element template_id=\"11\" type_element=\"templates\"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row]","Page Tracklist");
INSERT INTO pages VALUES("20","1","2015-09-26","[dzspgb_row][dzspgb_row_part part=\"3.4\"][dzspgb_element divider_height=\"30\" is_negative=\"\" type_element=\"divider\"][/dzspgb_element][dzspgb_element style=\"auto\" query_type=\"auto\" pagination=\"scroll\" apconfig=\"1\" limit_posts=\"3\" query_query=\"\" extra_classes=\"\" post_type=\"\" type_element=\"query\"][/dzspgb_element][/dzspgb_row_part][dzspgb_row_part part=\"1.4\"][dzspgb_element template_id=\"11\" type_element=\"templates\"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row]","Explore");
INSERT INTO pages VALUES("21","1","2015-10-04","[dzspgb_section extra_classes=\"main-section-register\"][dzspgb_container use_template=\"none\"][dzspgb_row][dzspgb_row_part part=\"1.1\"][dzspgb_element register_height=\"10\" type_element=\"register\"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row][/dzspgb_container][/dzspgb_section]","Page Register");
INSERT INTO pages VALUES("22","1","2015-10-08","[dzspgb_row][dzspgb_row_part part=\"1.1\"][dzspgb_element text=\"\" type_element=\"breakout_first\"][/dzspgb_element][dzspgb_element track_id=\"\" type_element=\"cover_image\"][/dzspgb_element][dzspgb_element text=\"\" type_element=\"breakout_final\"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row][dzspgb_row][dzspgb_row_part part=\"1.1\"][dzspgb_element divider_height=\"10\" is_negative=\"\" type_element=\"divider\"][/dzspgb_element][dzspgb_element style=\"auto\" type=\"auto\" pagination=\"auto\" apconfig=\"1\" limit_posts=\"\" query_query=\"\" extra_classes=\"\" type_element=\"query\"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row][dzspgb_row][dzspgb_row_part part=\"3.4\"][dzspgb_element track_id=\"\" type_element=\"comments\"][/dzspgb_element][/dzspgb_row_part][dzspgb_row_part part=\"1.4\"][dzspgb_element text=\"<h3 class={replacequotquot}widget-title{replacequotquot}>Similar Tracks</h3>\" type_element=\"text\"][/dzspgb_element][dzspgb_element style=\"list\" type=\"similar\" pagination=\"auto\" apconfig=\"1\" limit_posts=\"3\" query_query=\"\" extra_classes=\"\" type_element=\"query\"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row]","Page Track");
INSERT INTO pages VALUES("24","1","2015-10-15","[dzspgb_row][dzspgb_row_part part=\"1.1\"][dzspgb_element divider_height=\"10\" is_negative=\"\" type_element=\"divider\"][/dzspgb_element][dzspgb_element checkout_height=\"10\" type_element=\"checkout\"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row]","Page Checkout");
INSERT INTO pages VALUES("25","1","2015-10-24","[dzspgb_row][dzspgb_row_part part=\"1.1\"][dzspgb_element text=\"\" type_element=\"breakout_first\"][/dzspgb_element][dzspgb_element extra_classes=\"negative-margin-top\" type_element=\"10\" is_negative=\"\" type_element=\"user\"][/dzspgb_element][dzspgb_element text=\"\" type_element=\"breakout_final\"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row][dzspgb_row extra_classes=\"user-query\"][dzspgb_row_part part=\"1.1\"][dzspgb_element style=\"auto\" type=\"auto\" pagination=\"auto\" apconfig=\"1\" limit_posts=\"\" query_query=\"\" extra_classes=\"\" call_from_lab=\"page_user\" type_element=\"query\"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row]","Page User");
INSERT INTO pages VALUES("27","4","2015-11-04","[dzspgb_row][dzspgb_row_part part=\"1.1\"][dzspgb_element divider_height=\"30\" is_negative=\"\" type_element=\"divider\"][/dzspgb_element][dzspgb_element usersettings_height=\"10\" type_element=\"usersettings\"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row]","Page User Settings");
INSERT INTO pages VALUES("28","5","2015-11-25","[dzspgb_row][dzspgb_row_part part=\"3.4\"][dzspgb_element divider_height=\"30\" is_negative=\"\" type_element=\"divider\"][/dzspgb_element][dzspgb_element style=\"slider\" query_type=\"custom_ids\" pagination=\"auto\" apconfig=\"1\" limit_posts=\"\" query_query=\"24,25\" extra_classes=\"\" post_type=\"\" type_element=\"query\"][/dzspgb_element][dzspgb_element text=\"<h2 class={replacequotquot}section-title{replacequotquot}>Become a Pro Member</h2>\" kill_tinymce=\"off\" type_element=\"text\"][/dzspgb_element][dzspgb_element template_id=\"2\" type_element=\"templates\"][/dzspgb_element][dzspgb_element text=\"<h2 class={replacequotquot}section-title{replacequotquot}>Featured</h2>\" kill_tinymce=\"off\" type_element=\"text\"][/dzspgb_element][dzspgb_element style=\"thumbs\" query_type=\"auto\" pagination=\"auto\" apconfig=\"1\" limit_posts=\"\" query_query=\"\" extra_classes=\"\" post_type=\"\" type_element=\"query\"][/dzspgb_element][/dzspgb_row_part][dzspgb_row_part part=\"1.4\"][dzspgb_element divider_height=\"30\" is_negative=\"\" type_element=\"divider\"][/dzspgb_element][dzspgb_element style=\"list\" query_type=\"auto\" pagination=\"auto\" apconfig=\"1\" limit_posts=\"10\" query_query=\"\" extra_classes=\"color-white\" post_type=\"\" type_element=\"query\"][/dzspgb_element][dzspgb_element image=\"upload/adspace_1.png\" extra_classes=\"2\" type_element=\"image\"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row]","Homepage");
INSERT INTO pages VALUES("29","5","2015-12-09","[dzspgb_row][dzspgb_row_part part=\"3.4\"][dzspgb_element nr_columns=\"2\" extra_classes=\"\" item=\"multipleitems\" item2=\"multipleitems\" item3=\"multipleitems2\" item4=\"multipleitems4\" type_element=\"pricing_table\"][dzspgb_item label=\"item\" imgsource=\"Normal User\" extra_classes=\"title-item\"][/dzspgb_item][dzspgb_item label=\"item\" imgsource=\"test1\" extra_classes=\"\"][/dzspgb_item][dzspgb_item label=\"item\" imgsource=\"    \" extra_classes=\"\"][/dzspgb_item][dzspgb_item label=\"item\" imgsource=\"included\" extra_classes=\"\"][/dzspgb_item][dzspgb_item label=\"item2\" imgsource=\"Pro User\" extra_classes=\"title-item\"][/dzspgb_item][dzspgb_item label=\"item2\" imgsource=\"test\" extra_classes=\"\"][/dzspgb_item][dzspgb_item label=\"item2\" imgsource=\"<a href={replacequotquot}#{replacequotquot} data-playerid={replacequotquot}proaccount{replacequotquot} class={replacequotquot}add-to-cart-btn button button--secondary{replacequotquot}><span class={replacequotquot}button-label{replacequotquot}>Buy</span></a>\" extra_classes=\"purchase-item\"][/dzspgb_item][dzspgb_item label=\"item3\" imgsource=\"items3_1\" extra_classes=\"itme 3\"][/dzspgb_item][dzspgb_item label=\"item4\" imgsource=\"items4_1\" extra_classes=\"\"][/dzspgb_item][dzspgb_item label=\"item4\" imgsource=\"items4_2\" extra_classes=\"\"][/dzspgb_item][/dzspgb_element][/dzspgb_row_part][dzspgb_row_part part=\"1.4\"][/dzspgb_row_part][/dzspgb_row]","Pro Users");
INSERT INTO pages VALUES("30","5","2015-12-26","[dzspgb_section][dzspgb_container use_template=\"none\"][dzspgb_row][dzspgb_row_part part=\"1.1\"][dzspgb_element style=\"auto\" type=\"auto\" pagination=\"auto\" apconfig=\"1\" limit_posts=\"\" query_query=\"\" extra_classes=\"\" type_element=\"query\"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row][/dzspgb_container][/dzspgb_section]","Page Embed");
INSERT INTO pages VALUES("31","5","2016-02-26","[dzspgb_row][dzspgb_row_part part=\"1.1\"][dzspgb_element divider_height=\"30\" is_negative=\"\" type_element=\"divider\"][/dzspgb_element][dzspgb_element text=\"<p><strong><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>Cookie Policy for ZoomSounds</span></strong><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><strong><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>What Are Cookies</span></strong><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>As is common practice with almost all professional websites this site uses cookies, which are tiny files that are downloaded to your computer, to improve your experience. This page describes what information they gather, how we use it and why we sometimes need to store these cookies. We will also share how you can prevent these cookies from being stored however this may downgrade or \'break\' certain elements of the sites functionality.</span><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>For more general information on cookies see the Wikipedia article on HTTP Cookies...</span><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><strong><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>How We Use Cookies</span></strong><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>We use cookies for a variety of reasons detailed below. Unfortunately in most cases there are no industry standard options for disabling cookies without completely disabling the functionality and features they add to this site. It is recommended that you leave on all cookies if you are not sure whether you need them or not in case they are used to provide a service that you use.</span><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><strong><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>Disabling Cookies</span></strong><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>You can prevent the setting of cookies by adjusting the settings on your browser (see your browser Help for how to do this). Be aware that disabling cookies will affect the functionality of this and many other websites that you visit. Disabling cookies will usually result in also disabling certain functionality and features of the this site. Therefore it is recommended that you do not disable cookies.</span><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><strong><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>The Cookies We Set</span></strong><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>If you create an account with us then we will use cookies for the management of the signup process and general administration. These cookies will usually be deleted when you log out however in some cases they may remain afterwards to remember your site preferences when logged out.</span><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>We use cookies when you are logged in so that we can remember this fact. This prevents you from having to log in every single time you visit a new page. These cookies are typically removed or cleared when you log out to ensure that you can only access restricted features and areas when logged in.</span><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>This site offers e-commerce or payment facilities and some cookies are essential to ensure that your order is remembered between pages so that we can process it properly.</span><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><strong><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>Third Party Cookies</span></strong><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>In some special cases we also use cookies provided by trusted third parties. The following section details which third party cookies you might encounter through this site.</span><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>This site uses Google Analytics which is one of the most widespread and trusted analytics solution on the web for helping us to understand how you use the site and ways that we can improve your experience. These cookies may track things such as how long you spend on the site and the pages that you visit so we can continue to produce engaging content.</span><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>For more information on Google Analytics cookies, see the official Google Analytics page.</span><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>Third party analytics are used to track and measure usage of this site so that we can continue to produce engaging content. These cookies may track things such as how long you spend on the site or pages you visit which helps us to understand how we can improve the site for you.</span><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><strong><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>More Information</span></strong><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>Hopefully that has clarified things for you and as was previously mentioned if there is something that you aren\'t sure whether you need or not it\'s usually safer to leave cookies enabled in case it does interact with one of the features you use on our site. However if you are still looking for more information then you can contact us through one of our preferred contact methods.</span></p>\" kill_tinymce=\"off\" type_element=\"text\"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row]","Legal");



DROP TABLE IF EXISTS playlists;

CREATE TABLE `playlists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `author_id` int(255) NOT NULL,
  `published_date` date NOT NULL,
  `description` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

INSERT INTO playlists VALUES("12","test23","","4","2015-10-25","");
INSERT INTO playlists VALUES("15","Englend","a:1:{i:0;s:2:\"12\";}","4","2015-10-25","");
INSERT INTO playlists VALUES("16","test private","","4","2015-10-25","");
INSERT INTO playlists VALUES("17","test public","","4","2015-10-25","public");
INSERT INTO playlists VALUES("18","Favourites","a:2:{i:0;s:2:\"17\";i:1;s:2:\"25\";}","5","2015-12-08","");
INSERT INTO playlists VALUES("19","My Favs","a:1:{i:0;s:2:\"24\";}","1","2016-03-01","public");



DROP TABLE IF EXISTS post_meta;

CREATE TABLE `post_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `post_type` varchar(255) NOT NULL,
  `lab` longtext NOT NULL,
  `val` longtext NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

INSERT INTO post_meta VALUES("1","16","page","use_template","10","0000-00-00");
INSERT INTO post_meta VALUES("2","15","page","use_template","10","0000-00-00");
INSERT INTO post_meta VALUES("3","18","page","use_template","10","0000-00-00");
INSERT INTO post_meta VALUES("4","19","page","use_template","10","0000-00-00");
INSERT INTO post_meta VALUES("5","20","page","use_template","10","0000-00-00");
INSERT INTO post_meta VALUES("6","0","page","use_template","none","0000-00-00");
INSERT INTO post_meta VALUES("7","21","page","use_template","none","0000-00-00");
INSERT INTO post_meta VALUES("8","22","page","use_template","10","0000-00-00");
INSERT INTO post_meta VALUES("9","24","page","use_template","10","0000-00-00");
INSERT INTO post_meta VALUES("10","25","page","use_template","10","0000-00-00");
INSERT INTO post_meta VALUES("11","8","page","use_template","10","0000-00-00");
INSERT INTO post_meta VALUES("12","26","page","use_template","10","0000-00-00");
INSERT INTO post_meta VALUES("13","27","page","use_template","10","0000-00-00");
INSERT INTO post_meta VALUES("14","28","page","use_template","10","0000-00-00");
INSERT INTO post_meta VALUES("15","29","page","use_template","10","0000-00-00");
INSERT INTO post_meta VALUES("16","31","page","use_template","10","0000-00-00");



DROP TABLE IF EXISTS settings;

CREATE TABLE `settings` (
  `setting_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setting_name` varchar(255) NOT NULL,
  `setting_value` longtext NOT NULL,
  PRIMARY KEY (`setting_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO settings VALUES("1","text_home","[dzspgb_section extra_classes=\"mcon-mainmenu\"][dzspgb_container use_template=\"none\"][dzspgb_row][dzspgb_row_part part=\"1.1\"][dzspgb_element text=\"<p>test 1000</p>23\" header_style=\"style_default\" type_element=\"header\"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row][/dzspgb_container][/dzspgb_section][dzspgb_section][dzspgb_container use_template=\"none\"][dzspgb_row][dzspgb_row_part part=\"1.1\"][dzspgb_element text=\"\" type_element=\"breakout_first\"][/dzspgb_element][dzspgb_element text=\"\" type_element=\"slider\"][dzspgb_item label=\"item\" imgsource=\"upload/unsplash_52c319226cefb_1.jpeg_1\"][/dzspgb_item][dzspgb_item label=\"item\" imgsource=\"upload/uploads-14117450256890cec7683-4575979c.jpeg\"][/dzspgb_item][/dzspgb_element][dzspgb_element text=\"\" type_element=\"breakout_final\"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row][/dzspgb_container][/dzspgb_section][dzspgb_section][dzspgb_container use_template=\"none\"][dzspgb_row][dzspgb_row_part part=\"1.4\"][dzspgb_element text=\"<p>col 1</p>\" type_element=\"text\"][/dzspgb_element][/dzspgb_row_part][dzspgb_row_part part=\"1.4\"][dzspgb_element text=\"<p>col 2</p>\" type_element=\"text\"][/dzspgb_element][/dzspgb_row_part][dzspgb_row_part part=\"1.4\"][dzspgb_element text=\"\" type_element=\"slider\"][dzspgb_item label=\"item\" imgsource=\"upload/fff_2.png\"][/dzspgb_item][dzspgb_item label=\"item\" imgsource=\"upload/unsplash_52c319226cefb_1.jpeg\"][/dzspgb_item][/dzspgb_element][/dzspgb_row_part][dzspgb_row_part part=\"1.4\"][/dzspgb_row_part][/dzspgb_row][/dzspgb_container][/dzspgb_section]");
INSERT INTO settings VALUES("2","pagebuilder_data_upload","[dzspgb_section][dzspgb_container use_template=\"none\"][dzspgb_row][dzspgb_row_part part=\"1.3\"][/dzspgb_row_part][dzspgb_row_part part=\"1.3\"][/dzspgb_row_part][dzspgb_row_part part=\"1.3\"][/dzspgb_row_part][/dzspgb_row][/dzspgb_container][/dzspgb_section]");
INSERT INTO settings VALUES("3","mainsettings","theme=theme-default&use_ajax=on&home_is_stream=on&use_parallaxer=off&use_parallaxer=on&autoplay_next=off&autoplay_next=on&paths_are_absolute=off&allow_register=off&allow_register=on&disable_commenting=off&page_homepage=28&footer_player_config=2&extra_css=ceva+fly2&color_waveformbg=%23585858&color_waveformprog=%23ef6b13&waveformgenerator_multiplier=1&logo=img%2Flogo.png&developer_paypal_sandbox_mode=off&developer_paypal_sandbox_mode=on&paypal_receiver_account=digitalzoomstudio%40gmail.com&pro_account_price=10&upload_limit_normal=20&upload_limit_pro=500&lang_1_text=English&lang_1_img=img%2Fusa.png&lang_1_code=en_EN&lang_2_text=Germany&lang_2_img=img%2Fgermany.png&lang_2_code=da_DK&lang_3_text=Spain&lang_3_img=img%2Fspain.png&lang_3_code=es_ES&api_google_recapcha_sitekey=6LeCTccSAAAAAEGn9SIXupyX3AGARbCvqJMQafAj&api_google_recapcha_secret=6LeCTccSAAAAALX54kazHcEqZOWvHpnoxCloblWv&api_facebook_app_id=269610766536363&api_facebook_app_secret=d9298aed49c11bba1bffd1fedea25723&debug_pagebuilder=off&debug_pagebuilder=on&use_ajax=on&home_is_stream=on&use_parallaxer=off&use_parallaxer=on&autoplay_next=off&autoplay_next=on&paths_are_absolute=off&allow_register=off&allow_register=on&disable_commenting=off&page_homepage=28&footer_player_config=2&extra_css=ceva+fly2&color_waveformbg=%23585858&color_waveformprog=%23ef6b13&waveformgenerator_multiplier=1&logo=img%2Flogo.png&developer_paypal_sandbox_mode=off&developer_paypal_sandbox_mode=on&paypal_receiver_account=digitalzoomstudio%40gmail.com&pro_account_price=10&upload_limit_normal=20&upload_limit_pro=500&lang_1_text=English&lang_1_img=img%2Fusa.png&lang_1_code=en_EN&lang_2_text=Germany&lang_2_img=img%2Fgermany.png&lang_2_code=da_DK&lang_3_text=Spain&lang_3_img=img%2Fspain.png&lang_3_code=es_ES&api_google_recapcha_sitekey=6LeCTccSAAAAAEGn9SIXupyX3AGARbCvqJMQafAj&api_google_recapcha_secret=6LeCTccSAAAAALX54kazHcEqZOWvHpnoxCloblWv&api_facebook_app_id=269610766536363&api_facebook_app_secret=d9298aed49c11bba1bffd1fedea25723&debug_pagebuilder=off");



DROP TABLE IF EXISTS tracks;

CREATE TABLE `tracks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` longtext NOT NULL,
  `content` varchar(255) DEFAULT NULL,
  `author_id` int(10) DEFAULT NULL,
  `published_date` date DEFAULT NULL,
  `description` longtext NOT NULL,
  `waveform_bg` varchar(255) NOT NULL,
  `waveform_prog` varchar(255) NOT NULL,
  `backup_ogg` varchar(255) NOT NULL,
  `thumbnail` varchar(1024) NOT NULL,
  `tags` varchar(255) NOT NULL,
  `is_buyable` varchar(20) NOT NULL,
  `price` varchar(255) NOT NULL,
  `sample_time_start` int(255) NOT NULL,
  `sample_time_end` int(255) NOT NULL,
  `sample_time_total` int(255) NOT NULL,
  `cover_image` varchar(1024) NOT NULL,
  `filesize` int(255) NOT NULL COMMENT 'the size in mb',
  `download_link` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

INSERT INTO tracks VALUES("17","A Beautiful Day","upload/itsabeautifulday_16.mp3","14","2015-11-10","","http://localhost/soundportal/source/waves/scrubbg_itsabeautifulday_16mp3.png","http://localhost/soundportal/source/waves/scrubprog_itsabeautifulday_16mp3.png","","http://i.imgur.com/qXMHwE0.jpg","cheering, album, timmcmorris","on","50","0","0","0","","3000000","");
INSERT INTO tracks VALUES("18","Total Overdrive","upload/soundroll_1.mp3","20","2015-11-11","","http://localhost/soundportal/source/waves/scrubbg_soundroll_1mp3.png","http://localhost/soundportal/source/waves/scrubprog_soundroll_1mp3.png","","http://i.imgur.com/v1Md905.jpg","creative, banging, breaking","","","0","0","0","","3000000","");
INSERT INTO tracks VALUES("20","Colorful and Shiny Kit","upload/soundroll_2.mp3","20","2015-11-11","","http://localhost/soundportal/source/waves/scrubbg_soundroll_2mp3.png","http://localhost/soundportal/source/waves/scrubprog_soundroll_2mp3.png","","http://i.imgur.com/1JdDR2M.jpg","band,creative,bouncy","","","0","0","0","","3000000","");
INSERT INTO tracks VALUES("21","Give Our Dreams Their Wings To Fly","upload/timmcmorris_2.mp3","14","2015-11-14","","http://localhost/soundportal/source/waves/scrubbg_timmcmorris_2mp3.png","http://localhost/soundportal/source/waves/scrubprog_timmcmorris_2mp3.png","","upload/thumbs/timmcmorris_2_300.jpg","creative, care free, cheerful","","","0","0","0","","3000000","");
INSERT INTO tracks VALUES("22","Intro Sound","upload/adg3.mp3","21","2015-11-03","","http://localhost/soundportal/source/waves/scrubbg_adg3mp3.png","http://localhost/soundportal/source/waves/scrubprog_adg3mp3.png","","http://i.imgur.com/NYxgS4f.jpg","creative, intro,calm","","","0","0","0","","3000000","");
INSERT INTO tracks VALUES("23","On Top Of The World","upload/timmcmorris_3.mp3","14","2015-11-14","","http://localhost/soundportal/source/waves/scrubbg_timmcmorris_3mp3.png","http://localhost/soundportal/source/waves/scrubprog_timmcmorris_3mp3.png","","upload/thumbs/timmcmorris_3_300.jpg","advertise, creative, nice","","","0","0","0","","3000000","");
INSERT INTO tracks VALUES("24","A Great New World ","upload/steph3.mp3","5","2015-11-15","","http://localhost/soundportal/source/waves/scrubbg_steph3mp3.png","http://localhost/soundportal/source/waves/scrubprog_steph3mp3.png","","upload/thumbs/vag_1_300.jpg","creative, clasical, cheering","on","33","0","0","0","upload/cover/vag_1_900.jpg","3000000","test");
INSERT INTO tracks VALUES("25","Green Things","upload/steph4.mp3","5","2015-11-15","","http://localhost/soundportal/source/waves/scrubbg_steph4mp3.png","http://localhost/soundportal/source/waves/scrubprog_steph4mp3.png","","http://i.imgur.com/65GUP58.jpg","green, happy, world","","","0","0","0","upload/cover/vag_2_900.jpg","3000000","");



DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` longtext NOT NULL,
  `date` date DEFAULT NULL,
  `avatar` longtext NOT NULL,
  `capabilities` longtext NOT NULL,
  `purchases` longtext NOT NULL,
  `connections` longtext NOT NULL,
  `ip_registered_from` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `second_avatar` longtext NOT NULL,
  `description` longtext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

INSERT INTO users VALUES("4","Radul Match","radu.hulubas@yahoo.com","098f6bcd4621d373cade4e832627b4f6","2015-09-25","upload/avatar/radul_avatar_150.jpg","a:1:{i:0;s:5:\"admin\";}","","a:3:{i:5;s:8:\"messaged\";i:8;s:8:\"messaged\";i:20;s:8:\"followed\";}","","","admin","","");
INSERT INTO users VALUES("5","Mark Peterson","vezaigrija@gmail.com","098f6bcd4621d373cade4e832627b4f6","2015-10-05","upload/avatar/vag_avatar_150.jpg","a:2:{i:0;s:5:\"admin\";i:1;s:10:\"proaccount\";}","","a:3:{i:4;s:8:\"messaged\";i:8;s:8:\"messaged\";i:14;s:8:\"followed\";}","","","","","");
INSERT INTO users VALUES("13","b345","b345@gmail.com","098f6bcd4621d373cade4e832627b4f6","2015-11-02","","","","","","","","");
INSERT INTO users VALUES("14","Tim Mcmorris","test2344@gmail.com","098f6bcd4621d373cade4e832627b4f6","2015-11-02","upload/avatar/tm_avatar_150.jpg","","","","","","","","");
INSERT INTO users VALUES("20","soundroll","soundroll@gmail.com","098f6bcd4621d373cade4e832627b4f6","2015-11-11","upload/avatar/soundroll_avatar_150.jpg","","","","","","","","");
INSERT INTO users VALUES("21","ADG3","adg3@gmail.com","098f6bcd4621d373cade4e832627b4f6","2015-11-14","upload/avatar/adg3_avatar_150.jpg","","","","","","","","");
INSERT INTO users VALUES("22","","","4a094e453e6ee6a8253def63db4d1509","2016-02-28","https://scontent.xx.fbcdn.net/hprofile-frc3/v/t1.0-1/c7.0.50.50/p50x50/943263_10201066528334905_261999877_n.jpg?oh=9da59eb73712ee499162c7a96ea2bbf2&amp;oe=575E3CA6","","","","","","","","");



DROP TABLE IF EXISTS views;

CREATE TABLE `views` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_user` int(10) unsigned NOT NULL,
  `ip` varchar(255) NOT NULL,
  `track_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=latin1;

INSERT INTO views VALUES("1","4","::1","14");
INSERT INTO views VALUES("2","0","::1","14");
INSERT INTO views VALUES("3","0","::1","14");
INSERT INTO views VALUES("4","0","192.168.0.102","14");
INSERT INTO views VALUES("5","4","::1","15");
INSERT INTO views VALUES("6","0","::1","14");
INSERT INTO views VALUES("7","0","::1","15");
INSERT INTO views VALUES("8","14","::1","16");
INSERT INTO views VALUES("9","14","::1","17");
INSERT INTO views VALUES("10","0","::1","17");
INSERT INTO views VALUES("11","4","::1","17");
INSERT INTO views VALUES("12","0","::1","17");
INSERT INTO views VALUES("13","0","::1","17");
INSERT INTO views VALUES("14","20","::1","18");
INSERT INTO views VALUES("15","4","::1","18");
INSERT INTO views VALUES("16","0","::1","20");
INSERT INTO views VALUES("17","4","::1","20");
INSERT INTO views VALUES("18","0","::1","18");
INSERT INTO views VALUES("19","0","::1","22");
INSERT INTO views VALUES("20","0","::1","17");
INSERT INTO views VALUES("21","0","::1","20");
INSERT INTO views VALUES("22","0","::1","21");
INSERT INTO views VALUES("23","21","::1","21");
INSERT INTO views VALUES("24","0","::1","23");
INSERT INTO views VALUES("25","0","::1","21");
INSERT INTO views VALUES("26","0","::1","22");
INSERT INTO views VALUES("27","5","::1","24");
INSERT INTO views VALUES("28","0","::1","24");
INSERT INTO views VALUES("29","0","::1","23");
INSERT INTO views VALUES("30","0","::1","18");
INSERT INTO views VALUES("31","0","::1","20");
INSERT INTO views VALUES("32","0","::1","17");
INSERT INTO views VALUES("33","5","::1","25");
INSERT INTO views VALUES("34","5","::1","21");
INSERT INTO views VALUES("35","5","::1","23");
INSERT INTO views VALUES("36","5","::1","20");
INSERT INTO views VALUES("37","5","::1","18");
INSERT INTO views VALUES("38","0","::1","17");
INSERT INTO views VALUES("39","0","::1","22");
INSERT INTO views VALUES("40","0","::1","24");
INSERT INTO views VALUES("41","0","::1","25");
INSERT INTO views VALUES("42","0","::1","21");
INSERT INTO views VALUES("43","5","::1","22");
INSERT INTO views VALUES("44","5","::1","28");
INSERT INTO views VALUES("45","5","::1","27");
INSERT INTO views VALUES("46","5","::1","26");
INSERT INTO views VALUES("47","0","192.168.0.102","24");
INSERT INTO views VALUES("48","0","192.168.0.102","25");
INSERT INTO views VALUES("49","0","192.168.0.102","21");
INSERT INTO views VALUES("50","0","192.168.0.102","26");
INSERT INTO views VALUES("51","0","192.168.0.100","27");
INSERT INTO views VALUES("52","0","192.168.0.100","24");
INSERT INTO views VALUES("53","0","192.168.0.100","25");
INSERT INTO views VALUES("54","0","192.168.0.100","21");
INSERT INTO views VALUES("55","0","192.168.0.100","17");
INSERT INTO views VALUES("56","0","192.168.0.100","23");
INSERT INTO views VALUES("57","0","192.168.0.100","26");
INSERT INTO views VALUES("58","0","::1","24");
INSERT INTO views VALUES("59","0","192.168.0.100","22");
INSERT INTO views VALUES("60","0","::1","25");
INSERT INTO views VALUES("61","0","::1","0");
INSERT INTO views VALUES("62","0","::1","25");
INSERT INTO views VALUES("63","0","::1","0");
INSERT INTO views VALUES("64","0","::1","25");
INSERT INTO views VALUES("65","0","::1","0");
INSERT INTO views VALUES("66","0","::1","0");
INSERT INTO views VALUES("67","0","::1","25");
INSERT INTO views VALUES("68","0","::1","21");
INSERT INTO views VALUES("69","0","192.168.0.102","26");
INSERT INTO views VALUES("70","0","192.168.0.102","27");
INSERT INTO views VALUES("71","0","192.168.0.102","24");
INSERT INTO views VALUES("72","0","::1","24");
INSERT INTO views VALUES("73","0","::1","0");




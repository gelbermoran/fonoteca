function twoDigits(d) {
    if (0 <= d && d < 10) return "0" + d.toString();
    if (-10 < d && d < 0) return "-0" + (-1 * d).toString();
    return d.toString();
}


Date.prototype.toMysqlFormat = function() {
    return this.getUTCFullYear() + "-" + twoDigits(1 + this.getUTCMonth()) + "-" + twoDigits(this.getUTCDate()) + " " + twoDigits(this.getUTCHours()) + ":" + twoDigits(this.getUTCMinutes()) + ":" + twoDigits(this.getUTCSeconds());
};


window.first_meta_change = true;
window.admin_page_just_loaded = true;



function get_query_arg_sp(purl, key) {
    //console.info(purl);
    if (purl.indexOf(key + '=') > -1) {
        //faconsole.log('testtt');
        var regexS = "[?&]" + key + "(.+?)(?=&|$)";
        var regex = new RegExp(regexS);
        var regtest = regex.exec(purl);


        //console.info(regex, regtest);
        if (regtest != null) {
            //var splitterS = regtest;


            if (regtest[1]) {
                var aux = regtest[1].replace(/=/g, '');
                return aux;
            } else {
                return '';
            }


        }
        //$('.zoombox').eq
    }
}


jQuery(document).ready(function($) {

    var _feedbacker = $('.feedbacker').eq(0);


    //console.info('ceva');









    if ($.fn.datepicker) {
        $(".datepicker-me-global").datepicker({
            dateFormat: "yy-mm-dd"
        });
    }



    $('textarea.tinymce-me-global').each(function() {
        //return false;
        var _t = $(this);
        if (_t.parent().parent().parent().parent().hasClass('element-type-selector-con')) {
            return;
        }

        if (_t.hasClass('tinymce-inited')) {

            _t.tinymce().destroy();
        }

        //console.info(_t);
        _t.tinymce({

            // Location of TinyMCE script
            script_url: 'tinymce/tinymce.min.js',

            // General options
            theme: "modern",
            plugins: "code"

            //,cleanup : false
            ,
            valid_elements: '*[*]'


        });

        _t.addClass('tinymce-inited');
    });





    $(document).delegate('.btn-add-page, .btn-save-post, .kill-prev-tinymce, .btn-export-db, .btn-import-sample, .btn-repair-database, .btn-reset-statistics, .btn-reset-permalinks, .btn-show-classic-editor, .btn-show-serialized-template-data', 'click', handle_mouse);
    $(document).delegate('.btn-add-template', 'click', handle_mouse);
    $(document).delegate('.btn-page-delete', 'click', handle_mouse);
    $(document).delegate('.btn-save-main-settings, .btn-save-user-roles', 'click', handle_mouse);
    $(document).delegate('.dzscheckbox.skin-nova', 'click', handle_mouse);
    $(document).delegate('.dzspgb-saver-field, .delete-menuitem-con, .extra-options-menuitem-con,.delete-table', 'click', handle_mouse);
    $(document).delegate('select[name=use_template], textarea[name="item_content"], input[name="extra_classes"], select[name="visibility_type"]', 'change', handle_input);


    $(document).on('change', '.style-update-holder .style-changer,.type-update-holder .type-changer, .ajax-link-changer', handle_input);


    $(document).delegate('form.import-data-form, form.edit-panel', 'submit', handle_input);
    //$(document).delegate('select[name=use_template]', 'change', handle_input);


    $(document).delegate('.template-meta-button--delete, .insert-pages-in-menu', 'click', handle_mouse);



        $(document).on('change', '.dzs-dependency-field, .main-media-file', handle_submit);

    $(document).undelegate('.btn-autogenerate-waveform-bg', 'click');
    $(document).undelegate('.btn-autogenerate-waveform-prog', 'click');
    $(document).delegate('.btn-autogenerate-waveform-bg', 'click', click_btn_autogenerate_waveform_bg);
    $(document).delegate('.btn-autogenerate-waveform-prog', 'click', click_btn_autogenerate_waveform_prog);

    _feedbacker.fadeOut('slow');

    //var now = new Date();

    //console.info(now, now.toMysqlFormat())








    if (dzsap_settings.page == 'pagebuilder') {
        load_pages();
    }


    //console.info(dzsap_settings.page);
    if (dzsap_settings.page == 'menus') {
        load_pages({
            'post_type': 'menu'
        });

        setTimeout(function() {
            $('textarea[name="item_content"]').trigger('change');
        }, 1000);
    }
    if (dzsap_settings.page == 'tracks') {
        load_pages({
            'post_type': 'tracks'
        });

        setTimeout(function() {
            $('textarea[name="item_content"]').trigger('change');
        }, 1000);
    }
    if (dzsap_settings.page == 'widget_stacks') {
        load_pages({
            'post_type': 'widget_stack'
        });

        setTimeout(function() {
            $('textarea[name="item_content"]').trigger('change');
        }, 1000);
    }
    if (dzsap_settings.page == 'vpconfigs') {
        load_pages({
            'post_type': 'vpconfig'
        });

        setTimeout(function() {
            $('textarea[name="item_content"]').trigger('change');
        }, 1000);
    }
    if (dzsap_settings.page == 'apconfigs') {
        load_pages({
            'post_type': 'apconfig'
        });

        setTimeout(function() {
            $('textarea[name="item_content"]').trigger('change');
        }, 1000);
    }
    if (dzsap_settings.page == 'posts') {
        load_pages({
            'post_type': 'post',
            'post_type_type': 'event'
        });

        setTimeout(function() {
            $('textarea[name="item_content"]').trigger('change');
        }, 1000);
    }
    if (dzsap_settings.page == 'blogs') {
        load_pages({
            'post_type': 'post',
            'post_type_type': 'post'
        });

        setTimeout(function() {
            $('textarea[name="item_content"]').trigger('change');
        }, 1000);
    }
    if (dzsap_settings.page == 'users') {
        load_pages({
            'post_type': 'user'
        });

        setTimeout(function() {
            $('textarea[name="item_content"]').trigger('change');
        }, 1000);
    }
    if (dzsap_settings.page == 'purchases') {
        load_pages({
            'post_type': 'purchase'
        });

        setTimeout(function() {
            $('textarea[name="item_content"]').trigger('change');
        }, 1000);
    }
    if (dzsap_settings.page == 'reports') {
        load_pages({
            'post_type': 'report'
        });

        setTimeout(function() {
            $('textarea[name="item_content"]').trigger('change');
        }, 1000);
    }

    if (dzsap_settings.page == 'templates') {
        load_templates();
    }


    setTimeout(function() {

        $('.style-changer,.type-changer').trigger('change');
        window.admin_page_just_loaded = false;
    }, 1500)


    function show_feedback(arg, pargs) {


        var margs = {
            extra_class: ''
        }


        if (pargs) {
            margs = $.extend(margs, pargs);
        }



        var theclass = 'feedbacker ' + margs.extra_class;

        if (margs.extra_class == '') {
            //console.info(arg.indexOf('success - '));
            if (arg.indexOf('success - ') == 0) {
                arg = arg.substr(10);
            }
            if (arg.indexOf('error - ') == 0) {
                arg = arg.substr(8);
                theclass = 'feedbacker is-error';
            }
        }

        _feedbacker.attr('class', theclass);

        _feedbacker.html(arg);
        _feedbacker.fadeIn('fast');


        setTimeout(function() {

            _feedbacker.fadeOut('slow');
        }, 2000);

    }


        $('.dzs-dependency-field').trigger('change');

    function handle_submit(e) {
        var _t = $(this);


        if (e.type == 'change') {
            if (_t.hasClass('dzs-dependency-field')) {
                console.info("ceva");
                check_dependency_settings();
            }
        }
    }

    function check_dependency_settings() {
        $('*[data-dependency]').each(function() {
            var _t = $(this);


            console.info(_t);
            var dep_arr = JSON.parse(_t.attr('data-dependency'));

            console.warn(dep_arr);

            if (dep_arr[0]) {
                var _c = $('*[name="' + dep_arr[0].element + '"]').eq(0);

                console.info(_c, dep_arr[0].element, dep_arr[0].value);

                var sw_show = false;

                for (var i3 in dep_arr[0].value) {
                    if (_c.val() == dep_arr[0].value[i3]) {
                        sw_show = true;
                        break;

                    }
                }

                if (sw_show) {
                    _t.show();
                } else {
                    _t.hide();
                }


            }
        })
    }

    function load_pages(pargs) {


        var margs = {

            post_type: ''
        };

        //console.warn("load_pages()", pargs);

        if (pargs) {
            margs = $.extend(margs, pargs);
        }

        $('.pages-table').addClass('nontransition');
        $('.pages-table').addClass('loading');

        setTimeout(function() {

            $('.pages-table').removeClass('nontransition');
        }, 70);

        var data = {
            action: 'ajax_select_pages_array'
        };

        var arg_page = 'pagebuilder';


        if (margs.post_type == 'menu' || $('.admin-wrap').eq(0).hasClass('admin-wrap-for-menus')) {
            data.action = 'ajax_select_pages_array';
            data.post_type = 'menu';
            arg_page = 'menus';
        }
        if (margs.post_type == 'track' || $('.admin-wrap').eq(0).hasClass('admin-wrap-for-tracks')) {
            data.action = 'ajax_select_pages_array';
            data.post_type = 'track';
            arg_page = 'tracks';

            //console.warn(get_query_arg, get_query_arg(window.location.href, 'withoutwaveform'), window.location.href);

            if (get_query_arg(window.location.href, 'withoutwaveform') == 'on') {

                data.tracks_withoutwaveform = 'on'

            }
        }
        if (margs.post_type == 'widget-stack' || $('.admin-wrap').eq(0).hasClass('admin-wrap-for-widget_stacks')) {
            data.action = 'ajax_select_pages_array';
            data.post_type = 'widget_stack';
            arg_page = 'widget_stacks';
        }

        if (margs.post_type == 'vpconfig' || $('.admin-wrap').eq(0).hasClass('admin-wrap-for-vpconfigs')) {
            data.action = 'ajax_select_pages_array';
            data.post_type = 'vpconfig';
            arg_page = 'vpconfigs';
        }

        if (margs.post_type == 'apconfig' || $('.admin-wrap').eq(0).hasClass('admin-wrap-for-apconfigs')) {
            data.action = 'ajax_select_pages_array';
            data.post_type = 'apconfig';
            arg_page = 'apconfigs';
        }
        if (margs.post_type == 'post' || $('.admin-wrap').eq(0).hasClass('admin-wrap-for-posts')) {
            data.action = 'ajax_select_pages_array';
            data.post_type = 'post';
            data.post_type_type = 'event';
            arg_page = 'posts';
        }
        if (margs.post_type == 'post' || $('.admin-wrap').eq(0).hasClass('admin-wrap-for-blogs')) {
            data.action = 'ajax_select_pages_array';
            data.post_type = 'post';
            data.post_type_type = 'post';
            arg_page = 'blogs';
        }
        if (margs.post_type == 'user' || $('.admin-wrap').eq(0).hasClass('admin-wrap-for-users')) {
            data.action = 'ajax_select_pages_array';
            data.post_type = 'user';
            margs.post_type=data.post_type;
            arg_page = 'users';
        }
        if (margs.post_type == 'purchase' || $('.admin-wrap').eq(0).hasClass('admin-wrap-for-purchases')) {
            data.action = 'ajax_select_pages_array';
            data.post_type = 'purchase';
            arg_page = 'purchases';
        }
        if (margs.post_type == 'report' || $('.admin-wrap').eq(0).hasClass('admin-wrap-for-reports')) {
            data.action = 'ajax_select_pages_array';
            data.post_type = 'report';
            arg_page = 'reports';
        }


        //console.warn('load_pages() - ', margs, data, $('.admin-wrap').eq(0).hasClass('admin-wrap-for-reports'));


        $.ajax({
            url: "admin.php",
            type: "POST",
            data: data

            ,
            complete: function(res) {
                //console.info(res);


                //console.info();


                var auxa = {};



                try{
                    auxa = JSON.parse(res.responseText);
                }catch(err){
                    console.log('cannot parse - ',res.responseText);
                }


                //console.groupCollapsed('auxa json');
                //console.log(auxa);


                //console.info(auxa);
                $('.pages-table tbody').eq(0).html('');
                for (var i = 0; i < auxa.length; i++) {

                    var title = auxa[i].title;
                    var author = 'admin';
                    var date = auxa[i].published_date;

                    if (margs.post_type == 'user') {
                        title = auxa[i].username + ' / ' + auxa[i].email;
                    }


                    var page_meta_buttons = '<div class="page-meta-buttons "><a class="btn-page-view" href="#">view</a> | <a href="admin.php?zoomit=1&page=' + arg_page + '&subpage=' + auxa[i].id + '">edit</a> | <a class="btn-page-delete" href="#">delete</a></div>';

                    if (margs.post_type == 'purchase') {
                        page_meta_buttons = '';

                        title = auxa[i].author_name;
                        author = auxa[i].username;
                        date = auxa[i].track_name;
                    }
                    if (margs.post_type == 'report') {

                        // console.info('auxa[i] - ',auxa[i]);
                        page_meta_buttons = '<div class="page-meta-buttons"><a href="'+dzsap_settings.thepath+'index.php?page=track&track_id='+auxa[i].track_id+'" target="_blank" class="">track link</a> | <a href="#" class="btn-page-delete">ignore</a> | <a class="btn-track-delete" href="#">remove track</a></div>';

                        title = auxa[i].report;
                        author = auxa[i].username;
                        date = auxa[i].date;
                    }

                    // console.info(data);




                    var auxstr = '<tr data-page-id="' + auxa[i].id + '" data-post_type="' + data.post_type + '" data-track_id="' + auxa[i].track_id + '"> <td class="user-name"><span class="the-title">' + title + '</span> ' + page_meta_buttons + ' </td> <td class="user-email">' + author + '</td> <td class="user-phone">' + date + '</td> ';



                    if (margs.post_type == 'purchase') {

                        auxstr += '<td class="user-phone">' + auxa[i].amount + '</td>';
                        auxstr += '<td class="user-phone">' + auxa[i].date + '</td>';
                    }

                    auxstr += '</tr>';
                    //console.log(title, auxstr, margs, auxa[i]);


                    $('.pages-table tbody').eq(0).append(auxstr);
                }


                //console.groupEnd();


                setTimeout(function() {

                    $('.pages-table').removeClass('loading');
                }, 300);


                if (window.dzsapp_action_admin_after_tracks_load) {

                    window.dzsapp_action_admin_after_tracks_load();
                }

            }
        });
    }



    function load_templates() {

        $('.templates-collection').addClass('nontransition');
        $('.templates-collection').addClass('loading');

        setTimeout(function() {

            $('.templates-collection').removeClass('nontransition');
        }, 70);

        $.ajax({
            url: "admin.php",
            type: "POST",
            data: {
                action: 'ajax_select_templates_array'
            }

            ,
            complete: function(res) {
                //console.info(res);


                //console.info();


                var auxa = JSON.parse(res.responseText);


                //console.info(auxa);
                $('.templates-collection').eq(0).html('');
                for (i = 0; i < auxa.length; i++) {

                    //var auxstr = '<tr data-page-id="'+auxa[i].id+'"> <td class="user-name">'+auxa[i].title+' <div class="page-meta-buttons"><a class="btn-page-view" href="#">view</a> | <a href="admin.php?zoomit=1&page=pagebuilder&subpage='+auxa[i].id+'">edit</a> | <a class="btn-page-delete" href="#">delete</a></div> </td> <td class="user-email">admin</td> <td class="user-phone">'+auxa[i].published_date+'</td> </tr>';

                    //

                    var auxstr = '<div class="dzspb_layb_one_fourth"><a class="template-con" href="admin.php?page=templates&subpage=' + auxa[i].id + '" data-id="' + auxa[i].id + '"><div class="template-bg"><i class="fa fa-cubes template-icon"></i></div><div class="template-meta"><span class="the-name">' + auxa[i].template_name + '</span><span class="template-meta-button template-meta-button--delete  dzstooltip-con js for-hover"><i class="fa fa-times"></i><span style="width: auto; white-space:nowrap;  " class="dzstooltip arrow-bottom align-left">delete template</span></span><div class="clear"></div></div></a></div>';

                    //console.log(auxstr);


                    $('.templates-collection').eq(0).append(auxstr);
                }

                setTimeout(function() {

                    $('.templates-collection').removeClass('loading');
                }, 300)

            }
        });
    }


    function save_page_content(pargs) {

        console.log('save_page_content', pargs, $('#pgbcontent').val());

        var margs = {

            'update_meta_too': false,
            'meta_page_id': '',
            'meta_lab': '',
            'meta_val': ''
        };

        if (pargs) {
            margs = $.extend(margs, pargs);
        }



        //console.log('continue here');
        $(".feedbacker").eq(0).html('Saving.. ');
        $(".feedbacker").fadeIn('fast');
        var data = {
            action: 'ajax_update_page_attr',
            id: dzspgb_settings.page_id,
            arglab: 'content',
            argval: $('#pgbcontent').val()
        };





        // -- update page content or menu content

        if ($('.admin-wrap').eq(0).hasClass('admin-wrap-for-menus')) {


            $('textarea[name=item_content]').each(function() {
                var _t2 = $(this);


                var aux_str = _t2.val();
                _t2.data('original-html', aux_str);

                aux_str = String(aux_str).replace(/"/g, '{replacequotquot}');

                _t2.val(aux_str);
                _t2.trigger('change');

            });

            $('input[name=only_for_registered]').each(function() {
                var _t2 = $(this);


                _t2.trigger('change');

            });



            //console.info(JSON.stringify($('.dd').eq(0).nestable('serialize')))

            data.argval = JSON.stringify($('.dd').eq(0).nestable('serialize'));

            //data.argval = String(data.argval).replace(/"/g, '{replacequotquot}');

            data.post_type = 'menu';


            console.warn(data);



        }

        if ($('.admin-wrap').eq(0).hasClass('admin-wrap-for-vpconfigs')) {

            data.argval = JSON.stringify($('.dd').eq(0).nestable('serialize'));

            data.post_type = 'vpconfig';

        }

        if ($('.admin-wrap').eq(0).hasClass('admin-wrap-for-apconfigs')) {

            data.argval = $('.apconfig-form').eq(0).serialize();

            data.post_type = 'apconfig';

        }


        //console.log(data);
        $.ajax({
            type: "POST",
            url: 'admin.php',
            data: data,
            success: function(response) {
                setTimeout(function() {

                    if (margs.update_meta_too == false) {

                        $(".feedbacker").fadeOut('fast');
                    }


                    $('textarea[name=item_content]').each(function() {
                        var _t2 = $(this);

                        _t2.val(_t2.data('original-html'));
                        _t2.trigger('change');
                    })



                }, 1000);
                show_feedback(response);

                if (margs.update_meta_too) {
                    var data2 = {
                        action: 'ajax_update_page_meta',
                        page_id: margs.meta_page_id,
                        arglab: margs.meta_lab,
                        argval: margs.meta_val
                    }

                    //console.log(data2);
                    $.ajax({
                        type: "POST",
                        url: 'admin.php',
                        data: data2,
                        success: function(response) {
                            setTimeout(function() {

                                $(".saveconfirmer").fadeOut('fast');
                                window.location.reload();



                            }, 1000);
                        }
                    });
                }
            }
        });


    }


    function handle_input(e) {
        var _t = $(this);
        var _con = null;

        if (!_t || typeof(_t) == 'undefined') {
            return false;
        }

        if (e.type == 'change') {
            // console.log(_t);

            if (_t.attr('name') && _t.attr('name').indexOf('use_template') > -1) {
                //console.log(_t);

                // -- the use_template select fires a change event at first, make sure it tdoes not save settings too..
                if (window.admin_page_just_loaded == false) {
                    save_page_content({
                        'update_meta_too': true,
                        'meta_page_id': dzspgb_settings.page_id,
                        'meta_lab': 'use_template',
                        'meta_val': _t.val()
                    });
                }

            }
            if (_t.hasClass('style-changer')) {
                //console.log(_t);

                var aux = _t.val();

                if (_t.parent().parent().parent().hasClass('style-update-holder')) {
                    _con = _t.parent().parent().parent();
                }

                if (_con) {
                    _con.removeClass('style-thumbs');


                    _con.addClass('style-' + aux);
                }


                // console.info(_t, aux);
            }
            if (_t.hasClass('type-changer')) {
                //console.log(_t);

                var aux = _t.val();

                if (_t.parent().parent().parent().hasClass('type-update-holder')) {
                    _con = _t.parent().parent().parent();
                }

                if (_con) {
                    _con.removeClass('type-mostviewed');


                    _con.addClass('type-' + aux);
                }


                // console.info(_t, aux);
            }
            if (_t.hasClass('ajax-link-changer')) {
                //console.log(_t);

                var auxval = _t.val();

                var data = {
                    page_label: auxval,
                    target_id: get_query_arg_sp(window.location.href, 'subpage'),
                    type: $('*[name="type"]').val(),
                };

                update_page_permalink(data);

                // console.info(_t, aux);
            }
            if (_t.attr('name') && _t.attr('name').indexOf('item_content') > -1) {
                //console.log(_t);

                var aux = _t.val();

                _t.parent().parent().attr('data-content', aux);
            }
            if (_t.attr('name') && _t.attr('name').indexOf('extra_classes') > -1) {

                var aux = _t.val();

                _t.parent().parent().attr('data-extra_classes', aux);
            }
            if (_t.attr('name') && _t.attr('name').indexOf('visibility_type') > -1) {

                var aux = _t.val();


                //console.info(_t);

                _t.parent().parent().parent().attr('data-visibility_type', aux);
            }
        }

        if (e.type == 'submit') {
            //console.log(_t);

            if (_t.hasClass('import-data-activity')) {


                var data = {
                    action: 'ajax_dzsapp_admin_import_data',
                    postdata: _t.serialize(),
                    source: _t.find('.field-source').eq(0).val()
                };
                if (_t.hasClass('import-data-activity')) {
                    data.label = 'activity';
                }




                $.ajax({
                    type: "POST",
                    url: dzsap_settings.settings_ajax_handler,
                    data: data,
                    success: function(response) {
                        if (typeof window.console != "undefined") {
                            console.log('Got this from the server: ' + response);
                        }

                        show_notice(response);


                    },
                    error: function(arg) {
                        if (typeof window.console != "undefined") {
                            console.log('Got this from the server: ' + arg, arg);
                        };

                    }
                });

                return false;
            }
            if (_t.hasClass('import-data-form')) {


                var data = {
                    action: 'ajax_dzsapp_admin_import_data',
                    postdata: _t.serialize(),
                    source: _t.find('.field-source').eq(0).val()
                };
                if (_t.attr('data-table')) {
                    data.label = _t.attr('data-table');


                    if (_t.attr('data-table') == '*') {
                        data.action = 'ajax_dzsapp_admin_import_db';
                    }

                }




                $.ajax({
                    type: "POST",
                    url: dzsap_settings.settings_ajax_handler,
                    data: data,
                    success: function(response) {
                        if (typeof window.console != "undefined") {
                            console.log('Got this from the server: ' + response);
                        }

                        show_notice(response);


                    },
                    error: function(arg) {
                        if (typeof window.console != "undefined") {
                            console.log('Got this from the server: ' + arg, arg);
                        };

                    }
                });

                return false;
            }


            if (_t.hasClass('edit-panel')) {



                var data = {
                    action: 'save_track_settings',
                    postdata: $(this).serialize()
                };


                $.ajax({
                    type: "POST",
                    url: dzsap_settings.settings_php_handler,
                    data: data,
                    success: function(response) {
                        if (typeof window.console != "undefined") {
                            console.log('Submit message Got this from the server: ' + response);
                        }


                        //console.info($('input[name=message]'));

                        show_notice(response);


                        //load_messages();
                        //load_messages_friends();

                        //_t.addClass('active');
                    },
                    error: function(arg) {
                        if (typeof window.console != "undefined") {
                            console.log('Got this from the server: ' + arg, arg);
                        };

                        show_notice(arg);
                    }
                });

                return false;

            }
        }
    }

    function show_notice(response) {

        if (response.indexOf('error -') == 0) {
            _feedbacker.addClass('is-error');
            _feedbacker.html(response.substr(7));
            _feedbacker.fadeIn('fast');

            setTimeout(function() {

                _feedbacker.fadeOut('slow');
            }, 1500)
        }
        if (response.indexOf('success -') == 0) {
            _feedbacker.removeClass('is-error');
            _feedbacker.html(response.substr(9));
            _feedbacker.fadeIn('fast');

            setTimeout(function() {

                _feedbacker.fadeOut('slow');
            }, 1500)
        }
    }

    function handle_mouse(e) {
        var _t = $(this);


        if (e.type == 'click') {
            if (_t.hasClass('btn-add-page')) {


                if ($('input[name="newpage_name"]').eq(0).val()) {


                    var now = new Date();

                    var data2 = {
                        action: 'ajax_create_page',
                        title: $('input[name="newpage_name"]').eq(0).val(),
                        date: now.toMysqlFormat()
                    };

                    if ($('.admin-wrap').eq(0).hasClass('admin-wrap-for-menus')) {
                        data2.post_type = 'menu';

                        //console.log('ceva');
                    }
                    if ($('.admin-wrap').eq(0).hasClass('admin-wrap-for-tracks')) {
                        data2.post_type = 'track';

                        //console.log('ceva');
                    }


                    if ($('.admin-wrap').eq(0).hasClass('admin-wrap-for-widget_stacks')) {
                        data2.post_type = 'widget_stack';

                        //console.log('ceva');
                    }
                    if ($('.admin-wrap').eq(0).hasClass('admin-wrap-for-apconfigs')) {
                        data2.post_type = 'apconfig';

                        //console.log('ceva');
                    }
                    if ($('.admin-wrap').eq(0).hasClass('admin-wrap-for-users')) {
                        data2.post_type = 'user';

                        //console.log('ceva');
                    }
                    if ($('.admin-wrap').eq(0).hasClass('admin-wrap-for-vpconfigs')) {
                        data2.post_type = 'vpconfig';

                        //console.log('ceva');
                    }
                    if ($('.admin-wrap').eq(0).hasClass('admin-wrap-for-posts')) {
                        data2.post_type = 'post';

                        data2.post_type_type = 'event';
                    }
                    if ($('.admin-wrap').eq(0).hasClass('admin-wrap-for-blogs')) {
                        data2.post_type = 'post';

                        data2.post_type_type = 'post';
                    }


                    $.ajax({
                        url: "admin.php",
                        type: "POST",
                        data: data2

                        ,
                        complete: function(res) {
                            //console.info(res);
                            show_feedback(res.responseText);

                            setTimeout(function() {
                                load_pages();

                                $('input[name="newpage_name"]').val('');
                            }, 100);
                        }
                    });

                } else {

                }


                return false;
            }
            if (_t.hasClass('btn-show-classic-editor')) {


                $('.dzspgb-form').hide();
                $('#pgbcontent').show();


                return false;
            }
            if (_t.hasClass('btn-show-serialized-template-data')) {



                $('.dzspgb-builder--wrap').get(0).api_remove_non_actives();

                $('.elements-area > .dzspgb-element-con textarea').each(function(){
                    var _t = $(this);
                    console.info(_t.val());

                    var orig_t_val = _t.val();

                    if(orig_t_val){

                        var aux = String(_t.val()).replace(/"/g, '{replacequotquot}');

                        _t.val(aux);

                        console.info(aux, '||| original - ' + orig_t_val+'.');

                        setTimeout(function(){
                            _t.val(orig_t_val);
                        },2000);
                    }



                });

                $('.dzspgb-saver-template').before('<textarea style="width: 100%" class="serialized-template-content" rows="20">'+$('.dzspgb-form').eq(0).serializeAnything()+'</textarea><br><br>');
                $('.dzspgb-saver-template').removeClass('dzspgb-saver-template').addClass('dzspgb-save-serialized');

                $('.dzspgb-form').hide();


                return false;
            }
            if (_t.hasClass('btn-add-template')) {


                if ($('input[name="newtemplate_name"]').eq(0).val()) {


                    var now = new Date();

                    $.ajax({
                        url: "admin.php",
                        type: "POST",
                        data: {
                            action: 'ajax_create_template',
                            title: $('input[name="newtemplate_name"]').eq(0).val(),
                            date: now.toMysqlFormat()
                        }

                        ,
                        complete: function(res) {
                            //console.info(res);
                            show_feedback(res.responseText);

                            setTimeout(function() {
                                load_templates();

                                $('input[name="newtemplate_name"]').val('');
                            }, 100);
                        }
                    });

                } else {

                }


                return false;
            }
            if (_t.hasClass('btn-import-sample')) {

                var r = confirm("are you sure you want to import demo ? all previous data will be erased")


                if (r) {
                    var data = {
                        action: 'ajax_import_sample_db',
                        dzsapp_import_data_nonce: $('input[name=dzsapp_import_data_nonce]').eq(0).val(),
                        sample_nr: 1
                    };
                    if (_t.hasClass('btn-import-sample-2')) {
                        data.sample_nr = 2;
                    }
                    if (_t.hasClass('btn-import-sample-3')) {
                        data.sample_nr = 3;
                    }

                    var now = new Date();

                    $.ajax({
                        url: "admin.php",
                        type: "POST",
                        data: data

                        ,
                        complete: function(res) {
                            //console.info(res);
                            show_feedback(res.responseText);

                        }
                    });

                }

                return false;
            }
            if (_t.hasClass('btn-repair-database')) {


                $.ajax({
                    url: "index.php",
                    type: "POST",
                    data: {
                        action: 'ajax_repair_database'
                    }

                    ,
                    complete: function(res) {
                        //console.info(res);
                        show_feedback(res.responseText);

                    }
                });



                return false;
            }
            if (_t.hasClass('btn-reset-statistics')) {


                $.ajax({
                    url: "index.php",
                    type: "POST",
                    data: {
                        action: 'ajax_reset_statistics'
                    }

                    ,
                    complete: function(res) {
                        //console.info(res);
                        show_feedback(res.responseText);

                    }
                });



                return false;
            }
            if (_t.hasClass('btn-reset-permalinks')) {


                $.ajax({
                    url: "index.php",
                    type: "POST",
                    data: {
                        action: 'ajax_reset_permalinks'
                    }

                    ,
                    complete: function(res) {
                        //console.info(res);
                        show_feedback(res.responseText);

                    }
                });



                return false;
            }
            if (_t.hasClass('btn-export-db')) {


                $.ajax({
                    url: "index.php?page=backupdb",
                    type: "POST",
                    data: {
                        action: 'ajax_backupdb'
                    }

                    ,
                    complete: function(res) {
                        //console.info(res);
                        show_feedback(res.responseText);

                    }
                });



                return false;
            }
            if (_t.hasClass('delete-menuitem-con')) {

                var r = confirm("Are you sure you want to delete item ?");


                if (r) {

                    _t.parent().remove();
                }


                return false;
            }
            if (_t.hasClass('kill-prev-tinymce')) {

                var r = confirm("Are you sure you want to kill tinymce ?");


                if (r) {

                    if (_t.parent().prev().prev().hasClass('mce-tinymce')) {
                        _t.parent().prev().tinymce().remove();
                        _t.parent().prev().addClass('destroyed-tinymce-intentionally');
                    }

                    //console.warn(_t.parent().next().attr('name').indexOf('kill_tinymce'));
                    if (_t.parent().next().attr('name').indexOf('kill_tinymce') > -1) {
                        _t.parent().next().val('on');
                        console.warn(_t.parent().next(), _t.parent().next().val())
                    }

                    console.warn(_t.parent().next(), _t.parent().next().val())




                }


                return false;
            }
            if (_t.hasClass('extra-options-menuitem-con')) {

                _t.parent().toggleClass("active-extra-options");


                return false;
            }
            if (_t.hasClass('btn-page-delete')) {


                //console.info(_t.parent().parent().parent());
                if (_t.parent().parent().parent().attr('data-page-id')) {
                    var theid = (_t.parent().parent().parent().attr('data-page-id'));





                    var data = {
                        action: 'ajax_delete_page',
                        id: theid,
                        table: 'pages'
                    };


                    if ((_t.parent().parent().parent().attr('data-post_type') == 'track')) {
                        data.table = 'tracks';
                    }

                    if ((_t.parent().parent().parent().attr('data-post_type') == 'post')) {
                        data.table = 'posts';
                    }
                    if ((_t.parent().parent().parent().attr('data-post_type') == 'user')) {
                        data.table = 'users';
                    }
                    if ((_t.parent().parent().parent().attr('data-post_type') == 'report')) {
                        data.table = 'activity';
                    }



                    $.ajax({
                        url: "admin.php",
                        type: "POST",
                        data: data

                        ,
                        complete: function(res) {
                            //console.info(res);

                            setTimeout(function() {
                                show_feedback(res.responseText);
                                load_pages();

                            }, 100);
                        }
                    });

                }


                return false;
            }
            if (_t.hasClass('btn-track-delete')) {


                //console.info(_t.parent().parent().parent());
                if (_t.parent().parent().parent().attr('data-track-id')) {
                    var theid = (_t.parent().parent().parent().attr('data-track-id'));





                    var data = {
                        action: 'ajax_delete_page',
                        id: theid,
                        table: 'pages'
                    };


                    if ((_t.parent().parent().parent().attr('data-post_type') == 'report')) {
                        data.table = 'tracks';
                    }

                    if ((_t.parent().parent().parent().attr('data-post_type') == 'post')) {
                        data.table = 'posts';
                    }
                    if ((_t.parent().parent().parent().attr('data-post_type') == 'user')) {
                        data.table = 'users';
                    }



                    $.ajax({
                        url: "admin.php",
                        type: "POST",
                        data: data

                        ,
                        complete: function(res) {
                            //console.info(res);

                            setTimeout(function() {
                                show_feedback(res.responseText);
                                load_pages();

                            }, 100);
                        }
                    });

                }


                return false;
            }
            if (_t.hasClass('btn-save-post')) {




                //console.info($('form.edit-panel-post--main-fields').eq(0).serialize())




                $.ajax({
                    url: "admin.php",
                    type: "POST",
                    data: {
                        action: 'ajax_update_post'
                        ,postdata: $('form.edit-panel-post--main-fields').eq(0).serialize()
                    }

                    ,
                    complete: function(res) {
                        //console.info(res);

                        setTimeout(function() {
                            show_feedback(res.responseText);



                            if (_t.hasClass('btn-save-post-for-user')) {

                                $.ajax({
                                    url: "admin.php",
                                    type: "POST",
                                    data: {
                                        action: 'ajax_update_user_meta_all',
                                        postdata: $('form.edit-panel-post--meta-fields').eq(0).serialize()
                                    }

                                    ,
                                    complete: function(res) {
                                        //console.info(res);

                                        setTimeout(function() {
                                            //show_feedback(res.responseText);

                                        }, 100);
                                    }
                                });
                            } else {
                                $.ajax({
                                    url: "admin.php",
                                    type: "POST",
                                    data: {
                                        action: 'ajax_update_post_meta_all',
                                        postdata: $('form.edit-panel-post--meta-fields').eq(0).serialize()
                                    }

                                    ,
                                    complete: function(res) {
                                        //console.info(res);

                                        setTimeout(function() {
                                            //show_feedback(res.responseText);

                                        }, 100);
                                    }
                                });
                            }




                        }, 100);
                    }
                });


                return false;
            }
            if (_t.hasClass('dzspgb-saver-field')) {


                save_page_content();

                return false;
            }


            if (_t.hasClass('template-meta-button--delete')) {


                if (_t.parent().parent().attr('data-id')) {
                    var theid = (_t.parent().parent().attr('data-id'));


                    $.ajax({
                        url: "admin.php",
                        type: "POST",
                        data: {
                            action: 'ajax_delete_template',
                            id: theid
                        }

                        ,
                        complete: function(res) {
                            //console.info(res);

                            setTimeout(function() {
                                show_feedback(res.responseText);
                                load_templates();

                            }, 100);
                        }
                    });

                }
                return false;
            }


            if (_t.hasClass('delete-table')) {


                var theid = _t.attr('data-table');


                var data = {
                    action: 'ajax_delete_from_table',
                    table: theid
                };


                $.ajax({
                    url: "admin.php",
                    type: "POST",
                    data: data

                    ,
                    complete: function(res) {
                        //console.info(res);

                        setTimeout(function() {
                            show_feedback(res.responseText);

                        }, 50);
                    }
                });


                return false;
            }

            if (_t.hasClass('dzscheckbox')) {


                //console.info(_t, _t.find('input').eq(0).prop('checked'));

                if (_t.find('input').eq(0).prop('checked') == false) {
                    _t.find('input').eq(0).prop('checked', true);
                } else {
                    _t.find('input').eq(0).prop('checked', false);
                }

                _t.find('input').eq(0).trigger('change');

                return false;
            }


            if (_t.hasClass('btn-save-main-settings')) {


                //console.info(_t.parent().parent().parent());
                console.info('ceva', $('.settings-form').serialize());

                $.ajax({
                    url: "admin.php",
                    type: "POST",
                    data: {
                        action: 'ajax_save_mainsettings',
                        postdata: $('.settings-form').serialize()
                    }

                    ,
                    complete: function(res) {
                        console.info(res.responseText);

                        setTimeout(function() {
                            show_feedback(res.responseText);
                            //load_pages();

                        }, 100);
                    }
                });


                return false;
            }


            if (_t.hasClass('btn-save-user-roles')) {


                //console.info(_t.parent().parent().parent());
                console.info('ceva', $('.settings-form').serialize());


                $.ajax({
                    url: "admin.php",
                    type: "POST",
                    data: {
                        action: 'ajax_save_user_roles',
                        postdata: $('.settings-form').serialize()
                    }

                    ,
                    complete: function(res) {
                        console.info(res.responseText);

                        setTimeout(function() {
                            show_feedback(res.responseText);
                            //load_pages();

                        }, 100);
                    }
                });


                return false;
            }
            if (_t.hasClass('insert-pages-in-menu')) {


                //console.info(_t.parent().parent().parent());
                //console.info('ceva', $('.admin-menu-pages').find('input:checked'));

                var aux23 = '';

                $('.admin-menu-pages').find('input:checked').each(function() {
                    var _t2 = $(this);


                    var str_extra_html = '<h4>Content</h4><textarea name="item_content"></textarea><h4>Extra Classes</h4><input name="extra_classes" type="text"/>';


                    //console.info(_t2);

                    if (_t2.attr('data-type') == 'menupage') {
                        str_extra_html = '<h4>Replace Label</h4><textarea rows="1" name="item_content"></textarea><h4>Extra Classes</h4><input name="extra_classes" type="text"/>';
                    }


                    aux23 += '<li class="dd-item dd3-item';


                    if (_t2.attr('data-type') == 'customhtml') {
                        aux23 += ' active-extra-options';
                    }


                    aux23 += '" data-id="' + _t2.attr('data-id') + '" data-label="' + _t2.attr('data-label') + '" data-type="' + _t2.attr('data-type') + '" data-content="' + _t2.attr('data-content') + '"><div class="dd-handle dd3-handle">Drag</div><div class="dd3-content">' + _t2.parent().children('span').html() + '</div><div class="extra-html">' + str_extra_html + '</div><div class="delete-menuitem-con btn-menuitem-con"><i class="fa fa-times"></i></div><div class="extra-options-menuitem-con btn-menuitem-con"><i class="fa fa-plug"></i></div></li>';

                    _t2.prop('checked', false);

                });

                $('.dd-list').eq(0).append(aux23);


                var list = $('.dd').eq(0);
                //console.log(list);

                //console.log(list.nestable('serialize'), JSON.stringify(list.nestable('serialize')));
                //console.log(window.JSON.stringify(list.data('output')));


                return false;
            }
        }

    }





    function click_btn_autogenerate_waveform_bg(e) {
        var _t = $(this);
        var _themedia = '';


        if ($('.id-upload-mp3').length > 0) {
            _themedia = $('.id-upload-mp3').eq(0).val();
        }
        if ($('.source-for-autogenerate').length > 0) {
            _themedia = $('.source-for-autogenerate').eq(0).val();
        }




        if (typeof dzsap_settings != 'undefined') {

            //console.info(_themedia);

            var s_filename_arr = _themedia.split('/');

            //console.info(s_filename_arr);
            var s_filename = s_filename_arr[s_filename_arr.length - 1];

            s_filename = encodeURIComponent(s_filename);
            s_filename = s_filename.replace('.', '');
            s_filename = s_filename.replace(/ /g, '');



            window.waves_filename = '{{dirname}}waves/scrubbg_' + s_filename + '.png';
            ///console.info(s_filename);

            var aux = '<object type="application/x-shockwave-flash" data="' + dzsap_settings.thepath + 'wavegenerator.swf" width="230" height="30" id="flashcontent" style="visibility: visible;"><param name="movie" value="' + dzsap_settings.thepath + 'wavegenerator.swf"><param name="menu" value="false"><param name="allowScriptAccess" value="always"><param name="scale" value="noscale"><param name="allowFullScreen" value="true"><param name="wmode" value="opaque"><param name="flashvars" value="settings_multiplier=' + dzsap_settings.waveformgenerator_multiplier + '&media=' + _themedia + '&savetophp_loc=' + dzsap_settings.thepath + 'savepng.php&savetophp_pngloc=' + window.waves_filename + '&savetophp_pngprogloc=waves/scrubprog.png&color_wavesbg=' + dzsap_settings.color_waveformbg + '&color_wavesprog=' + dzsap_settings.color_waveformprog + '&settings_wavestyle=' + dzsap_settings.settings_wavestyle + '&settings_onlyautowavebg=on&settings_enablejscallback=on';

            if (dzsap_settings.waves_generation == 'auto') {
                aux += '&settings_autogenerate_bg=on';
                //aux+='&settings_autogenerate_prog=on';
            }

            aux += '"></object>';



            _t.parent().append(aux);



            //console.info(_t.parent().parent(), _t.parent().parent().find('.waves-field-target'));


            if (_t.parent().parent().find('.waves-field-target').length > 0) {
                window.waves_fieldtaget = _t.parent().parent().find('.waves-field-target').eq(0);

                //console.error(window.waves_fieldtaget);
            }

            _t.hide();
        }


        return false;
    }


    function click_btn_autogenerate_waveform_prog(e) {
        var _t = $(this);
        var _themedia = '';
        if ($('.id-upload-mp3').length > 0) {
            _themedia = $('.id-upload-mp3').eq(0).val();
        }
        if ($('.source-for-autogenerate').length > 0) {
            _themedia = $('.source-for-autogenerate').eq(0).val();
        }

        if (typeof dzsap_settings != 'undefined') {

            //console.info(_themedia);

            var s_filename_arr = _themedia.split('/');

            //console.info(s_filename_arr);
            var s_filename = s_filename_arr[s_filename_arr.length - 1];

            s_filename = encodeURIComponent(s_filename);
            s_filename = s_filename.replace('.', '');



            window.waves_filename = '{{dirname}}waves/scrubprog_' + s_filename + '.png';
            ///console.info(s_filename);

            var aux = '<object type="application/x-shockwave-flash" data="' + dzsap_settings.thepath + 'wavegenerator.swf" width="230" height="30" id="flashcontent" style="visibility: visible;"><param name="movie" value="' + dzsap_settings.thepath + 'wavegenerator.swf"><param name="menu" value="false"><param name="allowScriptAccess" value="always"><param name="scale" value="noscale"><param name="allowFullScreen" value="true"><param name="wmode" value="opaque"><param name="flashvars" value="settings_multiplier=' + dzsap_settings.waveformgenerator_multiplier + '&media=' + _themedia + '&savetophp_loc=' + dzsap_settings.thepath + 'savepng.php&savetophp_pngloc=' + window.waves_filename + '&savetophp_pngprogloc=' + window.waves_filename + '&color_wavesbg=' + dzsap_settings.color_waveformprog + '&color_wavesprog=' + dzsap_settings.color_waveformprog + '&settings_wavestyle=' + dzsap_settings.settings_wavestyle + '&settings_onlyautowaveprog=on&settings_enablejscallback=on';



            if (dzsap_settings.waves_generation == 'auto') {
                aux += '&settings_autogenerate_prog=on';
            }


            aux += '"></object>';

            _t.parent().append(aux);




            if (_t.parent().find('.waves-field-target').length > 0) {
                window.waves_fieldtaget = _t.parent().find('.waves-field-target').eq(0);
            } else {

                if (_t.parent().parent().find('.waves-field-target').length > 0) {
                    window.waves_fieldtaget = _t.parent().parent().find('.waves-field-target').eq(0);

                    //console.error(window.waves_fieldtaget);
                }
            }




            _t.hide();
        }


        return false;
    }

});


function update_page_permalink(pargs) {


    var margs = {

        'page_label': '',
        'target_id': '',
        'type': ''
    };

    if (pargs) {
        margs = $.extend(margs, pargs);
    }




    var data = {
        action: 'dzsapp_update_page_permalink',
        page_label: margs.page_label,
        target_id: margs.target_id,
        type: margs.type
    }

    //console.log(data);
    $.ajax({
        type: "POST",
        url: 'admin.php',
        data: data,
        success: function(response) {



            $('.ajax-link-changer').val(response);
            $('.ajax-permalink-preloader').fadeOut("slow");




        }
    });


}





window.waves_fieldtaget = null;
window.waves_filename = null;


window.api_wavesentfromflash = function(arg) {
    console.info('api_wavesentfromflash() - ', arg, window.waves_filename);


    //console.warn(window.waves_fieldtaget);
    if (window.waves_fieldtaget) {
        window.waves_filename = window.waves_filename.replace('{{dirname}}', dzsap_settings.thepath);
        window.waves_fieldtaget.val(window.waves_filename);
        window.waves_fieldtaget.trigger('change');


        if (window.waves_fieldtaget.next().hasClass('aux-wave-generator')) {

            window.waves_fieldtaget.next().find('button').show();
            window.waves_fieldtaget.next().find('object').remove();
        } else {

            window.waves_fieldtaget.next().next().find('button').show();
            window.waves_fieldtaget.next().next().find('object').remove();
        }


        //console.info(window.waves_fieldtaget.parent());
        if (window.waves_fieldtaget.parent().prev().hasClass('aux-wave-generator')) {

            window.waves_fieldtaget.parent().prev().find('a,button').show();
            window.waves_fieldtaget.parent().prev().find('object').remove();
        }
    }
    if (window.console) {
        console.info(arg);
    };

    //if(wave_prog_generated===false){
    //
    //    wave_prog_generated=true;
    //    $('.btn-autogenerate-waveform-prog').trigger('click');
    //}
};

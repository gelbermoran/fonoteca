<?php
if(!session_id()) {
    @ini_set('sql_mode','NO_ENGINE_SUBSTITUTION');
    @ini_set('session.save_path',dirname(__FILE__). '/tmp');
    session_start();
}

//echo 'ceva';

date_default_timezone_set('America/Los_Angeles');
ini_set("log_errors", 1);
ini_set('display_errors', '0');
error_reporting(E_ALL);
ini_set("error_log", "soundportal.log");


    if(isset($_GET['debug_display_errors']) && $_GET['debug_display_errors']=='on'){

        ini_set('display_errors', 1);
    }


include_once(dirname(__FILE__).'/dzs_functions.php');
include_once(dirname(__FILE__).'/class-portal.php');



//ini_set("display_startup_errors", 1);
//ini_set("display_errors", 1);

/* Reports for either E_ERROR | E_WARNING | E_NOTICE  | Any Error*/
//error_reporting(E_ERROR);

//    echo abc;


//


$lang = 'en_EN';
    $charset = 'utf-8';
if (isset($_GET['lang'])){
    $lang = $_GET['lang'];

    setcookie('dzsapp_lang',$lang, time()+3600);
}else{


    if(isset($_COOKIE['dzsapp_lang']) && $_COOKIE['dzsapp_lang']){

        $lang = $_COOKIE['dzsapp_lang'];
    }
}

    if($lang=='pt_PT'){
        $charset = 'iso-8859-1';
    }




putenv("LANG=$lang");
setlocale(LC_ALL, $lang);
if(function_exists("bindtextdomain")){
    bindtextdomain("wavecloud", "./locale/");
}

if(function_exists("textdomain")) {
    textdomain("wavecloud");
}

//    echo $lang;
$dzsap_portal = new DZSAP_Portal();

$meta_title = $dzsap_portal->main_settings['site_title'];
$meta_desc = '';
$meta_image = '';


dzsap_load_plugins();

$resp = ($dzsap_portal->get_api_call($_GET));

if(is_array($resp)){
    echo json_encode($resp);
}







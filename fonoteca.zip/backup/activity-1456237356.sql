1	2	add_user	a:1:{s:7:"id_user";i:2;}	2016-02-20
2	3	add_user	a:1:{s:7:"id_user";i:3;}	2016-02-20
3	4	add_user	a:1:{s:7:"id_user";i:4;}	2016-02-20

1	1	page	use_template	10	0000-00-00
3	1	post	location_name	Club Reisin	0000-00-00
4	1	post	time_hour	22:00 - 03:00	0000-00-00
5	1	post	location_lat	51.5243123	0000-00-00
6	1	post	location_long	-0.1653589	0000-00-00
7	1	post	thumbnail	upload/cover/cover0.jpg	0000-00-00
8	2	post	location_name	Square Hall	0000-00-00
9	2	post	location_lat	51.5343123	0000-00-00
10	2	post	thumbnail	upload/cover/cover1.jpg	0000-00-00
11	2	post	time_hour	15:00 - 18:00	0000-00-00
12	2	post	location_long	-0.1753589	0000-00-00
13	4	post	location_name	Pride Square	0000-00-00
14	4	post	location_lat	51.5043123	0000-00-00
15	4	post	thumbnail	upload/cover/cover2.jpg	0000-00-00
16	4	post	time_hour	20:00 - 24:00	0000-00-00
17	4	post	location_long	-0.1733589	0000-00-00
18	5	post	location_name	White Hall	0000-00-00
19	5	post	location_lat	51.5453123	0000-00-00
20	5	post	thumbnail	upload/cover/cover3.jpg	0000-00-00
21	5	post	time_hour	24:00 - 03:00	0000-00-00
22	5	post	location_long	-0.1783589	0000-00-00
23	7	post	location_name	Lux Club	0000-00-00
24	7	post	location_lat	51.5843123	0000-00-00
25	7	post	thumbnail	upload/cover/cover4.jpg	0000-00-00
26	7	post	time_hour	00:00 - 04:00	0000-00-00
27	7	post	location_long	-0.1733589	0000-00-00
28	8	post	location_name	Fratelli Club	0000-00-00
29	8	post	location_lat	51.5253123	0000-00-00
30	8	post	thumbnail	upload/cover/cover5.jpg	0000-00-00
31	8	post	time_hour	00:00 - 02:00	0000-00-00
32	8	post	location_long	-0.1813589	0000-00-00
33	5	page	use_template	10	0000-00-00
34	6	page	use_template	10	0000-00-00
35	7	page	use_template	10	0000-00-00
36	8	page	use_template	10	0000-00-00

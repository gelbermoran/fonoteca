1	Green Mood	upload/itsabeautifulday.mp3	1	2016-02-14		http://localhost/soundportal/source/waves/scrubbg_itsabeautifuldaymp3.png	http://localhost/soundportal/source/waves/scrubprog_itsabeautifuldaymp3.png			awesome,chill,beautiful	on	10	0	0	0	upload/cover/track1.jpg
2	Hollow Moon	upload/steph3.mp3	1	2016-02-16							on	30	0	0	0	upload/cover/track2.jpg
3	Sunshine Stairs	upload/steph4.mp3	1	2016-02-16							on	0	0	0	0	upload/cover/track3.jpg

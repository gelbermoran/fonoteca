<?php

/*
 * DZS Upload
 * version: 1.0
 * author: digitalzoomstudio
 * website: http://digitalzoomstudio.net
 *
 * Dual licensed under the MIT and GPL licenses:
 *   http://www.opensource.org/licenses/mit-license.php
 *   http://www.gnu.org/licenses/gpl.html
 */



ini_set("log_errors", 1);
ini_set('display_errors', '0');
error_reporting(E_ALL);
ini_set("error_log", "soundportal.log");
error_reporting(E_ALL);

$disallowed_filetypes = array('.php', '.exe', '.htaccess', '.asp', '.py', '.jsp', '.pl', '.phtml', '.ptxt');

if(function_exists('clean_mp3')==false){
    function clean_mp3($string){
        // Strip HTML Tags
        $string=preg_replace('/[^A-Za-z0-9 _\-\+\&]/','',$string);

        return $string;
    }
}

if (!function_exists('print_rr')) {


    function print_rr($arg, $pargs=array()){
        $margs = array(
            'echo'=>true,
        );

        if($pargs){
            $margs = array_merge($margs,$pargs);
        }


        $fout = '';
        if($margs['echo']==false){
            ob_start();
        }

        echo '<pre>';
        print_r($arg);
        echo '</pre>';


        if($margs['echo']==false){
            $fout = ob_get_clean();

            return $fout;
        }


    }


}



//
$allowed_filetypes = array('.jpg','.jpeg','.png','.gif','.tiff','.mp4','.m4v','.ogg','.ogv','.webm','.sql','.mp3','.wav','.m4a');
$upload_dir = dirname(__FILE__) . '/upload';

function get_theheaders() {
    //$headers = array();
    //print_r($_SERVER);
    return $_SERVER;
}

//print_r($_POST); print_r($HTTP_POST_FILES); print_r($_FILES);

if (isset($_FILES['file_field']['tmp_name'])) {
    $file_name = $_FILES['file_field']['name'];
    $file_name = str_replace(" ", "_", $file_name); // strip spaces
    $path = $upload_dir . "/" . $file_name;
    //print_r($HTTP_POST_FILES);
    //==== checking for disallowed file types
    $sw = true;


    foreach ($allowed_filetypes as $dft) {
//            print_r($dft);
        $pos = strpos(strtolower($file_name), $dft);


//            error_log($pos);
        if ($pos > strlen($file_name)-6) {
            $sw = false;
        }
    }

    if ($sw == true) {
        die('<div class="error">invalid extension - disallowed_filetypes</div><script>hideFeedbacksCall()</script>');
    }
    if (!is_writable($upload_dir)) {
        die('<div class="error">dir not writable - check permissions</div><script>hideFeedbacksCall()</script>');
    }




    if (copy($_FILES['file_field']['tmp_name'], $path)) {
        echo '<div class="success">file uploaded</div><script>top.hideFeedbacksCall();</script>';
    } else {
        echo '<div class="error">file could not be uploaded</div><script>window.hideFeedbacksCall()</script>';
    }
} else {
    $headers = get_theheaders();
//    print_r($_FILES);
    if (isset($headers['HTTP_X_FILE_NAME'])) {
        //print_r($headers);
        error_log('headers - '.print_rr($headers,array(
                'echo'=>false,
            ))) ;
        $file_name = $headers['HTTP_X_FILE_NAME'];
        $file_name = str_replace(" ", "_", $file_name); // strip spaces
        //                $target = $upload_dir . "/" . $file_name;
        $target = $file_name;


        //==== checking for disallowed file types
        $sw = true;

        foreach ($allowed_filetypes as $dft) {
//            print_r($dft);
            $pos = strpos(strtolower($file_name), $dft);


//            error_log($pos);
            if ($pos > strlen($file_name)-6) {
                $sw = false;
            }
        }



        if ($sw == true) {
            die('<div class="error">invalid extension - disallowed_filetypes</div>');
        }

        if (!is_writable($upload_dir)) {
            die('<div class="error">dir not writable - check permissions</div>');
        }


        $auxindex = 0;

        //                echo '$file_name - '.$file_name;
        //                $file_name = $this->seo_friendly_url($file_name);
        //                $file_name = $this->clean_mp3($file_name);
        $auxname = $file_name;
        $auxpath = $target;


        $arr_nams = explode('.',$file_name);

        $file_lab = '';
        $file_ext = '';

        for($i=0;$i<count($arr_nams);$i++){
            if($i<count($arr_nams)-1){

                $file_lab.=clean_mp3($arr_nams[$i]);
            }else{
                $file_ext = $arr_nams[$i];
            }
        }


        $target = $file_lab.'.'.$file_ext;
        //                error_log("target - ".$target);
        //                error_log('$file_name - '.$file_name);
        error_log('$upload_dir.$target - '.($upload_dir.'/'.$target));

        //                $path_dir = $this->path_base.'upload/';
        //                $path_dir = '';



        if(file_exists($upload_dir.'/'.$auxpath)){

            //            die('<div class="error">file already exists</div>');


            $breaker = 150;
            while(file_exists($upload_dir.'/'.$auxpath)===true){
                $auxindex++;

                $auxpath = $file_lab.'_'.$auxindex.'.'.$file_ext;
                $auxname = $file_lab.'_'.$auxindex.'.'.$file_ext;
                //                        error_log('$auxpath - '.$auxpath);
                //                        error_log('$auxname - '.$auxname);

                $breaker--;
                if($breaker<0){
                    break;
                }
            }
        }

        //                error_log("target semifinal - ".$target);
        $target = $auxpath;


//        print_r($_FILES);

        $filesize = $_FILES['myfile']['size'];
        //echo $target;
        if(move_uploaded_file($_FILES['myfile']['tmp_name'], $upload_dir.'/'.$target)){

        }else{

            die('<div class="error">error at file_put_contents</div>');
        }

        echo 'success - file written {{filename-'.$auxname.'}} {{filesize-'.$filesize.'}}';
    } else {
        die('not for direct access');
    }
}
// -- ZoomTimeline
// @version 0.90
// @this is not free software
// -- ZoomTimeline @copyright -- http://digitalzoomstudio.net


"use strict";

Object.size = function(obj) {
    var size = 0, key;
    for (key in obj) {
        if (obj.hasOwnProperty(key)) size++;
    }
    return size;
};
if(window.jQuery==undefined){
    alert("dzstabs.js -> jQuery is not defined or improperly declared ( must be included at the start of the head tag ), you need jQuery for this plugin");
}
jQuery.fn.outerHTML = function(e) {
    return e
        ? this.before(e).remove()
        : jQuery("<p>").append(this.eq(0).clone()).html();
};

window.dzsztm_self_options = {};

(function($) {


    $.fn.prependOnce = function(arg, argfind) {
        var _t = $(this) // It's your element


//        console.info(argfind);
        if(typeof(argfind) =='undefined'){
            var regex = new RegExp('class="(.*?)"');
            var auxarr = regex.exec(arg);


            if(typeof auxarr[1] !='undefined'){
                argfind = '.'+auxarr[1];
            }
        }


        // we compromise chaining for returning the success
        if(_t.children(argfind).length<1){
            _t.prepend(arg);
            return true;
        }else{
            return false;
        }
    };
    $.fn.appendOnce = function(arg, argfind) {
        var _t = $(this) // It's your element


        if(typeof(argfind) =='undefined'){
            var regex = new RegExp('class="(.*?)"');
            var auxarr = regex.exec(arg);


            if(typeof auxarr[1] !='undefined'){
                argfind = '.'+auxarr[1];
            }
        }
//        console.info(_t, _t.children(argfind).length, argfind);
        if(_t.children(argfind).length<1){
            _t.append(arg);
            return true;
        }else{
            return false;
        }
    };


    $.fn.zoomtimeline = function(o) {

        //==default options
        var defaults = {
            settings_slideshowTime : '5' //in seconds
            ,settings_enable_linking : 'off' // enable deeplinking on tabs
            , settings_contentHeight : '0'//set the fixed tab height
            , settings_scroll_to_start : 'off'//scroll to start when a tab menu is clicked
            , settings_startTab : 'default'// -- the start tab, default or a fixed number
            , design_skin : 'skin-default' // -- skin-default, skin-boxed, skin-melbourne or skin-blue
            , settings_mode : 'mode-default' // -- skin-default, skin-boxed, skin-melbourne or skin-blue
            , design_transition : 'default' // default, fade or slide
            , design_tabsposition : 'top' // -- set top, right, bottom or left
            , design_tabswidth : 'default' // -- set the tabs width for position left or right, if tabs position top or bottom and this is set to fullwidth, then the tabs will cover all the width
            , design_maxwidth : '4000'
            ,settings_makeFunctional: false
            ,settings_appendWholeContent: false // -- take the whole tab content and append it into the dzs tabs, this makes complex scripts like sliders still work inside of tabs
            ,toggle_breakpoint: '320' //  -- a number at which bellow the tabs will trasform to toggles
            ,toggle_type: 'accordion' // -- normally, the  toggles act like accordions, but they can act like traditional toggles if this is set to toggle
            ,refresh_tab_height: '0' // -- normally, the  toggles act like accordions, but they can act like traditional toggles if this is set to toggle
            ,outer_menu: null // -- normally, the  toggles act like accordions, but they can act like traditional toggles if this is set to toggle

        };

//        console.info(this, o);

        if(typeof o =='undefined'){
            if(typeof $(this).attr('data-options')!='undefined'  && $(this).attr('data-options')!=''){
                var aux = $(this).attr('data-options');
                aux = 'window.dzsztm_self_options = ' + aux;
                eval(aux);
                o = $.extend({}, window.dzsztm_self_options);
                window.dzsztm_self_options = $.extend({},{});
            }
        }
        o = $.extend(defaults, o);
        this.each( function(){
            var cthis = $(this)
                , cclass = ''
                ,cid = ''
                ;
            var nrChildren ;
            var currNr=-1
                ,currNrEx=-1
                ;
            var mem_children = [];
            var _tabsMenu
                ,_tabsContent
                ,items
                ,_c
                ,_carg
                ;
            var i=0;
            var ww
                ,wh
                ,tw
                ,targeth
                ,padding_content = 20
                ;
            var busy_transition=false;
            var handled = false; //describes if all loaded function has been called

            var preloading_nrtotalimages = 0
                ,preloading_nrtotalimagesloaded = 0
                ;

            var animation_slide_vars = {
                'duration' : 300
                ,'queue' : false
            }


            if(isNaN(Number(o.settings_startTab))==false){
                o.settings_startTab = parseInt(o.settings_startTab, 10);
            }

            if(can_history_api()==false){
                o.settings_enable_linking = 'off';
            }

            o.toggle_breakpoint = parseInt(o.toggle_breakpoint, 10);

            init();
            function init(){

                if(handled==true || cthis.hasClass('dzsztm-loaded')){
                    reinit();
                    return;
                }

                if(typeof(cthis.attr('class')) == 'string'){
                    cclass = cthis.attr('class');
                }else{
                    cclass=cthis.get(0).className;
                }




                cid = cthis.attr('id');
                if(typeof cid=='undefined' || cid==''){
                    var auxnr = 0;
                    var temps = 'dzs-tabs'+auxnr;

                    while($('#'+temps).length>0){
                        auxnr++;
                        temps = 'dzs-tabs'+auxnr;
                    }

                    cid = temps;
                    cthis.attr('id', cid);
                }



                if(cclass.indexOf('skin-')==-1){
                    cthis.addClass(o.design_skin);
                }

                if(cthis.hasClass('skin-default')){
                    o.design_skin = 'skin-default';
                }

                if(cclass.indexOf('mode-')==-1){
                    cthis.addClass(o.settings_mode);
                }

                if(cthis.hasClass('mode-default')){
                    o.settings_mode = 'mode-default';
                }
                if(cthis.hasClass('mode-oncenter')){
                    o.settings_mode = 'mode-oncenter';
                }


                if(o.design_transition=='default'){
                    o.design_transition='fade';
                }

                if(o.design_tabswidth=='default'){
                    if(o.design_tabsposition=='left' || o.design_tabsposition=='right'){
                        o.design_tabswidth = 'auto';
                    }else{
                        o.design_tabswidth = 'auto';
                    }

                }



                cthis.addClass('transition-'+ o.design_transition);
                cthis.addClass('tabs-'+ o.design_tabsposition);

//                cthis.addClass('toggle_type-'+ o.toggle_type);
                if(o.design_tabsposition=='bottom'){
                    cthis.appendOnce('<div class="tabs-content"></div>');
                    cthis.appendOnce('<div class="tabs-menu"></div>');
                }else{
                    cthis.appendOnce('<div class="tabs-menu"></div>');
                    cthis.appendOnce('<div class="tabs-content"></div>');

                }



                _tabsMenu = cthis.children('.tabs-menu').eq(0);
                _tabsContent = cthis.children('.tabs-content').eq(0);

                if(o.design_tabsposition=='none'){
                    _tabsMenu.hide();
                }

                if(o.outer_menu){
                    _tabsMenu = o.outer_menu;

                    _tabsMenu = _tabsMenu.eq(0);
                }









                reinit();




                $(window).bind('resize', handle_resize);
                handle_resize();

                setTimeout(function(){
                    cthis.addClass('ztm-ready');
                }, 200)

            }

            function reinit(){

                cthis.children('.ztm-item:not(.inited)').each(function(){
                    var _t = $(this);

                    if(o.settings_mode == 'mode-default'){
                        if(_t.children('.hex-icon').length==0){
                            _t.prepend('<div class="hex-icon"><i class="the-icon fa fa-music"></i></div>');
                        }
                    }
                    if(o.settings_mode == 'mode-oncenter'){
                        if(_t.children('.center').length==0){
                            _t.append('<div class="clear"></div>');
                        }
                    }

                    _t.addClass('inited');
                })
            }
            function loadedImage(){
            }
            function handleLoaded(){
            }


            function handle_menuclick(e){
            }

            function handle_resize(e){

                tw = cthis.width();

                //console.log(tw);



                if(tw<600){
                    cthis.addClass('under-600');
                }else{
                    cthis.removeClass('under-600');

                }
                if(tw<400){
                    cthis.addClass('under-400');
                }else{
                    cthis.removeClass('under-400');

                }
                //cthis.addClass('under-400');
                //cthis.addClass('under-600');
            }

            function calculate_dims_for_tab_height(){

            }

            function calculate_dims(){

                tw = cthis.width();



            }


            function goto_item_prev(){
            }
            function goto_item_next(){
            }


            function gotoItem(arg, pargs){

            }
            return this;
        })
    }
    window.dzsztm_init = function(selector, settings) {
        if(typeof(settings)!="undefined" && typeof(settings.init_each)!="undefined" && settings.init_each==true ){
            var element_count = 0;
            for (var e in settings) { element_count++; }
            if(element_count==1){
                settings = undefined;
            }

            $(selector).each(function(){
                var _t = $(this);
                _t.zoomtimeline(settings)
            });
        }else{
            $(selector).zoomtimeline(settings);
        }

    };
})(jQuery);


function can_history_api() {
    return !!(window.history && history.pushState);
}
function is_ios() {
    return ((navigator.platform.indexOf("iPhone") != -1) || (navigator.platform.indexOf("iPod") != -1) || (navigator.platform.indexOf("iPad") != -1)
    );
}

function is_android() {    //return true;
    var ua = navigator.userAgent.toLowerCase();    return (ua.indexOf("android") > -1);
}

function is_ie() {
    if (navigator.appVersion.indexOf("MSIE") != -1) {
        return true;    }; return false;
}
;
function is_firefox() {
    if (navigator.userAgent.indexOf("Firefox") != -1) {        return true;    };
    return false;
}
;
function is_opera() {
    if (navigator.userAgent.indexOf("Opera") != -1) {        return true;    };
    return false;
}
;
function is_chrome() {
    return navigator.userAgent.toLowerCase().indexOf('chrome') > -1;
}
;
function is_safari() {
    return navigator.userAgent.toLowerCase().indexOf('safari') > -1;
}
;
function version_ie() {
    return parseFloat(navigator.appVersion.split("MSIE")[1]);
}
;
function version_firefox() {
    if (/Firefox[\/\s](\d+\.\d+)/.test(navigator.userAgent)) {
        var aversion = new Number(RegExp.$1); return(aversion);
    }
    ;
}
;
function version_opera() {
    if (/Opera[\/\s](\d+\.\d+)/.test(navigator.userAgent)) {
        var aversion = new Number(RegExp.$1); return(aversion);
    }
    ;
}
;
function is_ie8() {
    if (is_ie() && version_ie() < 9) {  return true;  };
    return false;
}
function is_ie9() {
    if (is_ie() && version_ie() == 9) {
        return true;
    }
    return false;
}



function get_query_arg(purl, key){
    if(purl.indexOf(key+'=')>-1){
        //faconsole.log('testtt');
        var regexS = "[?&]"+key + "=.+";
        var regex = new RegExp(regexS);
        var regtest = regex.exec(purl);


        if(regtest != null){
            var splitterS = regtest[0];
            if(splitterS.indexOf('&')>-1){
                var aux = splitterS.split('&');
                splitterS = aux[1];
            }
            var splitter = splitterS.split('=');

            return splitter[1];

        }
        //$('.zoombox').eq
    }
}


function add_query_arg(purl, key,value){
    key = encodeURIComponent(key); value = encodeURIComponent(value);

    //if(window.console) { console.info(key, value); };

    var s = purl;
    var pair = key+"="+value;

    var r = new RegExp("(&|\\?)"+key+"=[^\&]*");


    //console.info(pair);

    s = s.replace(r,"$1"+pair);
    //console.log(s, pair);
    var addition = '';
    if(s.indexOf(key + '=')>-1){


    }else{
        if(s.indexOf('?')>-1){
            addition = '&'+pair;
        }else{
            addition='?'+pair;
        }
        s+=addition;
    }

    //if value NaN we remove this field from the url
    if(value=='NaN'){
        var regex_attr = new RegExp('[\?|\&]'+key+'='+value);
        s=s.replace(regex_attr, '');
    }


    //if(!RegExp.$1) {s += (s.length>0 ? '&' : '?') + kvp;};

    return s;
}




jQuery(document).ready(function($){
    dzsztm_init('.zoomtimeline.auto-init', {init_each: true});


});
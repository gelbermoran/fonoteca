<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta http-equiv="X-UA-COMPATIBLE" content="IE=EDGE">
    <title>Audio Player Preview</title>
    <script src="<?php echo $this->optional_url_base; ?>js/jquery.js"></script>
    <link href="<?php echo $this->optional_url_base; ?>libs/bootstrap/bootstrap.css" rel="stylesheet">
    <link href="<?php echo $this->optional_url_base; ?>libs/bootstrap/bootstrap-responsive.css" rel="stylesheet">
    <link rel='stylesheet' type="text/css" href="<?php echo $this->optional_url_base; ?>style/style.css"/>
    <link rel='stylesheet' type="text/css" href="<?php echo $this->optional_url_base; ?>libs/audioplayer/audioplayer.css"/>
    <!--    <script src="audioplayer/audioplayer.js" type="text/javascript"></script>-->
    <link rel='stylesheet' type="text/css" href="<?php echo $this->optional_url_base; ?>libs/dzstooltip/dzstooltip.css"/>
    <link rel='stylesheet' type="text/css" href="<?php echo $this->optional_url_base; ?>libs/advancedscroller/plugin.css"/>
    <link rel='stylesheet' type="text/css" href="<?php echo $this->optional_url_base; ?>libs/zoombox/zoombox.css"/>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,800' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="<?php echo $this->optional_url_base; ?>libs/fontawesome/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo $this->optional_url_base; ?>libs/dzstabsandaccordions/dzstabsandaccordions.css">
    <link rel='stylesheet' type="text/css" href="<?php echo $this->optional_url_base; ?>libs/dzscheckbox/dzscheckbox.css"/>

    <script>
        var dzsap_settings = {
            thepath: "<?php echo $this->url_base; ?>"
            ,optional_url_base: "<?php echo $this->optional_url_base; ?>"
            , waveformgenerator_multiplier: "1"
            , page: "playlists"
            , color_waveformbg: "111111"
            , color_waveformprog: "ef6b13"
            , enable_cart: "on"
            , settings_wavestyle: "reflect"<?php
                echo ',settings_php_handler: "publisher.php"';
                echo ',settings_ajax_handler: "index.php"';
                if(isset($_GET['media'])){
                    echo ',mediaid:"'.$_GET['media'].'"';
                }

                echo ',waves_generation:"auto"' // -- auto / manual / none

            ?>};</script>
</head>




<body class=" page-playlistadd ">

<div class="add-to-playlist-main-con">


    <div id="add-to-playlist-tabs" class="dzs-tabs auto-init" data-options="{ 'design_tabsposition' : 'top'
                ,design_transition: 'slide'
                ,design_tabswidth: 'default'
                ,toggle_breakpoint : '400'
                ,settings_appendWholeContent: false
                 ,toggle_type: 'accordion'
            ,refresh_tab_height: '1000' // -- normally, the  toggles act like accordions, but they can act like traditional toggles if this is set to toggle
                 }">

        <div class="dzs-tab-tobe">
            <div class="tab-menu with-tooltip"><?php echo __("Add to Playlist"); ?></div>
            <div class="tab-content ">
                <div class="playlists-con">
                <?php


//                $this->show_playlists();


                ?>
                </div>





            </div>
        </div>


        <div class="dzs-tab-tobe  tab-disabled">
            <div class="tab-menu with-tooltip">&nbsp;&nbsp;<span class="slash">/</span>&nbsp;&nbsp;</div>
            <div class="tab-content">
                <?php


                ?>



            </div>
        </div>



        <div class="dzs-tab-tobe">
            <div class="tab-menu with-tooltip">
<?php echo __("Create Playlist"); ?>
            </div>
            <div class="tab-content">

                <form name="add_track" method="POST">
                    <input class="simple-input-field" name="playlist_name"/>
                    <button class="button-primary btn-ajax-add-playlist" name="action" value="ajax_add_playlist"><?php echo __('Add Playlist'); ?></button><br><br>

                    <?php $lab = 'description';
$nam = $lab;
echo '<div class="setting " style="text-align: left;">
        <span class="setting-label">'.__('Public Playlist?').'</span>
        <div class="dzscheckbox skin-nova">
                            '.DZSHelpers::generate_input_checkbox($nam,array('id' => $lab, 'val' => 'public')).'
                            <label for="'.$nam.'"></label>
        </div>'; ?>

                    <br>
                    <br>
                    <div class="sidenote sidenote-loading-adding-playlist">&nbsp;<i class="fa fa-circle-o-notch fa-spin"></i>&nbsp;&nbsp;<?php echo __('Adding Playlist'); ?></div>
                    <div class="clear"></div>
                </form>
            </div>
        </div>

    </div>
</div>



<script src="<?php echo $this->optional_url_base; ?>js/portal.js"></script>
<script src="<?php echo $this->optional_url_base; ?>libs/advancedscroller/plugin.js"></script>
<script src="<?php echo $this->optional_url_base; ?>libs/dzstabsandaccordions/dzstabsandaccordions.js" type="text/javascript"></script>
</body>

</html>

<?php

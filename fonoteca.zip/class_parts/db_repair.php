<?php

//print_r($this);

$query = 'SELECT * FROM INFORMATION_SCHEMA.COLUMNS
           WHERE TABLE_SCHEMA=\''.$this->main_config_settings['mysql_database'].'\' AND TABLE_NAME=\'users\' AND column_name=\'user_meta\'';


$val = $this->dblink->query($query);

$sw = false;

if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!

    if($val->num_rows>0){


    }else{

        $query = 'ALTER TABLE `users` ADD `user_meta` LONGTEXT NOT NULL AFTER `description`';


        $val = $this->dblink->query($query);


        $sw = true;

    }

}else{


   //
}

$query = 'SELECT * FROM INFORMATION_SCHEMA.COLUMNS
           WHERE TABLE_SCHEMA=\''.$this->main_config_settings['mysql_database'].'\' AND TABLE_NAME=\'views\' AND column_name=\'date\'';


$val = $this->dblink->query($query);

if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!

    if($val->num_rows>0){


    }else{

        $query = 'ALTER TABLE `views` ADD `date` LONGTEXT NOT NULL';


        $val = $this->dblink->query($query);


        $sw = true;

    }

}else{


   //
}

$query = 'SELECT * FROM INFORMATION_SCHEMA.COLUMNS
           WHERE TABLE_SCHEMA=\''.$this->main_config_settings['mysql_database'].'\' AND TABLE_NAME=\'activity\' AND column_name=\'target_user_id\'';


$val = $this->dblink->query($query);


if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!

    if($val->num_rows>0){


    }else{

        $query = 'ALTER TABLE `activity` ADD `target_user_id` INT(255) NOT NULL';


        $val = $this->dblink->query($query);


        $sw = true;

    }

}else{


   //
}

$query = 'SELECT * FROM INFORMATION_SCHEMA.COLUMNS
           WHERE TABLE_SCHEMA=\''.$this->main_config_settings['mysql_database'].'\' AND TABLE_NAME=\'activity\' AND column_name=\'target_track_id\'';


$val = $this->dblink->query($query);

if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!

    if($val->num_rows>0){


    }else{

        $query = 'ALTER TABLE `activity` ADD `target_track_id` INT(255) NOT NULL';


        $val = $this->dblink->query($query);


        $sw = true;

    }

}else{


   //
}



$query = 'SELECT * FROM INFORMATION_SCHEMA.COLUMNS
           WHERE TABLE_SCHEMA=\''.$this->main_config_settings['mysql_database'].'\' AND TABLE_NAME=\'users\' AND column_name=\'stream_read\'';


$val = $this->dblink->query($query);


if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!

    if($val->num_rows>0){


    }else{

        $query = 'ALTER TABLE `users` ADD `stream_read` LONGTEXT NOT NULL AFTER `description`';


        $val = $this->dblink->query($query);


        $sw = true;

    }

}else{


   //
}



$query = 'SELECT * FROM INFORMATION_SCHEMA.COLUMNS
           WHERE TABLE_SCHEMA=\''.$this->main_config_settings['mysql_database'].'\' AND TABLE_NAME=\'users\' AND column_name=\'role\'';


$val = $this->dblink->query($query);


if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!

    if($val->num_rows>0){


    }else{

        $query = 'ALTER TABLE `users` ADD `role` MEDIUMTEXT NOT NULL AFTER `description`';


        $val = $this->dblink->query($query);


        $sw = true;

    }

}else{


   //
}


$query = 'SELECT * FROM INFORMATION_SCHEMA.COLUMNS
           WHERE TABLE_SCHEMA=\''.$this->main_config_settings['mysql_database'].'\' AND TABLE_NAME=\'tracks\' AND column_name=\'download_link_new_tab\'';


$val = $this->dblink->query($query);

//echo $query; print_r($val);

if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!

    if($val->num_rows>0){


    }else{

        $query = 'ALTER TABLE `tracks` ADD `download_link_new_tab` VARCHAR(5) NOT NULL AFTER `download_link`, ADD `extra_html` LONGTEXT NOT NULL AFTER `download_link`;';


        $val = $this->dblink->query($query);


        $sw = true;

    }

}else{


   //
}
$val2 = $this->dblink->query('ALTER TABLE  `tracks` CHANGE  `genre`  `genre` VARCHAR( 155 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT  \'\';');
$val2 = $this->dblink->query('ALTER TABLE  `tracks` CHANGE  `download_link_new_tab`  `download_link_new_tab` VARCHAR( 5 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT  \'\';');


$query = 'SELECT * FROM INFORMATION_SCHEMA.COLUMNS
           WHERE TABLE_SCHEMA=\''.$this->main_config_settings['mysql_database'].'\' AND TABLE_NAME=\'tracks\' AND column_name=\'filesize\'';


$val = $this->dblink->query($query);


//echo $query; print_r($val);

if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!

    if($val->num_rows>0){


    }else{

        $query = 'ALTER TABLE `tracks` ADD `filesize` int(255) NOT NULL AFTER `download_link`;';


        $val = $this->dblink->query($query);


        $sw = true;

    }

}else{


   //
}







$query = 'SELECT * FROM INFORMATION_SCHEMA.COLUMNS
           WHERE TABLE_SCHEMA=\''.$this->main_config_settings['mysql_database'].'\' AND TABLE_NAME=\'tracks\' AND column_name=\'genre\'';


$val = $this->dblink->query($query);

//echo $query; print_r($val);

if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!

    if($val->num_rows>0){


    }else{

        $query = 'ALTER TABLE `tracks` ADD `genre` varchar(255) NOT NULL AFTER `download_link`;';


        $val = $this->dblink->query($query);


        $sw = true;

    }

}else{


   //
}





$query = 'SELECT * FROM INFORMATION_SCHEMA.COLUMNS
           WHERE TABLE_SCHEMA=\''.$this->main_config_settings['mysql_database'].'\' AND TABLE_NAME=\'tracks\' AND column_name=\'type\'';


$val = $this->dblink->query($query);


//echo $query; print_r($val);

if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!

    if($val->num_rows>0){


    }else{

        $query = 'ALTER TABLE `tracks` ADD `type` VARCHAR(255) NOT NULL AFTER `download_link`;';


        $val = $this->dblink->query($query);


        $sw = true;

    }

}else{


   //
}



$query = 'SELECT * FROM INFORMATION_SCHEMA.COLUMNS
           WHERE TABLE_SCHEMA=\''.$this->main_config_settings['mysql_database'].'\' AND TABLE_NAME=\'users\' AND column_name=\'facebook_link\'';


$val = $this->dblink->query($query);


//echo $query; print_r($val);

if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!

    if($val->num_rows>0){


    }else{

        $query = 'ALTER TABLE `users` ADD `facebook_link` mediumtext NOT NULL ;';


        $val = $this->dblink->query($query);


        $sw = true;

    }

}else{


   //
}



$query = 'SELECT * FROM INFORMATION_SCHEMA.COLUMNS
           WHERE TABLE_SCHEMA=\''.$this->main_config_settings['mysql_database'].'\' AND TABLE_NAME=\'users\' AND column_name=\'twitter_link\'';


$val = $this->dblink->query($query);


//echo $query; print_r($val);

if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!

    if($val->num_rows>0){


    }else{

        $query = 'ALTER TABLE `users` ADD `twitter_link` mediumtext NOT NULL ;';


        $val = $this->dblink->query($query);


        $sw = true;

    }

}else{


   //
}


$query = 'SELECT * FROM INFORMATION_SCHEMA.COLUMNS
           WHERE TABLE_SCHEMA=\''.$this->main_config_settings['mysql_database'].'\' AND TABLE_NAME=\'users\' AND column_name=\'tags\'';


$val = $this->dblink->query($query);


//echo $query; print_r($val);

if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!

    if($val->num_rows>0){


    }else{

        $query = 'ALTER TABLE `users` ADD `tags` mediumtext NOT NULL ;';


        $val = $this->dblink->query($query);


        $sw = true;

    }

}else{


   //
}


$query = 'SELECT * FROM INFORMATION_SCHEMA.COLUMNS
           WHERE TABLE_SCHEMA=\''.$this->main_config_settings['mysql_database'].'\' AND TABLE_NAME=\'users\' AND column_name=\'country_code\'';


$val = $this->dblink->query($query);


//echo $query; print_r($val);

if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!

    if($val->num_rows>0){


    }else{

        $query = 'ALTER TABLE `users` ADD `country_code` varchar(10) NOT NULL ;';


        $val = $this->dblink->query($query);


        $sw = true;

    }

}else{


   //
}





$query = 'SELECT * FROM INFORMATION_SCHEMA.COLUMNS
           WHERE TABLE_SCHEMA=\''.$this->main_config_settings['mysql_database'].'\' AND TABLE_NAME=\'views\' AND column_name=\'type\'';


$val = $this->dblink->query($query);


//echo $query; print_r($val);

if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!

    if($val->num_rows>0){


    }else{

        $query = 'ALTER TABLE `views` ADD `type` VARCHAR(255) NOT NULL DEFAULT \'\' AFTER `date`;';


        $val = $this->dblink->query($query);


        $sw = true;

    }

}else{


   //
}




$query = 'SELECT * FROM INFORMATION_SCHEMA.COLUMNS
           WHERE TABLE_SCHEMA=\''.$this->main_config_settings['mysql_database'].'\' AND TABLE_NAME=\'users\' AND column_name=\'soundcloud_link\'';


$val = $this->dblink->query($query);


//echo $query; print_r($val);

if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!

    if($val->num_rows>0){


    }else{

        $query = 'ALTER TABLE `users` ADD `soundcloud_link` mediumtext NOT NULL ;';


        $val = $this->dblink->query($query);


        $sw = true;

    }

}else{


   //
}

$query = 'SELECT * FROM INFORMATION_SCHEMA.COLUMNS
           WHERE TABLE_SCHEMA=\''.$this->main_config_settings['mysql_database'].'\' AND TABLE_NAME=\'users\' AND column_name=\'paypal_email\'';


$val = $this->dblink->query($query);


//echo $query; print_r($val);

if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!

    if($val->num_rows>0){


    }else{

        $query = 'ALTER TABLE `users` ADD `paypal_email` mediumtext NULL DEFAULT NULL  ;';


        $val = $this->dblink->query($query);


        $sw = true;

    }

}else{


   //
}

$query = 'SELECT * FROM INFORMATION_SCHEMA.COLUMNS
           WHERE TABLE_SCHEMA=\''.$this->main_config_settings['mysql_database'].'\' AND TABLE_NAME=\'users\' AND column_name=\'verify_status\'';


$val = $this->dblink->query($query);


//echo $query; print_r($val);

if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!

    if($val->num_rows>0){


    }else{

        $query = 'ALTER TABLE `users` ADD `verify_status` mediumtext NULL DEFAULT NULL  ;';


        $val = $this->dblink->query($query);


        $sw = true;

    }

}else{


   //
}






$val = $this->dblink->query('select 1 from permalinks');


//echo $query; print_r($val);

if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!

    if($val->num_rows>0){


    }else{


    }

}else{

    $query = 'CREATE TABLE `permalinks` (
  `id` int(255) unsigned NOT NULL,
  `permalink` mediumtext NOT NULL,
  `type` mediumtext NOT NULL,
  `type_type` mediumtext NOT NULL,
  `target_id` int(255) NOT NULL
)';


    $val = $this->dblink->query($query);


    $sw = true;

   //
}



$val = $this->dblink->query('ALTER TABLE `views` CHANGE `id` `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT;');
if($val){


}else{
    echo 'error - '.__("cannot assign primary key - reset statistics first ").'<br><br>'.mysqli_error($this->dblink);
}

$val = $this->dblink->query('ALTER TABLE  `permalinks` CHANGE  `id`  `id` INT( 255 ) UNSIGNED NOT NULL AUTO_INCREMENT ;');
$val = $this->dblink->query('ALTER TABLE  `permalinks` CHANGE  `type_type`  `type_type` MEDIUMTEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL ;');
$val = $this->dblink->query('ALTER TABLE  `users` CHANGE  `avatar`  `avatar` LONGTEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL ;');
$val = $this->dblink->query('ALTER TABLE  `users` CHANGE  `capabilities`  `capabilities` LONGTEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL ;');
$val = $this->dblink->query('ALTER TABLE  `users` CHANGE  `purchases`  `purchases` LONGTEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL ;
');
$val = $this->dblink->query('ALTER TABLE  `users` CHANGE  `connections`  `connections` LONGTEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL ;
');
$val = $this->dblink->query('ALTER TABLE  `users` CHANGE  `ip_registered_from`  `ip_registered_from` VARCHAR( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT  \'\';');
$val = $this->dblink->query('ALTER TABLE  `users` CHANGE  `location`  `location` VARCHAR( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT  \'\';
');
$val = $this->dblink->query('ALTER TABLE  `users` CHANGE  `role`  `role` VARCHAR( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT  \'\';
');
$val = $this->dblink->query('ALTER TABLE  `users` CHANGE  `second_avatar`  `second_avatar` LONGTEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL ;');
$val = $this->dblink->query('ALTER TABLE  `users` CHANGE  `description`  `description` LONGTEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL ;');
$val = $this->dblink->query('ALTER TABLE  `users` CHANGE  `stream_read`  `stream_read` LONGTEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL ;');
$val = $this->dblink->query('ALTER TABLE  `users` CHANGE  `user_meta`  `user_meta` LONGTEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL ;');
$val = $this->dblink->query('ALTER TABLE  `users` CHANGE  `facebook_link`  `facebook_link` MEDIUMTEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL ;');
$val = $this->dblink->query('ALTER TABLE  `users` CHANGE  `twitter_link`  `twitter_link` MEDIUMTEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL ;');
$val = $this->dblink->query('ALTER TABLE  `users` CHANGE  `soundcloud_link`  `soundcloud_link` MEDIUMTEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL ;');
$val = $this->dblink->query('ALTER TABLE  `users` CHANGE  `paypal_email`  `paypal_email` MEDIUMTEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL ;');
$val = $this->dblink->query('ALTER TABLE  `tracks` CHANGE  `description`  `description` LONGTEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL ;');
$val = $this->dblink->query('ALTER TABLE  `tracks` CHANGE  `waveform_bg`  `waveform_bg` LONGTEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL ;');
$val = $this->dblink->query('ALTER TABLE  `tracks` CHANGE  `waveform_prog`  `waveform_prog` LONGTEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL ;');
$val = $this->dblink->query('ALTER TABLE  `tracks` CHANGE  `backup_ogg`  `backup_ogg` LONGTEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL ;');
$val = $this->dblink->query('ALTER TABLE  `tracks` CHANGE  `download_link`  `download_link` LONGTEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL');
$val = $this->dblink->query('ALTER TABLE  `pages` CHANGE  `content`  `content` LONGTEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL ;');






if($sw){
    echo 'success - '.__('database repaired');
}else{
    echo 'success - '.__('no changes');
}
//print_r($val);
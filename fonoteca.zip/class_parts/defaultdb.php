<?php

$val2 = $this->dblink->query('CREATE TABLE `tracks` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `title` longtext NOT NULL,
  `content` varchar(255) DEFAULT NULL,
  `author_id` int(10) DEFAULT NULL,
  `published_date` datetime DEFAULT NULL,
  `description` longtext NOT NULL,
  `waveform_bg` varchar(255) NOT NULL,
  `waveform_prog` varchar(255) NOT NULL,
  `backup_ogg` varchar(255) NOT NULL,
  `thumbnail` varchar(1024) NOT NULL,
  `tags` varchar(255) NOT NULL,
  `is_buyable` varchar(20) NOT NULL,
  `price` varchar(255) NOT NULL,
  `sample_time_start` int(255) NOT NULL,
  `sample_time_end` int(255) NOT NULL,
  `sample_time_total` int(255) NOT NULL,
  `cover_image` longtext NOT NULL,
  `type` varchar(256) NOT NULL,
  `genre` varchar(256) NOT NULL,
  `filesize` int(255) NOT NULL COMMENT \'the size in mb\',
  `download_link` longtext NOT NULL,
  `extra_html` longtext NOT NULL,
  `download_link_new_tab` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;');



$val2 = $this->dblink->query('
INSERT INTO tracks VALUES("1","A Beautiful Day","upload/adg3.mp3","1","2015-11-10","","img/scrubbg.png","img/scrubprog.png","","http://i.imgur.com/qXMHwE0.jpg","cheering, album, adg3","on","50","0","0","0","https://placeholdit.imgix.net/~text?txtsize=33&txt=placeholder&w=1400&h=600","","","3000000","","","");
');


if ($this->dblink->errno) {
    die('Error line 32 : '. $this->dblink->error);
}

$val2 = $this->dblink->query('
INSERT INTO tracks VALUES("2","Total Overdrive","upload/adg3.mp3","1","2015-11-11","","img/scrubbg.png","img/scrubprog.png","","http://i.imgur.com/v1Md905.jpg","creative, banging, breaking","","","0","0","0","https://placeholdit.imgix.net/~text?txtsize=33&txt=placeholder&w=1400&h=600","","","3000000","","","");
');

if ($this->dblink->errno) {
    die('Error line 40: '. $this->dblink->error);
}

if ($this->dblink->errno) {
    die('Error line 48: '. $this->dblink->error);
}

$val = $this->dblink->query('select 1 from `activity`');

//`activity` (`id_user`, `type`, `details`, `date`)
if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!
}else{
    $val2 = $this->dblink->query('CREATE TABLE IF NOT EXISTS `activity` (
    `id` int(10) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `id_user` int(10) DEFAULT NULL,
    `target_user_id` int(10) DEFAULT NULL,
    `target_track_id` int(10) DEFAULT NULL,
    `type` varchar(255) NOT NULL,
    `details` longtext NOT NULL,
    `date` DATETIME
    ) ENGINE=InnoDB DEFAULT CHARSET=latin1;');

//Output any connection error
    if ($this->dblink->errno) {
        die('Error : '. $this->dblink->error);
    }

}


$val = $this->dblink->query('select 1 from apconfigs');

//`activity` (`id_user`, `type`, `details`, `date`)
if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!
}else{





    $val2 = $this->dblink->query('CREATE TABLE `apconfigs` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `author_id` varchar(255) NOT NULL,
  `published_date` date NOT NULL,
  `content` longtext NOT NULL,
  `title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;');

//Output any connection error
    if ($this->dblink->errno) {
        die('Error : '. $this->dblink->error);
    }


    $val2 = $this->dblink->query("
INSERT INTO `apconfigs` (`id`, `author_id`, `published_date`, `content`, `title`) VALUES
(1, '1', '2015-10-11', 'skin_ap=skin-wave&settings_backup_type=simple&disable_volume=on&enable_embed_button=on&preload_method=metadata&playfrom=0&colorhighlight=111111&skinwave_dynamicwaves=off&button_aspect=button-aspect-noir+button-aspect-noir--filled&skinwave_layout=default&skinwave_enablespectrum=off&skinwave_enablereflect=on&skinwave_comments_enable=on&skinwave_mode=normal&enable_alternate_layout=off', 'skinwave'),
(2, '1', '2015-12-05', 'skin_ap=skin-silver&settings_backup_type=simple&disable_volume=default&enable_embed_button=off&playfrom=&colorhighlight=&skinwave_dynamicwaves=off&skinwave_enablespectrum=off&skinwave_enablereflect=on&skinwave_comments_enable=off&skinwave_mode=normal&enable_alternate_layout=off', 'skinsilver'),
(3, '1', '2016-06-06', 'skin_ap=skin-wave&settings_backup_type=simple&disable_volume=default&enable_embed_button=off&playfrom=&colorhighlight=&skinwave_dynamicwaves=off&skinwave_enablespectrum=off&skinwave_enablereflect=on&skinwave_comments_enable=off&skinwave_mode=normal&enable_alternate_layout=off', 'footer_skinwave');
");

//Output any connection error
    if ($this->dblink->errno) {
        die('Error : '. $this->dblink->error);
    }

}

$val = $this->dblink->query('select 1 from comments');

//`activity` (`id_user`, `type`, `details`, `date`)
if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!
}else{
    $val2 = $this->dblink->query('CREATE TABLE `comments` (
  `id` int(11) NOT NULL  AUTO_INCREMENT PRIMARY KEY,
  `author_id` int(11) NOT NULL,
  `published_date` datetime NOT NULL,
  `for_type` varchar(255) NOT NULL,
  `track_id` int(11) NOT NULL COMMENT \'foreign\',
  `content` longtext NOT NULL,
  `position` double NOT NULL,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;');

//Output any connection error
    if ($this->dblink->errno) {
        die('Error : '. $this->dblink->error);
    }

}

$val = $this->dblink->query('select 1 from dzspgb_templates');

//`activity` (`id_user`, `type`, `details`, `date`)
if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!
}else{
    $val2 = $this->dblink->query("CREATE TABLE `dzspgb_templates` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `template_name` varchar(255) NOT NULL,
  `template_data` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

");

//Output any connection error
    if ($this->dblink->errno) {
        die('Error : '. $this->dblink->error);
    }


    $val2 = $this->dblink->query("INSERT INTO `dzspgb_templates` (`id`, `template_name`, `template_data`) VALUES
(10, 'general_template', 'dzspgb%5Btype%5D=Full&dzspgb%5B0%5D%5Bextra_classes%5D=mcon-mainmenu&dzspgb%5B0%5D%5B0%5D%5Bextra_classes%5D=&dzspgb%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&dzspgb%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype%5D=row_part&dzspgb%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bpart%5D=1.1&dzspgb%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&dzspgb%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bheader_style%5D=style-default&dzspgb%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bmenu_select%5D=1&dzspgb%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=header&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Baudioplayer_style%5D=style_default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=audioplayer&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=breakout_final&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=breakout_first&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcheckout_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=checkout&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bdivider_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=divider&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bheader_style%5D=style-default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bmenu_select%5D=none&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=header&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstyle%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bapconfig%5D=1&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=query&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bregister_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=register&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem%5D%5Btype%5D=multipleitems&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=slider&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btemplate%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btemplate_id%5D=1&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=templates&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=text&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bupload_style%5D=style_default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=upload&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=user&dzspgb%5B0%5D%5B0%5D%5B0%5D%5Btype%5D=element&dzspgb%5B0%5D%5B0%5D%5Btype%5D=element&dzspgb%5B0%5D%5Btype%5D=section&dzspgb%5B1%5D%5Bextra_classes%5D=content-section&dzspgb%5B1%5D%5B0%5D%5Bextra_classes%5D=content-container&dzspgb%5B1%5D%5B0%5D%5Bis_content%5D=on&dzspgb%5B1%5D%5B0%5D%5Btype%5D=container&dzspgb%5B1%5D%5B1%5D%5Bextra_classes%5D=&dzspgb%5B1%5D%5B1%5D%5B0%5D%5Bextra_classes%5D=&dzspgb%5B1%5D%5B1%5D%5B0%5D%5B0%5D%5Btype%5D=row_part&dzspgb%5B1%5D%5B1%5D%5B0%5D%5B0%5D%5Bpart%5D=1.1&dzspgb%5B1%5D%5B1%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&dzspgb%5B1%5D%5B1%5D%5B0%5D%5B0%5D%5B0%5D%5Bheader_style%5D=style-footer-menu&dzspgb%5B1%5D%5B1%5D%5B0%5D%5B0%5D%5B0%5D%5Bmenu_select%5D=2&dzspgb%5B1%5D%5B1%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=header&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Baudioplayer_style%5D=style_default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=audioplayer&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=breakout_final&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=breakout_first&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcheckout_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=checkout&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bdivider_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=divider&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bheader_style%5D=style-default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bmenu_select%5D=none&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=header&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstyle%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bapconfig%5D=1&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=query&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bregister_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=register&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem%5D%5Btype%5D=multipleitems&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=slider&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btemplate%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btemplate_id%5D=1&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=templates&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=text&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bupload_style%5D=style_default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=upload&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=user&dzspgb%5B1%5D%5B1%5D%5B0%5D%5Btype%5D=element&dzspgb%5B1%5D%5B1%5D%5Btype%5D=element&dzspgb%5B1%5D%5Btype%5D=section');
");


    $val2 = $this->dblink->query('
INSERT INTO dzspgb_templates VALUES("2","pro_illustration","dzspgb%5Btype%5D=Row&dzspgb%5B0%5D%5Bextra_classes%5D=row-features&dzspgb%5B0%5D%5Bcolumn_padding%5D=default&dzspgb%5B0%5D%5B0%5D%5Btype%5D=row_part&dzspgb%5B0%5D%5B0%5D%5Bpart%5D=d&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstyle%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bapconfig%5D=3&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bids%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=artist_query&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bnr_columns%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Baudio_track%5D%5Btype%5D=multipleitems&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=audio_playlist&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Baudioplayer_style%5D=style_default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=audioplayer&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=breakout_final&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=breakout_first&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstart_month%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstart_year%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=calendar&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcheckout_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=checkout&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btrack_id%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=comments&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btrack_id%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=cover_image&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bdivider_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=divider&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcover_image%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bvideo%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=events&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bicon%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btitle%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bfeature%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bkill_tinymce%5D=off&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=feature&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bflickr_username%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bflickr_api_key%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=gallery&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bheader_style%5D=style-default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bmenu_select%5D=none&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=header&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bimage%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_html%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Blink%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Blink_extra_attr%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Blink_target%5D=_self&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=image&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bmenu_select%5D=none&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=inline_menu&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Blogin_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=login&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=messages&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=messages_friends&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=new_section&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bnr_columns%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem%5D%5Btype%5D=multipleitems&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem2%5D%5Btype%5D=multipleitems2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem3%5D%5Btype%5D=multipleitems3&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem4%5D%5Btype%5D=multipleitems4&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=pricing_table&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstyle%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bquery_type%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Binterval%5D=alltime&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bthumbs_per_row%5D=33.33%25&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bthumbs_bullets_position%5D=bottom&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bthumbs_disable_arrows%5D=off&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bthumbs_display_title_and_price%5D=off&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bthumbs_see_all_text%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bpagination%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Blimit_posts%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bpaged%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bapconfig%5D=3&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bquery_query%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bpost_type%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcall_from_lab%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=query&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bregister_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=register&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bskin%5D=skin-default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btransition%5D=fade&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem%5D%5Btype%5D=multipleitems&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=slider&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btemplate_id%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=templates&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bkill_tinymce%5D=off&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=text&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bupload_style%5D=style_default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=upload&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=user&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Busersettings_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=usersettings&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcover_image%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bvideo%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_text%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=videoplayer&dzspgb%5B0%5D%5B1%5D%5Btype%5D=row_part&dzspgb%5B0%5D%5B1%5D%5Bpart%5D=1.3&dzspgb%5B0%5D%5B1%5D%5B0%5D%5Btext%5D=%3Ch4%3EBigger+Upload+Limit%3C%2Fh4%3E&dzspgb%5B0%5D%5B1%5D%5B0%5D%5Bkill_tinymce%5D=off&dzspgb%5B0%5D%5B1%5D%5B0%5D%5Btype_element%5D=text&dzspgb%5B0%5D%5B1%5D%5B1%5D%5Bimage%5D=https%3A%2F%2Fplaceholdit.imgix.net%2F~text%3Ftxtsize%3D33%26txt%3Dplaceholder%26w%3D300%26h%3D300&dzspgb%5B0%5D%5B1%5D%5B1%5D%5Bextra_html%5D=&dzspgb%5B0%5D%5B1%5D%5B1%5D%5Bextra_classes%5D=test&dzspgb%5B0%5D%5B1%5D%5B1%5D%5Blink%5D=&dzspgb%5B0%5D%5B1%5D%5B1%5D%5Blink_extra_attr%5D=&dzspgb%5B0%5D%5B1%5D%5B1%5D%5Blink_target%5D=_self&dzspgb%5B0%5D%5B1%5D%5B1%5D%5Btype_element%5D=image&dzspgb%5B0%5D%5B1%5D%5B2%5D%5Btext%5D=%3Cp%3E%3Cem%3E%3C%2Fem%3E%3C%2Fp%3E%0A%3Cp%3E%3Cem%3E%3C%2Fem%3E%3C%2Fp%3E%0A%3Cp%3E%3Cem%3E%3C%2Fem%3E%3Cem%3EUpload+has+a+bigger+cap+with+PRO+user+privileges.+Submit+more+tracks!+Normal+users+have+a+lower+number+of+tracks+limit.%3C%2Fem%3E%3C%2Fp%3E&dzspgb%5B0%5D%5B1%5D%5B2%5D%5Bkill_tinymce%5D=off&dzspgb%5B0%5D%5B1%5D%5B2%5D%5Btype_element%5D=text&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstyle%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bapconfig%5D=3&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bids%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=artist_query&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bnr_columns%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Baudio_track%5D%5Btype%5D=multipleitems&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=audio_playlist&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Baudioplayer_style%5D=style_default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=audioplayer&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=breakout_final&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=breakout_first&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstart_month%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstart_year%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=calendar&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcheckout_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=checkout&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btrack_id%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=comments&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btrack_id%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=cover_image&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bdivider_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=divider&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcover_image%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bvideo%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=events&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bicon%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btitle%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bfeature%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bkill_tinymce%5D=off&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=feature&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bflickr_username%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bflickr_api_key%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=gallery&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bheader_style%5D=style-default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bmenu_select%5D=none&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=header&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bimage%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_html%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Blink%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Blink_extra_attr%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Blink_target%5D=_self&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=image&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bmenu_select%5D=none&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=inline_menu&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Blogin_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=login&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=messages&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=messages_friends&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=new_section&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bnr_columns%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem%5D%5Btype%5D=multipleitems&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem2%5D%5Btype%5D=multipleitems2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem3%5D%5Btype%5D=multipleitems3&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem4%5D%5Btype%5D=multipleitems4&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=pricing_table&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstyle%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bquery_type%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Binterval%5D=alltime&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bthumbs_per_row%5D=33.33%25&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bthumbs_bullets_position%5D=bottom&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bthumbs_disable_arrows%5D=off&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bthumbs_display_title_and_price%5D=off&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bthumbs_see_all_text%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bpagination%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Blimit_posts%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bpaged%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bapconfig%5D=3&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bquery_query%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bpost_type%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcall_from_lab%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=query&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bregister_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=register&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bskin%5D=skin-default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btransition%5D=fade&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem%5D%5Btype%5D=multipleitems&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=slider&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btemplate_id%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=templates&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bkill_tinymce%5D=off&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=text&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bupload_style%5D=style_default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=upload&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=user&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Busersettings_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=usersettings&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcover_image%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bvideo%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_text%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=videoplayer&dzspgb%5B0%5D%5B2%5D%5Btype%5D=row_part&dzspgb%5B0%5D%5B2%5D%5Bpart%5D=1.3&dzspgb%5B0%5D%5B2%5D%5B0%5D%5Btext%5D=%3Ch4%3EUnlimited+Playlists%3C%2Fh4%3E&dzspgb%5B0%5D%5B2%5D%5B0%5D%5Bkill_tinymce%5D=off&dzspgb%5B0%5D%5B2%5D%5B0%5D%5Btype_element%5D=text&dzspgb%5B0%5D%5B2%5D%5B1%5D%5Bimage%5D=https%3A%2F%2Fplaceholdit.imgix.net%2F~text%3Ftxtsize%3D33%26txt%3Dplaceholder%26w%3D300%26h%3D300&dzspgb%5B0%5D%5B2%5D%5B1%5D%5Bextra_html%5D=&dzspgb%5B0%5D%5B2%5D%5B1%5D%5Bextra_classes%5D=&dzspgb%5B0%5D%5B2%5D%5B1%5D%5Blink%5D=&dzspgb%5B0%5D%5B2%5D%5B1%5D%5Blink_extra_attr%5D=&dzspgb%5B0%5D%5B2%5D%5B1%5D%5Blink_target%5D=_self&dzspgb%5B0%5D%5B2%5D%5B1%5D%5Btype_element%5D=image&dzspgb%5B0%5D%5B2%5D%5B2%5D%5Btext%5D=%3Cp%3E%3Cem%3E%3C%2Fem%3E%3C%2Fp%3E%0A%3Cp%3E%3Cem%3E%3C%2Fem%3E%3C%2Fp%3E%0A%3Cp%3E%3Cem%3ECreate+unlimited+playlsits+being+a+PRO%7Breplacequotquot%7D+member%2C+either+Public+or+Private.+Normal+users+have+a+limit+of+4+playlists.%3C%2Fem%3E%3C%2Fp%3E%0A%3Cp%3E%3Ca+class%3D%7Breplacequotquot%7Dajax-link%7Breplacequotquot%7D+href%3D%7Breplacequotquot%7Dindex.php%3Fpage%3Dpage%26page_id%3D29%7Breplacequotquot%7D%3EView+Pricing%3C%2Fa%3E%3C%2Fp%3E&dzspgb%5B0%5D%5B2%5D%5B2%5D%5Bkill_tinymce%5D=off&dzspgb%5B0%5D%5B2%5D%5B2%5D%5Btype_element%5D=text&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstyle%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bapconfig%5D=3&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bids%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=artist_query&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bnr_columns%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Baudio_track%5D%5Btype%5D=multipleitems&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=audio_playlist&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Baudioplayer_style%5D=style_default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=audioplayer&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=breakout_final&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=breakout_first&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstart_month%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstart_year%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=calendar&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcheckout_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=checkout&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btrack_id%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=comments&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btrack_id%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=cover_image&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bdivider_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=divider&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcover_image%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bvideo%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=events&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bicon%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btitle%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bfeature%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bkill_tinymce%5D=off&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=feature&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bflickr_username%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bflickr_api_key%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=gallery&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bheader_style%5D=style-default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bmenu_select%5D=none&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=header&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bimage%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_html%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Blink%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Blink_extra_attr%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Blink_target%5D=_self&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=image&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bmenu_select%5D=none&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=inline_menu&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Blogin_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=login&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=messages&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=messages_friends&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=new_section&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bnr_columns%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem%5D%5Btype%5D=multipleitems&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem2%5D%5Btype%5D=multipleitems2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem3%5D%5Btype%5D=multipleitems3&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem4%5D%5Btype%5D=multipleitems4&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=pricing_table&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstyle%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bquery_type%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Binterval%5D=alltime&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bthumbs_per_row%5D=33.33%25&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bthumbs_bullets_position%5D=bottom&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bthumbs_disable_arrows%5D=off&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bthumbs_display_title_and_price%5D=off&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bthumbs_see_all_text%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bpagination%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Blimit_posts%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bpaged%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bapconfig%5D=3&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bquery_query%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bpost_type%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcall_from_lab%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=query&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bregister_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=register&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bskin%5D=skin-default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btransition%5D=fade&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem%5D%5Btype%5D=multipleitems&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=slider&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btemplate_id%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=templates&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bkill_tinymce%5D=off&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=text&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bupload_style%5D=style_default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=upload&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=user&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Busersettings_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=usersettings&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcover_image%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bvideo%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_text%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=videoplayer&dzspgb%5B0%5D%5B3%5D%5Btype%5D=row_part&dzspgb%5B0%5D%5B3%5D%5Bpart%5D=1.3&dzspgb%5B0%5D%5B3%5D%5B0%5D%5Btext%5D=%3Ch4%3EPRO+Badge%3C%2Fh4%3E&dzspgb%5B0%5D%5B3%5D%5B0%5D%5Bkill_tinymce%5D=off&dzspgb%5B0%5D%5B3%5D%5B0%5D%5Btype_element%5D=text&dzspgb%5B0%5D%5B3%5D%5B1%5D%5Bimage%5D=https%3A%2F%2Fplaceholdit.imgix.net%2F~text%3Ftxtsize%3D33%26txt%3Dplaceholder%26w%3D300%26h%3D300&dzspgb%5B0%5D%5B3%5D%5B1%5D%5Bextra_html%5D=&dzspgb%5B0%5D%5B3%5D%5B1%5D%5Bextra_classes%5D=&dzspgb%5B0%5D%5B3%5D%5B1%5D%5Blink%5D=&dzspgb%5B0%5D%5B3%5D%5B1%5D%5Blink_extra_attr%5D=&dzspgb%5B0%5D%5B3%5D%5B1%5D%5Blink_target%5D=_self&dzspgb%5B0%5D%5B3%5D%5B1%5D%5Btype_element%5D=image&dzspgb%5B0%5D%5B3%5D%5B2%5D%5Btext%5D=%3Cp%3E%3C%2Fp%3E%0A%3Cp%3E%3C%2Fp%3E%0A%3Cp%3E%3Cem%3EPRO+members+have+the+estinguished+PRO+badge+that+make+them+stand+out.+This+badge+will+appear+after+the+user+name.%3C%2Fem%3E%3C%2Fp%3E&dzspgb%5B0%5D%5B3%5D%5B2%5D%5Bkill_tinymce%5D=off&dzspgb%5B0%5D%5B3%5D%5B2%5D%5Btype_element%5D=text&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstyle%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bapconfig%5D=3&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bids%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=artist_query&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bnr_columns%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Baudio_track%5D%5Btype%5D=multipleitems&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=audio_playlist&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Baudioplayer_style%5D=style_default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=audioplayer&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=breakout_final&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=breakout_first&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstart_month%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstart_year%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=calendar&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcheckout_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=checkout&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btrack_id%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=comments&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btrack_id%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=cover_image&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bdivider_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=divider&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcover_image%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bvideo%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=events&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bicon%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btitle%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bfeature%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bkill_tinymce%5D=off&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=feature&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bflickr_username%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bflickr_api_key%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=gallery&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bheader_style%5D=style-default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bmenu_select%5D=none&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=header&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bimage%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_html%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Blink%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Blink_extra_attr%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Blink_target%5D=_self&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=image&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bmenu_select%5D=none&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=inline_menu&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Blogin_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=login&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=messages&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=messages_friends&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=new_section&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bnr_columns%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem%5D%5Btype%5D=multipleitems&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem2%5D%5Btype%5D=multipleitems2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem3%5D%5Btype%5D=multipleitems3&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem4%5D%5Btype%5D=multipleitems4&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=pricing_table&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstyle%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bquery_type%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Binterval%5D=alltime&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bthumbs_per_row%5D=33.33%25&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bthumbs_bullets_position%5D=bottom&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bthumbs_disable_arrows%5D=off&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bthumbs_display_title_and_price%5D=off&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bthumbs_see_all_text%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bpagination%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Blimit_posts%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bpaged%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bapconfig%5D=3&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bquery_query%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bpost_type%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcall_from_lab%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=query&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bregister_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=register&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bskin%5D=skin-default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btransition%5D=fade&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem%5D%5Btype%5D=multipleitems&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=slider&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btemplate_id%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=templates&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bkill_tinymce%5D=off&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=text&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bupload_style%5D=style_default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=upload&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=user&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Busersettings_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=usersettings&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcover_image%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bvideo%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_text%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=videoplayer&dzspgb%5B0%5D%5B0%5D%5B0%5D%5Btype%5D=element");
');


    $val2 = $this->dblink->query('
INSERT INTO dzspgb_templates VALUES("11","sidebar_stream","dzspgb%5Btype%5D=Row&dzspgb%5B0%5D%5Bextra_classes%5D=&dzspgb%5B0%5D%5B0%5D%5Btype%5D=row_part&dzspgb%5B0%5D%5B0%5D%5Bpart%5D=1.1&dzspgb%5B0%5D%5B0%5D%5B0%5D%5Bdivider_height%5D=30&dzspgb%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=divider&dzspgb%5B0%5D%5B0%5D%5B1%5D%5Btext%5D=%3Ch3+class%3D%7Breplacequotquot%7Dwidget-title%7Breplacequotquot%7D%3EMost+Liked%3C%2Fh3%3E&dzspgb%5B0%5D%5B0%5D%5B1%5D%5Bkill_tinymce%5D=off&dzspgb%5B0%5D%5B0%5D%5B1%5D%5Btype_element%5D=text&dzspgb%5B0%5D%5B0%5D%5B2%5D%5Bstyle%5D=list&dzspgb%5B0%5D%5B0%5D%5B2%5D%5Bquery_type%5D=auto&dzspgb%5B0%5D%5B0%5D%5B2%5D%5Bpagination%5D=auto&dzspgb%5B0%5D%5B0%5D%5B2%5D%5Bapconfig%5D=2&dzspgb%5B0%5D%5B0%5D%5B2%5D%5Blimit_posts%5D=5&dzspgb%5B0%5D%5B0%5D%5B2%5D%5Bquery_query%5D=&dzspgb%5B0%5D%5B0%5D%5B2%5D%5Bextra_classes%5D=&dzspgb%5B0%5D%5B0%5D%5B2%5D%5Bpost_type%5D=&dzspgb%5B0%5D%5B0%5D%5B2%5D%5Btype_element%5D=query&dzspgb%5B0%5D%5B0%5D%5B3%5D%5Btext%5D=%3Ch3+class%3D%7Breplacequotquot%7Dwidget-title%7Breplacequotquot%7D%3EFeatured+Artists%3C%2Fh3%3E&dzspgb%5B0%5D%5B0%5D%5B3%5D%5Bkill_tinymce%5D=off&dzspgb%5B0%5D%5B0%5D%5B3%5D%5Btype_element%5D=text&dzspgb%5B0%5D%5B0%5D%5B4%5D%5Bstyle%5D=thumbs&dzspgb%5B0%5D%5B0%5D%5B4%5D%5Btype%5D=auto&dzspgb%5B0%5D%5B0%5D%5B4%5D%5Bapconfig%5D=2&dzspgb%5B0%5D%5B0%5D%5B4%5D%5Bids%5D=1%2C14%2C20&dzspgb%5B0%5D%5B0%5D%5B4%5D%5Btype_element%5D=artist_query&dzspgb%5B0%5D%5B0%5D%5B5%5D%5Bdivider_height%5D=10&dzspgb%5B0%5D%5B0%5D%5B5%5D%5Btype_element%5D=divider&dzspgb%5B0%5D%5B0%5D%5B6%5D%5Btext%5D=%3Ch3+class%3D%7Breplacequotquot%7Dwidget-title%7Breplacequotquot%7D%3EAd+Space%3C%2Fh3%3E&dzspgb%5B0%5D%5B0%5D%5B6%5D%5Bkill_tinymce%5D=off&dzspgb%5B0%5D%5B0%5D%5B6%5D%5Btype_element%5D=text&dzspgb%5B0%5D%5B0%5D%5B7%5D%5Bimage%5D=upload%2Fadspace_1.png&dzspgb%5B0%5D%5B0%5D%5B7%5D%5Bextra_classes%5D=&dzspgb%5B0%5D%5B0%5D%5B7%5D%5Btype_element%5D=image&dzspgb%5B0%5D%5B0%5D%5B8%5D%5Bdivider_height%5D=10&dzspgb%5B0%5D%5B0%5D%5B8%5D%5Btype_element%5D=divider&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstyle%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bapconfig%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bids%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=artist_query&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bnr_columns%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Baudio_track%5D%5Btype%5D=multipleitems&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=audio_playlist&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Baudioplayer_style%5D=style_default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=audioplayer&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=breakout_final&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=breakout_first&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcover_image%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bvideo%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=calendar&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcheckout_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=checkout&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btrack_id%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=comments&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btrack_id%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=cover_image&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bdivider_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=divider&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcover_image%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bvideo%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=events&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bflickr_username%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bflickr_api_key%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=gallery&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bheader_style%5D=style-default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bmenu_select%5D=none&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=header&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bimage%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=image&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Blogin_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=login&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=messages&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=messages_friends&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=new_section&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bnr_columns%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem%5D%5Btype%5D=multipleitems&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem2%5D%5Btype%5D=multipleitems2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem3%5D%5Btype%5D=multipleitems3&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem4%5D%5Btype%5D=multipleitems4&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=pricing_table&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bstyle%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bquery_type%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bpagination%5D=auto&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bapconfig%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Blimit_posts%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bquery_query%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bpost_type%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=query&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bregister_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=register&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bitem%5D%5Btype%5D=multipleitems&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=slider&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btemplate_id%5D=2&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=templates&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bkill_tinymce%5D=off&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=text&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btext%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bupload_style%5D=style_default&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=upload&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&extra_classes=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=user&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Busersettings_height%5D=10&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=usersettings&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bcover_image%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bvideo%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_classes%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Bextra_text%5D=&newelement%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5B0%5D%5Btype_element%5D=videoplayer&dzspgb%5B0%5D%5B0%5D%5B0%5D%5Btype%5D=element");
');


    if ($this->dblink->errno) {
        die('Error : '. $this->dblink->error);
    }

}




$val = $this->dblink->query('select 1 from likes');

if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!
}else{
    $val2 = $this->dblink->query("CREATE TABLE `likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `id_user` int(11) NOT NULL,
  `track_id` int(11) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

//Output any connection error
    if ($this->dblink->errno) {
        die('Error : '. $this->dblink->error);
    }




}







$val = $this->dblink->query('select 1 from menus');

if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!
}else{
    $val2 = $this->dblink->query("CREATE TABLE `menus` (
  `id` int(255) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `author_id` int(11) NOT NULL,
  `published_date` date NOT NULL,
  `content` longtext NOT NULL,
  `title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");




    $val2 = $this->dblink->query('
INSERT INTO menus VALUES("1","1","2015-10-06","[{\"visibility_type\":\"always\",\"content\":\"\",\"type\":\"menupage\",\"label\":\"Explore\",\"id\":20},{\"visibility_type\":\"always\",\"content\":\"\",\"type\":\"menupage\",\"label\":\"Page Upload\",\"id\":18}]","mainmenu");

'
    );
    $val2 = $this->dblink->query('
INSERT INTO menus VALUES("2","1","2015-10-25","[{\"visibility_type\":\"always\",\"content\":\"<span class={replacequotquot}copyright-text{replacequotquot}>© copyright DZS 2015</span><br> \",\"type\":\"customhtml\",\"label\":\"Custom HTML\",\"id\":0},{\"visibility_type\":\"always\",\"content\":\"\",\"type\":\"menupage\",\"label\":\"Legal\",\"id\":31},{\"content\":\"Cookies\",\"type\":\"menupage\",\"label\":\"Legal\",\"id\":31},{\"content\":\"Privacy Policy\",\"type\":\"menupage\",\"label\":\"Legal\",\"id\":31}]","footer-menu");
');
    $val2 = $this->dblink->query('
INSERT INTO menus VALUES("3","1","2016-01-25","[{\"visibility_type\":\"always\",\"content\":\"\",\"type\":\"menupage\",\"label\":\"Explore\",\"id\":20},{\"visibility_type\":\"always\",\"content\":\"\",\"type\":\"menupage\",\"label\":\"Charts\",\"id\":33}]","charts-explore");
');


//Output any connection error
    if ($this->dblink->errno) {
        die('Error : '. $this->dblink->error);
    }

}










$val = $this->dblink->query('select 1 from messages');

if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!
}else{
    $val2 = $this->dblink->query("CREATE TABLE `messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `author_id` int(10) unsigned NOT NULL,
  `id_receiver` int(10) unsigned NOT NULL,
  `published_date` datetime NOT NULL,
  `content` longtext NOT NULL,
  `read_status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;");

//Output any connection error
    if ($this->dblink->errno) {
        die('Error : '. $this->dblink->error);
    }

}









$val = $this->dblink->query('select 1 from pages');

if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!
}else{
    $val2 = $this->dblink->query("CREATE TABLE `pages` (
  `id` int(255) UNSIGNED  AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `author_id` int(255) NOT NULL,
  `published_date` date NOT NULL,
  `content` longtext NOT NULL,
  `title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");






    $val2 = $this->dblink->query('
INSERT INTO pages VALUES("1","1","2015-11-25","[dzspgb_row][dzspgb_row_part part=\"3.4\"][dzspgb_element divider_height=\"30\" is_negative=\"\" type_element=\"divider\"][/dzspgb_element][dzspgb_element style=\"slider\" query_type=\"custom_ids\" pagination=\"auto\" apconfig=\"1\" limit_posts=\"\" query_query=\"1,2\" extra_classes=\"\" post_type=\"\" type_element=\"query\"][/dzspgb_element][dzspgb_element text=\"<h2 class={replacequotquot}section-title{replacequotquot}>Become a Pro Member</h2>\" kill_tinymce=\"off\" type_element=\"text\"][/dzspgb_element][dzspgb_element template_id=\"2\" type_element=\"templates\"][/dzspgb_element][dzspgb_element text=\"<h2 class={replacequotquot}section-title{replacequotquot}>Featured</h2>\" kill_tinymce=\"off\" type_element=\"text\"][/dzspgb_element][dzspgb_element style=\"thumbs\" query_type=\"auto\" pagination=\"auto\" apconfig=\"1\" limit_posts=\"\" query_query=\"\" extra_classes=\"\" post_type=\"\" type_element=\"query\"][/dzspgb_element][/dzspgb_row_part][dzspgb_row_part part=\"1.4\"][dzspgb_element divider_height=\"30\" is_negative=\"\" type_element=\"divider\"][/dzspgb_element][dzspgb_element style=\"list\" query_type=\"auto\" pagination=\"auto\" apconfig=\"1\" limit_posts=\"10\" query_query=\"\" extra_classes=\"color-white\" post_type=\"\" type_element=\"query\"][/dzspgb_element][dzspgb_element image=\"upload/adspace_1.png\" extra_classes=\"2\" type_element=\"image\"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row]","Homepage");

'
    );



    $val2 = $this->dblink->query('
INSERT INTO pages VALUES("18","1","2015-09-25","[dzspgb_row][dzspgb_row_part part=\"1.1\"][dzspgb_element divider_height=\"32\" type_element=\"divider\"][/dzspgb_element][dzspgb_element text=\"\" upload_style=\"style_new\" type_element=\"upload\"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row]","Upload");
');

    $val2 = $this->dblink->query('
INSERT INTO pages VALUES("19","1","2015-09-26","[dzspgb_row][dzspgb_row_part part=\"3.4\"][dzspgb_element divider_height=\"30\" is_negative=\"\" type_element=\"divider\"][/dzspgb_element][dzspgb_element style=\"auto\" query_type=\"auto\" pagination=\"scroll\" apconfig=\"1\" limit_posts=\"3\" query_query=\"\" extra_classes=\"\" post_type=\"\" type_element=\"query\"][/dzspgb_element][/dzspgb_row_part][dzspgb_row_part part=\"1.4\"][dzspgb_element template_id=\"11\" type_element=\"templates\"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row]","Page Tracklist");
');




    $val2 = $this->dblink->query('
INSERT INTO pages VALUES("20","1","2015-09-26","[dzspgb_row column_padding=\"default\"][dzspgb_row_part part=\"3.4\"][dzspgb_element divider_height=\"30\" type_element=\"divider\"][/dzspgb_element][dzspgb_element menu_select=\"3\" type_element=\"inline_menu\"][/dzspgb_element][dzspgb_element style=\"auto\" query_type=\"auto\" interval=\"alltime\" thumbs_per_row=\"33.33%\" thumbs_bullets_position=\"bottom\" thumbs_disable_arrows=\"off\" thumbs_display_title_and_price=\"off\" style_thumb_replace_page=\"Explore Page\" pagination=\"scroll\" limit_posts=\"3\" apconfig=\"1\" extra_classes=\"main-target-for-inline-menu\" post_type=\"track,soundcloud\" call_from_lab=\"debug\" type_element=\"query\"][/dzspgb_element][/dzspgb_row_part][dzspgb_row_part part=\"1.4\"][dzspgb_element template_id=\"11\" type_element=\"templates\"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row]","Explore");

'
    );


    $val2 = $this->dblink->query('
INSERT INTO pages VALUES("21","1","2015-10-04","[dzspgb_section extra_classes=\"main-section-register\"][dzspgb_container use_template=\"none\"][dzspgb_row][dzspgb_row_part part=\"1.1\"][dzspgb_element register_height=\"10\" type_element=\"register\"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row][/dzspgb_container][/dzspgb_section]","Page Register");

'
    );


    $val2 = $this->dblink->query('
INSERT INTO pages VALUES("22","1","2015-10-08",\'[dzspgb_row column_padding="default"][dzspgb_row_part part="1.1"][dzspgb_element type_element="breakout_first"][/dzspgb_element][dzspgb_element type_element="cover_image"][/dzspgb_element][dzspgb_element type_element="breakout_final"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row][dzspgb_row column_padding="default"][dzspgb_row_part part="1.1"][dzspgb_element divider_height="10" type_element="divider"][/dzspgb_element][dzspgb_element style="auto" query_type="auto" interval="alltime" thumbs_per_row="33.33%" thumbs_bullets_position="bottom" thumbs_disable_arrows="off" thumbs_display_title_and_price="off" pagination="auto" apconfig="1" type_element="query"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row][dzspgb_row column_padding="default"][dzspgb_row_part part="3.4"][dzspgb_element type_element="comments"][/dzspgb_element][/dzspgb_row_part][dzspgb_row_part part="1.4"][dzspgb_element text="<h3 class={replacequotquot}widget-title{replacequotquot}>Similar Tracks</h3>" kill_tinymce="off" type_element="text"][/dzspgb_element][dzspgb_element style="list" query_type="auto" interval="alltime" thumbs_per_row="33.33%" thumbs_bullets_position="bottom" thumbs_disable_arrows="off" thumbs_display_title_and_price="off" pagination="auto" limit_posts="3" apconfig="1" type_element="query"][/dzspgb_element][dzspgb_element text="<p><a data-source={replacequotquot}#reportcopyright{replacequotquot} class={replacequotquot}ultibox-item-delegated{replacequotquot} data-suggested-width={replacequotquot}400{replacequotquot} data-suggested-height={replacequotquot}300{replacequotquot} data-scaling={replacequotquot}fill{replacequotquot}>Report copyright infrigment</a></p>" kill_tinymce="on" type_element="text"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row]\',"Page Track");

'
    );



    $val2 = $this->dblink->query('
INSERT INTO pages VALUES("24","1","2015-10-15","[dzspgb_row][dzspgb_row_part part=\"1.1\"][dzspgb_element divider_height=\"10\" is_negative=\"\" type_element=\"divider\"][/dzspgb_element][dzspgb_element checkout_height=\"10\" type_element=\"checkout\"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row]","Page Checkout");
'
    );





    $val2 = $this->dblink->query('
INSERT INTO pages VALUES("25","1","2015-10-24","[dzspgb_row column_padding=\"default\"][dzspgb_row_part part=\"1.1\"][dzspgb_element type_element=\"breakout_first\"][/dzspgb_element][dzspgb_element extra_classes=\"negative-margin-top\" type_element=\"10\" type_element=\"user\"][/dzspgb_element][dzspgb_element type_element=\"breakout_final\"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row][dzspgb_row extra_classes=\"user-query\" column_padding=\"default\"][dzspgb_row_part part=\"3.4\"][dzspgb_element divider_height=\"10\" type_element=\"divider\"][/dzspgb_element][dzspgb_element style=\"auto\" query_type=\"auto\" interval=\"alltime\" thumbs_per_row=\"33.33%\" thumbs_bullets_position=\"bottom\" thumbs_disable_arrows=\"off\" thumbs_display_title_and_price=\"off\" style_thumb_replace_page=\"Explore Page\" pagination=\"scroll\" limit_posts=\"5\" apconfig=\"1\" call_from_lab=\"page_user\" type_element=\"query\"][/dzspgb_element][/dzspgb_row_part][dzspgb_row_part part=\"1.4\"][dzspgb_element divider_height=\"10\" type_element=\"divider\"][/dzspgb_element][dzspgb_element text=\"<h3 class={replacequotquot}widget-title{replacequotquot}><i class={replacequotquot}fa fa-user{replacequotquot}></i> About</h3>\" kill_tinymce=\"off\" type_element=\"text\"][/dzspgb_element][dzspgb_element id_user=\"auto\" type=\"description\" type_element=\"widget_stats\"][/dzspgb_element][dzspgb_element divider_height=\"10\" type_element=\"divider\"][/dzspgb_element][dzspgb_element text=\"<h3 class={replacequotquot}widget-title{replacequotquot}><i class={replacequotquot}fa fa-thumbs-up{replacequotquot}></i>Likes</h3>\" kill_tinymce=\"off\" type_element=\"text\"][/dzspgb_element][dzspgb_element id_user=\"auto\" type=\"likes\" type_element=\"widget_stats\"][/dzspgb_element][dzspgb_element divider_height=\"10\" type_element=\"divider\"][/dzspgb_element][dzspgb_element text=\"<h3 class={replacequotquot}widget-title{replacequotquot}><i class={replacequotquot}fa fa-users{replacequotquot}></i> Followers</h3>\" kill_tinymce=\"off\" type_element=\"text\"][/dzspgb_element][dzspgb_element id_user=\"auto\" type=\"followers\" type_element=\"widget_stats\"][/dzspgb_element][dzspgb_element divider_height=\"10\" type_element=\"divider\"][/dzspgb_element][dzspgb_element text=\"<h3 class={replacequotquot}widget-title{replacequotquot}><i class={replacequotquot}fa fa-gears{replacequotquot}></i>Stats</h3>\" kill_tinymce=\"off\" type_element=\"text\"][/dzspgb_element][dzspgb_element id_user=\"auto\" type=\"stats\" type_element=\"widget_stats\"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row]","Page User");

'
    );




    $val2 = $this->dblink->query('
INSERT INTO pages VALUES("27","4","2015-11-04","[dzspgb_row][dzspgb_row_part part=\"1.1\"][dzspgb_element divider_height=\"30\" is_negative=\"\" type_element=\"divider\"][/dzspgb_element][dzspgb_element usersettings_height=\"10\" type_element=\"usersettings\"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row]","Page User Settings");
'
    );






    $val2 = $this->dblink->query('
INSERT INTO pages VALUES("29","5","2015-12-09","[dzspgb_row][dzspgb_row_part part=\"3.4\"][dzspgb_element divider_height=\"30\" is_negative=\"\" type_element=\"divider\"][/dzspgb_element][dzspgb_element text=\"<h3>Pro Accounts</h3><p>With a PRO account, you can upload more files and get the infamous PRO badge. It allows you to upload bigger tracks, so if you wanted to upload a mix for example, you can do it only via a PRO account.</p><p>Here is a list of PRO features</p>\" kill_tinymce=\"off\" type_element=\"text\"][/dzspgb_element][dzspgb_element nr_columns=\"2\" extra_classes=\"color-table\" item=\"multipleitems\" item2=\"multipleitems\" item3=\"multipleitems2\" item4=\"multipleitems4\" type_element=\"pricing_table\"][dzspgb_item label=\"item\" imgsource=\"Normal User\" extra_classes=\"title-item\"][/dzspgb_item][dzspgb_item label=\"item\" imgsource=\"100M Upload Limit\" extra_classes=\"\"][/dzspgb_item][dzspgb_item label=\"item\" imgsource=\"5M Max Track Size\" extra_classes=\"\"][/dzspgb_item][dzspgb_item label=\"item\" imgsource=\"No Pro Badge\" extra_classes=\"\"][/dzspgb_item][dzspgb_item label=\"item\" imgsource=\"No Feature\" extra_classes=\"\"][/dzspgb_item][dzspgb_item label=\"item\" imgsource=\"<a href={replacequotquot}#{replacequotquot} data-playerid={replacequotquot}proaccount{replacequotquot} class={replacequotquot}active button button--secondary{replacequotquot}><span class={replacequotquot}button-label{replacequotquot}>Included</span></a>\" extra_classes=\"purchase-item\"][/dzspgb_item][dzspgb_item label=\"item2\" imgsource=\"Pro User\" extra_classes=\"title-item\"][/dzspgb_item][dzspgb_item label=\"item2\" imgsource=\"500MB Upload Limit\" extra_classes=\"\"][/dzspgb_item][dzspgb_item label=\"item2\" imgsource=\"100M Max Track Size\" extra_classes=\"\"][/dzspgb_item][dzspgb_item label=\"item2\" imgsource=\"Pro Badge <i class={replacequotquot}fa fa-star{replacequotquot}></i>\" extra_classes=\"\"][/dzspgb_item][dzspgb_item label=\"item2\" imgsource=\"Featured 1 Month\" extra_classes=\"\"][/dzspgb_item][dzspgb_item label=\"item2\" imgsource=\"<a href={replacequotquot}#{replacequotquot} data-playerid={replacequotquot}proaccount{replacequotquot} class={replacequotquot}add-to-cart-btn button button--secondary{replacequotquot}><span class={replacequotquot}button-label{replacequotquot}>Get PRO</span></a>\" extra_classes=\"purchase-item\"][/dzspgb_item][dzspgb_item label=\"item3\" imgsource=\"items3_1\" extra_classes=\"itme 3\"][/dzspgb_item][dzspgb_item label=\"item4\" imgsource=\"items4_1\" extra_classes=\"\"][/dzspgb_item][dzspgb_item label=\"item4\" imgsource=\"items4_2\" extra_classes=\"\"][/dzspgb_item][/dzspgb_element][/dzspgb_row_part][dzspgb_row_part part=\"1.4\"][dzspgb_element template_id=\"11\" type_element=\"templates\"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row]","Pro Users");
'
    );




    $val2 = $this->dblink->query('
INSERT INTO pages VALUES("30","1","2015-12-26","[dzspgb_section][dzspgb_container use_template=\"none\"][dzspgb_row][dzspgb_row_part part=\"1.1\"][dzspgb_element style=\"auto\" type=\"auto\" pagination=\"auto\" apconfig=\"1\" limit_posts=\"\" query_query=\"\" extra_classes=\"\" type_element=\"query\"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row][/dzspgb_container][/dzspgb_section]","Page Embed");

'
    );






    $val2 = $this->dblink->query('
INSERT INTO pages VALUES("31","5","2016-02-26","[dzspgb_row][dzspgb_row_part part=\"1.1\"][dzspgb_element divider_height=\"30\" is_negative=\"\" type_element=\"divider\"][/dzspgb_element][dzspgb_element text=\"<p><strong><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>Cookie Policy for ZoomSounds</span></strong><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><strong><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>What Are Cookies</span></strong><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>As is common practice with almost all professional websites this site uses cookies, which are tiny files that are downloaded to your computer, to improve your experience. This page describes what information they gather, how we use it and why we sometimes need to store these cookies. We will also share how you can prevent these cookies from being stored however this may downgrade or \'break\' certain elements of the sites functionality.</span><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>For more general information on cookies see the Wikipedia article on HTTP Cookies...</span><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><strong><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>How We Use Cookies</span></strong><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>We use cookies for a variety of reasons detailed below. Unfortunately in most cases there are no industry standard options for disabling cookies without completely disabling the functionality and features they add to this site. It is recommended that you leave on all cookies if you are not sure whether you need them or not in case they are used to provide a service that you use.</span><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><strong><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>Disabling Cookies</span></strong><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>You can prevent the setting of cookies by adjusting the settings on your browser (see your browser Help for how to do this). Be aware that disabling cookies will affect the functionality of this and many other websites that you visit. Disabling cookies will usually result in also disabling certain functionality and features of the this site. Therefore it is recommended that you do not disable cookies.</span><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><strong><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>The Cookies We Set</span></strong><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>If you create an account with us then we will use cookies for the management of the signup process and general administration. These cookies will usually be deleted when you log out however in some cases they may remain afterwards to remember your site preferences when logged out.</span><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>We use cookies when you are logged in so that we can remember this fact. This prevents you from having to log in every single time you visit a new page. These cookies are typically removed or cleared when you log out to ensure that you can only access restricted features and areas when logged in.</span><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>This site offers e-commerce or payment facilities and some cookies are essential to ensure that your order is remembered between pages so that we can process it properly.</span><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><strong><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>Third Party Cookies</span></strong><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>In some special cases we also use cookies provided by trusted third parties. The following section details which third party cookies you might encounter through this site.</span><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>This site uses Google Analytics which is one of the most widespread and trusted analytics solution on the web for helping us to understand how you use the site and ways that we can improve your experience. These cookies may track things such as how long you spend on the site and the pages that you visit so we can continue to produce engaging content.</span><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>For more information on Google Analytics cookies, see the official Google Analytics page.</span><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>Third party analytics are used to track and measure usage of this site so that we can continue to produce engaging content. These cookies may track things such as how long you spend on the site or pages you visit which helps us to understand how we can improve the site for you.</span><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><strong><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>More Information</span></strong><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><br style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot} /><span style={replacequotquot}color: #333333; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 25px;{replacequotquot}>Hopefully that has clarified things for you and as was previously mentioned if there is something that you aren\'t sure whether you need or not it\'s usually safer to leave cookies enabled in case it does interact with one of the features you use on our site. However if you are still looking for more information then you can contact us through one of our preferred contact methods.</span></p>\" kill_tinymce=\"off\" type_element=\"text\"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row]","Legal");

'
    );




    $val2 = $this->dblink->query('
INSERT INTO pages VALUES("32","4","2016-03-04","[dzspgb_row][dzspgb_row_part part=\"2.3\"][dzspgb_element extra_classes=\"\" type_element=\"10\" is_negative=\"\" type_element=\"messages\"][/dzspgb_element][/dzspgb_row_part][dzspgb_row_part part=\"1.3\"][dzspgb_element extra_classes=\"\" type_element=\"10\" is_negative=\"\" type_element=\"messages_friends\"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row]","Page Messages");
'
    );


    $val2 = $this->dblink->query('
INSERT INTO pages VALUES("33","4","2016-03-04",\'[dzspgb_row column_padding="default"][dzspgb_row_part part="1.1"][dzspgb_element divider_height="30" type_element="divider"][/dzspgb_element][dzspgb_element menu_select="3" type_element="inline_menu"][/dzspgb_element][dzspgb_element divider_height="10" type_element="divider"][/dzspgb_element][dzspgb_element style="charts" query_type="mostviewed" interval="last168" thumbs_per_row="33.33%" thumbs_bullets_position="bottom" thumbs_disable_arrows="off" thumbs_display_title_and_price="off" pagination="auto" apconfig="2" extra_classes="main-target-for-inline-menu" type_element="query"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row]\',"Charts");
'
    );


    $val2 = $this->dblink->query('
INSERT INTO pages VALUES("34","4","2016-03-04",\'[dzspgb_row column_padding="default"][dzspgb_row_part part="1.1"][dzspgb_element text="<svg id={replacequotquot}Layer_1{replacequotquot} style={replacequotquot}enable-background:new 0 0 128 128;{replacequotquot} version={replacequotquot}1.1{replacequotquot} viewBox={replacequotquot}0 0 128 128{replacequotquot} xml:space={replacequotquot}preserve{replacequotquot} xmlns={replacequotquot}http://www.w3.org/2000/svg{replacequotquot} xmlns:xlink={replacequotquot}http://www.w3.org/1999/xlink{replacequotquot}><style type={replacequotquot}text/css{replacequotquot}>
	.st0{fill:#00AEBF;}
	.st1{fill:#FFFFFF;}
	.st2{fill:#EFF0F1;}
	.st3{fill:#2CBED3;}
	.st4{fill:#D3DBDB;}
	.st5{fill:#474F5A;}
	.st6{fill:#30363D;}
	.st7{fill:#84C78C;}
	.st8{fill:#F2856E;}
	.st9{fill:#EDBD3D;}
	.st10{fill:#F2D87E;}
	.st11{fill:#F7DB87;}
	.st12{fill:#C1DEB4;}
</style><g><circle class={replacequotquot}st0{replacequotquot} cx={replacequotquot}64{replacequotquot} cy={replacequotquot}64{replacequotquot} r={replacequotquot}63.5{replacequotquot}/><g><path class={replacequotquot}st6{replacequotquot} d={replacequotquot}M74.4,80.2h-8.7h-3.6h-8.7c0,0,1.3,5-8.9,9.8h17.6h3.6h17.6C73.1,85.2,74.4,80.2,74.4,80.2z{replacequotquot}/></g><path class={replacequotquot}st5{replacequotquot} d={replacequotquot}M97.2,35.4H30.8c-2.4,0-4.3,1.9-4.3,4.3v38.7c0,2.4,1.9,4.3,4.3,4.3h66.4c2.4,0,4.3-1.9,4.3-4.3V39.7   C101.5,37.3,99.6,35.4,97.2,35.4z{replacequotquot}/><path class={replacequotquot}st1{replacequotquot} d={replacequotquot}M31.1,77V41.1c0-0.6,0.5-1.1,1.1-1.1h63.6c0.6,0,1.1,0.5,1.1,1.1V77c0,0.6-0.5,1.1-1.1,1.1H32.2   C31.6,78.2,31.1,77.7,31.1,77z{replacequotquot}/><path class={replacequotquot}st5{replacequotquot} d={replacequotquot}M83.6,93.6H44.4c-1.3,0-2.3-0.8-2.3-1.8V91c0-1,1-1.8,2.3-1.8h39.2c1.3,0,2.3,0.8,2.3,1.8v0.8   C86,92.8,84.9,93.6,83.6,93.6z{replacequotquot}/><g><path class={replacequotquot}st8{replacequotquot} d={replacequotquot}M49.4,60.3v-2.9H53v2.9h1.9v3.2H53v4h-3.6v-4h-6.7v-2.8l5.9-9.8h4l-5.6,9.4H49.4z{replacequotquot}/><path class={replacequotquot}st8{replacequotquot} d={replacequotquot}M64.1,67.7c-2.3,0-4-0.8-5.2-2.3c-1.1-1.6-1.7-3.6-1.7-6.2c0-2.6,0.6-4.7,1.7-6.2c1.1-1.6,2.9-2.3,5.2-2.3    c2.3,0,4,0.8,5.2,2.3c1.1,1.6,1.7,3.6,1.7,6.2c0,2.6-0.6,4.7-1.7,6.2C68.1,66.9,66.4,67.7,64.1,67.7z M61.6,55.1    c-0.5,1-0.8,2.4-0.8,4c0,1.7,0.3,3,0.8,4c0.5,1,1.3,1.5,2.4,1.5c1.1,0,1.9-0.5,2.4-1.5c0.5-1,0.8-2.4,0.8-4c0-1.7-0.3-3-0.8-4    s-1.3-1.5-2.4-1.5C63,53.6,62.1,54.1,61.6,55.1z{replacequotquot}/><path class={replacequotquot}st8{replacequotquot} d={replacequotquot}M79.8,60.3v-2.9h3.6v2.9h1.9v3.2h-1.9v4h-3.6v-4h-6.7v-2.8l5.9-9.8h4l-5.6,9.4H79.8z{replacequotquot}/></g></g></svg>" kill_tinymce="on" type_element="text"][/dzspgb_element][dzspgb_element text="<p>The page you are looking for is not there</p>
<p><a href={replacequotquot}{{homepage}}{replacequotquot} class={replacequotquot}dzs-button btn-skin-vive ajax-link{replacequotquot}>Go to homepage</a></p>" kill_tinymce="off" type_element="text"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row]\',"Page 404");
'
    );


    $val2 = $this->dblink->query('
INSERT INTO pages VALUES("35","4","2016-03-04",\'[dzspgb_row column_padding="default"][dzspgb_row_part part="3.4"][dzspgb_element divider_height="30" type_element="divider"][/dzspgb_element][dzspgb_element style="under" query_type="stream" interval="alltime" thumbs_per_row="33.33%" thumbs_bullets_position="bottom" thumbs_disable_arrows="off" thumbs_display_title_and_price="off" style_thumb_replace_page="Explore Page" pagination="scroll" limit_posts="3" apconfig="1" post_type="track,soundcloud" call_from_lab="debug" type_element="query"][/dzspgb_element][/dzspgb_row_part][dzspgb_row_part part="1.4"][dzspgb_element template_id="11" type_element="templates"][/dzspgb_element][/dzspgb_row_part][/dzspgb_row]\',"Stream");
'
    );




//Output any connection error
    if ($this->dblink->errno) {
        die('Error : '. $this->dblink->error);
    }

}










$val = $this->dblink->query('select 1 from playlists');

if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!
}else{
    $val2 = $this->dblink->query("CREATE TABLE `playlists` (
  `id` int(11) UNSIGNED  AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `author_id` int(255) NOT NULL,
  `published_date` date NOT NULL,
  `description` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

//Output any connection error
    if ($this->dblink->errno) {
        die('Error : '. $this->dblink->error);
    }

}









$val = $this->dblink->query('select 1 from posts');

if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!
}else{
    $val2 = $this->dblink->query("CREATE TABLE `posts` (
  `id` int(255) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `author_id` int(11) NOT NULL,
  `published_date` datetime NOT NULL,
  `content` longtext NOT NULL,
  `post_type` varchar(255) NOT NULL,
  `title` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

//Output any connection error
    if ($this->dblink->errno) {
        die('Error : '. $this->dblink->error);
    }

}









$val = $this->dblink->query('select 1 from post_meta');

if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!
}else{
    $val2 = $this->dblink->query("CREATE TABLE `post_meta` (
  `id` int(10) UNSIGNED  AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `post_id` int(11) NOT NULL,
  `post_type` varchar(255) NOT NULL,
  `lab` longtext NOT NULL,
  `val` longtext NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");



    $val2 = $this->dblink->query('
INSERT INTO post_meta VALUES("1","1","page","use_template","10","0000-00-00");'
    );
    $val2 = $this->dblink->query('
INSERT INTO post_meta VALUES("2","18","page","use_template","10","0000-00-00");
'
    );
    $val2 = $this->dblink->query('
INSERT INTO post_meta VALUES("3","19","page","use_template","10","0000-00-00");'
    );
    $val2 = $this->dblink->query('
INSERT INTO post_meta VALUES("4","20","page","use_template","10","0000-00-00");
'
    );
    $val2 = $this->dblink->query('
INSERT INTO post_meta VALUES("6","22","page","use_template","10","0000-00-00");
'
    );
    $val2 = $this->dblink->query('
INSERT INTO post_meta VALUES("7","24","page","use_template","10","0000-00-00");
'
    );
    $val2 = $this->dblink->query('
INSERT INTO post_meta VALUES("8","25","page","use_template","10","0000-00-00");
'
    );
    $val2 = $this->dblink->query('
INSERT INTO post_meta VALUES("9","27","page","use_template","10","0000-00-00");
'
    );
    $val2 = $this->dblink->query('
INSERT INTO post_meta VALUES("13","29","page","use_template","10","0000-00-00");
'
    );
    $val2 = $this->dblink->query('
INSERT INTO post_meta VALUES("11","31","page","use_template","10","0000-00-00");
'
    );
    $val2 = $this->dblink->query('
INSERT INTO post_meta VALUES("12","32","page","use_template","10","0000-00-00");
'
    );
    $val2 = $this->dblink->query('
INSERT INTO post_meta VALUES("15","33","page","use_template","10","0000-00-00");
'
    );
    $val2 = $this->dblink->query('
INSERT INTO post_meta VALUES("16","34","page","use_template","10","0000-00-00");
'
    );
    $val2 = $this->dblink->query('
INSERT INTO post_meta VALUES("17","35","page","use_template","10","0000-00-00");
'
    );

//Output any connection error
    if ($this->dblink->errno) {
        die('Error : '. $this->dblink->error);
    }

}





















$val = $this->dblink->query('select 1 from `settings`');

if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!
}else{
    $val2 = $this->dblink->query('CREATE TABLE IF NOT EXISTS `settings` (
    `setting_id` int(10) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `setting_name` varchar(255) NOT NULL,
    `setting_value` longtext NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=latin1;');

//Output any connection error





    $val2 = $this->dblink->query('
INSERT INTO settings VALUES("1","mainsettings","theme=theme-default&use_ajax=on&home_is_stream=on&use_parallaxer=off&use_parallaxer=on&autoplay_next=off&autoplay_next=on&paths_are_absolute=off&allow_register=off&allow_register=on&disable_commenting=off&page_homepage=1&footer_player_config=2&color_waveformbg=%23585858&color_waveformprog=%23ef6b13&waveformgenerator_multiplier=1&logo=img%2Flogo.png&developer_paypal_sandbox_mode=off&developer_paypal_sandbox_mode=on&paypal_receiver_account=digitalzoomstudio%40gmail.com&pro_account_price=10&upload_limit_normal=20&upload_limit_pro=500&lang_1_text=English&lang_1_img=img%2Fusa.png&lang_1_code=en_EN&lang_2_text=Germany&lang_2_img=img%2Fgermany.png&lang_2_code=da_DK&lang_3_text=Spain&lang_3_img=img%2Fspain.png&lang_3_code=es_ES&debug_pagebuilder=off&debug_pagebuilder=on&use_ajax=on&home_is_stream=on&use_parallaxer=off&use_parallaxer=on&autoplay_next=off&autoplay_next=on&paths_are_absolute=off&allow_register=off&allow_register=on&disable_commenting=off&page_homepage=1&footer_player_config=2&extra_css=ceva+fly2&color_waveformbg=%23585858&color_waveformprog=%23ef6b13&waveformgenerator_multiplier=1&logo=img%2Flogo.png&developer_paypal_sandbox_mode=off&developer_paypal_sandbox_mode=on&paypal_receiver_account=digitalzoomstudio%40gmail.com&pro_account_price=10&upload_limit_normal=20&upload_limit_pro=500&lang_1_text=English&lang_1_img=img%2Fusa.png&lang_1_code=en_EN&lang_2_text=Germany&lang_2_img=img%2Fgermany.png&lang_2_code=da_DK&lang_3_text=Spain&lang_3_img=img%2Fspain.png&lang_3_code=es_ES&debug_pagebuilder=off");
'
    );




    if ($this->dblink->errno) {
        die('Error : '. $this->dblink->error);
    }





}






$val = $this->dblink->query('select 1 from `users`');

if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!
}else{
    $val2 = $this->dblink->query('CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` longtext NOT NULL,
  `date` datetime DEFAULT NULL,
  `avatar` longtext NOT NULL,
  `capabilities` longtext NOT NULL,
  `purchases` longtext NOT NULL,
  `connections` longtext NOT NULL,
  `ip_registered_from` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `country_code` varchar(10) DEFAULT NULL,
  `verify_status` varchar(15) DEFAULT NULL,
  `tags` mediumtext DEFAULT NULL,
  `second_avatar` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `stream_read` longtext DEFAULT NULL,
  `user_meta` longtext DEFAULT NULL,
  `facebook_link` longtext DEFAULT NULL,
  `twitter_link` longtext DEFAULT NULL,
  `soundcloud_link` longtext DEFAULT NULL,
  `paypal_email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;');

//Output any connection error
    if ($this->dblink->errno) {
        die('Error : '. $this->dblink->error);
    }


    $val2 = $this->dblink->query("INSERT INTO `users` (`id`, `username`, `email`, `password`, `date`, `avatar`, `capabilities`, `purchases`, `connections`, `ip_registered_from`, `location`, `role`) VALUES
(1, '".$this->main_config_settings['admin_user']."', '".$this->main_config_settings['admin_email']."', '".$this->main_config_settings['admin_password']."', '2015-09-25', '', 'a:1:{i:0;s:5:\"admin\";}', '', '', '', '', 'admin');
");

//Output any connection error
    if ($this->dblink->errno) {
        die('Error : '. $this->dblink->error);
    }

}






$val = $this->dblink->query('select 1 from views');

if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!
}else{
    $val2 = $this->dblink->query("CREATE TABLE `views` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `id_user` int(10) UNSIGNED NOT NULL,
  `ip` varchar(255) NOT NULL,
  `track_id` int(10) UNSIGNED NOT NULL,
  `date` datetime DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

//Output any connection error
    if ($this->dblink->errno) {
        die('Error : '. $this->dblink->error);
    }

}


$val = $this->dblink->query('select 1 from permalinks');

if($val !== FALSE){
    //DO SOMETHING! IT EXISTS!
}else{
    $val2 = $this->dblink->query("CREATE TABLE `permalinks` (
  `id` int(255) UNSIGNED NOT NULL,
  `permalink` mediumtext,
  `type` mediumtext NOT NULL,
  `type_type` mediumtext NOT NULL,
  `target_id` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

//Output any connection error
    if ($this->dblink->errno) {
        die('Error : '. $this->dblink->error);
    }

}

$val = $this->dblink->query('ALTER TABLE `permalinks` ADD PRIMARY KEY(`id`);');
$val = $this->dblink->query('ALTER TABLE  `permalinks` CHANGE  `id`  `id` INT( 255 ) UNSIGNED NOT NULL AUTO_INCREMENT ;');
$val = $this->dblink->query('ALTER TABLE  `permalinks` CHANGE  `type_type`  `type_type` MEDIUMTEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL ;');

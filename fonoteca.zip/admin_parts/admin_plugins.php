<?php
function part_plugins(){
    global $dzsap_portal,$dzspgb_forportal;
//    print_r($dzsap_portal);

    $page = 'plugins';
    $pagetitle = __('Plugins');
    ?>


    <div class="admin-wrap admin-wrap-for-plugins">


        <?php
        echo generate_admin_header(array(

            'title'=> $pagetitle,
            'page'=>$page
        ));



        $plugins = array();

        $directories = glob('plugins' . '/*' , GLOB_ONLYDIR);


//        print_r($directories);

        $plugins_list = array();

        foreach ($directories as $dir){
//            print_r($dir);



            $files = glob($dir . '/*' );





            foreach ($files as $fil){

//                echo dirname(__FILE__).'/'.$fil.',';


//                $file_path = dirname(dirname(__FILE__)).'/'.$fil;
                $file_path = $fil;


//                echo $file_path;
                $file_contents = file_get_contents($file_path);


                $output_array=array();

                preg_match_all("/Plugin Name: (.*?)$[\s|\S]*Author: (.*?)$/m", $file_contents, $output_array);


//                print_r($output_array);


                if(count($output_array[0])){




                    $aux = array(
                        'name'=>$output_array[1][0],
                        'author'=>$output_array[2][0],
                        'location'=>$file_path,
                    );

                    array_push($plugins_list, $aux);

                    break;
                }
            }

        }


        foreach ($plugins_list as $lab => $plg){
            if(in_array($plg['location'],$dzsap_portal->main_settings['active_plugins'])){
                $plugins_list[$lab]['active']='on';
            }else{
                $plugins_list[$lab]['active']='off';
            }
        }
//        print_r($plugins_list);


        ?>




        <div class="dzspb_lay_con">
            <div class="dzspb_layb_one_full">
                <div class="admin-breadcrumps">
                    <a href="admin.php"><i class="fa fa-home"></i>&nbsp;&nbsp;<?php echo __("Home"); ?></a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;<span class="current-page" ><?php echo __("Plugins"); ?></span>
                </div>
            </div>
        </div>


        <div class="dzs-row">


            <div class="dzs-col-md-12">



                <table class="pages-table ">
                    <thead>
                    <tr>
                        <th class="column-name"><?php echo __("Plugin"); ?></th>
                        <th class="column-author"><?php echo __("Author"); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php

                            foreach ($plugins_list as $lab => $plg){
                                echo '<tr class="';
                                if($plg['active']=='on'){
                                    echo ' active';
                                }

                                echo '">';


                                echo '<td class="user-name">';
                                echo $plg['name'];

                                if($plg['active']=='on'){
                                    echo '<br><a href="?deactivate_plugin='.$plg['location'].'">'.__("Deactivate").'</a>';

                                }else{
                                    $curr_url = dzs_curr_url();
                                    $curr_url = remove_query_arg('activate_plugin');
                                    $curr_url = remove_query_arg('deactivate_plugin');
                                    echo '<br><a href="?activate_plugin='.$plg['location'].'">'.__("Activate").'</a>';
                                }

                                echo '</td>';

                                echo '<td class="user-email">';
                                echo $plg['author'];
                                echo '</td>';


                                echo '</tr>';
                            }


                            ?>

                    </tbody>
                </table>
                <div class="separator general-margin"></div>

            </div>

        </div>

    </div>





    <?php
}

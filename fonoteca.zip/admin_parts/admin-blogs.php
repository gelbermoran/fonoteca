<?php
function part_blogs(){
    global $dzsap_portal,$dzspgb_forportal;
//    print_r($dzsap_portal);

    $page = 'blogs';
    $pagetitle = __('Blogs');
    ?>


    <div class="admin-wrap admin-wrap-for-blogs">


        <?php
        echo generate_admin_header(array(

            'title'=> $pagetitle,
            'page'=>$page
        ));
        ?>




        <div class="dzspb_lay_con">
            <div class="dzspb_layb_one_full">
                <div class="admin-breadcrumps">
                    <a href="admin.php"><i class="fa fa-home"></i>&nbsp;&nbsp;Home</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;<span class="current-page" ><?php echo __("Blogs"); ?></span>
                </div>
            </div>
        </div>
        <div class="dzspb_lay_con">


            <div class="dzspb_layb_one_full">



                <table class="pages-table loading">
                    <thead>
                    <tr>
                        <th class="column-name"><?php echo __("Name"); ?></th>
                        <th class="column-author"><?php echo __("Author"); ?></th>
                        <th class="column-date"><?php echo __("Date"); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>loading...</td>
                    </tr>

                    </tbody>
                </table>
                <div class="separator general-margin"></div>
                <h2><?php echo __("Create new Post"); ?></h2>
                <div class="big-field-con">
                    <button class="btn-add-page">NEW POST</button>
                    <div class="big-field-div" placeholder="<?php echo __("enter here a new page name... "); ?>"><input class="bigfield" name="newpage_name"/></div>

                </div>

            </div>
        </div>

    </div>



    <?php
}

<?php
function part_reports(){
    global $dzsap_portal,$dzspgb_forportal;
//    print_r($dzsap_portal);

    $page = 'reports';
    $pagetitle = __('Reports');
    ?>


    <div class="admin-wrap admin-wrap-for-reports">


        <?php
        echo generate_admin_header(array(

            'title'=> $pagetitle,
            'page'=>$page
        ));
        ?>




        <div class="dzspb_lay_con">
            <div class="dzspb_layb_one_full">
                <div class="admin-breadcrumps">
                    <a href="admin.php"><i class="fa fa-home"></i>&nbsp;&nbsp;<?php echo __("Home"); ?></a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;<span class="current-page" ><?php echo __("Reports"); ?></span>
                </div>
            </div>
        </div>
        <div class="dzspb_lay_con">


            <div class="dzspb_layb_one_full">



                <table class="pages-table loading">
                    <thead>
                    <tr>
                        <th class="column-name"><?php echo __("Content"); ?></th>
                        <th class="column-author"><?php echo __("Reporter"); ?></th>
                        <th class="column-date"><?php echo __("Date"); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>loading...</td>
                    </tr>

                    </tbody>
                </table>
                <div class="separator general-margin"></div>

            </div>
        </div>

    </div>



    <?php
}

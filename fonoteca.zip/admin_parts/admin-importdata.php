<?php

function generate_table_str($pargs = array()){
    $margs = array(
        'table_name' => 'activity'
    ,'table_lab' => __("Activity")
    );

    if($pargs){
        $margs = array_merge($margs, $pargs);
    }

    $fout = '';

    $fout.='<div class="setting">
    <h6>'.$margs['table_lab'];


//    print_r($margs);
    if($margs['table_name']!=='*'){
        $fout.='- <span class="delete-table" data-table="'.$margs['table_name'].'">'.__("Delete Table Data").'</span>';
    }

    $fout.='</h6>


                    <form class="import-data-form import-data-'.$margs['table_name'].'" data-table="'.$margs['table_name'].'" name="" method="post">
                        <div class="dzs-upload-con">
                            <input type="text" class="simple-input-field target-field field-source" name="source"/>
                    <span class="dzs-single-upload">
                        <input class="" name="file_field" type="file" accept="">
                    </span>
                        </div>
                        <div class="sidenote">'.__("Upload the .sql file, then click the Import Data button.").'</div>
                        <br>
                        <button class="button--secondary button" style="padding: 4px 20px 6px;"><span class="button-label">'.__("Import Data").'</span></button>
                    </form>
</div>';

    return $fout;
}

function part_importdata(){
    global $dzsap_portal;
    global $dzspgb_forportal;
//    print_r($dzsap_portal);

    $page = 'importdata';
    $pagetitle = __('Import Data');

    ?>
    <div class="admin-wrap admin-wrap-importdata">


        <?php
        echo generate_admin_header(array(

            'title'=> $pagetitle,
            'page'=>$page,
            'extra_html_before_title-header'=>'<div class="float-right"><a class="btn-white btn-export-db" href="index.php">'.__("Backup Database").'</a></div>',
        ));
        ?>



        <div class="dzspb_lay_con">
            <div class="dzspb_layb_one_full">
                <div class="admin-breadcrumps">
                    <a href="admin.php"><i class="fa fa-home"></i>&nbsp;&nbsp;Home</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;<span class="current-page" ><?php echo $pagetitle; ?></span>
                </div>
            </div>
        </div>
        <!--
        <div class="row">

            <div class="col-md-12">
                <h2 style="margin-bottom: 0; margin-top: 15px;"><?php echo __("Import Table"); ?></h2>
            </div>

            <div class="col-md-6">

                <?php
                echo generate_table_str(array(
                    'table_name' => 'activity'
                ,'table_lab' => __("Activity")
                ));


                ?>




                <?php
                echo generate_table_str(array(
                    'table_name' => 'apconfigs'
                ,'table_lab' => __("Audio Player Configs Table")
                ));


                ?>





                <?php
                echo generate_table_str(array(
                    'table_name' => 'comments'
                ,'table_lab' => __("Comments Table")
                ));


                ?>

                <?php
                echo generate_table_str(array(
                    'table_name' => 'dzspgb_templates'
                ,'table_lab' => __("Templates Table")
                ));


                ?>




                <?php
                echo generate_table_str(array(
                    'table_name' => 'likes'
                ,'table_lab' => __("Likes Table")
                ));


                ?>





                <?php
                echo generate_table_str(array(
                    'table_name' => 'menus'
                ,'table_lab' => __("Menus Table")
                ));


                ?>




                <?php
                echo generate_table_str(array(
                    'table_name' => 'messages'
                ,'table_lab' => __("Messages Table")
                ));


                ?>





            </div>

            <div class="col-md-6">

                <?php



                //            print_r($dzsap_portal->main_importdata);
                ?>










                <?php
                echo generate_table_str(array(
                    'table_name' => 'pages'
                ,'table_lab' => __("Pages Table")
                ));


                ?>





                <?php
                echo generate_table_str(array(
                    'table_name' => 'playlists'
                ,'table_lab' => __("Playlists Table")
                ));


                ?>




                <?php
                echo generate_table_str(array(
                    'table_name' => 'post_meta'
                ,'table_lab' => __("Post Meta Table")
                ));


                ?>






                <?php
                echo generate_table_str(array(
                    'table_name' => 'settings'
                ,'table_lab' => __("Settings Table")
                ));


                ?>





                <?php
                echo generate_table_str(array(
                    'table_name' => 'tracks'
                ,'table_lab' => __("Tracks Table")
                ));


                ?>




                <?php
                echo generate_table_str(array(
                    'table_name' => 'users'
                ,'table_lab' => __("Users Table")
                ));


                ?>


                <?php
                echo generate_table_str(array(
                    'table_name' => 'views'
                ,'table_lab' => __("Views Table")
                ));


                ?>








            </div>


        </div>
            -->

        <div class="row">


            <div class="col-md-12">
                <h2 style="margin-bottom: 0; margin-top: 15px;"><?php echo __("Import Whole Database"); ?></h2>
            </div>



            <div class="col-md-6">


                <?php
//                echo generate_table_str(array(
//                    'table_name' => 'views'
//                ,'table_lab' => __("Views Table")
//                ));


                ?>

                <?php
                echo generate_table_str(array(
                    'table_name' => '*'
                ,'table_lab' => __("All Database")
                ));
                ?>

                <p class="sidenote"><?php echo sprintf('%s <a href="'.$dzsap_portal->optional_url_base.'index.php?page=backupdb" target="_blank">%s</a>', __("Export the database by accessing  "), __("this link") ); ?></p>
            </div>


        </div>
        <div class="row">


            <?php
            $lab = 'dzsapp_import_data_nonce';
            $aux = rand(0,10000);
            $_SESSION[$lab] = $aux;
            echo '<input type="hidden" name="'.$lab.'" value="'.$aux.'"/>';
            ?>
            <div class="col-md-12">
                <h2 style="margin-bottom: 0; margin-top: 15px;"><?php echo __("Import Demo"); ?></h2>
            </div>


</div>
        <div class="row">
            <div class="col-md-3">
                <img class="fullwidth btn-import-sample btn-import-sample-1" src="sample_dbs/sample1.png"/>
            </div>
            <div class="col-md-3">
                <img class="fullwidth btn-import-sample btn-import-sample-2" src="sample_dbs/sample2.png"/>
            </div>
            <div class="col-md-3">
                <img class="fullwidth btn-import-sample btn-import-sample-3" src="sample_dbs/sample3.png"/>
            </div>


        </div>
    </div>

    <script>
    </script>
    <?php
}

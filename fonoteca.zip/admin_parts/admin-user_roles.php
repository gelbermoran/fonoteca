<?php

function part_user_roles() {
    global $dzsap_portal;
    global $dzspgb_forportal;
//    print_r($dzsap_portal);

    $page = 'user_roles';
    $pagetitle = __('User Roles');




//    print_r($dzsap_portal->main_settings);
//    print_r(curl_version());

    ?>
    <div class="admin-wrap">


    <?php
    echo generate_admin_header(array(
        'title' => $pagetitle,
        'page' => $page
    ));
    ?>



        <div class="dzspb_lay_con">
            <div class="dzspb_layb_one_full">
                <div class="admin-breadcrumps">
                    <a href="admin.php"><i class="fa fa-home"></i>&nbsp;&nbsp;Home</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;<span class="current-page" ><?php echo $pagetitle; ?></span>
                </div>
            </div>
        </div>
        <div class="dzspb_lay_con">


    <?php
//            print_r($dzsap_portal->main_settings);
    ?>



            <div class="dzspb_layb_one_full">
                <form class="settings-form">

                    <div class="setting">



    <?php
    $lab = 'theme';

    $auxa = $dzsap_portal->get_setting('user_roles');

    $user_roles = (json_decode($auxa,true));

//    print_r($user_roles);

    //                        print_r($opts);
    ?>
                    </div>

                    <style>
                        body .dzs-checkbox-selector.skin-nova > label input:checked + .the-label{ background-color: #70b780; }
                    </style>


                    <h3><?php echo __("User Capabilities"); ?></h3>

                    <?php

                    $lab = 'user';





                    ;

                    ?>

                    <div class="dzs-checkbox-selector skin-nova">

                        <?php
                        foreach ($dzsap_portal->user_capabilities as $cap){

//                            print_r($cap);
                            echo '<label><input type="checkbox" name="'.$lab.'[]" value="'.$cap['value'].'"';

                            if(isset($user_roles[$lab])){

                                if(in_array($cap['value'],$user_roles[$lab])){
                                    echo ' checked';
                                }
                            }



                            echo '><span class="the-label"><span class="the-text">'.$cap['label'].'</span></span></label>';
                        }
                        ?>


                    </div>

                    <br>
                    <br>

                    <h3><?php echo __("Pro Capabilities"); ?></h3>

                    <?php

                    $lab = 'pro';


                    ?>

                    <div class="dzs-checkbox-selector skin-nova">

                        <?php
                        foreach ($dzsap_portal->user_capabilities as $cap){

//                            print_r($cap);
                            echo '<label><input type="checkbox" name="'.$lab.'[]" value="'.$cap['value'].'"';

                            if(isset($user_roles[$lab])){

                                if(in_array($cap['value'],$user_roles[$lab])){
                                    echo ' checked';
                                }
                            }



                            echo '><span class="the-label"><span class="the-text">'.$cap['label'].'</span></span></label>';
                        }
                        ?>


                    </div>

                    <br>
                    <br>

                    <h3><?php echo __("Admin Capabilities"); ?></h3>

                    <?php

                    $lab = 'admin';


                    ?>

                    <div class="dzs-checkbox-selector skin-nova">

                        <?php
                        foreach ($dzsap_portal->user_capabilities as $cap){

//                            print_r($cap);
                            echo '<label><input type="checkbox" name="'.$lab.'[]" value="'.$cap['value'].'"';

                            if(isset($user_roles[$lab])){

                                if(in_array($cap['value'],$user_roles[$lab])){
                                    echo ' checked';
                                }
                            }



                            echo '><span class="the-label"><span class="the-text">'.$cap['label'].'</span></span></label>';
                        }
                        ?>


                    </div>

                    <?php


                    foreach ($dzsap_portal->user_types as $ut){


                        if($ut['value']=='user' || $ut['value']=='pro' || $ut['value']=='admin'){
                            continue;
                        }



                        ?>



                        <br>
                        <br>

                        <h3><?php echo $ut['label']; ?> <?php echo __("Capabilities"); ?></h3>

                        <?php

                        $lab = $ut['value'];


                        ?>

                        <div class="dzs-checkbox-selector skin-nova">

                            <?php
                            foreach ($dzsap_portal->user_capabilities as $cap){

//                            print_r($cap);
                                echo '<label><input type="checkbox" name="'.$lab.'[]" value="'.$cap['value'].'"';

                                if(isset($user_roles[$lab])){

                                    if(in_array($cap['value'],$user_roles[$lab])){
                                        echo ' checked';
                                    }
                                }



                                echo '><span class="the-label"><span class="the-text">'.$cap['label'].'</span></span></label>';
                            }
                            ?>


                        </div>


                    <?php


//                        print_r($ut);


                    }

//                    print_r($dzsap_portal->user_types);

                    ?>



                    <br>
                    <br>

                    <div class="save-main-settings-con">
                        <button class="btn-primary btn-save-user-roles"><?php echo __("Save"); ?></button>
                    </div>

                    <br>
                    <br>
                    <br>

                </form>
            </div>


        </div>


    </div>
    <script>
    </script>
    
    
            <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
            <script src="jqueryui/jquery-ui.min.js" type="text/javascript"></script>
                                        <?php
                                        
                                        
                                    }
                                    
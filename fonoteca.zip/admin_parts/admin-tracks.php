<?php
function part_tracks(){
    global $dzsap_portal,$dzspgb_forportal;
//    print_r($dzsap_portal);

    $page = 'tracks';
    $pagetitle = __('tracks');
    ?>


    <div class="admin-wrap admin-wrap-for-tracks">


        <?php
        echo generate_admin_header(array(

            'title'=> $pagetitle,
            'page'=>$page
        ));
        ?>




        <div class="dzspb_lay_con">
            <div class="dzspb_layb_one_full">
                <div class="admin-breadcrumps">
                    <a href="admin.php"><i class="fa fa-home"></i>&nbsp;&nbsp;Home</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;<span class="current-page" >Tracks</span>
                </div>
            </div>
        </div>
        <div class="dzspb_lay_con">


            <div class="dzspb_layb_one_full">

                <p><a class="<?php if(isset($_GET['withoutwaveform'])==false || $_GET['withoutwaveform']!='on'){ echo 'weight-strong'; }; ?> " href="<?php echo remove_query_arg('withoutwaveform', dzs_curr_url());?>"><?php echo __("All Tracks"); ?></a> | <a class="<?php if(isset($_GET['withoutwaveform']) && $_GET['withoutwaveform']=='on'){ echo 'weight-strong'; }; ?>" href="<?php echo add_query_arg('withoutwaveform', 'on',dzs_curr_url());?>"><?php echo __("Tracks without Waveform"); ?> </a></p>

                <table class="pages-table loading">
                    <thead>
                    <tr>
                        <th class="column-name"><?php echo ("Name"); ?></th>
                        <th class="column-author"><?php echo ("Author"); ?></th>
                        <th class="column-date"><?php echo ("Date"); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>loading...</td>
                    </tr>


                    </tbody>
                </table>
                <?php
                $dzsap_portal->do_action("after_tracks");
                ?>
                <div class="separator general-margin"></div>
                <h2>Create New TRACK</h2>
                <div class="big-field-con">
                    <button class="btn-add-page">NEW TRACK</button>
                    <div class="big-field-div" placeholder="<?php echo __("enter here a new page name... "); ?>"><input class="bigfield" name="newpage_name"/></div>

                </div>

            </div>
        </div>

    </div>



    <?php
}

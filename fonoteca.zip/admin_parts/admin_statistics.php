<?php
function part_statistics(){
    global $dzsap_portal,$dzspgb_forportal;
//    print_r($dzsap_portal);

    $page = 'statistics';
    $pagetitle = __('Statistics');
    ?>


    <div class="admin-wrap admin-wrap-for-statistics">


        <?php
        echo generate_admin_header(array(

            'title'=> $pagetitle,
            'page'=>$page
        ));




        $trks = $dzsap_portal->get_tracks(array(
            'type'=>'album,track,soundcloud'
        ));
        $urs = $dzsap_portal->get_users();

        //            print_r($trks);



        $arr_stats = array();

        $nr_plays = 0;
        $nr_plays24 = 0;
        $nr_plays720 = 0;

        $nr_users = count($urs);

        $nr_users_today = count($dzsap_portal->get_users(array(
            'get_last'=>'on',
            'interval'=>'24',
        )));
        $nr_users_month = count($dzsap_portal->get_users(array(
            'get_last'=>'on',
            'interval'=>'720',
        )));


        foreach ($trks as $tr){
            $aux = array();
            $aux['title'] = $tr['title'];
            $aux['views'] = $dzsap_portal->mysql_get_track_activity($tr['id']);
            $aux['views24'] = $dzsap_portal->mysql_get_track_activity($tr['id'], array(
                'get_last'=>'on',
                'interval'=>'24',
            ));
            $aux['views720'] = $dzsap_portal->mysql_get_track_activity($tr['id'], array(
                'get_last'=>'on',
                'interval'=>'720',
            ));


            $nr_plays+=intval($aux['views']);
            $nr_plays24+=intval($aux['views24']);
            $nr_plays720+=intval($aux['views720']);

                array_push($arr_stats, $aux);
        }



        ?>




        <div class="dzspb_lay_con">
            <div class="dzspb_layb_one_full">
                <div class="admin-breadcrumps">
                    <a href="admin.php"><i class="fa fa-home"></i>&nbsp;&nbsp;<?php echo __("Home"); ?></a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;<span class="current-page" ><?php echo __("Statistics"); ?></span>
                </div>
            </div>
        </div>
        <div class="dzs-row">


            <div class="dzs-col-md-6">



                <div class="white-box">
                    <h3><?php echo __('Track Plays'); ?></h3>
                    <div id="chart_div"></div>
                </div>

            </div>
            <div class="dzs-col-md-6">



                <div class="white-box">
                    <h3><?php echo __('Numbers'); ?></h3>

                    <div class="dzs-row">
                        <div class="dzs-col-xs-4">

                            <h5><?php echo __("Total Plays"); ?></h5>
                            <div class="the-number"><?php echo $nr_plays; ?></div>
                        </div>
                        <div class="dzs-col-xs-4">

                            <h5><?php echo __("Recent Plays"); ?></h5>
                            <div class="the-number"><?php echo $nr_plays24; ?></div>
                        </div>
                        <div class="dzs-col-xs-4">

                            <h5><?php echo __("Plays This Month"); ?></h5>
                            <div class="the-number"><?php echo $nr_plays720; ?></div>
                        </div>
                    </div>

                    <br>
                    <div class="dzs-row">
                        <div class="dzs-col-xs-4">

                            <h5><?php echo __("Total Users"); ?></h5>
                            <div class="the-number"><?php echo $nr_users; ?></div>
                        </div>
                        <div class="dzs-col-xs-4">

                            <h5><?php echo __("Registered Today"); ?></h5>
                            <div class="the-number"><?php echo $nr_users_today; ?></div>
                        </div>
                        <div class="dzs-col-xs-4">

                            <h5><?php echo __("Registered This Month"); ?></h5>
                            <div class="the-number"><?php echo $nr_users_month; ?></div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </div>

    <script>

        google.charts.load('current', {packages: ['corechart', 'bar']});
        google.charts.setOnLoadCallback(drawTitleSubtitle);



        jQuery(document).ready(function($){
            $(window).on('resize', handle_resize);

            var inter_redraw = 0;

            function handle_resize(){

                if(inter_redraw){
                    clearTimeout(inter_redraw);
                }
                inter_redraw = setTimeout(drawTitleSubtitle,500);
            }
        })

        <?php


//            print_r($arr_stats);

    ?>

        function drawTitleSubtitle() {
            var data = google.visualization.arrayToDataTable([
                ['<?php echo __("Track"); ?>', '<?php echo __("Whole Time"); ?>', '<?php echo __("Last 24hrs"); ?>']

                <?php
                foreach ($arr_stats as $arr){

    $title = $arr['title'];


//                    $title = str_replace("'","&#39;", $title);
                    $title = str_replace("'","", $title);

                    $views = $arr['views'];
                    $views24 = $arr['views24'];
                    echo ',['.'\''.$title.'\''.','.$views.''.','.$views24.''.']';
                }
                ?>
            ]);

            var options = {
                chartArea: {width: '90%'},
                hAxis: {
                    title: 'Total Population',
                    minValue: 0,
                },
                vAxis: {
                    title: 'Track'
                },
                bars: 'horizontal'
                ,height: <?php echo count($arr_stats) * 50; ?>
                ,colors: ['#A76B68', '#6BBD72', '#7570b3']
            };
            var material = new google.charts.Bar(document.getElementById('chart_div'));
            material.draw(data, options);
        }
    </script>



    <?php
}

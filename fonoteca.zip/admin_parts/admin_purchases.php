<?php
function part_purchases(){
    global $dzsap_portal,$dzspgb_forportal;
//    print_r($dzsap_portal);

    $page = 'purchases';
    $pagetitle = __('Transactions');
    ?>


    <div class="admin-wrap admin-wrap-for-purchases">


        <?php
        echo generate_admin_header(array(

            'title'=> $pagetitle,
            'page'=>$page
        ));
        ?>




        <div class="dzspb_lay_con">
            <div class="dzspb_layb_one_full">
                <div class="admin-breadcrumps">
                    <a href="admin.php"><i class="fa fa-home"></i>&nbsp;&nbsp;<?php echo __("Home"); ?></a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;<span class="current-page" ><?php echo __("Purchases"); ?></span>
                </div>
            </div>
        </div>
        <div class="dzspb_lay_con">


            <div class="dzspb_layb_one_full">



                <table class="pages-table loading">
                    <thead>
                    <tr>
                        <th class="column-name"><?php echo __("Author Name"); ?></th>
                        <th class="column-author"><?php echo __("Buyer"); ?></th>
                        <th class="column-song"><?php echo __("Song"); ?></th>
                        <th class="column-author"><?php echo __("Amount"); ?></th>
                        <th class="column-date"><?php echo __("Date"); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>loading...</td>
                    </tr>

                    </tbody>
                </table>
                <div class="separator general-margin"></div>

            </div>
        </div>

    </div>



    <?php
}

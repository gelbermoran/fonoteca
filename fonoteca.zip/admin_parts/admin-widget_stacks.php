<?php
function part_widget_stacks(){
    global $dzsap_portal,$dzspgb_forportal;
//    print_r($dzsap_portal);

    $page = 'widget_stacks';
    $pagetitle = __('Widget Stacks');
    ?>


    <div class="admin-wrap admin-wrap-for-widget_stacks">


        <?php
        echo generate_admin_header(array(

            'title'=> $pagetitle,
            'page'=>$page
        ));
        ?>


        <div class="dzspb_lay_con">
            <div class="dzspb_layb_one_full">
                <div class="admin-breadcrumps">
                    <a href="admin.php"><i class="fa fa-home"></i>&nbsp;&nbsp;Home</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;<span class="current-page" >Widget Stacks</span>
                </div>
            </div>
        </div>
        <div class="dzspb_lay_con">


            <div class="dzspb_layb_one_full">

                <table class="pages-table loading">
                    <thead>
                    <tr>
                        <th class="column-name">Name</th>
                        <th class="column-author">Author</th>
                        <th class="column-date">Date</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>loading...</td>
                    </tr>

                    </tbody>
                </table>
                <div class="separator general-margin"></div>
                <h2>Create New MENU</h2>
                <div class="big-field-con">
                    <button class="btn-add-page">NEW MENU</button>
                    <div class="big-field-div" placeholder="<?php echo __("enter here a new page name... "); ?>"><input class="bigfield" name="newpage_name"/></div>

                </div>

            </div>
        </div>

    </div>


    <script>
        jQuery(document).ready(function($){

            $('#nestable3').nestable({
                'maxDepth':1
            });
            $('#nestable4').nestable({
                'maxDepth':1
            });
        })
    </script>
    <?php
}

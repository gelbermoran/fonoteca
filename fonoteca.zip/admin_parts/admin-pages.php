<?php
function part_pages(){
    global $dzsap_portal;
//    print_r($dzsap_portal);

    $page = 'pages';
    $pagetitle = __('Pages');

    ?>
    <div class="admin-wrap">


        <?php
        echo generate_admin_header(array(

            'title'=> $pagetitle,
            'page'=>$page
        ));
        ?>


        <div class="dzspb_lay_con">
            <div class="dzspb_layb_one_full">
                <div class="admin-breadcrumps">
                    <a href="admin.php"><i class="fa fa-home"></i>&nbsp;&nbsp;Home</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;<span class="current-page" >Pages</span>
                </div>
                </div>
            </div>
        <div class="dzspb_lay_con">


<div class="dzspb_layb_one_full">

                        <table class="pages-table loading">
                            <thead>
                            <tr>
                                <th class="column-name">Name</th>
                                <th class="column-author">Author</th>
                                <th class="column-date">Date</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td>loading...</td>
                            </tr>

                            </tbody>
                        </table>
    <div class="separator general-margin"></div>
    <h2>Create New Page</h2>
    <div class="big-field-con">
        <button class="btn-add-page">NEW PAGE</button>
        <div class="big-field-div" placeholder="<?php echo __("enter here a new page name... "); ?>"><input class="bigfield" name="newpage_name"/></div>

    </div>

    </div>
            </div>

        </div>


    <script>
        jQuery(document).ready(function($){

            $('#nestable3').nestable({
                'maxDepth':3
            });
            $('#nestable4').nestable({
                'maxDepth':1
            });
        })
    </script>
    <?php
}

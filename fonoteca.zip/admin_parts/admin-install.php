<?php


if(function_exists('__')==false){
    function __($arg='',$arg2=''){

        if($arg===''){
            return '';
        }

        if(function_exists("_")){
            return _($arg);
        }else{
            return $arg;
        }

    }
}


if(isset($_POST['action']) && $_POST['action']=='ajax_install'){


//    print_r($_POST);

    $data = array();

    parse_str($_POST['postdata'],$data);

    $str = file_get_contents(dirname(dirname(__FILE__)).'/config-sample.php');


//    print_r($data);



    $str = str_replace('{{replace_mysql_server}}', $data['mysql_server'], $str);
    $str = str_replace('{{replace_mysql_user}}', $data['mysql_user'], $str);
    $str = str_replace('{{replace_mysql_password}}', $data['mysql_password'], $str);
    $str = str_replace('{{replace_mysql_database}}', $data['mysql_database'], $str);
    $str = str_replace('{{replace_admin_user}}', $data['admin_user'], $str);
    $str = str_replace('{{replace_admin_password}}', MD5($data['admin_password']), $str);
    $str = str_replace('{{replace_admin_email}}', $data['admin_email'], $str);


//    echo $str;


    $file = dirname(dirname(__FILE__)).'/config.php';
    $aux = file_put_contents($file, $str);


    if($aux){

        echo 'success - ZoomPortal installed';
    }else{

        echo 'error - could not write config.php';
    }


    die();
}


if(isset($_POST['action']) && $_POST['action']=='ajax_check_credentials'){


//    print_r($_POST);

    parse_str($_POST['postdata'], $post_arr);

//    print_r($post_arr);


    $dblink = mysqli_connect($post_arr['mysql_server'],$post_arr['mysql_user'],$post_arr['mysql_password']);
    if (!$dblink) {
        $err = mysqli_connect_error();


        if(strpos($err, "nodename nor servname")!==false){
            echo 'error - '.__("Hello, mysql_server might be wrong in config.php, try to modify config.php with the correct mysql_server.").'<br><br>';
        }

        die('Could not connect: '.$err);

    }



    if($dblink){

        echo 'success - '.'credentials correct';
    }else{

        echo 'error - could not write config.php';
    }


    die();
}

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta http-equiv="X-UA-COMPATIBLE" content="IE=EDGE">
    <title>Audio Player Preview</title>
    <script src="js/jquery.js"></script>
    <link href="./libs/bootstrap/bootstrap.css" rel="stylesheet">
    <link href="./libs/bootstrap/bootstrap-responsive.css" rel="stylesheet">
    <link rel='stylesheet' type="text/css" href="style/style.css"/>
    <link rel='stylesheet' type="text/css" href="libs/audioplayer/audioplayer.css"/>
    <!--    <script src="audioplayer/audioplayer.js" type="text/javascript"></script>-->
    <link rel='stylesheet' type="text/css" href="libs/dzstooltip/dzstooltip.css"/>
    <link rel='stylesheet' type="text/css" href="libs/dzsscroller/scroller.css"/>
    <link rel='stylesheet' type="text/css" href="libs/advancedscroller/plugin.css"/>
    <link rel='stylesheet' type="text/css" href="libs/zoombox/zoombox.css"/>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,400italic' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Dosis:400' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <!--    <link href='http://fonts.googleapis.com/css?family=Droid+Sans' rel='stylesheet' type='text/css'>-->


    <style class="dzsapp-extra-css">h5{
            text-transform: uppercase;
            margin-top: 40px;
            margin-bottom: 20px;
            font-weight: bold;
        }</style>
    <script>
        var dzsap_settings = {
            thepath: "http://localhost/soundportal/source/"
            ,page: "page"
            ,currUserId: "0"
            ,optional_url_base: "http://localhost/soundportal/source/"
            , waveformgenerator_multiplier: "3"
            , color_waveformbg: "585858"
            , color_waveformprog: "ef6b13"
            , enable_cart: "on"
            , enable_ajax: "on"
            , settings_wavestyle: "reflect",settings_php_handler: "index.php",settings_ajax_handler: "index.php",waves_generation:"auto"};
        var dzsap_ltz = {
            follow: "Follow"
            ,unfollow: "Unfollow"
        };
        window.dzs_phpfile_path = "http://localhost/soundportal/source/upload.php";
        window.dzs_upload_path = "http://localhost/soundportal/source/upload/";</script>
</head>
<body class=" page-page ">
<div class="content-wrapper">


    <!--starthere parsing shortcode--><section class=" main-section-register" style="height: auto; min-height: 100vh;padding: 40px 0;"><div class="container container-for-install">
            <div class="row "><div class="col-md-12 ">

                    <div class="shortcode-register" style="">
                        <form class="install-form" name="install-form" action="index.php" method="POST">

                            <ul class="notices-box"></ul>


                            <h5 style="margin-top: 0;"><?php echo __("Database Options");?></h5>

                            <div class="setting"><div class="setting-label"></div><input type="text" name="mysql_server" placeholder="<?php echo __("MySQL Server...");?>" value=""/></div>


                            <div class="setting"><div class="setting-label"></div><input type="text" name="mysql_user" placeholder="<?php echo __("MySQL User...");?>" value=""/></div>



                            <div class="setting"><div class="setting-label"></div><input type="text" name="mysql_password" placeholder="<?php echo __("MySQL Password...");?>" value=""/></div>


                            <div class="setting"><div class="setting-label"></div><input type="text" name="mysql_database" placeholder="<?php echo __("MySQL Database...");?>" value=""/></div>



                            <h5><?php echo __("Admin Account"); ?></h5>

                            <div class="setting"><div class="setting-label"></div><input type="text" name="admin_user" placeholder="<?php echo __("User Name ...");?>" value=""/></div>


                            <div class="setting"><div class="setting-label"></div><input type="text" name="admin_email" placeholder="<?php echo __("Email...");?>" value=""/></div>


                            <div class="setting"><div class="setting-label"></div><input type="password" name="admin_password" placeholder="<?php echo __("Password...");?>"/ value=""></div>

                            <div class="setting">

                                <div class="setting-label"></div>

                            </div>

                            <div>
                                <input type="hidden" name="action" value="register"/>

                                <button class="button-primary button-primary-for-register btn-install-zoomportal"><?php echo __("Install ZoomPortal"); ?></button>

                            </div>

                        </form>
                        <div class="clear"></div>


                    </div>
                </div></div></div></section><!--endhere-->

    <!--            <section class="mcon-section">-->
    <!--	            -->    <!--            </section>-->











</div>



<div class="preloader-audio">
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
</div>
<div class="feedbacker" style="display:none;"></div>


<script>
    window.init_zoombox_settings = {
        settings_disableSocial : "on"
        ,design_skin : "skin-nebula"
    }
</script>
<script src="libs/audioplayer/audioplayer.js" type="text/javascript"></script>
<script src="libs/dzstooltip/dzstooltip.js" type="text/javascript"></script>
<script src="js/portal.js"></script>
<script src="libs/zoombox/zoombox.js"></script>
<script src="libs/dzsscroller/scroller.js"></script>
<script src="libs/advancedscroller/plugin.js" type="text/javascript"></script>
<script src="https://www.google.com/recaptcha/api.js"></script></body>
</html>

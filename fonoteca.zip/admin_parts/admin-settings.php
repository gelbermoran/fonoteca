<?php

function part_settings() {
    global $dzsap_portal;
    global $dzspgb_forportal;
//    print_r($dzsap_portal);

    $page = 'settings';
    $pagetitle = __('Settings');




//    print_r($dzsap_portal->main_settings);
//    print_r(curl_version());
    if ($dzsap_portal->main_settings['ssl_protocol'] == '') {


        if (function_exists('curl_version')) {
            $meta = curl_version();


            if ($meta['ssl_version']) {
                $dzsap_portal->main_settings['ssl_protocol'] = $meta['ssl_version'];


                $query = "UPDATE `settings` SET `setting_value`='".http_build_query($dzsap_portal->main_settings)."' WHERE `setting_name`='mainsettings'";
                $dzsap_portal->dblink->query($query);
            }
        } else {

            $dzsap_portal->main_settings['ssl_protocol'] = 'not supported';


            $query = "UPDATE `settings` SET `setting_value`='".http_build_query($dzsap_portal->main_settings)."' WHERE `setting_name`='mainsettings'";
            $dzsap_portal->dblink->query($query);
        }
    }

    if ($dzsap_portal->main_settings['tls_protocol'] == '') {


        $ctx = stream_context_create(
                array('ssl' => array(
                        'capture_session_meta' => TRUE
                    ),
                )
        );

        $html = file_get_contents('https://google.com/',FALSE,$ctx);


        $session_meta = '';


        $meta_arr = stream_context_get_options($ctx);

        $meta = $meta_arr['ssl']['session_meta'];


//        $meta2 = stream_get_meta_data($html);
//        print_r($meta2);
//    print_r($meta);

        $dzsap_portal->main_settings['tls_protocol'] = $meta['protocol'];




        $query = "UPDATE `settings` SET `setting_value`='".http_build_query($dzsap_portal->main_settings)."' WHERE `setting_name`='mainsettings'";
        $dzsap_portal->dblink->query($query);
    }
    ?>
    <div class="admin-wrap">


    <?php
    echo generate_admin_header(array(
        'title' => $pagetitle,
        'page' => $page
    ));
    ?>



        <div class="dzspb_lay_con">
            <div class="dzspb_layb_one_full">
                <div class="admin-breadcrumps">
                    <a href="admin.php"><i class="fa fa-home"></i>&nbsp;&nbsp;Home</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;<span class="current-page" ><?php echo $pagetitle; ?></span>
                </div>
            </div>
        </div>
        <div class="dzspb_lay_con">


    <?php
//            print_r($dzsap_portal->main_settings);
    ?>



            <div class="dzspb_layb_one_full">
                <form class="settings-form">

                    <div class="setting">

                        <h4 class="setting-label"><?php echo __("Theme"); ?></h4>


    <?php
    $lab = 'theme';

    $auxa = $dzspgb_forportal->ajax_select_pages_array(array(
        'for_ajax' => false,
    ));

    $auxarr = (json_decode($auxa));

    $opts = array(
        array(
            'val' => 'theme-default'
            ,'lab' => __("Default Theme")
        ),
        array(
            'val' => 'theme-dark'
            ,'lab' => __("Dark Theme")
        ),
        array(
            'val' => 'theme-luna'
            ,'lab' => __("Luna Theme")
        ),
        array(
            'val' => 'theme-domino'
            ,'lab' => __("Domino Theme")
        ),
    );

    echo DZSHelpers::generate_select($lab,array('options' => $opts,'class' => 'dzs-style-me skin-beige   ','seekval' => $dzsap_portal->main_settings[$lab]));

    //                        print_r($opts);
    ?>
                    </div>


                    <div class="dzs-tabs auto-init" data-options="{ 
                         'design_tabsposition' : 'top'
                         ,design_transition: 'fade'
                         ,design_tabswidth: 'default'
                         ,toggle_breakpoint : '400'
                         ,refresh_tab_height : '1000'
                         ,settings_enable_linking : 'on'
             ,settings_appendWholeContent: true
                         ,toggle_type: 'accordion'}">

                        <div class="dzs-tab-tobe">
                            <div class="tab-menu with-tooltip">
                                <i class="fa fa-cog"></i> <?php echo __("General"); ?>
                            </div>
                            <div class="tab-content">
                                <br>

                                <div class="row">
                                <div class="col-md-6">
                                    <div class="setting">
                                        <h4 class="setting-label"><?php echo __('Use AJAX?','dzsapp'); ?></h4>
                                        <div class="dzscheckbox skin-nova">
                                            <?php $lab = 'use_ajax';
                                            echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab]));
                                            ?>
                                            <label for="<?php echo $lab; ?>"></label>
                                        </div>
                                        <div class="sidenote"><?php echo __('by default scripts and styles from this gallery are included only when needed for optimizations reasons, but you can choose to always use them ( useful for when you are using a ajax theme that does not reload the whole page on url change )','dzsapp'); ?></div>
                                    </div>







                                    <?php
                                    $lab = 'home_is_stream';
                                    echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                    ?>
                                    <div class="setting">
                                        <h4 class="setting-label"><?php echo __('Homepage leads to Stream Page for logged in users?','dzsapp'); ?></h4>
                                        <div class="dzscheckbox skin-nova">
                                            <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                            <label for="<?php echo $lab; ?>"></label>
                                        </div>
                                        <div class="sidenote"><?php echo __('index page can lead to the Follow Stream page'); ?></div>
                                    </div>

                                    <?php
                                    $lab = 'use_parallaxer';
                                    echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                    ?>
                                    <div class="setting">
                                        <h4 class="setting-label"><?php echo __('Use Parallax Effects ?','dzsapp'); ?></h4>
                                        <div class="dzscheckbox skin-nova">
                                            <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                            <label for="<?php echo $lab; ?>"></label>
                                        </div>
                                        <div class="sidenote"><?php echo __('parallax effects can be added to some elements'); ?></div>
                                    </div>



                                    <?php
                                    $lab = 'autoplay_next';
                                    echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                    ?>
                                    <div class="setting">
                                        <h4 class="setting-label"><?php echo __('Autoplay Next Track Automatically ?','dzsapp'); ?></h4>
                                        <div class="dzscheckbox skin-nova">
                                            <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                            <label for="<?php echo $lab; ?>"></label>
                                        </div>
                                        <div class="sidenote"><?php echo __('once a track has ended you have the option to continue playing other tracks in line'); ?></div>
                                    </div>

                                    <?php
                                    $lab = 'paths_are_absolute';
                                    echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                    ?>
                                    <div class="setting">
                                        <h4 class="setting-label"><?php echo __('Paths are Absolute ?','dzsapp'); ?></h4>
                                        <div class="dzscheckbox skin-nova">
                                            <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                            <label for="<?php echo $lab; ?>"></label>
                                        </div>
                                        <div class="sidenote"><?php echo __('check this so that paths linking to files are absolute'); ?></div>
                                    </div>

                                    <?php
                                    $lab = 'use_pretty_links';
                                    echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                    ?>
                                    <div class="setting">
                                        <h4 class="setting-label"><?php echo __('Use Pretty Links?','dzsapp'); ?></h4>
                                        <div class="dzscheckbox skin-nova">
                                            <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                            <label for="<?php echo $lab; ?>"></label>
                                        </div>
                                        <div class="sidenote"><?php echo __("Search Engine Friendly URLs"); echo ' / '; echo sprintf('%s<br>%s<strong>http://yoursite.com/index.php?track_id=3</strong>%s<strong>http://yoursite.com/tracks/track_title</strong>',__('make sure that the url base is set'),__('this will convert from '),__(' to ')) ?></div>
                                    </div>







                                    <div class="setting">

                                        <h4 class="setting-label"><?php echo __("Handle www. requests"); ?></h4>


                                        <?php
                                        $lab = 'www_handle';

                                        $opts = array(
                                            array(
                                                'val' => 'default'
                                            ,'lab' => __("No Change")
                                            ),
                                            array(
                                                'val' => 'force_www'
                                            ,'lab' => __("Force WWW")
                                            ),
                                            array(
                                                'val' => 'force_no_www'
                                            ,'lab' => __("Force Disable WWW")
                                            ),
                                        );

                                        echo DZSHelpers::generate_select($lab,array('options' => $opts,'class' => 'dzs-style-me skin-beige   ','seekval' => $dzsap_portal->main_settings[$lab]));

                                        //                        print_r($opts);
                                        ?>
                                        <div class="sidenote"><?php echo sprintf('%s',__('this will manage how www. is added or removed to the site link')) ?></div>
                                    </div>






                                    <div class="setting">

                                        <h4 class="setting-label"><?php echo __("URL Base"); ?></h4>


                                        <?php
                                        $lab = 'url_base';
                                        echo DZSHelpers::generate_input_text($lab,array('class' => ' simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                        //                        print_r($opts);
                                        ?>
                                        <div class="sidenote"><?php echo sprintf('%s<br>%s<strong>http://www.zoomthe.me/soundportal/admin.php?zoomit=1&page=settings&dzstaa_starttab_dzs-tabs0=0</strong>%s<strong>http://www.zoomthe.me/soundportal</strong>',__('enter the base url of the site for pretty links to work'),__('if the link to this page is '),__(' then the url base is ')) ?></div>
                                    </div>


                                    <div class="setting">

                                        <h4 class="setting-label"><?php echo __("Site Title"); ?></h4>


                                        <?php
                                        $lab = 'site_title';
                                        echo DZSHelpers::generate_input_text($lab,array('class' => ' simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                        //                        print_r($opts);
                                        ?>
                                        <div class="sidenote"><?php echo __("Enter the site title"); ?></div>
                                    </div>
                                    <div class="setting">

                                        <h4 class="setting-label"><?php echo __("Site Encryption Key"); ?></h4>


                                        <?php
                                        $lab = 'site_encryption_key';
                                        echo DZSHelpers::generate_input_text($lab,array('class' => ' simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                        //                        print_r($opts);
                                        ?>
                                        <div class="sidenote"><?php echo __("enter a 16 character encryption key ( can be numbers ) if you want to enable forgot password functionality"); ?></div>
                                    </div>


                                    <div class="setting">
                                        <h4 class="setting-label"><?php echo __('Play Remember Time'); ?></h4>
                                        <?php
                                        $lab = 'play_remember_time';
                                        $val = '';
                                        if ($dzsap_portal->main_settings[$lab]) {
                                            $val = $dzsap_portal->main_settings[$lab];
                                        }
                                        echo DZSHelpers::generate_input_text($lab, array('val' => '', 'seekval' => $val, 'type' => '', 'class' => ''));
                                        ?>
                                        <div
                                                class="sidenote"><?php echo __('plays are regitered by ip - you can specify a time ( in minutes ) at which plays are remembers. after this time - a new play can be registered for the same ip'); ?></div>
                                    </div>

                                    <?php
                                    $dzsap_portal->do_action('admin_more_options_general');
                                    ?>
                                    <div class="setting">

                                        <h4 class="setting-label"><?php echo __("Google Analytics Tracking code"); ?></h4>


                                        <?php
                                        $lab = 'ga_tracking_code';
                                        echo DZSHelpers::generate_input_text($lab,array('class' => ' simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                        //                        print_r($opts);
                                        ?>
                                        <div class="sidenote"><?php echo __("enable the google analytics plugin"); ?></div>
                                    </div>


                                </div><!-- end col-md-6 -->
                                    <div class="col-md-6">


                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Download - Ad Site"); ?></h4>


                                            <?php
                                            $lab = 'download_ad_link';
                                            echo DZSHelpers::generate_input_text($lab,array('class' => ' simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                            //                        print_r($opts);
                                            ?>
                                            <div class="sidenote"><?php echo __("Enter a link if you want for your visitors to get redirected to a ad site when clicking the download button or leave blank."); ?></div>
                                        </div>


                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Suggested Tags"); ?></h4>


                                            <?php
                                            $lab = 'tags_suggested';
                                            echo DZSHelpers::generate_input_text($lab,array('class' => ' simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                            //                        print_r($opts);
                                            ?>
                                            <div class="sidenote"><?php echo __("enter the suggested tags separated by , ( comma )  "); ?></div>
                                        </div>


                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Maximum number of tags"); ?></h4>


                                            <?php
                                            $lab = 'tags_max_nr';
                                            echo DZSHelpers::generate_input_text($lab,array('class' => ' simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                            //                        print_r($opts);
                                            ?>

                                        </div>


                                        <?php
                                        $lab = 'tags_allow_only_suggested';
                                        echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                        ?>
                                        <div class="setting">
                                            <h4 class="setting-label"><?php echo __('Allow Only Suggested Tags?','dzsapp'); ?></h4>
                                            <div class="dzscheckbox skin-nova">
                                                <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                                <label for="<?php echo $lab; ?>"></label>
                                            </div>
                                            <div class="sidenote"><?php echo __('allow creating new accounts'); ?></div>
                                        </div>


                                        <?php
                                        $lab = 'allow_register';
                                        echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                        ?>
                                        <div class="setting">
                                            <h4 class="setting-label"><?php echo __('Allow Register','dzsapp'); ?></h4>
                                            <div class="dzscheckbox skin-nova">
                                                <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                                <label for="<?php echo $lab; ?>"></label>
                                            </div>
                                            <div class="sidenote"><?php echo __('allow creating new accounts'); ?></div>
                                        </div>


                                        <?php
                                        $lab = 'new_users_need_verification';
                                        echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                        ?>
                                        <div class="setting">
                                            <h4 class="setting-label"><?php echo __('New Users Require Email Verification?','dzsapp'); ?></h4>
                                            <div class="dzscheckbox skin-nova">
                                                <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                                <label for="<?php echo $lab; ?>"></label>
                                            </div>
                                            <div class="sidenote"><?php echo __('new users will have to click a link - remember to place a 16 character site encryption key'); ?></div>
                                        </div>


                                        <?php
                                        $lab = 'enable_reposts';
                                        echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                        ?>
                                        <div class="setting">
                                            <h4 class="setting-label"><?php echo __('Enable Reposts','dzsapp'); ?></h4>
                                            <div class="dzscheckbox skin-nova">
                                                <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                                <label for="<?php echo $lab; ?>"></label>
                                            </div>
                                            <div class="sidenote"><?php echo __('allow users tagging tracks to repost'); ?></div>
                                        </div>

                                        <?php
                                        $lab = 'cache_album_download';
                                        echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                        ?>
                                        <div class="setting">
                                            <h4 class="setting-label"><?php echo __('Cache Album Download','dzsapp'); ?></h4>
                                            <div class="dzscheckbox skin-nova">
                                                <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                                <label for="<?php echo $lab; ?>"></label>
                                            </div>
                                            <div class="sidenote"><?php echo __('cache the album download so the server will not have to repack the zip file every time'); ?></div>
                                        </div>


                                        <?php
                                        $lab = 'enable_notifications';
                                        echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                        ?>
                                        <div class="setting">
                                            <h4 class="setting-label"><?php echo __('Enable Notifications','dzsapp'); ?></h4>
                                            <div class="dzscheckbox skin-nova">
                                                <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                                <label for="<?php echo $lab; ?>"></label>
                                            </div>
                                            <div class="sidenote"><?php echo __('enable a notification menu for logged in users in the header'); ?></div>
                                        </div>


                                        <div class="setting">
                                            <?php
                                            $lab = 'disable_commenting';
                                            echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                            ?>
                                            <h4 class="setting-label"><?php echo __('Disable Commenting','dzsapp'); ?></h4>
                                            <div class="dzscheckbox skin-nova">
                                                <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                                <label for="<?php echo $lab; ?>"></label>
                                            </div>
                                            <div class="sidenote"><?php echo __('disable comment option'); ?></div>
                                        </div>


                                        <div class="setting">
                                            <?php
                                            $lab = 'comments_allow_post_if_not_logged_in';
                                            echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                            ?>
                                            <h4 class="setting-label"><?php echo __('Allow comments on non logged in users','dzsapp'); ?></h4>
                                            <div class="dzscheckbox skin-nova">
                                                <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                                <label for="<?php echo $lab; ?>"></label>
                                            </div>
                                            <div class="sidenote"><?php echo __('allow comments even if not registered'); ?></div>
                                        </div>



                                        <div class="setting">
                                            <?php
                                            $lab = 'likes_allow_post_if_not_logged_in';
                                            echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                            ?>
                                            <h4 class="setting-label"><?php echo __('Allow likes for non logged in users','dzsapp'); ?></h4>
                                            <div class="dzscheckbox skin-nova">
                                                <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                                <label for="<?php echo $lab; ?>"></label>
                                            </div>
                                            <div class="sidenote"><?php echo __('allow likes even if not registered'); ?></div>
                                        </div>


                                        <div class="setting">
                                            <?php
                                            $lab = 'delete_track_on_track_removal';
                                            echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                            ?>
                                            <h4 class="setting-label"><?php echo __('Delete files on track removal','dzsapp'); ?></h4>
                                            <div class="dzscheckbox skin-nova">
                                                <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                                <label for="<?php echo $lab; ?>"></label>
                                            </div>
                                            <div class="sidenote"><?php echo __('physically delete files on track removal'); ?></div>
                                        </div>


                                        <div class="setting">
                                            <?php
                                            $lab = 'delete_previous_upload';
                                            echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                            ?>
                                            <h4 class="setting-label"><?php echo __('Delete previous Upload','dzsapp'); ?></h4>
                                            <div class="dzscheckbox skin-nova">
                                                <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                                <label for="<?php echo $lab; ?>"></label>
                                            </div>
                                            <div class="sidenote"><?php echo __('physically delete the previous file when a new file is uploaded'); ?></div>
                                        </div>


                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Home Page"); ?></h4>


                                            <?php
                                            $auxa = $dzspgb_forportal->ajax_select_pages_array(array(
                                                'for_ajax' => false,
                                            ));

                                            $auxarr = (json_decode($auxa));

                                            $opts = array();

                                            foreach ($auxarr as $arr_item) {
                                                $aux_arr2 = array(
                                                    'lab' => $arr_item->title,
                                                    'val' => $arr_item->id,
                                                );

                                                array_push($opts,$aux_arr2);
                                            };

                                            echo DZSHelpers::generate_select('page_homepage',array('options' => $opts,'class' => 'dzs-style-me skin-beige   ','seekval' => $dzsap_portal->main_settings['page_homepage']));

                                            //                        print_r($opts);
                                            ?>
                                        </div>





                                        <?php
                                        $fout = '';

                                        $lab = 'footer_player_config';
                                        $nam = $lab;


                                        $args = array(
                                            'for_ajax' => false,
                                            'post_type' => 'apconfig',
                                        );

                                        $auxa = ($dzspgb_forportal->ajax_select_pages_array($args));


                                        $apconfigs = json_decode($auxa,true);

                                        //        print_r($apconfigs);

                                        $arr_opts = array(array(
                                            'val' => 'off',
                                            'lab' => __('No Player'),
                                        ));
                                        foreach ($apconfigs as $auxa_it) {

                                            $auxb = array(
                                                'val' => $auxa_it['id'],
                                                'lab' => $auxa_it['title'],
                                            );

                                            array_push($arr_opts,$auxb);
                                        }






                                        $fout.='<div class="setting">
        <div class="setting-label">'.__('Footer Player Configuration').'</div>
'.DZSHelpers::generate_select($nam,array('class' => 'dzs-style-me skin-beige ','options' => $arr_opts,'seekval' => $dzsap_portal->main_settings[$lab],)).'
</div>';

                                        echo $fout;
                                        ?>




                                        <div class="dzstoggle toggle1" rel="">
                                            <div class="toggle-title" style=""><?php echo  __('Reset Statistics', 'dzsap');?></div>
                                            <div class="toggle-content">
                                                <p><button class="btn-primary padding-small btn-reset-statistics"><?php echo __("Reset statistics"); ?></button></p>
                                                <div class="sidenote"><?php echo __('reset statistics for this site'); ?></div>
                                                <br>
                                            </div>
                                        </div>


                                        <div class="dzstoggle toggle1" rel="">
                                            <div class="toggle-title" style=""><?php echo  __('Reset Permalinks', 'dzsap');?></div>
                                            <div class="toggle-content">
                                                <p><button class="btn-primary padding-small btn-reset-permalinks"><?php echo __("Reset Permalinks"); ?></button></p>
                                                <div class="sidenote"><?php echo __('reset permalinks for this site'); ?></div>
                                                <br>
                                            </div>
                                        </div>





                                </div>


                                </div>





                            </div>
                        </div>

                        <div class="dzs-tab-tobe tab-disabled">
                            <div class="tab-menu ">
                                &nbsp;&nbsp;
                            </div>
                            <div class="tab-content">

                            </div>
                        </div>

                        <div class="dzs-tab-tobe">
                            <div class="tab-menu with-tooltip">
                                <i class="fa fa-envelope"></i> <?php echo __("Mail"); ?>
                            </div>
                            <div class="tab-content mail_type-changer-con">
                                <br>

                                <div class="dzs-row">
                                    <div class="dzs-col-md-6">
                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Mail Send Method"); ?></h4>


                                            <?php
                                            $lab = 'mail_type';




                                            $arr_opts = array(
                                                array(
                                                    'val' => 'mail',
                                                    'lab' => __('Simple Mail'),
                                                ),
                                                array(
                                                    'val' => 'smtp',
                                                    'lab' => __('Smtp Mail'),
                                                ),
                                            );





                                            $fout = '
'.DZSHelpers::generate_select($lab,array('class' => 'dzs-style-me skin-beige dzs-dependency-field ','options' => $arr_opts,'seekval' => $dzsap_portal->main_settings[$lab],)).'
';

                                            echo $fout;
                                            ?>

                                            <div class="sidenote"><?php echo __("mail() function might be disabled or limited on some hosts, so smtp might be the option to choose"); ?></div>
                                        </div>

                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Admin Email"); ?></h4>


                                            <?php
                                            $lab = 'mail_target';
                                            echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                            //                        print_r($opts);
                                            ?>


                                            <div class="sidenote"><?php echo __("The receiver of the emails"); ?></div>
                                        </div>

                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Mail Sender"); ?></h4>


                                            <?php
                                            $lab = 'mail_sender';
                                            echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                            //                        print_r($opts);
                                            ?>


                                            <div class="sidenote"><?php echo __("The sender of the emails"); ?></div>
                                        </div>

                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Mail Template"). ' - '. __("New User"); ?></h4>


                                            <?php
                                            $lab = 'mail_template_new_user';
                                            echo DZSHelpers::generate_input_textarea($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],'extraattr' => ' rows="4" style="height: 100px; width: 100%; "',));

                                            //                        print_r($opts);
                                            ?>


                                            <div class="sidenote"><?php echo __("The sender of the emails"); ?></div>
                                        </div>

                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Mail Template"). ' - '. __("Admin New User"); ?></h4>


                                            <?php
                                            $lab = 'mail_template_admin_new_user';
                                            echo DZSHelpers::generate_input_textarea($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],'extraattr' => ' rows="4" style="height: 100px; width: 100%; "',));

                                            //                        print_r($opts);
                                            ?>


                                            <div class="sidenote"><?php echo __("The sender of the emails"); ?></div>
                                        </div>

                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Mail Template"). ' - '. __("Forgot Password"); ?></h4>


                                            <?php
                                            $lab = 'mail_template_forgot_password';
                                            echo DZSHelpers::generate_input_textarea($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],'extraattr' => ' rows="4" style="height: 100px; width: 100%; "',));

                                            //                        print_r($opts);
                                            ?>


                                            <div class="sidenote"><?php echo __("The sender of the emails"); ?></div>
                                        </div>

                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Mail Template"). ' - '. __("Verify Account"); ?></h4>


                                            <?php
                                            $lab = 'mail_template_verify_account';
                                            echo DZSHelpers::generate_input_textarea($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],'extraattr' => ' rows="4" style="height: 100px; width: 100%; "',));

                                            //                        print_r($opts);
                                            ?>


                                            <div class="sidenote"><?php echo __("The sender of the emails"); ?></div>
                                        </div>

                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Mail Template"). ' - '. __("Login Details"); ?></h4>


                                            <?php
                                            $lab = 'mail_template_login_details';
                                            echo DZSHelpers::generate_input_textarea($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],'extraattr' => ' rows="4" style="height: 100px; width: 100%; "',));

                                            //                        print_r($opts);
                                            ?>


                                            <div class="sidenote"><?php echo __("The sender of the emails"); ?></div>
                                        </div>

                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Mail Template"). ' - '. __("New Like"); ?></h4>


                                            <?php
                                            $lab = 'mail_template_new_like';
                                            echo DZSHelpers::generate_input_textarea($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],'extraattr' => ' rows="4" style="height: 100px; width: 100%; "',));

                                            //                        print_r($opts);
                                            ?>


                                            <div class="sidenote"><?php echo __("The sender of the emails"); ?></div>
                                        </div>

                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Mail Template"). ' - '. __("New Comment"); ?></h4>


                                            <?php
                                            $lab = 'mail_template_new_comment';
                                            echo DZSHelpers::generate_input_textarea($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],'extraattr' => ' rows="4" style="height: 100px; width: 100%; "',));

                                            //                        print_r($opts);
                                            ?>


                                            <div class="sidenote"><?php echo __("The sender of the emails"); ?></div>
                                        </div>

                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Mail Template"). ' - '. __("New Purchase"); ?></h4>


                                            <?php
                                            $lab = 'mail_template_new_purchase';
                                            echo DZSHelpers::generate_input_textarea($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],'extraattr' => ' rows="4" style="height: 100px; width: 100%; "',));

                                            //                        print_r($opts);
                                            ?>


                                            <div class="sidenote"><?php echo __("The sender of the emails"); ?></div>
                                        </div>

                                        <?php
                                        $dependency = array(
                                            array(
                                                'element' => 'mail_type',
                                                'value' => array('smtp'),
                                            ),
                                        )
                                        ;
                                        ?>
                                        <div class="setting"  data-dependency='<?php echo json_encode($dependency); ?>'>

                                            <h4 class="setting-label"><?php echo __("SMTP Host"); ?></h4>


                                            <?php
                                            $lab = 'smtp_host';
                                            echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                            //                        print_r($opts);
                                            ?>


                                            <div class="sidenote"><?php echo sprintf(__("example for gmail - %s"),'stmp.gmail.com'); ?></div>
                                        </div>
                                        <div class="setting"  data-dependency='<?php echo json_encode($dependency); ?>'>

                                            <h4 class="setting-label"><?php echo __("SMTP Port"); ?></h4>


                                            <?php
                                            $lab = 'smtp_port';
                                            echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                            //                        print_r($opts);
                                            ?>


                                            <div class="sidenote"><?php echo sprintf(__("example for gmail - %s"),'587'); ?></div>
                                        </div>
                                        <div class="setting"  data-dependency='<?php echo json_encode($dependency); ?>'>

                                            <h4 class="setting-label"><?php echo __("SMTP Username"); ?></h4>


                                            <?php
                                            $lab = 'smtp_username';
                                            echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                            //                        print_r($opts);
                                            ?>


                                            <div class="sidenote"><?php echo sprintf(__("your username")); ?></div>
                                        </div>
                                        <div class="setting"  data-dependency='<?php echo json_encode($dependency); ?>'>

                                            <h4 class="setting-label"><?php echo __("SMTP Password"); ?></h4>


                                            <?php
                                            $lab = 'smtp_password';
                                            echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                            //                        print_r($opts);
                                            ?>


                                            <div class="sidenote"><?php echo sprintf(__("your password")); ?></div>
                                        </div>
                                    </div>
                                    
                                    <div class="dzs-col-md-6">



                                        <?php
                                        $lab = 'mail_on_register';
                                        echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                        ?>
                                        <div class="setting">
                                            <h4 class="setting-label"><?php echo __('Mail admin when user registered','dzsapp'); ?></h4>
                                            <div class="dzscheckbox skin-nova">
                                                <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                                <label for="<?php echo $lab; ?>"></label>
                                            </div>
                                            <div class="sidenote"><?php echo __(''); ?></div>
                                        </div>



                                        <?php
                                        $lab = 'mail_user_on_register';
                                        echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                        ?>
                                        <div class="setting">
                                            <h4 class="setting-label"><?php echo __('Mail newly registered user with login details','dzsapp'); ?></h4>
                                            <div class="dzscheckbox skin-nova">
                                                <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                                <label for="<?php echo $lab; ?>"></label>
                                            </div>
                                            <div class="sidenote"><?php echo __(''); ?></div>
                                        </div>


                                    </div>
                                </div>


                            </div>
                        </div>

                        <div class="dzs-tab-tobe tab-disabled">
                            <div class="tab-menu ">
                                &nbsp;&nbsp;
                            </div>
                            <div class="tab-content">

                            </div>
                        </div>

                        <div class="dzs-tab-tobe">
                            <div class="tab-menu with-tooltip">
                                <i class="fa fa-paint-brush"></i> <?php echo __("Appearance"); ?>
                            </div>
                            <div class="tab-content">
                                <br>

                                <div class="setting">

                                    <h4 class="setting-label"><?php echo __("Extra CSS"); ?></h4>


                                    <?php
                                    $lab = 'extra_css';
                                    echo DZSHelpers::generate_input_textarea($lab,array('class' => 'semi-big-textarea','seekval' => $dzsap_portal->main_settings[$lab],'extraattr' => ' rows="5"'));

                                    //                        print_r($opts);
                                    ?>
                                </div>

                                <div class="setting">

                                    <h4 class="setting-label"><?php echo __("Extra Javascript"); ?></h4>


                                    <?php
                                    $lab = 'extra_js';
                                    echo DZSHelpers::generate_input_textarea($lab,array('class' => 'semi-big-textarea','seekval' => $dzsap_portal->main_settings[$lab],'extraattr' => ' rows="5"'));

                                    //                        print_r($opts);
                                    ?>
                                </div>

                                <div class="setting">
                                    <h4 class="setting-label"><?php echo __('Waveform Mode','dzsap'); ?></h4>
    <?php
    $lab = 'skinwave_wave_mode';

    $opts = array(
        array(
            'lab' => __("Image"),
            'val' => 'image'
        ),
        array(
            'lab' => __("Canvas"),
            'val' => 'canvas'
        ),
    );


    echo DZSHelpers::generate_select($lab,array(
        'class' => ' dzs-dependency-field  dzs-style-me skin-beige',
        'options' => $opts,
        'seekval' => $dzsap_portal->main_settings[$lab]
    ));
    ?>


                                    <div class="sidenote"><?php echo __("this is the wave style ").'<br>';
                                printf("<strong> %s </strong> - %s <br>",__("Image"),__("is just a image png that must be generated from the backend"));
                                echo sprintf("<strong> %s </strong> - %s <br>",__("Canvas"),__("is a new and more immersive mode to show the waves. you can control color more easily, reflection size and wave bars number")); ?></div>
                                </div>


    <?php
    $dependency = array(
        array(
            'element' => 'skinwave_wave_mode',
            'value' => array('canvas'),
        ),
    )
    ;
    ?>
                                <div class="setting" data-dependency='<?php echo json_encode($dependency); ?>'>
                                    <h4 class="setting-label"><?php echo __('Reflection Size','dzsap'); ?></h4>
    <?php
    $lab = 'skinwave_wave_mode_canvas_reflection_size';

    $opts = array(
        array(
            'lab' => __("None"),
            'val' => '0'
        ),
        array(
            'lab' => __("Normal"),
            'val' => '0.25'
        ),
        array(
            'lab' => __("Big"),
            'val' => '0.5'
        ),
    );


    echo DZSHelpers::generate_select($lab,array('class' => '  dzs-style-me skin-beige','options' => $opts,'seekval' => $dzsap_portal->main_settings[$lab]));
    ?>


                                    <div class="sidenote"><?php echo __("the waveform reflection size").''; ?></div>
                                </div>


                                <?php
                                $lab = 'pcm_data_try_to_generate';
                                        echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                ?>

                                <div class="setting">
                                    <h4 class="setting-label"><?php echo __('Generate Waveforms','dzsapp'); ?></h4>
                                    <div class="dzscheckbox skin-nova">
                                        <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                        <label for="<?php echo $lab; ?>"></label>
                                    </div>
                                    <div class="sidenote"><?php echo __('allow creating new accounts'); ?></div>
                                </div>


                                    <?php
                                    $dependency = array(
                                        array(
                                            'element' => 'skinwave_wave_mode',
                                            'value' => array('canvas'),
                                        ),
                                            )
                                    ;
                                    ?>
                                <div class="setting" data-dependency='<?php echo json_encode($dependency); ?>'>
                                    <h4 class="setting-label"><?php echo __('Waves Number','dzsap'); ?></h4>
                                    <?php
                                    $lab = 'skinwave_wave_mode_canvas_waves_number';

                                    echo DZSHelpers::generate_input_text($lab,array(
                                        'class' => '',
                                        'type' => 'slider',
                                        'class' => 'disabled',
                                        'slider_min' => '50',
                                        'slider_max' => '300',
                                        'seekval' => $dzsap_portal->main_settings[$lab]
                                    ));
                                    ?>


                                    <div class="sidenote"><?php echo __("the waveform reflection size").''; ?></div>
                                </div>



                                <div class="setting">

                                    <h4 class="setting-label"><?php echo __("Waveform Background Color"); ?></h4>


                                    <?php
                                    $lab = 'color_waveformbg';
                                    echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field with-colorpicker','seekval' => $dzsap_portal->main_settings[$lab],));

                                    //                        print_r($opts);
                                    ?><div class="picker-con"><div class="the-icon"></div><div class="picker"></div></div>
                                </div>

                                <div class="setting">

                                    <h4 class="setting-label">Waveform Progress Color</h4>


    <?php
    $lab = 'color_waveformprog';
    echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field with-colorpicker','seekval' => $dzsap_portal->main_settings[$lab],));

    //                        print_r($opts);
    ?><div class="picker-con"><div class="the-icon"></div><div class="picker"></div></div>
                                </div>

                                <div class="setting">

                                    <h4 class="setting-label">Waveform Multiplier</h4>


    <?php
    $lab = 'waveformgenerator_multiplier';
    echo DZSHelpers::generate_input_text($lab,array('class' => ' simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

    //                        print_r($opts);
    ?>
                                    <div class="sidenote">A multiplier on the wave generator</div>
                                </div>

                                <div class="setting">

                                    <h4 class="setting-label"><?php echo __("Logo"); ?></h4>


                                    <?php
                                    $lab = 'logo';
                                    echo DZSHelpers::generate_input_text($lab,array('class' => ' simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                    //                        print_r($opts);
                                    ?>
                                    <div class="sidenote"><?php echo __("The Logo Path"); ?></div>
                                </div>

                                <div class="setting">

                                    <h4 class="setting-label"><?php echo __("Logo Max Width"); ?></h4>


                                    <?php
                                    $lab = 'logo_max_width';
                                    echo DZSHelpers::generate_input_text($lab,array('class' => ' simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                    //                        print_r($opts);
                                    ?>
                                    <div class="sidenote"><?php echo __("input a max width and max height to make the logo retina ready"); ?></div>
                                </div>

                                <div class="setting">

                                    <h4 class="setting-label"><?php echo __("Logo Max Height"); ?></h4>


                                    <?php
                                    $lab = 'logo_max_height';
                                    echo DZSHelpers::generate_input_text($lab,array('class' => ' simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                    //                        print_r($opts);
                                    ?>
                                    <div class="sidenote"><?php echo __("input a max width and max height to make the logo retina ready"); ?></div>
                                </div>

                                <div class="setting">

                                    <h4 class="setting-label"><?php echo __("Default Thumbnail"); ?></h4>


                                    <?php
                                    $lab = 'default_thumb';
                                    echo DZSHelpers::generate_input_text($lab,array('class' => ' simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                    //                        print_r($opts);
                                    ?>
                                    <div class="sidenote"><?php echo __("default thumbnail"); ?></div>
                                </div>

                                <div class="setting">
                                    <h4 class="setting-label"><?php echo __('Make no-thumb track adopt the default thumbnail','dzsapp'); ?></h4>
                                    <div class="dzscheckbox skin-nova">
                                        <?php
                                        $lab = 'has_default_thumb_on_empty_tracks';
                                        ?>
                                        <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                        <label for="<?php echo $lab; ?>"></label>
                                    </div>
                                    <div class="sidenote"><?php echo __('apply this default thumbnail to tracks without thumbnails setup'); ?></div>
                                </div>

                                <div class="setting">

                                    <h4 class="setting-label"><?php echo __("Translate Free"); ?></h4>


                                    <?php
                                    $lab = 'translate_free';
                                    echo DZSHelpers::generate_input_text($lab,array('class' => ' simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                    //                        print_r($opts);
                                    ?>
                                    <div class="sidenote"><?php echo __("translate the Free keyword"); ?></div>
                                </div>

                                <h3><?php echo __("Google Fonts"); ?></h3>


                                    <?php
                                    $lab = 'google_fonts_enable';

                                    echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                    ?>
                                <div class="setting">
                                    <h4 class="setting-label"><?php echo __('Enable Google Fonts ?','dzsapp'); ?></h4>
                                    <div class="dzscheckbox skin-nova">
    <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                        <label for="<?php echo $lab; ?>"></label>
                                    </div>
                                    <div class="sidenote"><?php echo __('you can disable the loading of google fonts and use default ones'); ?></div>
                                </div>
                                    <?php
                                    $lab = 'gzip_start_styles';

                                    echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                    ?>
                                <div class="setting">
                                    <h4 class="setting-label"><?php echo __('Compress Start Stylesheets','dzsapp'); ?></h4>
                                    <div class="dzscheckbox skin-nova">
    <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                        <label for="<?php echo $lab; ?>"></label>
                                    </div>
                                    <div class="sidenote"><?php echo __('this could help reduce load time if your server supports gzip'); ?></div>
                                </div>



                                <div class="setting">

                                    <h4 class="setting-label"><?php echo __("Like Markup"); ?></h4>


                                    <?php
                                    $lab = 'str_likes_part1';
                                    echo DZSHelpers::generate_input_textarea($lab,array('class' => 'semi-big-textarea','seekval' => $dzsap_portal->main_settings[$lab],'extraattr' => ' rows="4"'));

                                    //                        print_r($opts);
                                    ?>
                                </div>

                                <div class="setting">

                                    <h4 class="setting-label"><?php echo __("Like Count Markup "); ?></h4>


                                    <?php
                                    $lab = 'str_likes_part2';
                                    echo DZSHelpers::generate_input_textarea($lab,array('class' => 'semi-big-textarea','seekval' => $dzsap_portal->main_settings[$lab],'extraattr' => ' rows="2"'));

                                    //                        print_r($opts);
                                    ?>
                                </div>

                                <div class="setting">

                                    <h4 class="setting-label"><?php echo __("View Markup "); ?></h4>


                                    <?php
                                    $lab = 'str_views';
                                    echo DZSHelpers::generate_input_textarea($lab,array('class' => 'semi-big-textarea','seekval' => $dzsap_portal->main_settings[$lab],'extraattr' => ' rows="4"'));

                                    //                        print_r($opts);
                                    ?>
                                </div>


                            </div>
                        </div><div class="dzs-tab-tobe tab-disabled">
                            <div class="tab-menu ">
                                &nbsp;&nbsp;
                            </div>
                            <div class="tab-content">

                            </div>
                        </div>

                        <div class="dzs-tab-tobe">
                            <div class="tab-menu with-tooltip">
                                <i class="fa fa-paypal"></i> <?php echo __("Payment"); ?>
                            </div>
                            <div class="tab-content">
                                <br>

                                    <?php
                                    $lab = 'enable_shop';

                                    echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                    ?>
                                <div class="setting">
                                    <h4 class="setting-label"><?php echo __('Enable Shop ?','dzsapp'); ?></h4>
                                    <div class="dzscheckbox skin-nova">
    <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                        <label for="<?php echo $lab; ?>"></label>
                                    </div>
                                    <div class="sidenote"><?php echo __('enable shop and cart; if disabled, tracks can still be set for download by setting the price to 0'); ?></div>
                                </div>

                                    <?php
                                    $lab = 'paypal_use_author_email';

                                    echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                    ?>
                                <div class="setting">
                                    <h4 class="setting-label"><?php echo __('Use Author Email for Paying Tracks?','dzsapp'); ?></h4>
                                    <div class="dzscheckbox skin-nova">
    <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                        <label for="<?php echo $lab; ?>"></label>
                                    </div>
                                    <div class="sidenote"><?php echo __('leave the payments to be transfered to the track author directly '); ?></div>
                                </div>

                                    <?php
                                    $lab = 'developer_paypal_sandbox_mode';

                                    echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                    ?>
                                <div class="setting">
                                    <h4 class="setting-label"><?php echo __('Paypal Sandbox Mode','dzsapp'); ?></h4>
                                    <div class="dzscheckbox skin-nova">
    <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                        <label for="<?php echo $lab; ?>"></label>
                                    </div>
                                    <div class="sidenote"><?php echo __('payment leads to test paypal or real paypal?'); ?></div>
                                </div>



                                <div class="setting">

                                    <h4 class="setting-label"><?php echo __("Paypal Currency Code"); ?></h4>


                                    <?php
                                    $lab = 'paypal_currency_code';
                                    echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                    //                        print_r($opts);
                                    ?>

                                    <div class="sidenote"><?php echo __('change the currency code to EUR / etc.'); ?></div>
                                </div>

    <?php
    $lab = 'enable_user_credit';

    echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
    ?>
                                <div class="setting">
                                    <h4 class="setting-label"><?php echo __('Enable Credit Option','dzsapp'); ?></h4>
                                    <div class="dzscheckbox skin-nova">
                                    <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                        <label for="<?php echo $lab; ?>"></label>
                                    </div>
                                    <div class="sidenote"><?php echo __('enable user credit - must be added by admin'); ?></div>
                                </div>





                                <div class="setting">

                                    <h4 class="setting-label"><?php echo sprintf("<strong>%s</strong> %s",__("Add to cart"),__("Text")); ?>
                                    </h4>


                                        <?php
                                        $lab = 'add_to_cart_str';
                                        echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => htmlentities($dzsap_portal->main_settings[$lab]),));

                                        //                        print_r($opts);
                                        ?>

                                    <div class="sidenote"><?php echo __('default is ').'<strong>'.htmlentities('<i class="fa fa-shopping-cart"></i><span class="btn-label">'.__('Add to Cart').'</span>').'</strong>'; ?></div>
                                </div>





                                <div class="setting">

                                    <h4 class="setting-label">PayPal Receiver Account</h4>


    <?php
    $lab = 'paypal_receiver_account';
    echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

    //                        print_r($opts);
    ?>

                                    <div class="sidenote"><?php echo __('Here all the commision payments will be sent.'); ?></div>
                                </div>




                                <div class="setting">

                                    <h4 class="setting-label"><?php echo __("Currency Label"); ?></h4>


    <?php
    $lab = 'currency_label';
    echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

    //                        print_r($opts);
    ?>

                                    <div class="sidenote"><?php echo __('the currency shown in cart'); ?></div>
                                </div>


                                <div class="setting">

                                    <h4 class="setting-label"><?php echo __("PRO Account Price 30 days"); ?></h4>


    <?php
    $lab = 'pro_account_price';
    echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

    //                        print_r($opts);
    ?>

                                    <div class="sidenote"><?php echo __('pro account price in US$'); ?></div>
                                </div>


                                <div class="setting">

                                    <h4 class="setting-label"><?php echo __("PRO Account Price 90 days"); ?></h4>


    <?php
    $lab = 'pro_account_price_90';
    echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

    //                        print_r($opts);
    ?>

                                    <div class="sidenote"><?php echo __('pro account price in US$'); ?></div>
                                </div>


                                <div class="setting">

                                    <h4 class="setting-label"><?php echo __("PRO Account Price One Year"); ?></h4>


    <?php
    $lab = 'pro_account_price_year';
    echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

    //                        print_r($opts);
    ?>

                                    <div class="sidenote"><?php echo __('pro account price in US$'); ?></div>
                                </div>




                                <div class="setting">

                                    <h4 class="setting-label"><?php echo __("Normal Account Upload Limit"); ?></h4>


    <?php
    $lab = 'upload_limit_normal';
    echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

    //                        print_r($opts);
    ?>

                                    <div class="sidenote"><?php echo __('in MB / or just place "unlimited" for unlimtied space'); ?></div>
                                </div>




                                <div class="setting">

                                    <h4 class="setting-label"><?php echo __("PRO Account Upload Limit"); ?></h4>


                                    <?php
                                    $lab = 'upload_limit_pro';
                                    echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                    //                        print_r($opts);
                                    ?>

                                    <div class="sidenote"><?php echo __('in MB / or just place "unlimited" for unlimtied space'); ?></div>
                                </div>




                                <div class="setting">

                                    <h4 class="setting-label"><?php echo __("Normal Account Upload Track Number Limit"); ?></h4>


    <?php
    $lab = 'upload_nr_limit_normal';
    echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

    //                        print_r($opts);
    ?>

                                    <div class="sidenote"><?php echo __('max number of tracks to be able to be uploaded by normal account'); ?></div>
                                </div>




                                <div class="setting">

                                    <h4 class="setting-label"><?php echo __("PRO Account Upload Track Number Limit"); ?></h4>


                                    <?php
                                    $lab = 'upload_nr_limit_pro';
                                    echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                    //                        print_r($opts);
                                    ?>

                                    <div class="sidenote"><?php echo __('max number of tracks to be able to be uploaded by normal account'); ?></div>
                                </div>





    <?php
    $lab = 'allow_only_logged_in_users_to_download_free_tracks';
    echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
    ?>
                                <div class="setting">
                                    <h4 class="setting-label"><?php echo __('Allow Only Logged In Users to Download Free Tracks','dzsapp'); ?></h4>
                                    <div class="dzscheckbox skin-nova">
                                    <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                        <label for="<?php echo $lab; ?>"></label>
                                    </div>
                                    <div class="sidenote"><?php echo sprintf(''); ?></div>
                                </div>


                            </div>


                        </div>

                        <div class="dzs-tab-tobe tab-disabled">
                            <div class="tab-menu ">
                                &nbsp;&nbsp;
                            </div>
                            <div class="tab-content">

                            </div>
                        </div>

                        <div class="dzs-tab-tobe">
                            <div class="tab-menu with-tooltip">
                                <i class="fa fa-globe"></i> <?php echo __("Languages"); ?>
                            </div>
                            <div class="tab-content">
                                <br>

                                <div class="row">
                                    <div class="col-md-6">

                                        <?php
                                        $lab = 'lang_1_text';
                                        ?>

                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Language 1 Text"); ?></h4>


                                            <?php
                                            echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                            //                        print_r($opts);
                                            ?>

                                            <div class="sidenote"><?php echo __('Language Name.'); ?></div>
                                        </div>


                                        <?php
                                        $lab = 'lang_1_img';
                                        ?>
                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Language 1 Image"); ?></h4>


                                            <?php
                                            echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                            //                        print_r($opts);
                                            ?>

                                            <div class="sidenote"><?php echo __('Language Image.'); ?></div>
                                        </div>

                                        <?php
                                        $lab = 'lang_1_code';
                                        ?>

                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Language 1 Code"); ?></h4>


                                            <?php
                                            echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                            //                        print_r($opts);
                                            ?>

                                            <div class="sidenote"><?php echo __('The language code. For example for english it is - en_EN'); ?></div>
                                        </div>



                                        <?php
                                        $lab = 'lang_1_is_rtl';

                                        echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                        ?>
                                        <div class="setting">
                                            <h4 class="setting-label"><?php echo __('Is RTL ?','dzsapp'); ?></h4>
                                            <div class="dzscheckbox skin-nova">
                                                <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                                <label for="<?php echo $lab; ?>"></label>
                                            </div>
                                            <div class="sidenote"><?php echo __('Check if the writing is from right to left ( like arabic ) '); ?></div>
                                        </div>
                                        <br>
                                        <br>





                                        <?php
                                        $lab = 'lang_3_text';
                                        ?>

                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Language 3 Text"); ?></h4>


                                            <?php
                                            echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                            //                        print_r($opts);
                                            ?>

                                            <div class="sidenote"><?php echo __('Language Name.'); ?></div>
                                        </div>

                                        <?php
                                        $lab = 'lang_3_img';
                                        ?>

                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Language 3 Image"); ?></h4>


                                            <?php
                                            echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                            //                        print_r($opts);
                                            ?>

                                            <div class="sidenote"><?php echo __('Language Image.'); ?></div>
                                        </div>

                                        <?php
                                        $lab = 'lang_3_code';
                                        ?>

                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Language 3 Code"); ?></h4>


                                            <?php
                                            echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                            //                        print_r($opts);
                                            ?>

                                            <div class="sidenote"><?php echo __('The language code. For example for english it is - en_EN'); ?></div>
                                        </div>




                                        <?php
                                        $lab = 'lang_3_is_rtl';

                                        echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                        ?>
                                        <div class="setting">
                                            <h4 class="setting-label"><?php echo __('Is RTL ?','dzsapp'); ?></h4>
                                            <div class="dzscheckbox skin-nova">
                                                <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                                <label for="<?php echo $lab; ?>"></label>
                                            </div>
                                            <div class="sidenote"><?php echo __('Check if the writing is from right to left ( like arabic ) '); ?></div>
                                        </div>
                                        <br>
                                        <br>












                                        <?php
                                        $lab = 'lang_5_img';
                                        ?>

                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Language 5 Image"); ?></h4>


                                            <?php
                                            echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                            //                        print_r($opts);
                                            ?>

                                            <div class="sidenote"><?php echo __('Language Image.'); ?></div>
                                        </div>

                                        <?php
                                        $lab = 'lang_5_code';
                                        ?>

                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Language 5 Code"); ?></h4>


                                            <?php
                                            echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                            //                        print_r($opts);
                                            ?>

                                            <div class="sidenote"><?php echo __('The language code. For example for english it is - en_EN'); ?></div>
                                        </div>

                                        <?php
                                        $lab = 'lang_5_text';
                                        ?>

                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Language 5 Text"); ?></h4>


                                            <?php
                                            echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                            //                        print_r($opts);
                                            ?>

                                            <div class="sidenote"><?php echo __('Language Name.'); ?></div>
                                        </div>





                                        <?php
                                        $lab = 'lang_5_is_rtl';

                                        echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                        ?>
                                        <div class="setting">
                                            <h4 class="setting-label"><?php echo __('Is RTL ?','dzsapp'); ?></h4>
                                            <div class="dzscheckbox skin-nova">
                                                <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                                <label for="<?php echo $lab; ?>"></label>
                                            </div>
                                            <div class="sidenote"><?php echo __('Check if the writing is from right to left ( like arabic ) '); ?></div>
                                        </div>
                                        <br>



                                    </div>

<!--                                    end .col-md-6-->

                                    <div class="col-md-6">





                                        <?php
                                        $lab = 'lang_2_text';
                                        ?>

                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Language 2 Text"); ?></h4>


                                            <?php
                                            echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                            //                        print_r($opts);
                                            ?>

                                            <div class="sidenote"><?php echo __('Language Name.'); ?></div>
                                        </div>

                                        <?php
                                        $lab = 'lang_2_img';
                                        ?>

                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Language 2 Image"); ?></h4>


                                            <?php
                                            echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                            //                        print_r($opts);
                                            ?>

                                            <div class="sidenote"><?php echo __('Language Image.'); ?></div>
                                        </div>

                                        <?php
                                        $lab = 'lang_2_code';
                                        ?>

                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Language 2 Code"); ?></h4>


                                            <?php
                                            echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                            //                        print_r($opts);
                                            ?>

                                            <div class="sidenote"><?php echo __('The language code. For example for english it is - en_EN'); ?></div>
                                        </div>


                                        <?php
                                        $lab = 'lang_2_is_rtl';

                                        echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                        ?>
                                        <div class="setting">
                                            <h4 class="setting-label"><?php echo __('Is RTL ?','dzsapp'); ?></h4>
                                            <div class="dzscheckbox skin-nova">
                                                <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                                <label for="<?php echo $lab; ?>"></label>
                                            </div>
                                            <div class="sidenote"><?php echo __('Check if the writing is from right to left ( like arabic ) '); ?></div>
                                        </div>
                                        <br>
                                        <br>



                                        <?php
                                        $lab = 'lang_4_img';
                                        ?>

                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Language 4 Image"); ?></h4>


                                            <?php
                                            echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                            //                        print_r($opts);
                                            ?>

                                            <div class="sidenote"><?php echo __('Language Image.'); ?></div>
                                        </div>

                                        <?php
                                        $lab = 'lang_4_code';
                                        ?>

                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Language 4 Code"); ?></h4>


                                            <?php
                                            echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                            //                        print_r($opts);
                                            ?>

                                            <div class="sidenote"><?php echo __('The language code. For example for english it is - en_EN'); ?></div>
                                        </div>

                                        <?php
                                        $lab = 'lang_4_text';
                                        ?>

                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Language 4 Text"); ?></h4>


                                            <?php
                                            echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                            //                        print_r($opts);
                                            ?>

                                            <div class="sidenote"><?php echo __('Language Name.'); ?></div>
                                        </div>





                                        <?php
                                        $lab = 'lang_4_is_rtl';

                                        echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                        ?>
                                        <div class="setting">
                                            <h4 class="setting-label"><?php echo __('Is RTL ?','dzsapp'); ?></h4>
                                            <div class="dzscheckbox skin-nova">
                                                <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                                <label for="<?php echo $lab; ?>"></label>
                                            </div>
                                            <div class="sidenote"><?php echo __('Check if the writing is from right to left ( like arabic ) '); ?></div>
                                        </div>
                                        <br>
                                        <br>





                                        <?php
                                        $lab = 'lang_6_img';
                                        ?>

                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Language 6 Image"); ?></h4>


                                            <?php
                                            echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                            //                        print_r($opts);
                                            ?>

                                            <div class="sidenote"><?php echo __('Language Image.'); ?></div>
                                        </div>

                                        <?php
                                        $lab = 'lang_6_code';
                                        ?>

                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Language 6 Code"); ?></h4>


                                            <?php
                                            echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                            //                        print_r($opts);
                                            ?>

                                            <div class="sidenote"><?php echo __('The language code. For example for english it is - en_EN, for italian it is it_IT'); ?></div>
                                        </div>



                                        <?php
                                        $lab = 'lang_6_text';
                                        ?>

                                        <div class="setting">

                                            <h4 class="setting-label"><?php echo __("Language 6 Text"); ?></h4>


                                            <?php
                                            echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                            //                        print_r($opts);
                                            ?>

                                            <div class="sidenote"><?php echo __('Language Name.'); ?></div>
                                        </div>





                                        <?php
                                        $lab = 'lang_6_is_rtl';

                                        echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                        ?>
                                        <div class="setting">
                                            <h4 class="setting-label"><?php echo __('Is RTL ?','dzsapp'); ?></h4>
                                            <div class="dzscheckbox skin-nova">
                                                <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                                <label for="<?php echo $lab; ?>"></label>
                                            </div>
                                            <div class="sidenote"><?php echo __('Check if the writing is from right to left ( like arabic ) '); ?></div>
                                        </div>
                                        <br>



                                    </div>
                                </div>


<!--                                end .row-->









                            </div>


                        </div>

                        <div class="dzs-tab-tobe tab-disabled">
                            <div class="tab-menu ">
                                &nbsp;&nbsp;
                            </div>
                            <div class="tab-content">

                            </div>
                        </div>

                        <div class="dzs-tab-tobe">
                            <div class="tab-menu with-tooltip">
                                <i class="fa fa-toggle-on"></i> <?php echo __("Developer") ?>
                            </div>
                            <div class="tab-content">
                                <br>



                                <div class="setting">

                                    <h4 class="setting-label">Google Recapcha Sitekey</h4>


    <?php
    $lab = 'api_google_recapcha_sitekey';
    echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

    //                        print_r($opts);
    ?>

                                    <div class="sidenote"><?php echo __('Get Google Sitekey and secret from <a href="https://www.google.com/recaptcha/admin#list">here</a>.'); ?></div>
                                </div>


                                <div class="setting">

                                    <h4 class="setting-label">Google Recapcha Secret</h4>


                                <?php
                                $lab = 'api_google_recapcha_secret';
                                echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                //                        print_r($opts);
                                ?>
                                </div>



                                <div class="setting">

                                    <h4 class="setting-label">Facebook Application ID</h4>


                                    <?php
                                    $lab = 'api_facebook_app_id';
                                    echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                    //                        print_r($opts);
                                    ?>

                                    <div class="sidenote"><?php echo __('Create a new application from <a href="https://developers.facebook.com/">here</a>.'); ?></div>
                                </div>


                                <div class="setting">

                                    <h4 class="setting-label"><?php echo __("Facebook Application Secret"); ?></h4>


                                    <?php
                                    $lab = 'api_facebook_app_secret';
                                    echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                    //                        print_r($opts);
                                    ?>
                                </div>


                                <div class="setting">

                                    <h4 class="setting-label"><?php echo __("Soundcloud API Key"); ?></h4>


                                    <?php
                                    $lab = 'soundcloud_api_key';
                                    echo DZSHelpers::generate_input_text($lab,array('class' => 'simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

                                    //                        print_r($opts);
                                    ?>
                                    <div
                                        class="sidenote"><?php echo __('You can get one by going to <a href="http://soundcloud.com/you/apps/new">here</a> and registering a new app. The api key wil lbe the client ID you get at the end.', 'dzsap'); ?></div>
                                </div>


                                <?php
                                $lab = 'debug_pagebuilder';
                                echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                ?>
                                <div class="setting">
                                    <h4 class="setting-label"><?php echo __('Debug Pagebuilder Frontend ?','dzsapp'); ?></h4>
                                    <div class="dzscheckbox skin-nova">
    <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                        <label for="<?php echo $lab; ?>"></label>
                                    </div>
                                    <div class="sidenote"><?php echo __('parallax effects can be added to some elements'); ?></div>
                                </div>




                            </div>
                        </div>




                        <!-- system check -->
                        <div class="dzs-tab-tobe tab-disabled">
                            <div class="tab-menu ">
                                &nbsp;&nbsp;
                            </div>
                            <div class="tab-content">

                            </div>
                        </div>

                        <div class="dzs-tab-tobe">
                            <div class="tab-menu with-tooltip">
                                <i class="fa fa-gear"></i> <?php echo __("System Check"); ?>
                            </div>
                            <div class="tab-content">
                                <br>



                                <div class="setting">

                                    <h4 class="setting-label">GetText <?php echo __("Support"); ?></h4>


    <?php
    if (function_exists("gettext")) {
        echo '<div class="setting-text-ok"><i class="fa fa-thumbs-up"></i> '.''.__("supported").'</div>';
    } else {

        echo '<div class="setting-text-notok">'.''.__("not supported").'</div>';
    }
    ?>

                                    <div class="sidenote"><?php echo __('translation support'); ?></div>
                                </div>


                                <div class="setting">

                                    <h4 class="setting-label">ZipArchive <?php echo __("Support"); ?></h4>


    <?php
    if (class_exists("ZipArchive")) {
        echo '<div class="setting-text-ok"><i class="fa fa-thumbs-up"></i> '.''.__("supported").'</div>';
    } else {

        echo '<div class="setting-text-notok">'.''.__("not supported").'</div>';
    }
    ?>

                                    <div class="sidenote"><?php echo __('zip making for album download support'); ?></div>
                                </div>



                                <div class="setting">

                                    <h4 class="setting-label">Curl <?php echo __("Support"); ?></h4>


                                    <?php
                                    if (function_exists('curl_version')) {
                                        echo '<div class="setting-text-ok"><i class="fa fa-thumbs-up"></i> '.''.__("supported").'</div>';
                                    } else {

                                        echo '<div class="setting-text-notok">'.''.__("not supported").'</div>';
                                    }
                                    ?>

                                    <div class="sidenote"><?php echo __('for making youtube / vimeo api calls'); ?></div>
                                </div>
                                <div class="setting">

                                    <h4 class="setting-label">allow_url_fopen <?php echo __("Support"); ?></h4>


                                    <?php
                                    if (ini_get('allow_url_fopen')) {
                                        echo '<div class="setting-text-ok"><i class="fa fa-thumbs-up"></i> '.''.__("supported").'</div>';
                                    } else {

                                        echo '<div class="setting-text-notok">'.''.__("not supported").'</div>';
                                    }
                                    ?>

                                    <div class="sidenote"><?php echo __('for making youtube / vimeo api calls'); ?></div>
                                </div>


                                <div class="setting">

                                    <h4 class="setting-label">file_put_contents <?php echo __("Support"); ?></h4>


    <?php
    if (ini_get("allow_url_fopen")) {
        echo '<div class="setting-text-ok"><i class="fa fa-thumbs-up"></i> '.''.__("supported").'</div>';
    } else {

        echo '<div class="setting-text-notok">'.''.__("not supported").'</div>';
    }
    ?>

                                    <div class="sidenote"><?php echo __('this is for uploading'); ?></div>
                                </div>


                                <div class="setting">

                                    <h4 class="setting-label">SQL <?php echo __("Mode"); ?></h4>


    <?php

    $aux = $dzsap_portal->dblink->query('SELECT @@sql_mode');

//    print_r($aux);

    while($row = $aux->fetch_assoc()){
//        print_r($row);

        if($row['@@sql_mode']){
            echo $row['@@sql_mode'];
        }
    }


    ?>

                                    <div class="sidenote"><?php printf(__('should be %sNO_ENGINE_SUBSTITUTION%s'),'<strong>','</strong>'); ?></div>
                                </div>



                                <div class="setting">

                                    <h4 class="setting-label"><?php echo __("PHP Version"); ?></h4>

                                    <div class="setting-text-ok">
    <?php
    echo phpversion();
    ?>
                                    </div>

                                    <div class="sidenote"><?php echo __('the install php version, 5.4 or greater required for facebook api'); ?></div>
                                </div>



                                <div class="setting">

                                    <h4 class="setting-label"><?php echo __("SSL Version"); ?></h4>

                                    <div class="setting-text-ok">
                                    <?php
                                    echo $dzsap_portal->main_settings['ssl_protocol'];
                                    ?>
                                    </div>

                                    <div class="sidenote"><?php echo __('the ssl version - will be needed for correct communication to PayPal'); ?></div>
                                </div>



                                <div class="setting">

                                    <h4 class="setting-label"><?php echo __("TLS Version"); ?></h4>

                                    <div class="setting-text-ok">
                                    <?php
                                    echo $dzsap_portal->main_settings['tls_protocol'];
                                    ?>
                                    </div>

                                    <div class="sidenote"><?php echo __('the tls version - will be needed for correct communication to PayPal'); ?></div>
                                </div>



                                <div class="setting">


                                    <p><button class="btn-primary padding-small btn-repair-database"><?php echo __("Repair Database"); ?></button></p>
                                </div>




                            </div>
                        </div>
                        <!-- system check END -->




                        <!-- sociak -->
                        <div class="dzs-tab-tobe tab-disabled">
                            <div class="tab-menu ">
                                &nbsp;&nbsp;
                            </div>
                            <div class="tab-content">

                            </div>
                        </div>

                        <div class="dzs-tab-tobe">
                            <div class="tab-menu with-tooltip">
                                <i class="fa fa-share-alt"></i> <?php echo __("Social"); ?>
                            </div>
                            <div class="tab-content">
                                <br>



    <?php
    $lab = 'enable_facebook_share';
    echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
    ?>
                                <div class="setting">
                                    <h4 class="setting-label"><?php echo __('Enable Facebook Share','dzsapp'); ?></h4>
                                    <div class="dzscheckbox skin-nova">
                                <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                        <label for="<?php echo $lab; ?>"></label>
                                    </div>
                                    <div class="sidenote"><?php echo ''; ?></div>
                                </div>



    <?php
    $lab = 'enable_twitter_share';
    echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
    ?>
                                <div class="setting">
                                    <h4 class="setting-label"><?php echo __('Enable Twitter Share','dzsapp'); ?></h4>
                                    <div class="dzscheckbox skin-nova">
    <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                        <label for="<?php echo $lab; ?>"></label>
                                    </div>
                                    <div class="sidenote"><?php echo ''; ?></div>
                                </div>



    <?php
    $lab = 'enable_google_share';
    echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
    ?>
                                <div class="setting">
                                    <h4 class="setting-label"><?php echo __('Enable Google Plus Share','dzsapp'); ?></h4>
                                    <div class="dzscheckbox skin-nova">
    <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                        <label for="<?php echo $lab; ?>"></label>
                                    </div>
                                    <div class="sidenote"><?php echo ''; ?></div>
                                </div>



    <?php
    $lab = 'enable_linkedin_share';
    echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
    ?>
                                <div class="setting">
                                    <h4 class="setting-label"><?php echo __('Enable Linkedin Share','dzsapp'); ?></h4>
                                    <div class="dzscheckbox skin-nova">
                                    <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                        <label for="<?php echo $lab; ?>"></label>
                                    </div>
                                    <div class="sidenote"><?php echo ''; ?></div>
                                </div>


                                    <?php
                                    $lab = 'enable_pinterest_share';
                                    echo DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));
                                    ?>
                                <div class="setting">
                                    <h4 class="setting-label"><?php echo __('Enable Pinterest Share','dzsapp'); ?></h4>
                                    <div class="dzscheckbox skin-nova">
    <?php echo DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $dzsap_portal->main_settings[$lab])); ?>
                                        <label for="<?php echo $lab; ?>"></label>
                                    </div>
                                    <div class="sidenote"><?php echo ''; ?></div>
                                </div>




                            </div>
                        </div>
                        <!-- system check END -->



                    </div>






                    <div class="save-main-settings-con">
                        <button class="btn-primary btn-save-main-settings">Save</button>
                    </div>

                    <br>
                    <br>
                    <br>

                </form>
            </div>


        </div>


    </div>
    <script>
    </script>
    
    
            <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
            <script src="jqueryui/jquery-ui.min.js" type="text/javascript"></script>
                                        <?php
                                        
                                        
                                    }
                                    
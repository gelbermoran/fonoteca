/*

Author: DigitalZoomStudio
Version: 1.43

 */


"use strict";


if (String(window.location.hash).substring(0, 1) == "#") {
    window.location.hash = "";
    window.location.href = window.location.href.slice(0, -1);
}

window.cache_cards = {};

window.wave_bg_generated = false;
window.wave_prog_generated = false;


var first_time_loaded_messages = true;




window.getTabforMap = function (arg, pargs) {
    if (window.gm_locations[arg] && window.gm_locations[arg].lat) {

        window.panTo(window.gm_locations[arg].lat, window.gm_locations[arg].long);
    }
}


function get_query_arg_sp(purl, key) {
    //console.info(purl);
    if (purl.indexOf(key + '=') > -1) {
        //faconsole.log('testtt');
        var regexS = "[?&]" + key + "(.+?)(?=&|$)";
        var regex = new RegExp(regexS);
        var regtest = regex.exec(purl);


        //console.info(regex, regtest);
        if (regtest != null) {
            //var splitterS = regtest;


            if (regtest[1]) {
                var aux = regtest[1].replace(/=/g, '');
                return aux;
            } else {
                return '';
            }


        }
        //$('.zoombox').eq
    }
}



jQuery(document).ready(function ($) {



    var _cart_contents = $('.cart-contents')
            , _feedbacker = $('.feedbacker').eq(0)
            , _content_wrapper = $('.content-wrapper').eq(0)
            , _mainMenu = null
            , _mainMenuResponsive = null
            , _body = $('body').eq(0)
            , _notificationsCon = $('.notifications-con').eq(0)
            , _notificationsMainCon = $('.notifications-main-con').eq(0)
            , _theActualNav = null
            , _contentContainer = null// -- the content container , this is where ajax content goes
            ;

    var messages_array = [];
    var _messages_container = null
            , _messages_friends_container = null
            ;

    var responsive_threshold = 900;

    var inter_load_results = 0
            , inter_load_messages = 0
            , inter_stop_next_track_from_playing = 0
            ;

    var sw_can_next_track_play = true
            ;

    var ww = 0
            , wh = 0


    var query_scroll_targets = []
            ;



    // -- ajax vars



    var new_page_html = '';
    var newclass_body = '';
    var currclass_body = '';

    var scripts_loaded_arr = [];
    var scripts_tobeloaded = [];
    var stylesheets_tobeloaded = [];

    var elements_tobe_added_arr = []
            , videoplayers_tobe_resized = []
            ;

    var windowhref = ''
            , ajax_site_url = ''
            , curr_html = ''
            , newtitle = ''
            , curr_html_with_clear_cache = false
            , history_first_pushed_state = false

            ;

    var has_custom_outside_content_1 = false;

    var ___response = null;

    var currPage = 'page'
            , currPage_type = 'page'
            , uploader_type = 'track'
            ;

    var bg_transition = 'fade'
            ;



    var old_dzsap_options = {}
    ;


    var tracks_list = [] // -- we need this for autoplay next option
            , curr_playing_track = 0 // -- the current playing track id
            ;

    var state_curr_menu_items_links = []
            ;


    var busy_main_transition = false

            , page_change_ind = 0
            , content_wrapper_transitioned_out = false
            ;

    var debug_var = false;

    var checkout_original_form_action = ''
            ;



    var map = null;


    if ($('.shortcode-header').length > 0) {

        _mainMenu = $('.shortcode-header').eq(0);
    }


    windowhref = window.location.href;
    var auxa = windowhref.split('/');

    var i = 0;
    for (i in auxa) {

        if (i > 0) {
            ajax_site_url += '/';
        }
        if (i < auxa.length - 1) {
            ajax_site_url += auxa[i];
        }


    }

    if (dzsap_settings.optional_url_base) {
        ajax_site_url = dzsap_settings.optional_url_base;
    }

    //console.info(ajax_site_url);




    // -- building the main menu
    if (_mainMenu) {

        _mainMenu.addClass('main-menu');


        _content_wrapper.after('<div class="main-menu-responsive"></div>');


        _mainMenuResponsive = _content_wrapper.next('.main-menu-responsive').eq(0);




        // console.info(_mainMenu, _mainMenu.attr('class'), _mainMenu.hasClass('style-default'))


        var regex_style = /(style-.*?)[ |$]/g;


        var aux = regex_style.exec(_mainMenu.attr('class'));

        // console.info(aux);

        if (aux) {
            $('.header--padder').eq(0).addClass('for-' + aux[1]);
        }



        if (_mainMenu.hasClass('style-default') || _mainMenu.hasClass('style-domino')) {


            _mainMenuResponsive.append('<h4>Main Menu</h4>');
            _mainMenuResponsive.append(_mainMenu.find('.header-menu').eq(0).clone());

            _mainMenuResponsive.append('<h4>Other Pages</h4>');

            //console.info(_mainMenu.find('.fa-shopping-cart'));

            if (_mainMenu.find('.fa-shopping-cart').length > 0) {

                _mainMenuResponsive.append('<ul><li><a href="' + dzsap_settings.optional_url_base + 'index.php?page=checkout"><i class="fa fa fa-shopping-cart"></i> Checkout</a></li><li><a href="#"><i class="fa fa fa-search"></i> Search</a></li></ul>');
                //_mainMenuResponsive.append('');
            }


            _mainMenuResponsive.append('<h4>User Options</h4>');
            if (_mainMenu.find('.user-menu--options').eq(0).length == 0) {

                //console.info(_mainMenu.find('.login-login.menu-right-block'));
                _mainMenuResponsive.append(_mainMenu.find('.login-login.menu-right-block').eq(0).children().clone());

                _mainMenuResponsive.children().removeClass('dzstooltip');

            } else {

                _mainMenuResponsive.append(_mainMenu.find('.user-menu--options').eq(0).clone());
            }

        }

        //console.info(_mainMenuResponsive);
    }

    if ($('.the-actual-nav').length == 0) {
        _theActualNav = $('ul.header-menu').eq(0);
    }

    if (dzsap_settings.enable_ajax == 'on') {
        _contentContainer = $('.content-section').eq(0);
    }

    //console.info(_theActualNav, _contentContainer);


    //console.log(_mainMenu);
//    console.info($('.dzs-single-upload'));

    //console.log($('.dzs-single-upload'));


    determine_curr_html();


    $('body.page-register .register-btn').bind('click', handle_mouse);
    $(window).bind('resize', handle_resize);
    $(window).on('scroll', handle_scroll);


    if (window.addEventListener) {

        window.addEventListener('popstate', handle_popstate);
    }

    // console.info($('.checkout-form input[name=first_name]'));

    //$(document).delegate('', 'change', handle_change );
    $(document).delegate('input[name=search_keywords], .input-ujarak-style, .selector-main-searcher', 'keyup', handle_submit);
    $(document).delegate('form.messages-send-con,form.usersettings-form, form.comment-form-con, form.edit-panel, form.reportcopyright, form.install-form', 'submit', handle_submit);
    $(document).delegate('.ajax-link', 'click', click_menu_anchor);
    $(document).delegate('.btn-autogenerate-waveform-bg', 'click', click_btn_autogenerate_waveform_bg);
    $(document).delegate('.btn-autogenerate-waveform-prog', 'click', click_btn_autogenerate_waveform_prog);
    $(document).delegate('.upload-track-btn,.cancel-upload-btn, form.register-form .button-primary-for-register,.dzscheckbox, .add-to-cart-btn, .add-to-playlist-btn, .btn-ajax-add-playlist, .btn-ajax-add-to-playlist-id, .btn-ajax-remove-playlist, .btn-toggle-responsive-menu, .big-search-btn, .bigsearch--the-bg,.btn-follow,.edit-btn,.delete-repost-btn,.share-btn,.stats-btn, .field-for-view,.delete-track-btn, .responsive-menu-closer, .cart-delete-item-btn,.btn-pagination-button, .pagination-a', 'click', handle_mouse);
    $(document).delegate('input[name=is_buyable], input[name=thumbnail], input[name=pay_with], .checkout-form input[name=first_name], .checkout-form input[name=last_name], .checkout-form input[name=user_address], .checkout-form input[name=user_country], .checkout-form input[name=user_telephone]', 'change', handle_change);

    $(document).on('click', '.btn-repost, .btn-install-zoomportal, .login-login .login-signup--label, .upload-track-options .delete-track-con, .album-part .add-btn, .album-part .remove-btn, .delete-comment-btn, .download-anchor-btn, .btn-in-zoombox, a[data-playerid="proaccount"],.delete-watermark-btn', handle_mouse);
    $(document).on('change', '.submit-track-form select[name=type],.submit-track-form *[name=source], input[name=title],.upload-watermark-field', handle_change);
    $(document).on('mouseover', '.dzstooltip-con-user-summary', handle_mouse);

    window.click_menu_anchor = click_menu_anchor;
    window.dzsapp_click_menu_anchor = click_menu_anchor;


    handle_scroll();

    setTimeout(handle_scroll, 1000);
    setTimeout(handle_scroll, 2000);

    //console.log($('input[name=is_buyable]'));
    //console.log($('.upload-track-btn'));
    //$(document).delegate('.btn-delete-element', 'click', handle_mouse);

    setInterval(check_things_interval, 1000);



    $('.playlists-con .playlist-btn').bind('click', handle_mouse);
    init();

//    console.info($('.playlists-con .playlist-btn'));

//    $('#upload-mp3').get(0).ceva='alceva';


    function init() {

        if (dzsap_settings.enable_cart == 'on') {

            load_cart();
        }




        var regex_bodyclass = /.*?(page-.*?)[ |"]/g;


        //console.info(_body.attr('class'));
        var aux23 = regex_bodyclass.exec(_body.attr('class'));

        currclass_body = '';
        if (aux23) {
            if (aux23[1]) {
                currclass_body = aux23[1];
            }
        }

        //console.info(currclass_body);


        $('script').each(function () {
            var _t = $(this);


            if (_t.attr('src')) {
                scripts_loaded_arr.push(_t.attr('src'));
            }
            //console.info(_t.attr('src'));

            if (String(_t.attr('src')).indexOf('https://maps.googleapis.com/maps/api') == 0) {
                window.google_maps_loaded = true;
            }
        });


        $('link').each(function () {
            var _t = $(this);

            //console.info(_t);

            if (_t.attr('rel') == 'stylesheet' && _t.attr('href')) {
                var aux_href = _t.attr('href');
                if (aux_href.indexOf('./') == 0) {
                    aux_href = aux_href.replace('./', '');
                }
                scripts_loaded_arr.push(aux_href);
            }
        });

        if (is_ios() || is_android()) {
            // $('.dzsap-sticktobottom, .dzsap-sticktobottom-placeholder').hide();
        }

        if (dzsap_settings && dzsap_settings.currUserId == '0' && dzsap_settings.allow_only_logged_in_users_to_download_free_tracks == 'on') {
            $(document).on('click', 'a[href*="?page=download&track_id"]', function () {
                alert("You must be logged in to download");
                return false;
            });
        }




        if (dzsap_settings.enable_notifications == 'on' && _notificationsMainCon && _notificationsMainCon.length && dzsap_settings.currUserId && dzsap_settings.currUserId != '0') {
            setTimeout(function () {

                get_notifications();
            }, 2000)

            setInterval(get_notifications, 30000);

            _notificationsMainCon.on('mouseleave', function () {
                console.info('mouseleave');


                setTimeout(function () {

                    var stream_add_str = '';

                    _notificationsCon.children('.notification-con.is-unread').each(function () {
                        var _t2 = $(this);

                        console.info(_t2.attr('data-notification-id'));


                        if (stream_add_str) {
                            stream_add_str += ',' + _t2.attr('data-notification-id');
                        } else {
                            stream_add_str += '' + _t2.attr('data-notification-id');

                        }
                    });


                    if(stream_add_str){

                        var data = {
                            action: 'ajax_submit_stream_read'
                            , postdata: stream_add_str
                        };




                        $.ajax({
                            type: "POST",
                            url: dzsap_settings.settings_ajax_handler,
                            data: data,
                            success: function (response) {
                                console.info(response, response.indexOf('success - '));
                            },
                            error: function (arg) {
                                if (typeof window.console != "undefined") {
                                    console.log('Got this from the server: ' + arg, arg);
                                }
                                ;

                            }
                        });
                    }


                }, 1000)

                setTimeout(function () {

                    get_notifications();
                }, 5000)

            })
        }




        reinit();

        handle_resize();


        setTimeout(function () {

        }, 3000);
    }


    function get_notifications() {

        var data = {
            action: 'ajax_get_notifications'
        };


        $('.sidenote-loading-adding-playlist').addClass('active');
        $.ajax({
            type: "POST",
            url: dzsap_settings.settings_ajax_handler,
            data: data,
            success: function (response) {
                // console.info(response,response.indexOf('success - '));
                _notificationsCon.html(response);

                var nr_unread = 0;

                nr_unread = _notificationsCon.children('.is-unread').length;

                if (nr_unread > 0) {

                    _notificationsMainCon.find('.the-number').eq(0).html(nr_unread);
                    _notificationsMainCon.addClass('has-unread');
                } else {
                    _notificationsMainCon.removeClass('has-unread');
                }
            },
            error: function (arg) {
                if (typeof window.console != "undefined") {
                    console.log('Got this from the server: ' + arg, arg);
                }
                ;

            }
        });
    }


    function check_things_interval() {
        if (dzsap_settings.page == 'track') {
            if ($('.dzsparallaxer-for-track-cover-image').length > 0) {
                // $('.shortcode-query-type-track').eq(0).css('height()


                $('.dzsparallaxer-for-track-cover-image').eq(0).height($('.shortcode-query-type-track').eq(0).outerHeight() + 50);
                $('.dzsparallaxer-for-track-cover-image').get(0).api_handle_resize();
            }
        }
    }


    function handle_popstate(e) {
        //console.log(e, e.state);

        if (e.state && e.state.href) {
            click_menu_anchor(null, {
                'force_href': e.state.href
                , force_no_ajax: 'off'
            })

            //console.info(e.state.curr_menu_items,Object(e.state.curr_menu_items).size,Object.size(e.state.curr_menu_items));

            //console.log(e.state.curr_menu_items, e.state, history);

            if (Object.size(e.state.curr_menu_items) > 0) {


                //console.info('my docs', _theActualNav.find('.current-menu-item'))
                _theActualNav.find('.current-menu-item').removeClass('current-menu-item');

                for (var i2 = 0; i2 < Object.size(e.state.curr_menu_items); i2++) {
                    _theActualNav.find('li').eq(e.state.curr_menu_items[i2]).addClass('current-menu-item');
                }
            }
            return false;
        }
    }


    function click_menu_anchor(e, pargs) {

        //console.info('click_menu_anchor()', pargs);

        var _t = $(this);
        var thehref = _t.attr('href');
        var isselectoption = false;

        var margs = {
            _t: null
            , force_href: ''
            , force_no_ajax: 'off'
            , from_zoombox: 'off'
            , force_pushState: false
        };


        if (pargs) {
            margs = $.extend(margs, pargs);
        }

        if (margs._t) {
            _t = margs._t;
            thehref = _t.attr('href');
        }

        //console.info(_body.hasClass('page-playlistadd'), currclass_body);
        if (_body.hasClass('page-playlistadd')) {

            var args = {
                _t: _t
                , 'from_zoombox': 'on'
            };

            if (parent && parent.click_menu_anchor) {
                parent.click_menu_anchor(e, args);
            }



            return false;
        }
        if (_t && _t.parent().hasClass('current-menu-item')) {
            return false;
        }

        if (margs.from_zoombox == 'on') {
            //console.info("CLOSE ZOOMBOS");
            window.api_close_zoombox();
        }

        if (_t.hasClass && _t.hasClass('result-con')) {

            $('.bigsearch-con').removeClass('activated');
            _body.removeClass('big-search-activated');
        }



        if (_t && _t.get(0) && _t.get(0).nodeName == 'SELECT') {

            isselectoption = true;
            thehref = _t.val();
            //thehref = _t.find(':selected').attr('value');

        }

        if (_t && _t.get(0) && _t.get(0).nodeName == 'OPTION') {

            isselectoption = true;
            thehref = _t.val();
            //thehref = _t.find(':selected').attr('value');

        }

        //console.info(_t.hasClass('current-menu-item'), _t, _t.attr('class'));
        //if(_t&&_t.parent().hasClass('current-menu-item') && margs.force_no_ajax!='on'){
        //
        //    return false;
        //}

        //console.log(thehref, curr_html);

        if (thehref === curr_html) {
            return false;
        }


        if (is_touch_device()) {
            // margs.force_no_ajax = 'on';
            // window.location.href = thehref;
        }
        //console.info(_t[0]==window, thehref, margs);
        //if(_t[0]==window){
        //    return false;
        //}

        //console.info(margs.force_href, margs.force_no_ajax);
        if (margs.force_href) {
            thehref = margs.force_href;

            //console.info(margs.force_no_ajax, thehref);

            if (margs.force_no_ajax == 'on') {
                window.location.href = thehref;
            }
        }




        //console.info(busy_main_transition);
        if (busy_main_transition) {

            setTimeout(function () {
                var args = {};
                if (_t) {
                    args._t = _t;
                    args.force_href = thehref
                }
                ;

                click_menu_anchor(e, args);
            }, 1000);

            return false;
        }


        //console.info(_t,_t.val(), isselectoption,thehref);
        if (isselectoption) {
            //return false;
        }
//        console.info(_t);

        //==== well test if it's an outer link, if its an outside link we dont need any ajax.


        //console.info(ajax_site_url); return;
        //console.info(window.dzsap_settings.enable_ajax == 'on', window, margs.force_no_ajax)
        if (window.dzsap_settings.enable_ajax == 'on' && window && margs.force_no_ajax != 'on') {


            //console.info(thehref);
            if (thehref == '#') {

            } else {
                //console.info( window.location.href, thehref )
                if (window.location.href && window.location.href.indexOf('file://') == 0 || (thehref.indexOf('http://') > -1 && thehref.indexOf(ajax_site_url) != 0)) {



                } else {
                    //if indeed we are going to history api it

                    //console.info(scripts_loaded_arr);
                    $('body').removeClass('loaded');
                    $('.toexecute-from-portal').remove();
                    if (can_history_api()) {
                        scripts_tobeloaded = [];
                        stylesheets_tobeloaded = [];
                        var nr_scripts_tobeloaded = 0;


                        content_wrapper_transitioned_out = false;

                        if (_t.hasClass('ajax-link-user')) {

                            // -- ajax link user

                            _body.addClass('portal-ajax-user-transitioning-out');

                            _t.parent().children().removeClass('curr-work');
                            _t.addClass('curr-work');

                        } else {


                            if (_t.hasClass('ajax-link-inline-menu')) {

                                // -- ajax link user

                                _body.addClass('portal-ajax-inline-menu-transitioning-out');
                                _t.parent().parent().find('.current-menu-item').removeClass('current-menu-item');
                                _t.parent().addClass('current-menu-item');


                            } else {

                                _body.addClass('portal-ajax-transitioning-out');
                            }
                            $('#ajax-loading-bar').addClass('semi-loaded');

                        }

                        setTimeout(function () {
                            content_wrapper_transitioned_out = true;
                        }, 300);

                        $.ajax({
                            url: thehref,
                            context: document.body
                        }).done(function (response) {

                            if (_t) {
                                //console.info(_t.parent().parent().parent());
                                if (_t.parent().parent().parent().hasClass('menu-toggler-target')) {
                                    _t.parent().parent().parent().removeClass('active');
                                }
                                if (_t.parent().parent().parent().parent().parent().hasClass('menu-toggler-target')) {
                                    _t.parent().parent().parent().parent().parent().removeClass('active');
                                }
                            }

                            //console.info(_t);

                            ___response = $(response);



                            //var regex_bodyclass = /<body.*?class=".*?(page-.*?)[ |"]/g;
                            var regex_bodyclass = /<body.*?class="(.*?)"/g;


                            var aux23 = regex_bodyclass.exec(response);

                            newclass_body = '';
                            if (aux23) {
                                if (aux23[1]) {
                                    newclass_body = aux23[1];
                                }
                            }


                            console.log('newclass_body - ',newclass_body);

                            //newclass_body_nopadding = false;
                            //newclass_body_with_fullbg = false;

                            regex_bodyclass = /<body.*?class=".*?(no-padding)[ |"]/g;


                            aux23 = regex_bodyclass.exec(response);
                            if (aux23) {
                                if (aux23[1]) {
                                    //newclass_body_nopadding=true;
                                }
                            }


                            regex_bodyclass = /<body.*?class=".*?(with-fullbg)[ |"]/g;


                            aux23 = regex_bodyclass.exec(response);
                            if (aux23) {
                                if (aux23[1]) {
                                    //newclass_body_with_fullbg=true;
                                }
                            }


                            // console.groupCollapsed("response");
                            // console.log(response, ___response);
                            // console.groupEnd();


                            //console.log(scripts_loaded_arr);
                            for (i = 0; i < ___response.length; i++) {
                                var _t3 = ___response[i];

                                if (_t3.attr && _t3.attr('class') == 'mainoptions') {
                                    //continue;
                                }


                                // console.warn(_t3);


                                var aux_href = '';
                                if (_t3.href) {
                                    aux_href = _t3.href;

                                    if (aux_href.indexOf('./') == 0) {
                                        aux_href = aux_href.replace('./', '');
                                    }
                                }

                                //console.info(_t3);



                                if (has_custom_outside_content_1) {
                                    //console.info(_t3, _t3.className);
                                    if (_t3.className == 'custom-outside-content-1') {
                                        $('.custom-outside-content-1').html(_t3.innerHTML);

                                        //console.info();
                                    }
                                }


                                if (_t3.nodeName == 'TITLE') {
                                    newtitle = _t3.innerHTML;

                                    // console.info(newtitle);
                                }

                                if (_t3.className == 'social-scripts') {
                                    //console.info(_t3);



                                    //if(social_scripts_loaded==false){
                                    //
                                    //    _body.append(_t3);
                                    //    social_scripts_loaded=true;
                                    //}
                                    //social_scripts_reinit = true;

                                    //console.info('social_scripts_reinit INIT', social_scripts_reinit)
                                }

                                if (_t3.className == 'hidden-resources') {

                                    if($('.hidden-resources').length){
                                        $('.hidden-resources').html($(_t3).html());
                                    }else{
                                        _body.append(_t3.outerHTML);
                                    }
                                }

                                if (_t3.className == 'content-wrapper') {


                                    if (_body.hasClass('portal-ajax-user-transitioning-out')) {

                                        new_page_html = $(_t3).find('.content-section .user-query').eq(0).get(0).outerHTML;
                                    } else {
                                        if (_body.hasClass('portal-ajax-inline-menu-transitioning-out')) {

                                            if($(_t3).find('.main-target-for-inline-menu').eq(0).get(0)){

                                                new_page_html = $(_t3).find('.main-target-for-inline-menu').eq(0).get(0).outerHTML;
                                            }else{

                                                new_page_html = $(_t3).find('.content-section').eq(0).html();
                                            }
                                        } else {

                                            new_page_html = $(_t3).find('.content-section').eq(0).html();
                                        }
                                    }
                                }

                                if (_t3.className == 'portfolio-fulscreen--items') {
                                    //console.info(_t3);


                                    _body.append(_t3);

                                    //console.info('social_scripts_reinit INIT', social_scripts_reinit)
                                }

                                if (_t3 != undefined && _t3.nodeName != undefined && _t3.nodeName == 'SCRIPT') {

                                    //if(_t3.className=='toexecute'){
                                    //
                                    //    continue;
                                    //}

                                    //console.info(_t3,_t3.src, scripts_loaded_arr);




                                    if (_t3.className == 'mainoptions') {
                                        //console.info(_t3);

                                        //old_qcre_options = $.extend([],qcreative_options);
                                        var aux = eval(_t3.innerHTML);

                                        //console.log(qcreative_options_defaults);

                                        var auxer5 = JSON.parse(qcreative_options_defaults_string);
                                        //console.log(auxer5);

                                        //qcreative_options = $.extend(auxer5, qcreative_options)



                                        if (customizer_force_blur > -1) {
                                            qcreative_options.blur_ammount = customizer_force_blur;
                                        }

                                        window.qcreative_options = qcreative_options;

                                        //--- not a good solution
//                                        console.info(aux,move_options, old_move_options);

                                        //console.info(qcreative_options);



                                    }

                                    if (_t3.className == 'zoombox-settings') {
                                        //console.info(_t3);

                                        if (zoombox_options) {

                                            //old_zoombox_options = $.extend([],zoombox_options);
                                        }
                                        var aux = eval(_t3.innerHTML);


                                        if (window.zoombox_default_opts_string) {
                                            var def_opts_parse = $.extend(true, {}, $.parseJSON(window.zoombox_default_opts_string));
                                            //zoombox_options = $.extend(def_opts_parse, window.init_zoombox_settings);

                                            //console.info('new zoombox settings', zoombox_options,window.zoombox_default_opts,window.init_zoombox_settings);
                                            window.init_zoombox_settings = zoombox_options;
                                        }


                                        //console.info(init_zoombox_settings, _t3.innerHTML);

                                        //console.info('MAKE YOU MOVE', window.api_zoombox_setoptions, zoombox_options, $('.zoombox-maincon'))

                                        //console.log(window.api_zoombox_setoptions);

                                        if (window.api_zoombox_setoptions) {
                                            //window.api_zoombox_setoptions(zoombox_options);
                                        }

                                        //qcre_init_zoombox = true;

                                        //--- not a good solution
//                                        console.info(aux,move_options, old_move_options);

                                        //console.info(qcreative_options);



                                    }

                                    var sw = false;

                                    for (j = 0; j < scripts_loaded_arr.length; j++) {

                                        //console.info(_t3.src, scripts_loaded_arr[j], (qcreative_options.site_url + scripts_loaded_arr[j]));

                                        //console.info(_t3.src, scripts_loaded_arr[j], ajax_site_url);
                                        if (_t3.src == '' || scripts_loaded_arr[j] == _t3.src || ajax_site_url + scripts_loaded_arr[j] == _t3.src) {
                                            sw = true;
                                        }
                                    }

                                    if (sw == false) {

                                        scripts_tobeloaded.push(_t3.src);
                                    }
                                }


                                if (_t3 != undefined && _t3.nodeName != undefined && _t3.nodeName == 'LINK') {


                                    // -- stylesheets check

                                    if (_t3.rel != 'stylesheet') {
                                        continue;
                                    }


                                    var sw = false;


                                    for (var j = 0; j < scripts_loaded_arr.length; j++) {


                                        //console.info(aux_href, scripts_loaded_arr[j],ajax_site_url, scripts_loaded_arr[j], (ajax_site_url + scripts_loaded_arr[j]));
                                        if (aux_href == '' || scripts_loaded_arr[j] == aux_href || ajax_site_url + scripts_loaded_arr[j] == aux_href) {
                                            sw = true;
                                        }
                                    }

                                    if (sw == false) {

                                        stylesheets_tobeloaded.push(_t3.href);
                                    }
                                }



                            }

                            //console.info(scripts_loaded_arr);
                            //console.info(scripts_tobeloaded, stylesheets_tobeloaded);


                            //console.info($.zfolio);
                            setTimeout(function () {
                                var i = 0;
                                nr_scripts_tobeloaded = scripts_tobeloaded.length;


                                function loadFunc(e) {
                                    //console.info(e);
                                }

                                if (nr_scripts_tobeloaded <= 0) {



                                    ajax_load_new_page();
                                    return false;
                                }

                                //console.info('scripts to be loaded - ',scripts_tobeloaded);


                                var i4 = 0;
                                for (i4 = 0; i4 < scripts_tobeloaded.length; i4++) {

                                    $.getScript(scripts_tobeloaded[i4], function (data, textStatus, jqxhr) {
                                        //console.log( data ); // Data returned
                                        //console.log( textStatus ); // Success
                                        //console.log( jqxhr.status ); // 200
                                        //console.log( "Load was performed." );


                                        //eval(data);

                                        //console.log(this, data,textStatus, jqxhr);


                                        if (String(this.url).indexOf('http://maps.googleapis.com/maps') > -1) {

                                            window.google_maps_loaded = true;
                                            window.gooogle_maps_must_init = true;
                                        }


                                        nr_scripts_tobeloaded--;
                                        //console.info(nr_scripts_tobeloaded);

                                        if (nr_scripts_tobeloaded <= 0) {
                                            //console.info('loadnewpage');

                                            //console.info($.zfolio);



                                            ajax_load_new_page();
                                        }

                                        //console.info(this,i4);

                                        var aux = this.url;

                                        if (aux.indexOf('?') > -1) {
                                            aux = aux.split('?')[0];
                                        }

                                        //console.info(aux);
                                        scripts_loaded_arr.push(aux);

                                    });
                                }
                                for (i4 = 0; i4 < stylesheets_tobeloaded.length; i4++) {

                                    $('<link/>', {
                                        rel: 'stylesheet',
                                        type: 'text/css',
                                        href: stylesheets_tobeloaded[i4]
                                    }).appendTo('head');

                                    scripts_loaded_arr.push(stylesheets_tobeloaded[i4]);


                                }


                                setTimeout(function () {
                                    //console.info(window.dzsprx_init);
                                    //console.info($.zfolio,jQuery.zfolio);
                                }, 1000)


//                            console.info(___response, ___response_scriptmo);
                            }, 100);


                            //console.info(thehref)





                            //console.info('destroy zoombox');



                            // -- we destroy it but only if we init another one
                            //if(window.api_destroy_zoombox){
                            //    window.api_destroy_zoombox();
                            //}

                            //console.info()

                            //console.info('STATE CURR MENU ITEMS LINKS2',state_curr_menu_items_links);






                            if (_t.get(0) != window || margs.force_pushState) {




                                if (history_first_pushed_state == false) {

                                    if (window.location.href.indexOf('file://') === -1) {

                                        var aux = curr_html;
                                        if (aux == 'index.php') {
                                            aux = '';
                                        }

                                        var stateObj = {href: curr_html};

                                        history.pushState(stateObj, null, aux);
                                    }
                                    history_first_pushed_state = true;
                                }

                                var aux_arr = state_curr_menu_items_links.slice(0);

                                var stateObj = {foo: page_change_ind, href: thehref, 'curr_menu_items': aux_arr};

                                page_change_ind++;
                                //console.info('PUSH STATE', stateObj, thehref)
                                history.pushState(stateObj, newtitle, thehref);
                                // -- test
                                if (newtitle) {
                                    document.title = newtitle;
                                }
                            }
                        });


                        //console.info(_t.parent());




                        //console.info(state_curr_menu_items_links);

                        //state_curr_menu_items_links = _theActualNav.find('.current-menu-item');



                        if (_t.get(0) != window) {



                            state_curr_menu_items_links = [];

                            _theActualNav.find('.current-menu-item').each(function () {
                                var _t = $(this);

                                //console.log(_t,_theActualNav.find('*').index(_t));


                                state_curr_menu_items_links.push(_theActualNav.find('li').index(_t));
                            })

                            //console.info('STATE CURR MENU ITEMS LINKS', state_curr_menu_items_links);

                            if (_t.parent().parent().parent().parent().hasClass('main-menu')) {
                                _t.parent().parent().find('.current-menu-item').removeClass('current-menu-item');
                                _t.parent().addClass('current-menu-item');
                            } else {

                                $('.main-menu').find('.current-menu-item').removeClass('current-menu-item');
                            }
                            //if(_t.parent().parent().parent().parent().hasClass('the-actual-nav')){
                            //    _t.parent().parent().parent().parent().find('.current-menu-item').removeClass('current-menu-item');
                            //    _t.parent().parent().parent().addClass('current-menu-item');
                            //    _t.parent().addClass('current-menu-item');
                            //}
                        }
                        return false;

                        if (_t && _t.hasClass('ajax-link')) {
                            _theActualNav.find('li > a').each(function () {
                                var _t3 = $(this);

                                //console.log(_t3, _t3.attr('href'), thehref);

                                if (_t3.attr('href') == thehref || _t3.attr('href') == ajax_site_url + thehref) {
                                    _theActualNav.find('li').removeClass('current-menu-item');
                                    _t3.parent().addClass('current-menu-item');
                                }
                            })
                        }


                        return false;
                    }


                }

            }
        }

    }

    function ajax_load_new_page() {


        //console.info('whaa');

        if (content_wrapper_transitioned_out == false) {
            setTimeout(ajax_load_new_page, 300);

            return false;
        }
        //console.info('ajax_load_new_page()', new_page_html);

        // destroy listeners for all objects hier


        // -- tbc

        //console.info(currclass_body, newclass_body);


        _contentContainer.find('.audioplayer,.dzsparallaxer').each(function () {

            var _t = $(this);

            //console.info(_t);

            if (_t.get(0) && _t.get(0).api_destroy_listeners) {
                _t.get(0).api_destroy_listeners();
            }

            setTimeout(function(){
                if (_t.get(0) && _t.get(0).api_destroy) {

                    // _t.get(0).api_destroy();
                }
            },300)
        })


        if (_body.hasClass('portal-ajax-user-transitioning-out')) {

            //console.info(new_page_html);

            // console.info("USER REQUESTED PAGE")


            _contentContainer.find('.user-query').eq(0).after(new_page_html);
            _contentContainer.find('.user-query').eq(0).remove();
            //_contentContainer.append(new_page_html);

        } else {

            if (_body.hasClass('portal-ajax-inline-menu-transitioning-out')) {

                //console.info(new_page_html);

                // console.info("INLINE MENU REQUESTED PAGE");


                _contentContainer.find('.main-target-for-inline-menu').eq(0).after(new_page_html);
                _contentContainer.find('.main-target-for-inline-menu').eq(0).remove();
                //_contentContainer.append(new_page_html);

            } else {

                _contentContainer.children().remove();
                _contentContainer.append(new_page_html);
                var _cash = _contentContainer.children().last();
                _cash.addClass('new-content');

                setTimeout(function () {


                    _cash.removeClass('new-content');
                }, 200);
            }

        }


        var bclass = _body.attr('class');

        bclass = bclass.replace(/page-\d+/g, '');
        _body.attr('class',bclass);


        //console.info(margs);
        _body.removeClass('page-404 page-track  page-page page-user')
        _body.addClass(newclass_body)


        reinit();


        setTimeout(function () {


            _body.removeClass('portal-ajax-transitioning-out');
            _body.removeClass('portal-ajax-user-transitioning-out');
            _body.removeClass('portal-ajax-inline-menu-transitioning-out');


            $('#ajax-loading-bar').addClass('full-loaded');
        }, 500);

        setTimeout(function () {


            $('#ajax-loading-bar').addClass('full-loaded');


            setTimeout(function () {



                $('#ajax-loading-bar').removeClass('semi-loaded full-loaded');
            }, 300);
        }, 200);


        if (bg_transition == 'fade') {
            //_mainBg.addClass('for-remove');
            //
            //var aux9000 = _mainBg;
            //
            //setTimeout(function(){
            //
            //    if(aux9000.get(0) && aux9000.get(0).api_destroy){
            //
            //        aux9000.get(0).api_destroy();
            //    }
            //},300);


        } else {

            //if(_mainBg.get(0) && _mainBg.get(0).api_destroy){
            //
            //    _mainBg.get(0).api_destroy();
            //}
        }

        busy_main_transition = true;
    }


    function handle_scroll(e) {

        var st = $(window).scrollTop();

        //console.info('portal scroll');


        if (st > 100) {

            if ($('section.mcon-mainmenu').hasClass('shrink-it') == false) {
                $('section.mcon-mainmenu').animate({
                    'top': '-70px'
                }, {
                    duration: 300
                    , queue: false
                    , complete: function () {

                        setTimeout(function () {
                            $('section.mcon-mainmenu').animate({
                                'top': '0px'
                            }, {
                                duration: 300
                                , queue: false
                                , complete: function () {
                                    $('section.mcon-mainmenu').animate({
                                        'top': '0px'
                                    }, {
                                    })
                                }
                            })

                        }, 100);
                    }
                })

                $('section.mcon-mainmenu').addClass('shrink-it');
            }

        } else {

            $('section.mcon-mainmenu').removeClass('shrink-it');
        }

        if (st > 100) {

            if ($('section.mcon-mainmenu-luna').hasClass('shrink-it') == false) {

                $('section.mcon-mainmenu-luna').addClass('shrink-it');

                $('.start-scroll-icon').fadeOut('slow');
            }

        } else {

            $('section.mcon-mainmenu-luna').removeClass('shrink-it');
        }



        if (query_scroll_targets && query_scroll_targets.length > 0) {
            // console.info(query_scroll_targets);

            for (var i23 in query_scroll_targets) {
                //console.log(query_scroll_targets[i23].offset().top, query_scroll_targets[i23].height())


                if (query_scroll_targets[i23].data('busy_ajax') != true && st + wh + 100 > query_scroll_targets[i23].offset().top + query_scroll_targets[i23].height()) {
                    //console.info('LOAD NEXT');


                    // if(query_scroll_targets[i23])
                    load_next_page_for_pagination_target(query_scroll_targets[i23]);

                }
            }
        }


        //console.info(st,wh);

    }


    function load_next_page_for_pagination_target(_arg) {






        var data = {
            action: 'ajax_get_query'
        };


        data = $.extend(data, _arg.data('thequery'));

        //console.info(data);

        data.paged = _arg.data('paged');

        if (isNaN(data.paged)) {
            data.paged = 0;
        }
        if (isNaN(_arg.data('paged'))) {
            _arg.data('paged', 0);

            if(_arg.attr('data-currpage')){

                _arg.data('paged', Number(_arg.attr('data-currpage')));
            }
        }
        if (isNaN(_arg.data('maxpages'))) {
            _arg.data('maxpages', 0);

            if(_arg.attr('data-maxpages')){

                _arg.data('maxpages', Number(_arg.attr('data-maxpages')));
            }
        }
        //data.paged = parseInt(_arg.data('paged'),10)+1;


        data.paged = data.paged + 1;
        //console.info(data);





        if($('.hidden-resources .dzsapp_currpage_type').length && $('.hidden-resources .dzsapp_currpage_type').html()){

            data.currpage_type = $('.hidden-resources .dzsapp_currpage_type').html();
        }

        if(_arg.data('paged')<Number(_arg.data('maxpages'))){





            _arg.addClass('loading-it');

            _arg.data('busy_ajax', true);



            $.ajax({
                type: "POST",
                url: dzsap_settings.settings_ajax_handler,
                data: data,
                success: function (response) {
                    if (typeof window.console != "undefined") {
                        // console.log('load_next_page_for_pagination response: ' + response);
                    }


                    //_cart_contents.html(response);
                    _arg.data('paged', _arg.data('paged') + 1);

                    if (_arg.data('paged') >= _arg.data('maxpages') - 1) {
                        //console.info('max pages',_arg.data('paged')==_arg.data('maxpages')-1);


                        for (var i23 in query_scroll_targets) {
                            if (query_scroll_targets[i23] == _arg) {
                                query_scroll_targets.splice(i23, 1);
                            }


                            _arg.find('.preloader-con').animate({
                                'height': 0
                            }, {
                                queue: false
                                , duration: 500
                            });

                            setTimeout(function () {
                                _arg.find('.preloader-con').hide();
                            }, 1500);

                            //var ind = query_scroll_targets.indexOf(_arg);

                        }

                        // console.info(_arg);

                        _arg.children('.button-con').remove();

                        //console.info(query_scroll_targets);
                    }


                    console.warn('_arg.hasClass(\'style-under-with-timeline\')', _arg.hasClass('style-under-with-timeline'));
                    if (_arg.hasClass('style-under-with-timeline')) {
                        _arg.children('.zoomtimeline').append(response);

                        execute_portal_scripts();
                    }else if (_arg.hasClass('style-under')) {
                        _arg.children('.style-under-con').append(response);

                        execute_portal_scripts();
                    }else{

                        _arg.children().eq(0).append(response);
                        execute_portal_scripts();
                    }



                    setTimeout(function () {

                        _arg.removeClass('loading-it');
                        _arg.data('busy_ajax', false);
                        reinit_all_loaded({
                            check_tracks_list: true
                            , animate_shortcode_user: false
                        });
                    }, 1000);

                },
                error: function (arg) {
                    if (typeof window.console != "undefined") {
                        console.log('Got this from the server: ' + arg, arg);
                    }
                    ;

                }
            })
        }

         // console.info('hmm page', data);
;

    }


    function load_page_for_pagination_target(_arg, arg) {


        _arg.addClass('loading-it');

        _arg.data('busy_ajax', true);





        var data = {
            action: 'ajax_get_query'
        };


        data = $.extend(data, _arg.data('thequery'));

        //console.info(data);

        if($('.hidden-resources .dzsapp_currpage_type').length && $('.hidden-resources .dzsapp_currpage_type').html()){

            data.currpage_type = $('.hidden-resources .dzsapp_currpage_type').html();
        }

        data.paged = arg;

        if (isNaN(data.paged)) {
            data.paged = 0;
        }
        if (isNaN(_arg.data('paged'))) {
            _arg.data('paged', 0);
        }
        //data.paged = parseInt(_arg.data('paged'),10)+1;


        // console.info('hmm page'm data);

        if (_arg.hasClass('style-under-with-timeline')) {
            _arg.children('.zoomtimeline').removeClass('ztm-ready');

        }
        if (_arg.children('.style-nova,.list-tracks-con').length) {
            _arg.children('.style-nova,.list-tracks-con').animate({
                'opacity': '0'
            })
        }

        $.ajax({
            type: "POST",
            url: dzsap_settings.settings_ajax_handler,
            data: data,
            success: function (response) {
                if (typeof window.console != "undefined") {
                    console.log('load_page ' + arg + ' response: ' + response);
                }


                //_cart_contents.html(response);
                _arg.data('paged', _arg.data('paged') + 1);

                if (_arg.data('paged') >= _arg.data('maxpages') - 1) {
                    //console.info('max pages',_arg.data('paged')==_arg.data('maxpages')-1);



                    // console.info(_arg);

                    _arg.children('.button-con').remove();

                    //console.info(query_scroll_targets);
                }

                if (_arg.hasClass('style-under-with-timeline')) {
                    _arg.children('.zoomtimeline').html(response);

                    execute_portal_scripts();
                } else {
                    if (_arg.hasClass('style-under')) {
                        _arg.html(response);

                        execute_portal_scripts();
                    } else {

                        if (_arg.children('.style-nova,.list-tracks-con').length) {


                        }
                    }
                }


                setTimeout(function () {

                    _arg.removeClass('loading-it');
                    _arg.data('busy_ajax', false);
                    reinit_all_loaded({
                        check_tracks_list: true
                        , animate_shortcode_user: false
                    });


                    if (_arg.children('.style-nova,.list-tracks-con').length) {
                        _arg.children('.style-nova,.list-tracks-con').html(response);
                        _arg.children('.style-nova,.list-tracks-con').animate({
                            'opacity': '1'
                        })
                    }
                }, 1000);

            },
            error: function (arg) {
                if (typeof window.console != "undefined") {
                    console.log('Got this from the server: ' + arg, arg);
                }
                ;

            }
        });

    }


    function execute_portal_scripts() {
        $('.toexecute-from-portal').each(function () {
            var _t = $(this);

            if (_t.hasClass('executed') == false) {



                //console.info(_t.html());
                eval(_t.html());
                //$.ready();
                _t.addClass('executed');
            } else {

            }
        });

        if (window.dzsztm_init) {

            //console.info('dzs-tabs: ', $('.zoomtimeline'));
            window.dzsztm_init('.zoomtimeline.auto-init', {init_each: true});
        }
        if (window.dzsap_init) {

            //console.info('dzs-tabs: ', $('.dzs-tabs.auto-init'));
            window.dzsap_init('.audioplayer-tobe.auto-init-from-dzsapp', {init_each: true});
        }
        if (window.dzsag_init) {

            //console.info('dzs-tabs: ', $('.dzs-tabs.auto-init'));
            window.dzsag_init('.audiogallery.auto-init-from-dzsapp', {init_each: true});
        }
        if (window.dzstaa_init) {

            //console.info('dzs-tabs: ', $('.dzs-tabs.auto-init'));
            window.dzstaa_init('.dzs-tabs.auto-init-from-dzsapp', {init_each: true});
        }

        if (window.dzsas_init) {

            //console.info('dzs-tabs: ', $('.dzs-tabs.auto-init'));
            window.dzsas_init('.advancedscroller.auto-init-from-dzsapp', {init_each: true});
        }
        if (window.dzscal_init) {

            //console.info('dzs-tabs: ', $('.dzs-tabs.auto-init'));
            window.dzscal_init('.dzscalendar.auto-init-from-dzsapp', {init_each: true});
        }
        if (window.dzsprx_init) {

            //console.info('dzs-tabs: ', $('.dzs-tabs.auto-init'));
            window.dzsprx_init('.dzsparallaxer.auto-init', {init_each: true});
        }
        if (window.dzszvp_init) {

            //console.info('dzs-tabs: ', $('.dzs-tabs.auto-init'));
            window.dzszvp_init('.zoomvideoplayer.auto-init-from-dzsapp', {init_each: true});
        }


        setTimeout(function () {
            $(window).trigger('resize');


            if (window.FB && FB.XFBML && FB.XFBML.parse) {
                //console.info('REINIT SOCIAL SCRIPS - FB');
                FB.XFBML.parse();
            }
        }, 300)
    }

    function handle_resize() {

        ww = $(window).width();

        wh = $(window).height();

        if (ww < responsive_threshold) {
            _body.addClass('responsive-mode');

        } else {

            _body.removeClass('responsive-mode');
            _body.removeClass('sidebar-activated');
        }


        $('.dzsapp-full-height').each(function () {
            var _t = $(this);

            _t.height(wh);
        })

        $('.js-height-as-width').each(function () {
            var _t = $(this);

            _t.outerHeight(_t.outerWidth());
        })

    }

    function load_cart() {








        var data = {
            action: 'ajax_show_cart'
        };


        $.ajax({
            type: "POST",
            url: dzsap_settings.settings_ajax_handler,
            data: data,
            success: function (response) {
                if (typeof window.console != "undefined") {
                    //console.log('Got this from the server: ' + response);
                }


                _cart_contents.html(response);

            },
            error: function (arg) {
                if (typeof window.console != "undefined") {
                    console.log('Got this from the server: ' + arg, arg);
                }
                ;

            }
        });


    }



    function load_results() {



        console.info('load_results');
        var data = {
            action: 'ajax_load_results'
            , postdata: $('input[name=search_keywords]').val()
        };


        $.ajax({
            type: "POST",
            url: dzsap_settings.settings_ajax_handler,
            data: data,
            success: function (response) {
                if (typeof window.console != "undefined") {
                    console.log('Got this from the server: ' + response);
                }


                $('.bigsearch-con').removeClass('loading');

                $('.search-results-con .inner').html(response);

            },
            error: function (arg) {
                if (typeof window.console != "undefined") {
                    console.log('Got this from the server: ' + arg, arg);
                }
                ;

            }
        });
    }

    function load_messages_friends() {









        var data = {
            action: 'ajax_messages_friends_get_array'
            , 'id_receiver': get_query_arg(window.location.href, 'user_id')
        };


        $.ajax({
            type: "POST",
            url: dzsap_settings.settings_ajax_handler,
            data: data,
            success: function (response) {
                if (typeof window.console != "undefined") {
                    console.log('Got this from the server: ' + response);
                }




                var aux_arr = '';

                if (response) {


                    if (_messages_friends_container) {
                        _messages_friends_container.html(response);

                    }
                    _messages_friends_container.children().each(function () {
                        var _t = $(this);

                        //console.info(_t, _t.attr('data-userid'), get_query_arg(window.location.href, 'user_id'));

                        if (_t.attr('data-userid') == get_query_arg(window.location.href, 'user_id')) {
                            _t.addClass('current-chat-friend');


                            _t.attr('href', '#');
                        }
                    })





                }




                //console.info(aux_arr, messages_array);




            },
            error: function (arg) {
                if (typeof window.console != "undefined") {
                    console.log('Got this from the server: ' + arg, arg);
                }
                ;

            }
        });


    }

    window.portal_action_track_play = function (arg) {
        // console.info('action_track_play ( from PORTAL ) ',arg);


        if (arg.attr('data-playerid')) {
            curr_playing_track = arg.attr('data-playerid');



            // var data = {
            //     action: 'dzsap_retract_playlist_entry',
            //     playlistid: _t.attr('data-id'),
            //     mediaid: dzsap_settings.mediaid
            // };
            //
            //
            // $.ajax({
            //     type: "POST",
            //     url: dzsap_settings.settings_php_handler,
            //     data: data,
            //     success: function (response) {
            //         if (typeof window.console != "undefined") {
            //             console.log('Got this from the server: ' + response);
            //         }
            //
            //         _t.removeClass('active');
            //     },
            //     error: function (arg) {
            //         if (typeof window.console != "undefined") {
            //             console.log('Got this from the server: ' + arg, arg);
            //         }
            //         ;
            //
            //     }
            // });

        }

        //console.info(curr_playing_track, tracks_list);
    }

    window.portal_action_audio_end = function (arg, arg2) {
        console.warn('action_audio_end ( from PORTAL )',arg,arg2, curr_playing_track, tracks_list);

        for (var i = 0; i < tracks_list.length - 1; ++i) {
            if (tracks_list[i] == curr_playing_track) {

                if (sw_can_next_track_play) {

                    var _c_ = document.getElementById("ap" + (tracks_list[i + 1]));

                    console.info('check - ', _c_, _c_.api_play_media);
                    if (_c_ && _c_.api_play_media) {
                        setTimeout(function () {
                            _c_.api_play_media();
                        }, 400);

                    }


                    sw_can_next_track_play = false;
                    clearTimeout(inter_stop_next_track_from_playing);
                    inter_stop_next_track_from_playing = setTimeout(func_can_next_track_play, 1000);

                    break;

                }
            }
        }



        //console.info(curr_playing_track, arg,arg2);
    }

    function func_can_next_track_play() {
        sw_can_next_track_play = true;
    }

    function load_messages() {









        var data = {
            action: 'ajax_messages_get_array'
            , 'id_receiver': get_query_arg(window.location.href, 'user_id')
        };


        $.ajax({
            type: "POST",
            url: dzsap_settings.settings_ajax_handler,
            data: data,
            success: function (response) {
                //if(typeof window.console != "undefined" ){ console.log('Got this from the server: ' + response); }




                var aux_arr = '';

                if (response) {

                    try {
                        aux_arr = $.parseJSON(response);

                    } catch (err) {
                        console.info('there was a error - ', err);
                    }

                    //console.info(typeof aux_arr);
                    if (typeof aux_arr == 'object') {

                        for (var lab in aux_arr) {
                            //console.log(aux_arr[lab]);


                            var sw = true;


                            //console.info(messages_array);
                            for (var lab2 in messages_array) {
                                if (messages_array[lab2].id == aux_arr[lab].id) {
                                    sw = false;
                                }
                            }

                            if (sw) {
                                //console.info("SW IS TRU");
                                messages_array.push($.extend({}, aux_arr[lab]));
                            }

                        }


                    }
                }

                //console.info(aux_arr, messages_array);

                var aux_str = '';

                for (var lab2 in messages_array) {


                    var mes_obj = messages_array[lab2];

                    aux_str += '<div class="chat-message';


                    //console.info(mes_obj, dzsap_settings.currUserId);

                    if (mes_obj.author_id != dzsap_settings.currUserId) {
                        aux_str += ' chat-message-from-other-user';
                    }

                    aux_str += '" id="message' + mes_obj.id + '">';


                    aux_str += '<div class="user-avatar" style="background-image: url(' + mes_obj.author_avatar + ');"></div>';
                    aux_str += '<div class="user-overflow">';
                    aux_str += '<h4 class="user-name">' + mes_obj.author_username + '</h4>';

                    aux_str += '<p class="user-message">' + mes_obj.content + '</p>'

                    aux_str += '</div>';



                    aux_str += '<div class="clear"></div>';
                    aux_str += '</div>';


                }
                if (_messages_container) {
                    _messages_container.html(aux_str);

                    setTimeout(function () {
                        if (_messages_container.parent().parent().hasClass('scroller-con')) {
                            if (_messages_container.parent().parent().get(0).api_scrolly_to) {
                                _messages_container.parent().parent().get(0).api_scrolly_to(1);
                            }
                        }
                    }, 1000);

                }



            },
            error: function (arg) {
                if (typeof window.console != "undefined") {
                    console.log('Got this from the server: ' + arg, arg);
                }
                ;

            }
        });


    }

    function load_playlists() {








        var data = {
            action: 'ajax_show_playlists'
            , track_id: get_query_arg(window.location.href, 'track_id')
        };


        $.ajax({
            type: "POST",
            url: dzsap_settings.settings_ajax_handler,
            data: data,
            success: function (response) {
                //if(typeof window.console != "undefined" ){ console.log('Got this from the server: ' + response); }


                //console.log($('.playlists-con'));
                $('.playlists-con').html(response);

                setTimeout(function () {

                    $('.playlists-con').addClass('loaded');


                    if (window.dzsas_init) {

                        dzsas_init('.advancedscroller.auto-init', {init_each: true});
                    }
                }, 500)

            },
            error: function (arg) {
                if (typeof window.console != "undefined") {
                    console.log('Got this from the server: ' + arg, arg);
                }
                ;

            }
        });


    }

    function action_file_upload_start(pfile, pargs) {

        console.info('action_file_upload_start from PORTAL uploader_type ( ' + uploader_type + ' ) - ', pfile, pargs);




        if (uploader_type == 'track'  ) {
            if (String(pfile.name).indexOf('.mp3') > -1 || String(pfile.name).indexOf('.m4a') || String(pfile.name).indexOf('.wav')  ) {
                upload_hide_upload_field($('input[name="source"]'));
                setTimeout(function(){
                    $('input[name=title]').trigger('change');
                },1000);
                $('.main-upload-options').addClass('loader-active');


                console.info('pargs._progress - ',pargs._progress);
                if(pargs.call_from!='user_meta_change'){

                    window.dzs_uploader_force_progress($('.main-upload-options'));
                }
            }
            var name = String(pfile.name);
            name = name.replace('.mp3', '');
            name = name.replace('.wav', '');
            name = name.replace('.m4a', '');


            if(pargs.cthis.prev().hasClass('id-upload-mp3')){

                $('*[name="title"]').val(name);
            }
        }

        if (uploader_type == 'album') {
            if (String(pfile.name).indexOf('.mp3') > -1) {


                var name = String(pfile.name);
                name = name.replace('.mp3', '');

                $('*[name="title"]').val(name);
                setTimeout(function(){
                    $('input[name=title]').trigger('change');
                },1000);

                upload_hide_upload_field($('input[name="source"]'));
                
                
                $('.upload-track-options-con').append('<div class="upload-track-options"><input type="hidden" name="track_source[]"><div class="preloader-bar dzs-upload--progress--barprog"></div><div class="handle-con"><i class="fa fa-bars"></i></div><div class="input-con"><input type="text" name="track_title[]"> </div><div class="delete-track-con"><i class="fa fa-times"></i></div></div>');
                var _c = $('.upload-track-options-con').find('.upload-track-options').last(); 
                _c.addClass('loader-active');
                window.dzs_uploader_force_progress(_c);
                
                _c.find('input[name*="track_title"]').val(name);
            }
        }



        show_main_upload_options();
        //show_notice(arg);
        //


    }


    function show_main_upload_options(){



        var _c = $('.main-upload-options').eq(0);


        console.info('_C - ',_c);
        init_tinymces(_c);

        _c.css('height', 'auto');

        var h = (_c.height());


        _c.css('height','1px');

        setTimeout(function(){
            _c.animate({
                'height':h
            },{
                queue:false
                ,duration: 300
                ,complete:function(){
                    $(this).css('height', 'auto');
                }
            });

            _c.addClass('main-option-active');
        },100);
        _c.addClass('main-option-active');
    }

    function action_file_uploaded(argresp, pargs, matches) {

        console.info('action_file_uploaded from PORTAL', argresp, pargs);



        if(pargs && pargs.responseText && pargs.responseText.indexOf('error')==0){
            show_notice(pargs.responseText);
        }
        
        
        if (uploader_type == 'album') {
            
                var name = String(pargs.file.name);
                name = name.replace('.mp3', '');
                
                var _c = $('.upload-track-options-con').eq(0);
                _c.find('input[name*="track_title"]').each(function(){
                    var _t2 = $(this);
                    
                    if(name==_t2.val()){
                        var _c2 = _t2.parent().parent();
                        
                        _c2.find('input[name*="track_source"]').eq(0).val(pargs.final_location);
                    }
                    
                    //console.info('testing name', name, _t2.val());
                })
        }




        var _c = $('.main-upload-options').eq(0);
        _c.addClass('main-option-active');





        //show_notice(arg);
        //

    }

    function reinit() {

        //console.log('reinit()')


        $("html, body").animate({scrollTop: 0}, "fast");

        //console.log('.dzs-single-upload');
        if (window.dzsuploader_single_init) {
            //console.info('ceva', $('span:not(.for-clone-item) .dzs-single-upload'));
            window.dzsuploader_single_init('.dzs-single-upload', {
                action_file_uploaded: action_file_uploaded
                , action_file_upload_start: action_file_upload_start
            });
        }


        console.info('_body.attr(\'class\') - ', _body.attr('class'))


        var regex_page_type = /page-([a-z].*?)[$ ]/g;

        var aux = regex_page_type.exec(_body.attr('class'));

        console.info('aux - ',aux);

        if(aux[1]){
            currPage_type= aux[1];

            $('.content-section').removeClass('page-type-user page-type-track page-type-page').addClass('page-type-'+currPage_type);
        }

        if (dzsap_settings.waves_generation == 'auto') {
            $('.dzs-single-upload--for-wavegeneration').hide();
            //$('.aux-wave-generator').css('opacity',0);

            $('input[name=waveform_bg],input[name=waveform_prog]').addClass('input-pseudo-disabled', true);
        }


        determine_curr_html();

        $('.id-upload-mp3').each(function () {

            var _t = $(this);

            _t.get(0).api_finished_upload = function (resp, pargs, matches) {
            console.info('api_finished_upload() - ',resp, pargs, matches);

                // console.info(resp);

                if (resp.indexOf('error') != 0) {
                    if (pargs.filename.indexOf('.mp3') > -1) {

                        if ($('#upload-tabs').length && $('#upload-tabs').get(0)) {

                            $('#upload-tabs').find('.tab-disabled').removeClass('tab-disabled');
                            $('#upload-tabs').get(0).api_goto_tab(1);
                        }

                        if (dzsap_settings.waves_generation == 'auto') {

                            if(uploader_type=='track'){
                                $('.btn-autogenerate-waveform-bg').trigger('click');
                                setTimeout(function () {

                                }, 1000)
                            }

                        }


//                        $('.upload-track-btn').addClass('disabled');
                        setTimeout(function () {

                            $('.upload-track-btn').removeClass('disabled');
                        }, 30000);


                        if (matches) {
                            for (var k in matches) {
                                if (matches[k][1] == 'filesize') {
                                    //console.warn(pargs[k]);

                                    //console.info($('input[name=filesize]'));
                                    $('input[name=filesize]').val(matches[k][2]);

                                    //console.log($('input[name=filesize]').eq(0).val());
                                }
                            }
                        }


                    } else {
                        $('.notices-box').append('<li class="notice notice-mp3notmatch">file should be an mp3</li>');

                        setTimeout(function () {
                            //console.info($('.notice-mp3notmatch'));
                            $('.notice-mp3notmatch').fadeOut(1000);
                            setTimeout(function () {

                                $('.notice-mp3notmatch').remove();
                            }, 1000)
                        }, 1000);
                        //return false;
                    }
                } else {

                    show_notice(resp);
                }




            }

        });
        
        if($('.upload-track-options-con').length){

            if($.fn.sortable){

                $( ".upload-track-options-con" ).sortable({
                    placeholder: "ui-state-highlight"
                });
            }else{
                console.warn('sortable not loaded');
            }
        }

        $('.google-maps-me').each(function () {

            var _t = $(this);









            if (window.google) {
                var styling = [{"featureType": "water", "elementType": "geometry", "stylers": [{"color": "#e9e9e9"}, {"lightness": 17}]}, {"featureType": "landscape", "elementType": "geometry", "stylers": [{"color": "#f5f5f5"}, {"lightness": 20}]}, {"featureType": "road.highway", "elementType": "geometry.fill", "stylers": [{"color": "#ffffff"}, {"lightness": 17}]}, {"featureType": "road.highway", "elementType": "geometry.stroke", "stylers": [{"color": "#ffffff"}, {"lightness": 29}, {"weight": 0.2}]}, {"featureType": "road.arterial", "elementType": "geometry", "stylers": [{"color": "#ffffff"}, {"lightness": 18}]}, {"featureType": "road.local", "elementType": "geometry", "stylers": [{"color": "#ffffff"}, {"lightness": 16}]}, {"featureType": "poi", "elementType": "geometry", "stylers": [{"color": "#f5f5f5"}, {"lightness": 21}]}, {"featureType": "poi.park", "elementType": "geometry", "stylers": [{"color": "#dedede"}, {"lightness": 21}]}, {"elementType": "labels.text.stroke", "stylers": [{"visibility": "on"}, {"color": "#ffffff"}, {"lightness": 16}]}, {"elementType": "labels.text.fill", "stylers": [{"saturation": 36}, {"color": "#333333"}, {"lightness": 40}]}, {"elementType": "labels.icon", "stylers": [{"visibility": "off"}]}, {"featureType": "transit", "elementType": "geometry", "stylers": [{"color": "#f2f2f2"}, {"lightness": 19}]}, {"featureType": "administrative", "elementType": "geometry.fill", "stylers": [{"color": "#fefefe"}, {"lightness": 20}]}, {"featureType": "administrative", "elementType": "geometry.stroke", "stylers": [{"color": "#fefefe"}, {"lightness": 17}, {"weight": 1.2}]}];


                var gm_position = new google.maps.LatLng(window.gm_locations[0].lat, gm_locations[0].long);
                var mapProp = {
                    center: gm_position,
                    zoom: 15,
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                    , styles: styling
                };


                map = new google.maps.Map(
                        _t.get(0)
                        , mapProp
                        );




                var image = 'img/gmaps_marker_1.png';


                for (var i2 in window.gm_locations) {
                    var aux_gm_position = new google.maps.LatLng(gm_locations[i2].lat, gm_locations[i2].long - 0.0015);


                    var beachMarker = new google.maps.Marker({
                        position: aux_gm_position,
                        map: map,
                        icon: image
                    });
                }



            }


        });

        if (dzsap_settings.page && dzsap_settings.page == 'playlists') {
            //console.info('ceva');

            load_playlists();
        }

        // @ this is the part that should be moved when ajax_transition_complete


        first_time_loaded_messages = true;
        messages_array = [];
        query_scroll_targets = [];



        _messages_container = $('.messages-container').eq(0);
        _messages_friends_container = $('.messages-friends-container').eq(0);

        //console.info('clearInterval', inter_load_messages, dzsap_settings.page, curr_html, get_query_arg(curr_html, 'page'));
        //console.warn(curr_html, get_query_arg_sp(curr_html, 'page'));
        clearInterval(inter_load_messages);
        if (get_query_arg_sp(curr_html, 'page') == 'messages') {
            load_messages();
            load_messages_friends();


            inter_load_messages = setInterval(function () {
                load_messages();
                load_messages_friends();
            }, 5000);
        }

        $('.shortcode-query.pagination-scroll,.shortcode-query.pagination-button,.shortcode-query.pagination-pagination').each(function () {
            var _t = $(this);

            //console.info(JSON.parse(_t.attr('data-thequery')));

            var aux_arr = JSON.parse(_t.attr('data-thequery'));

            aux_arr.paged = parseInt(aux_arr.paged, 10);

            _t.data('thequery', aux_arr);

            _t.data('currpage', parseInt(aux_arr.paged, 10));


            _t.data('maxpages', Math.ceil(aux_arr.custom_ids.length / parseInt(aux_arr.limit_posts)));

            //console.info(_t.data('currpage'),_t.data('maxpages'),_t.data('thequery'));

            // console.log(_t,query_scroll_targets);
        })
        $('.shortcode-query.pagination-scroll').each(function () {
            var _t = $(this);
            query_scroll_targets.push(_t);
        })

        execute_portal_scripts();

        //console.info(query_scroll_targets);

        $('.input-ujarak-style').trigger('keyup');


        setTimeout(function () {
            reinit_all_loaded();
        }, 700);



        if(window.dzssel_init){

            dzssel_init('select.dzs-style-me', {init_each: true});
        }

        if(window.dzstaa_init) {
            dzstaa_init('.dzs-tabs.auto-init:not(".dzstaa-loaded")', {init_each: true});
        }


        setTimeout(function(){

            if(window.twttr && twttr.widgets){

                window.twttr.widgets.load()
            }

            $('.upload-watermark-field').trigger('change');
        },100);


        if(_body.hasClass('not-logged-in')){
            if(dzsap_settings.likes_allow_post_if_not_logged_in=='off'){
                $('.btn-like').each(function(){
                    var _t = $(this);

                    _t.removeClass('btn-like');
                    _t.addClass('dzstooltip-con');
                    _t.children('.the-label,.the-icon').css('opacity','0.5');
                    _t.append('<span class="dzstooltip arrow-bottom align-left" style="white-space: nowrap; width: auto;">'+'You need to be logged in to like stracks'+'</span>')
                })
            }
        }


        apply_tags();

    }

    function apply_tags(){


        $('.tagify-me:not(.taggified)').each(function(){
            var _t = $(this);


            var tags = String(dzsap_settings.tags_suggested).split(',')
            var enforeWhitelist = false;


            if(dzsap_settings.tags_allow_only_suggested=='on'){
                enforeWhitelist = true;
            }


            var tags_max_nr = Number(dzsap_settings.tags_max_nr) - 1;

            if(_t.hasClass('only-3')){
                tags_max_nr = 2;
            }

            var tagify2 = new Tagify(_t.get(0), {
                enforeWhitelist : enforeWhitelist,
                duplicates : false,
                maxtags :  tags_max_nr,
                whitelist       : tags
            });
        })
    }



    var panPath = [];   // An array of points the current panning action will use
    var panQueue = [];  // An array of subsequent panTo actions to take
    var STEPS = 50;     // The number of steps that each panTo action will undergo

    var inter_refresh_map = 0;

    // -- code from - http://stackoverflow.com/questions/3817812/google-maps-v3-can-i-ensure-smooth-panning-every-time ( Darren Hicks )
    window.panTo = function (newLat, newLng) {
        if (panPath.length > 0) {
            // We are already panning...queue this up for next move
            panQueue.push([newLat, newLng]);
        } else {
            // Lets compute the points we'll use
            panPath.push("LAZY SYNCRONIZED LOCK");  // make length non-zero - 'release' this before calling setTimeout
            var curLat = map.getCenter().lat();
            var curLng = map.getCenter().lng();
            var dLat = (newLat - curLat) / STEPS;
            var dLng = (newLng - curLng) / STEPS;

            for (var i = 0; i < STEPS; i++) {
                panPath.push([curLat + dLat * i, curLng + dLng * i]);
            }
            panPath.push([newLat, newLng]);
            panPath.shift();      // LAZY SYNCRONIZED LOCK
            setTimeout(doPan, 20);

            clearTimeout(inter_refresh_map);
            inter_refresh_map = setTimeout(refresh_map, 1000)
        }
    }

    function refresh_map() {
        //console.warn('refresh_map()');
        google.maps.event.trigger(map, 'resize')
    }

    function doPan() {
        var next = panPath.shift();
        if (next != null) {
            // Continue our current pan action
            map.panTo(new google.maps.LatLng(next[0], next[1]));
            setTimeout(doPan, 20);
        } else {
            // We are finished with this pan - check if there are any queue'd up locations to pan to
            var queued = panQueue.shift();
            if (queued != null) {
                panTo(queued[0], queued[1]);
            }
        }
    }



    function reinit_all_loaded(pargs) {


        var margs = {
            check_tracks_list: true
            , animate_shortcode_user: true
        };

        if (pargs) {
            margs = $.extend(margs, pargs);
        }

        _body.addClass('reinited');

        //console.info($('.audioplayer'));

        busy_main_transition = false;

        //console.info($('.audioplayer'))

        if (margs.check_tracks_list) {
            tracks_list = [];

            $('.audioplayer,.audioplayer-tobe').each(function () {
                var _t = $(this);

                if (!(_t.attr('data-playerid')) || _t.attr('data-playerid') == 'apfooter') {
                    return;
                }

                tracks_list.push(_t.attr('data-playerid'));

                if (Number(_t.attr('data-playerid')) == Number(curr_playing_track)) {

                    if ($('.apapfooter').length > 0 && $('.apapfooter').get(0) && $('.apapfooter').get(0).api_change_visual_target) {
                        $('.apapfooter').get(0).api_change_visual_target(_t);

                        if (_t.hasClass('media-setuped') == false) {
                            if (_t.get(0) && _t.get(0).api_click_for_setup_media) {
                                _t.get(0).api_click_for_setup_media(null, {
                                    'do_not_autoplay': true
                                });
                                _t.get(0).api_play_media_visual();
                            }
                        }
                    }
                }


            });
        }



        //console.info('tracks_list - ',tracks_list);

        if (margs.animate_shortcode_user) {
            setTimeout(function () {

                if($('.shortcode-user.style-default').eq(0).height()!=180){
                    $('.shortcode-user.style-default').animate({
                        'height': '180px'
                    }, {
                        queue: false
                        , duration: 300
                        , complete: function(){
                            $(this).addClass('animation-finished');
                        }
                    })
                }

            }, 500);
        }
    }

    function upload_hide_upload_field(arg) {

        var _t = arg;
        var _con = null;
        //console.info(_t, _t.prop('checked'), _t.parent().parent().parent());

        if (_t.parent().parent().parent().hasClass('submit-track-form')) {
            _con = _t.parent().parent().parent();

            _con.find('.main-upload-options-con').addClass('active');

            show_main_upload_options();
        }

        if (_t.parent().hasClass('dzs-upload-con')) {
            _con = _t.parent();

            _con.addClass('disabling');

            _con.animate({
                'height': 0
            }, {
                queue: false
                , duration: 300
            });
        }
    }

    function getSoundCloudId(permalink) {
        var jsonp   = document.createElement('script');
        var script  = document.getElementsByTagName('script')[0];
        jsonp.type  = 'text/javascript';
        jsonp.async = true;
        jsonp.src   = 'http://api.soundcloud.com/resolve.json?client_id='+dzsap_settings.soundcloud_apikey
            + '&url='+encodeURIComponent(permalink)+'&callback=jsonpResponse';
        script.parentNode.insertBefore(jsonp, script);
        return false;
    }

    function handle_change(e) {

        var _t = $(this);
        var _con = null;
        //console.info(_t);

        if (e.type == 'change') {
            if (_t.attr('name') == 'is_buyable') {
                //console.info(_t, _t.prop('checked'));

                if (_t.prop('checked')) {

                    $('.price-conglomerate').addClass('active');
                } else {
                    // -- you can see typing is slow now ... lets see later...
                    $('.price-conglomerate').removeClass('active');
                }
            }
            if (_t.attr('name') == 'thumbnail') {
                //console.info(_t, _t.prop('checked'));

                if (_t.val()) {
                    if (_t.parent().find('.preview-thumb-con').length > 0) {
                        var _cach = _t.parent().find('.preview-thumb-con').eq(0);

                        _cach.addClass('has-image');
                        _cach.css('background-image', 'url(' + _t.val() + ')');
                    }
                }
            }
            if (_t.attr('name') == 'title') {
                //console.info(_t, _t.prop('checked'));

                if (_t.val()) {
                    var _cach = $('.upload-btn').eq(0);

                    _cach.removeClass('disabled');
                    _cach.parent().find('.dzstooltip').addClass('display-none');
                }
            }
            if (_t.attr('name') == 'type') {
                //console.info(_t, _t.prop('checked'));

                if (_t.parent().parent().hasClass('submit-track-form')) {
                    _con = _t.parent().parent();


                    _con.removeClass('type-track type-soundcloud  type-album ');

                    _con.addClass('type-' + _t.val());

                    uploader_type = _t.val();
                    if (uploader_type == 'track') {
                        _con.find('.the-real-uploader').removeAttr('multiple');
                    }

                    if (uploader_type == 'album') {
                        _con.find('.the-real-uploader').attr('multiple', '');
                    }
                }
            }


            if (_t.attr('name') == 'source') {




                if (uploader_type == 'soundcloud'  ) {



                    $.ajax({
                        type: "GET",
                        url: dzsap_settings.sc_retriever + '?scurl='+encodeURIComponent('https://api.soundcloud.com/resolve.json?url='+(_t.val())+'&consumer_key='+dzsap_settings.soundcloud_apikey),
                        data: data,
                        success: function (response) {
                            if (typeof window.console != "undefined") {
                                console.log('Got this from the retriever: ' + response);
                            }







                            try{
                                var arr = (JSON.parse(response));


                                console.info('soundcloud arr - ',arr);

                                $('*[name="title"]').val(arr.title);
                                $('*[name="description"]').val(arr.description);


                                var ed = null;

                                try{
                                    ed = tinyMCE.get('description');

                                    ed.execCommand('mceSetContent', false, arr.description);
                                }
                                catch(err){
                                    console.info(err);
                                }

                                var tags = arr.tag_list;
                                console.info('tags - ',tags);


                                tags = tags.replace(/" "/g, ',');
                                tags = tags.replace(/"/g, ',');


                                console.info('tags - ',tags);
                                console.info('tags - ',$('*[name="tags"]'));
                                $('*[name="tags"]').val(tags);


                                setTimeout(function(){
                                    $('input[name=title]').trigger('change');
                                    $('*[name="tags"]').val(tags);
                                },1000);


                            }catch(err){
                                console.info(err);
                            }





                        },
                        error: function (arg) {
                            if (typeof window.console != "undefined") {
                                console.log('Got this from the server: ' + arg, arg);
                            }
                            ;

                        }
                    })

                    /*

                    */


                    // getSoundCloudId(_t.val());

                }


                upload_hide_upload_field(_t);
            }
            if (_t.attr('name') == 'pay_with') {
                console.info(_t, _t.val(), _t.prop('checked'));

                if (_t.val() == 'user_credit') {

                    checkout_original_form_action = $('.checkout-form').attr('action');

                    $('.checkout-form').attr('action', 'index.php?page=checkout');

                } else {

                    $('.checkout-form').attr('action', checkout_original_form_action);
                }

            }
            if (_t.attr('name') == 'upload-watermark-field') {
                console.info(_t, _t.val(), _t.prop('checked'));

                if (_t.val() ) {

                    _t.parent().parent().find('.delete-watermark-btn').show();

                } else {

                    _t.parent().parent().find('.delete-watermark-btn').hide();
                }

            }
            if (_t.attr('name') == 'first_name' || _t.attr('name') == 'last_name' || _t.attr('name') == 'user_country' || _t.attr('name') == 'user_telephone' || _t.attr('name') == 'user_address') {
                console.info(_t, _t.val(), _t.prop('checked'));




                var data = {
                    action: 'ajax_update_user_meta'
                    , user_id: dzsap_settings.currUserId
                    , arglab: _t.attr('name')
                    , argval: _t.val()
                };





                $.ajax({
                    type: "POST",
                    url: dzsap_settings.settings_ajax_handler,
                    data: data,
                    success: function (response) {
                        if (typeof window.console != "undefined") {
                            console.log('Got this from the server: ' + response);
                        }


                    },
                    error: function (arg) {
                        if (typeof window.console != "undefined") {
                            console.log('Got this from the server: ' + arg, arg);
                        }
                        ;

                    }
                })


            }

            //console.info(_t);
        }
    }

    function determine_curr_html() {

        var auxa = String(window.location.href).split('/');


        var aux2 = auxa[auxa.length - 1];

        //console.info(auxa);
        curr_html = aux2;

        if (curr_html == '') {
            curr_html = 'index.php';
        }

        //console.info(curr_html);
    }

    function validateEmail(email) {
        var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
        return re.test(email);
    }

    function generate_repeater_field(_arg){



        var arr = [];
        _arg.children().each(function(){
            var _t = $(this);

            // console.info(_t);

            if(_t.hasClass('active')){

                arr.push(_t.attr('data-id'));
            }
        })

        _arg.prev().val(php_serialize(arr));

        // console.warn(php_serialize(arr));
    }


    function handle_mouse(e) {


        function set_user_card(_t, arr){

            _t.find('.user-summary-background').css('background-image','url('+arr.cover+')');
            if(arr.cover_set=='on'){
                _t.find('.user-summary-background').addClass('cover-user-set');
            }
            _t.find('.user-avatar').css('background-image','url('+arr.avatar+')');
            _t.find('.followers-count').html(arr.followers);

            _t.addClass('loaded');
        }
        var _t = $(this);

        if (e.type == 'mouseover') {

            if (_t.hasClass('dzstooltip-con-user-summary')) {

                if(_t.hasClass('loading')){

                }else{
                    _t.addClass('loading');


                    if(window.cache_cards[_t.attr('data-user-id')]){

                        _t.addClass('instant-transition');
                        set_user_card(_t,window.cache_cards[_t.attr('data-user-id')]);
                    }else{

                        var data = {
                            action: 'ajax_get_user_card'
                            , user_id: _t.attr('data-user-id')
                        };

                        $.ajax({
                            type: "POST",
                            url: dzsap_settings.settings_ajax_handler,
                            data: data,
                            success: function (response) {
                                if (typeof window.console != "undefined") {
                                    console.log('Got this from the server: ' + response);
                                }


                                var arr = (JSON.parse(response));

                                set_user_card(_t,arr);
                                window.cache_cards[_t.attr('data-user-id')] = arr;
                            },
                            error: function (arg) {
                                if (typeof window.console != "undefined") {
                                    console.log('Got this from the server: ' + arg, arg);
                                }
                                ;

                            }
                        });
                    }

                }
            }
        }

        if (e.type == 'click') {
            if (_t.hasClass('register-btn')) {
                //console.info(_t);

                if ($('input[name=pass]').val() != $('input[name=pass_confirm]').val()) {

                    $('.notices-box').append('<li class="notice notice-passmatch">password and confirm password do not match</li>');

                    setTimeout(function () {
                        $('.notice-passmatch').eq(0).fadeOut(1000);
                        setTimeout(function () {

                            $('.notice-passmatch').eq(0).remove();
                        }, 1000)
                    }, 1000)
                    return false;
                }
            }
            if (_t.hasClass('delete-watermark-btn')) {
                //console.info(_t);

                _t.parent().find('input').eq(0).val('');

                return false;
            }
            if (_t.hasClass('add-btn')) {
                //console.info(_t);

                _t.parent().parent().addClass('active');
                generate_repeater_field(_t.parent().parent().parent());
                    return false;
            }

            if(_t.attr('data-playerid')=='proaccount'){
                if(_t.hasClass('btn-in-zoombox')==false && dzsap_settings.number_of_pro_account_options!='1' && dzsap_settings.number_of_pro_account_options!='0'){



                    console.info("OPEN ULTIBOX FROM API");
                    window.open_ultibox(null, {'suggested_width': 500, 'suggested_height': 82, 'dims_scaling': "fill", 'extra_classes': '', forcenodeeplink: 'on', inline_content_move: 'off', source:'#inline-content1', type: 'inlinecontent'})


                    return false;
                }
            }

            if (_t.hasClass('btn-in-zoombox')) {
                //console.info(_t);

                window.close_ultibox();
            }
            if (_t.hasClass('download-anchor-btn')) {
                //console.info(_t);


                if(dzsap_settings.download_ad_link){

                    window.open(dzsap_settings.download_ad_link,'_blank');
                }
            }
            if (_t.hasClass('delete-comment-btn')) {
                //console.info(_t);


                var data = {
                    action: 'ajax_delete_comment'
                    , comment_id: _t.attr('data-comment_id')
                    , nonce: _t.attr('data-nonce')
                };

                $.ajax({
                    type: "POST",
                    url: dzsap_settings.settings_ajax_handler,
                    data: data,
                    success: function (response) {
                        if (typeof window.console != "undefined") {
                            console.log('Got this from the server: ' + response);
                        }


                        show_notice(response);


                        if (response.indexOf('success -') == 0) {
                            _t.removeClass('active');

                            _t.parent().parent().slideUp("fast");

                        }
                    },
                    error: function (arg) {
                        if (typeof window.console != "undefined") {
                            console.log('Got this from the server: ' + arg, arg);
                        }
                        ;

                    }
                });
                return false;
            }
            if (_t.hasClass('remove-btn')) {
                //console.info(_t);

                _t.parent().parent().removeClass('active');
                generate_repeater_field(_t.parent().parent().parent());
                    return false;
            }


            if (_t.hasClass('dzscheckbox')) {


                //console.info(_t, _t.find('input').eq(0).prop('checked'));

                if (_t.find('input').eq(0).prop('checked') == false) {
                    _t.find('input').eq(0).prop('checked', true);
                } else {
                    _t.find('input').eq(0).prop('checked', false);
                }

                _t.find('input').eq(0).trigger('change');

                //return false;
            }


            if (_t.hasClass('delete-track-con')) {


                //console.info(_t, _t.find('input').eq(0).prop('checked'));

                _t.parent().remove();
                //return false;
            }

            if (_t.hasClass('btn-install-zoomportal')) {


                console.info('ceva');








                if (_t.hasClass('credentials-verified') == false) {


                    var data = {
                        action: 'ajax_check_credentials'
                        , postdata: $('.install-form').eq(0).serialize()
                    };

                    $.ajax({
                        type: "POST",
                        url: dzsap_settings.settings_ajax_handler,
                        data: data,
                        success: function (response) {
                            if (typeof window.console != "undefined") {
                                console.log('Got this from the server: ' + response);
                            }


                            show_notice(response);


                            if (response.indexOf('success -') == 0) {
                                _t.removeClass('active');

                            }

                            setTimeout(function () {

                                _t.addClass('credentials-verified');
                                _t.trigger('click');
                            }, 500)
                        },
                        error: function (arg) {
                            if (typeof window.console != "undefined") {
                                console.log('Got this from the server: ' + arg, arg);
                            }
                            ;

                        }
                    })
                    return false;
                }



            }
            if (_t.hasClass('login-signup--label')) {


                _t.parent().find('.dzstooltip').toggleClass('active');
            }
            if (_t.hasClass('btn-pagination-button')) {


                var _con = _t.parent().parent();



                if (_con.data('busy_ajax') != true) {
                    //console.info('LOAD NEXT');


                    // if(query_scroll_targets[i23])
                    load_next_page_for_pagination_target(_con);

                }
            }
            if (_t.hasClass('pagination-a')) {


                var _con = _t.parent().parent().parent();



                console.info(_con);

                _t.parent().parent().find('.active').removeClass('active');
                _t.parent().addClass('active');

                if (_con.data('busy_ajax') != true) {
                    //console.info('LOAD NEXT');


                    // if(query_scroll_targets[i23])
                    load_page_for_pagination_target(_con, Number(_t.html()) - 1);

                }

                return false;
            }

            if (_t.hasClass('edit-btn')) {


                var _con = _t.parent();

                if (_con.hasClass('ztm-content') || _con.hasClass('style-under--item')) {
                    if (_con.hasClass('active')) {

                        _con.removeClass('active');
                        _t.removeClass('active');
                        if (_t.next().hasClass('edit-panel')) {
                            _t.next().slideUp("fast");

                        }

                        if(_body.hasClass('page-track')){
                        }
                        _body.removeClass('edit-track-opened');
                        $('.content-section').removeClass('edit-track-opened');
                    } else {
                        _con.addClass('active');
                        _t.addClass('active');
                        if (_t.next().hasClass('edit-panel')) {
                            _t.next().slideDown("fast");
                            init_tinymces(_t.next());
                            _con.find('textarea[name=tags]').addClass('tagify-me');
                            apply_tags();
                        }
                        _body.addClass('edit-track-opened');
                        $('.content-section').addClass('edit-track-opened');
                    }
                } else {

                }
            }

            if (_t.hasClass('delete-repost-btn')) {



                var r = confirm("Are you sure you want to delete this repost ?");


                if (r) {


                    var data = {
                        action: 'ajax_delete_repost'
                        , player_id: _t.attr('data-player-id')
                        , repost_id: _t.attr('data-repost-id')
                    };


                    $.ajax({
                        type: "POST",
                        url: dzsap_settings.settings_ajax_handler,
                        data: data,
                        success: function (response) {
                            //console.info(response,response.indexOf('success - '));
                            if (response.indexOf('success - ') > -1) {

                                show_notice(response);

                                window.location.reload();
                            }
                        },
                        error: function (arg) {
                            if (typeof window.console != "undefined") {
                                console.log('Got this from the server: ' + arg, arg);
                            }
                            ;

                        }
                    });

                }
            }

            if (_t.hasClass('field-for-view')) {


                selectText(_t.get(0));
            }

            if (_t.hasClass('share-btn')) {


                //console.info(_t, '#share-content-'+_t.attr('data-playerid'), $('#share-content-'+_t.attr('data-playerid')));

                window.open_ultibox(null, {'suggested_width': 500, 'suggested_height': 250, 'dims_scaling': "fill", 'extra_classes': '', forcenodeeplink: 'on', inline_content_move: 'off', source:'#share-content-' + _t.attr('data-playerid'), type: 'inlinecontent'});
            }


            if (_t.hasClass('stats-btn')) {



                var _con = _t.parent();

                if(_t.hasClass('disabled')){
                    return false;
                }
                _t.addClass('disabled');
                setTimeout(function(){
                    _t.removeClass('disabled')
                },2000)

                if(_con.find('.stats-container').length){

                    _t.removeClass('active');
                    _con.find('.stats-container').each(function(){
                        var _t2 = $(this);
                        _t2.addClass('transitioning-out').removeClass('loaded');

                        // _t2.animate({
                        //     'height':0
                        // },{queue:false
                        // ,duration: 300})


                        _t2.slideUp("fast");


                        setTimeout(function(){
                            _con.find('.stats-container.transitioning-out').remove()
                        },400)
                    })
                }else{

                    _t.addClass('active');
                    load_statistics(_con);
                }

            }


            if (_t.hasClass('btn-follow')) {


                //console.info(_t, _t.find('input').eq(0).prop('checked'));

                //console.info('ceva');




                var target_user_id = $('.dzsapp_var_user_id').eq(0).text();

                if(_t.attr('data-user-id')){
                    target_user_id = _t.attr('data-user-id');
                }


                console.warn(' _t.attr(\'data-user-id\') -   ',_t.attr('data-user-id') , _t);

                var data = {
                    action: 'ajax_follow_user'
                    , target_user_id: target_user_id
                };



                if (_t.hasClass('active')) {

                    data.action = 'ajax_unfollow_user';

                    $.ajax({
                        type: "POST",
                        url: dzsap_settings.settings_ajax_handler,
                        data: data,
                        success: function (response) {
                            if (typeof window.console != "undefined") {
                                console.log('Got this from the server: ' + response);
                            }


                            response = parse_response(response);
                            show_notice(response);

                            console.warn(response);


                            if (response.report == 'success') {
                                _t.html('<span class="button-label">' + dzsap_ltz.follow + '</span>');
                            }

                            setTimeout(function () {

                            }, 500)
                        },
                        error: function (arg) {
                            if (typeof window.console != "undefined") {
                                console.log('Got this from the server: ' + arg, arg);
                            }
                            ;

                        }
                    })
                } else {
                    $.ajax({
                        type: "POST",
                        url: dzsap_settings.settings_ajax_handler,
                        data: data,
                        success: function (response) {
                            if (typeof window.console != "undefined") {
                                console.log('Got this from the server: ' + response);
                            }



                            response = parse_response(response);
                            show_notice(response);

                            console.warn(response);


                            if (response.report == 'success') {
                                _t.html('<span class="button-label">' + dzsap_ltz.unfollow + '</span>');
                                _t.addClass('active');
                            }

                            setTimeout(function () {

                            }, 500)
                        },
                        error: function (arg) {
                            if (typeof window.console != "undefined") {
                                console.log('Got this from the server: ' + arg, arg);
                            }
                            ;

                        }
                    })
                }

                ;

                return false;

                //return false;
            }


            if (_t.hasClass('btn-repost')) {


                //console.info(_t, _t.find('input').eq(0).prop('checked'));

                //console.info('ceva');


                if (_t.hasClass('active')) {
                    var data = {
                        action: 'ajax_delete_repost'
                        , player_id: _t.attr('data-track_id')
                        , repost_id: _t.attr('data-repost-id')
                    };


                    $.ajax({
                        type: "POST",
                        url: dzsap_settings.settings_ajax_handler,
                        data: data,
                        success: function (response) {
                            //console.info(response,response.indexOf('success - '));
                            if (response.indexOf('success - ') > -1) {






                                show_notice(response);



                                response = parse_response(response);

                                //show_notice(response);


                                console.info('respost response - ',response);



                                if (response.report=='success') {
                                }

                                _t.removeClass('active');
                                _t.removeClass('already-activated')

                                // window.location.reload();
                            }
                        },
                        error: function (arg) {
                            if (typeof window.console != "undefined") {
                                console.log('Got this from the server: ' + arg, arg);
                            }
                            ;

                        }
                    });

                    return false;
                }


                _t.addClass('activating');


                var data = {
                    action: 'ajax_repost_track'
                    , track_id: _t.attr('data-track_id')
                };




                // return;

                $.ajax({
                    type: "POST",
                    url: dzsap_settings.settings_ajax_handler,
                    data: data,
                    success: function (response) {




                        response = parse_response(response);

                        //show_notice(response);


                        console.info('respost response - ',response);



                        if (response.report=='success') {
                            _t.addClass('active');
                            _t.attr('data-repost_id', response.repost_id)
                        }
                        if (response.report=='error') {
                            //_t.addClass('active');
                        }


                        setTimeout(function () {

                        }, 500)
                    },
                    error: function (arg) {
                        if (typeof window.console != "undefined") {
                            console.log('Got this from the server: ' + arg, arg);
                        }
                        ;

                    }
                })

                return false;

                //return false;
            }
            if (_t.hasClass('btn-comment-submit')) {


                //console.info(_t, _t.find('input').eq(0).prop('checked'));

                //console.info('ceva');




                //return false;
            }

            if (_t.hasClass('big-search-btn')) {


                //console.info(_t, _t.find('input').eq(0).prop('checked'));

                $('.bigsearch-con').addClass('activated');
                _body.addClass('big-search-activated');

                //return false;
            }

            if (_t.hasClass('bigsearch--the-bg')) {


                //console.info(_t, _t.find('input').eq(0).prop('checked'));

                $('.bigsearch-con').removeClass('activated');
                _body.removeClass('big-search-activated');

                //return false;
            }

            if (_t.hasClass('add-to-playlist-btn')) {

                if (_t.get(0).nodeName != 'A') {


                    window.open_ultibox(null, {suggested_width: 500, suggested_height: 500, forcenodeeplink: 'on', type: 'iframe', dims_scaling: 'fill', source:dzsap_settings.optional_url_base + 'index.php?action=playlists_iframe&track_id=' + _t.parent().parent().parent().parent().parent().attr('data-playerid')});

                    return false;
                }


                //console.info(_t, _t.find('input').eq(0).prop('checked'), _t.parent().parent().parent().parent());

            }
            if (_t.hasClass('btn-toggle-responsive-menu')) {


                //console.info(_t, _t.find('input').eq(0).prop('checked'), _t.parent().parent().parent().parent());


                //console.info(_t);

                if (_body.hasClass('sidebar-activated')) {
                    _body.removeClass('sidebar-activated')
                } else {
                    _body.addClass('sidebar-activated')
                }

                return false;
            }
            if (_t.hasClass('responsive-menu-closer')) {


                //console.info(_t, _t.find('input').eq(0).prop('checked'), _t.parent().parent().parent().parent());


                //console.info(_t);
                _body.removeClass('sidebar-activated')


                return false;
            }

            if (_t.hasClass('add-to-cart-btn')) {


                //console.info(_t, _t.find('input').eq(0).prop('checked'));

                if (_t.parent().parent().parent().parent().parent().hasClass('audioplayer') || _t.attr('data-playerid')) {
                    var _con = _t.parent().parent().parent().parent().parent();
                    //console.log(_con.attr('data-playerid'));



                    var data = {
                        action: 'ajax_add_to_cart'
                        , prod_id: _con.attr('data-playerid')
                    };

                    if (_con.attr('data-playerid')) {
                        data.prod_id = _con.attr('data-playerid');
                    }

                    if (_t.attr('data-playerid')) {
                        data.prod_id = _t.attr('data-playerid');
                    }


                    $.ajax({
                        type: "POST",
                        url: dzsap_settings.settings_ajax_handler,
                        data: data,
                        success: function (response) {
                            if (typeof window.console != "undefined") {
                                console.log('Got this from the server: ' + response);
                            }


                            load_cart();

                            //console.info($('.menu-right-block-cart'));
                            _cart_contents.addClass('active');

                            setTimeout(function () {

                                _cart_contents.removeClass('active');
                            }, 500);




                            $('.mcon-mainmenu').prepend('<div class="purchase-confirmation-clip"></div>');

                            var _pcc = $('.mcon-mainmenu').eq(0).children('.purchase-confirmation-clip');

                            _pcc.append(response);

                            setTimeout(function () {
                                _pcc.addClass('active');
                            }, 50);

                            _pcc.css('height', '0');
                            _pcc.css('opacity', '0');
                            _pcc.animate({
                                height: _pcc.children('.purchase-confirmation').eq(0).height()
                                , opacity: 1
                            }, {
                                queue: false
                                , duration: 300
                            });
                            setTimeout(function () {

                                _pcc.animate({
                                    height: 0
                                    , opacity: 0
                                }, {
                                    queue: false
                                    , duration: 300
                                });
                                _pcc.removeClass('active');
                            }, 2000);
                            setTimeout(function () {

                                _pcc.remove();
                            }, 3000);
                        },
                        error: function (arg) {
                            if (typeof window.console != "undefined") {
                                console.log('Got this from the server: ' + arg, arg);
                            }
                            ;

                        }
                    });

                }
                return false;
            }

            if (_t.hasClass('cart-delete-item-btn')) {


                //console.info(_t, _t.find('input').eq(0).prop('checked'));

                if (_t.parent().parent().parent().parent().parent().hasClass('audioplayer') || _t.attr('data-playerid')) {
                    var _con = _t.parent().parent().parent().parent().parent();
                    //console.log(_con.attr('data-playerid'));



                    var data = {
                        action: 'ajax_remove_to_cart'
                        , prod_id: _con.attr('data-playerid')
                    };

                    if (_con.attr('data-playerid')) {
                        data.prod_id = _con.attr('data-playerid');
                    }

                    if (_t.attr('data-playerid')) {
                        data.prod_id = _t.attr('data-playerid');
                    }


                    $.ajax({
                        type: "POST",
                        url: dzsap_settings.settings_ajax_handler,
                        data: data,
                        success: function (response) {
                            if (typeof window.console != "undefined") {
                                console.log('Got this from the server: ' + response);
                            }


                            load_cart();

                            //console.info($('.menu-right-block-cart'));
                            _cart_contents.addClass('active');

                            setTimeout(function () {

                                _cart_contents.removeClass('active');

                                if (get_query_arg_sp(window.location.href, 'page') == 'checkout') {
                                    window.location.reload();
                                }
                            }, 500)
                        },
                        error: function (arg) {
                            if (typeof window.console != "undefined") {
                                console.log('Got this from the server: ' + arg, arg);
                            }
                            ;

                        }
                    });

                }
                return false;
            }


            if (_t.hasClass('btn-ajax-add-playlist')) {


                //console.info($('input[name=playlist_name]'), $('input[name=playlist_name]').eq(0).val());


                var data = {
                    action: 'ajax_add_playlist'
                    , postdata: $('#add-to-playlist-tabs .tab-content.active form[name=add_track]').eq(0).serialize()
                };


                $('.sidenote-loading-adding-playlist').addClass('active');
                $.ajax({
                    type: "POST",
                    url: dzsap_settings.settings_ajax_handler,
                    data: data,
                    success: function (response) {
                        console.info(response, response.indexOf('success - '));
                        if (response.indexOf('success - ') > -1) {

                            setTimeout(function () {

                                $('.sidenote-loading-adding-playlist').removeClass('active');

                                $('#add-to-playlist-tabs').get(0).api_goto_tab(0);

                                $('.playlists-con').removeClass('loaded').addClass('loading');
                                load_playlists();
                            }, 500);
                        }
                    },
                    error: function (arg) {
                        if (typeof window.console != "undefined") {
                            console.log('Got this from the server: ' + arg, arg);
                        }
                        ;

                    }
                });


                return false;
            }


            if (_t.hasClass('btn-ajax-remove-playlist')) {


                //console.info(_t);
                //console.info($('input[name=playlist_name]'), $('input[name=playlist_name]').eq(0).val());


                var r = confirm("Are you sure you want to delete this playlist ?");


                if (r) {


                    var data = {
                        action: 'ajax_remove_playlist'
                        , playlist_id: _t.attr('data-playlist_id')
                    };


                    $.ajax({
                        type: "POST",
                        url: dzsap_settings.settings_ajax_handler,
                        data: data,
                        success: function (response) {
                            //console.info(response,response.indexOf('success - '));
                            if (response.indexOf('success - ') > -1) {

                                $('.playlists-con').removeClass('loaded').addClass('loading');
                                _t.parent().parent().slideUp('fast');
                                setTimeout(function () {


                                    load_playlists();
                                }, 500);
                            }
                        },
                        error: function (arg) {
                            if (typeof window.console != "undefined") {
                                console.log('Got this from the server: ' + arg, arg);
                            }
                            ;

                        }
                    });

                }


                return false;
            }

            if (_t.hasClass('btn-ajax-add-to-playlist-id')) {


                //console.info($('input[name=playlist_name]'), $('input[name=playlist_name]').eq(0).val());

                var data = {
                    action: 'ajax_add_to_playlist_id'
                    , track_id: get_query_arg(window.location.href, "track_id")
                    , playlist_id: _t.attr('data-playlist_id')
                };

                if (_t.hasClass('playlist-added')) {
                    data.action = 'ajax_remove_to_playlist_id';
                } else {


                }



                $.ajax({
                    type: "POST",
                    url: dzsap_settings.settings_ajax_handler,
                    data: data,
                    success: function (response, e) {

                        if (typeof window.console != "undefined") {
                            console.log('Got this from the server: ' + response);
                        }
                        ;

                        if (response.indexOf('success - ') > -1) {

                            if (_t.hasClass('active')) {

                                _t.removeClass('active playlist-added');

                                _t.children('.btn-label').html('Add to Playlist');
                            } else {

                                _t.addClass('active playlist-added');

                                _t.children('.btn-label').html('Remove Track');
                            }


                        }
                    },
                    error: function (arg) {
                        if (typeof window.console != "undefined") {
                            console.log('Got this from the server: ' + arg, arg);
                        }
                        ;

                    }
                });


                return false;
            }


            if (_t.hasClass('button-primary-for-register')) {
                //console.info(_t);

                if ($('input[name=password]').val() != $('input[name=confirm_password]').val()) {

                    $('.notices-box').append('<li class="notice notice-passmatch">password and confirm password do not match</li>');

                    setTimeout(function () {
                        $('.notice-passmatch').eq(0).fadeOut(1000);
                        setTimeout(function () {

                            $('.notice-passmatch').eq(0).remove();
                        }, 1000)
                    }, 1000);


                    return false;
                }
            }
            if (_t.hasClass('playlist-btn')) {

//                console.info(_t);



                if (_t.hasClass('active')) {


                    var data = {
                        action: 'dzsap_retract_playlist_entry',
                        playlistid: _t.attr('data-id'),
                        mediaid: dzsap_settings.mediaid
                    };


                    $.ajax({
                        type: "POST",
                        url: dzsap_settings.settings_php_handler,
                        data: data,
                        success: function (response) {
                            if (typeof window.console != "undefined") {
                                console.log('Got this from the server: ' + response);
                            }

                            _t.removeClass('active');
                        },
                        error: function (arg) {
                            if (typeof window.console != "undefined") {
                                console.log('Got this from the server: ' + arg, arg);
                            }
                            ;

                        }
                    });


                } else {


                    var data = {
                        action: 'dzsap_submit_playlist_entry',
                        playlistid: _t.attr('data-id'),
                        mediaid: dzsap_settings.mediaid
                    };


                    $.ajax({
                        type: "POST",
                        url: dzsap_settings.settings_php_handler,
                        data: data,
                        success: function (response) {
                            if (typeof window.console != "undefined") {
                                console.log('Got this from the server: ' + response);
                            }

                            _t.addClass('active');
                        },
                        error: function (arg) {
                            if (typeof window.console != "undefined") {
                                console.log('Got this from the server: ' + arg, arg);
                            }
                            ;

                        }
                    });

                }
            }



            if (_t.hasClass('upload-track-btn')) {
                //console.log('ceva');



                if($('#fortinymceundefined').hasClass('tinymce-activated')){
                    if(window.tinyMCE){
                        var ed = tinyMCE.get('fortinymceundefined');

                        //console.info(ed);
                        if(ed){

                            //console.info('val - ',ed.getContent({format : 'raw'}))
                            tinyMCE.triggerSave()
                            //$('#fortinymceundefined').val(ed.getContent({format : 'raw'}))

                        }
                    }


                }


                var data = {
                    action: 'dzsap_submit_track',
                    postdata: $('.submit-track-form').eq(0).serialize()
                };

                _t.addClass('disabled');
                setTimeout(function(){

                    _t.removeClass('disabled');
                },3000)

                $.ajax({
                    type: "POST",
                    url: dzsap_settings.settings_ajax_handler,
                    data: data,
                    success: function (response) {
                        if (typeof window.console != "undefined") {
                            console.log('Got this from the server: ' + response);
                        }

                        show_notice(response);




                        response = parse_response(response);
                        show_notice(response);

                        console.warn(response);


                        if (response.report == 'success') {
                            setTimeout(function () {
                                click_menu_anchor(null, {
                                    force_href: response.permalink
                                    , force_pushState: true
                                });
                            }, 500);
                        }


                    },
                    error: function (arg) {
                        if (typeof window.console != "undefined") {
                            console.log('Got this from the server: ' + arg, arg);
                        }
                        ;

                    }
                });



                return false;
            }




            if (_t.hasClass('cancel-upload-btn')) {
                //console.log('ceva');



                var _c = $('.dzs-upload-con').eq(0);

                _c.removeClass('disabling');
                _c.css('height', 'auto');

//                console.info(_c, _c.height());

                return false;
            }



            if (_t.hasClass('delete-track-btn')) {
                //console.log('ceva');


                var aux = window.confirm("Are you sure you want to delete this track?");

                if (aux) {

                    var data = {
                        action: 'dzsap_delete_track',
                        postdata: _t.attr('data-playerid')
                    };


                    $.ajax({
                        type: "POST",
                        url: dzsap_settings.settings_ajax_handler,
                        data: data,
                        success: function (response) {
                            if (typeof window.console != "undefined") {
                                console.log('Got this from the server: ' + response);
                            }

                            show_notice(response);

                            if (response.indexOf('success -') == 0) {

                                if (_t.parent().parent().parent().hasClass('ztm-item')) {
                                    _t.parent().parent().parent().fadeOut("slow");
                                }


                            }
                        },
                        error: function (arg) {
                            if (typeof window.console != "undefined") {
                                console.log('Got this from the server: ' + arg, arg);
                            }
                            ;

                        }
                    });
                }




                return false;
            }
        }
    }


    function load_statistics(_con){


        if(window.google && window.google.charts ){


            if(window.google.visualization){






                console.info("NOW APPLYING");

                var data = {
                    action: 'ajax_get_statistics_html',
                    postdata: _con.parent().attr('data-playerid')
                };


                $.ajax({
                    type: "POST",
                    url: dzsap_settings.settings_php_handler,
                    data: data,
                    success: function (response) {
                        if (typeof window.console != "undefined") {
                            console.groupCollapsed('Submit message Got this from the server:');
                            console.log(' ' + response);
                            console.groupEnd();
                        }


                        _con.append('<div class="stats-container">'+response+'</div>')

                        setTimeout(function(){

                            var _c = _con.find('.stats-container');
                            // _c.css('height','auto');
                            // var auxh = (_c.outerHeight());

                            // _c.css('height',0);

                            // console.info('try to get real height - ', _c.get(0).scrollHeight)
                            _c.addClass('loaded');



                            var auxr = /<div class="hidden-data">(.*?)<\/div>/g;
                            var aux = auxr.exec(response);
                            // console.log('aux - ',aux);

                            var aux_resp = '';
                            if(aux[1]){
                                aux_resp = aux[1];
                            }


                            var resp_arr = [];
                            // console.info(aux_resp);

                            try{
                                resp_arr = JSON.parse(aux_resp);
                            }catch(err){

                            }
                            // console.warn(resp_arr);



                            var arr = [

                            ];


                            arr[0] = [];
                            for(var i in resp_arr['labels']){


                                // console.info('i - ',i, resp_arr['labels'][i]);

                                arr[0].push(resp_arr['labels'][i]);
                            }
                            for(var i in resp_arr['lastdays']){

                                i=parseInt(i,10);

                                arr[i+1] = [];
                                for(var j in resp_arr['lastdays'][i]){

                                    j=parseInt(j,10);

                                    // console.info('j - ',j, resp_arr['lastdays'][i][j]);

                                    var aux = parseFloat(resp_arr['lastdays'][i][j]);
                                    if(isNaN(aux)==false){
                                        resp_arr['lastdays'][i][j] = aux;
                                    }
                                    arr[i+1].push(resp_arr['lastdays'][i][j]);
                                }

                            }



                            // console.info('stats arr - ',arr);
                            var data = google.visualization.arrayToDataTable(arr);

                            var options = {

                                backgroundColor: '#444444',
                                height: '300',
                                chart: {
                                    title: 'Track Performance'
                                    ,backgroundColor: '#444444'
                                }
                                ,chartArea:{
                                    backgroundColor: '#444444'
                                }
                            };
                            var material = new google.charts.Bar(_con.find('.trackchart').get(0));
                            material.draw(data, google.charts.Bar.convertOptions(options));

                            _c.slideDown("fast");

                            setTimeout(function(){

                                $(this).css('height','auto');
                            },400);


                            // _c.animate({
                            //     'height': auxh
                            // },{
                            //     queue:false
                            //     ,duration: 300
                            //     ,complete: function(){
                            //     }
                            // })
                        },100);


                    },
                    error: function (arg) {
                        if (typeof window.console != "undefined") {
                            console.log('Got this from the server: ' + arg, arg);
                        }
                        ;

                    }
                });





            }else{
                google.charts.load('current', {packages: ['corechart', 'bar']});
                google.charts.setOnLoadCallback(function(){
                    load_statistics(_con);
                });
            }






        }else{

            if(window.dzsapp_loading_google_charts){




            }else{



                var url = 'https://www.gstatic.com/charts/loader.js';
                //console.warn(scripts[i23], baseUrl, url);






                // console.info('load wavesurfer');
                $.ajax({
                    url: url,
                    dataType: "script",
                    success: function(arg) {
                        //console.info(arg);

                        // cthis.append('')





                        console.info('loaded charts');




                    }
                });


                window.dzsapp_loading_google_charts = true;
            }

            setTimeout(function(){
                load_statistics(_con)
            },1000);
        }

    }

    function draw_chart_for_con(_con) {
        var data = google.visualization.arrayToDataTable(
        );
    }

    function init_tinymces(_con){


        //console.info(_con);

        _con.find('.with-tinymce').each(function(){
            var _t = $(this);
            //console.info(_t);

            var _con = _t.parent().parent().parent().parent();



            var trackid = (_con.find('*[name=track_id]').eq(0).val());

            //console.warn(trackid);
            _t.attr('id','fortinymce'+trackid);
            init_try_tinymce(_t);
        })
    }

    function init_try_tinymce(_c){

        if(_c.hasClass('tinymce-activated')){
            return false;
        }

        if(window.tinyMCE){


            console.info("HMM");
            tinyMCE.baseURL = dzsap_settings.thepath+'tinymce';
            tinyMCE.init({
                selector: '#'+_c.attr('id')
                ,base: dzsap_settings.thepath+'tinymce/'
                ,menubar: false
                ,toolbar: 'styleselect | bold italic | link image code bullist numlist'
                ,plugins: 'code,lists,link'
                ,selection_toolbar: 'bold italic | quicklink h2 h3 blockquote code fontsize '
            });

            _c.addClass('tinymce-activated');


        }else{

            if(window.tinymce_trying_to_load!=true){

                window.tinymce_trying_to_load = true;

                $.getScript(dzsap_settings.thepath+'tinymce/tinymce.min.js', function (data, textStatus, jqxhr) {

                    init_try_tinymce(_c);
                })
            }
        }
    }


    function handle_submit(e) {

        //console.info(e);

        var _t = $(this);


        if (e.type == 'keyup') {


            if (_t.attr('name') == 'search_keywords') {

                //console.log(e.keyCode);

                if (_t.val() != '') {
                    _t.parent().parent().parent().addClass("has-input");
                    _t.parent().parent().parent().addClass("loading");

                    if (inter_load_results) {
                        clearTimeout(inter_load_results);
                    }

                    inter_load_results = setTimeout(load_results, 500);

                } else {

                    _t.parent().parent().parent().removeClass("has-input");
                    _t.parent().parent().parent().removeClass("loading");

                    if (inter_load_results) {
                        clearTimeout(inter_load_results);
                    }

                }
            }

            if (_t.hasClass('input-ujarak-style')) {
                //console.info(_t, _t.prop('checked'));

                //console.info(_t.val(), _t.parent())
                if (_t.val()) {
                    if (_t.parent().hasClass('setting')) {
                        _t.parent().removeClass('ujarak-empty');
                    }
                } else {

                    if (_t.parent().hasClass('setting')) {
                        _t.parent().addClass('ujarak-empty');
                    }
                }
            }
            if (_t.hasClass('selector-main-searcher')) {
                //console.info(_t, _t.prop('checked'));

                //console.info(_t.val(), _t.parent())
                var _c = _t.parent().next();

                //console.info('_c - ',_c);
                _c.children().each(function(){
                    var _t2 = $(this);

                    var title = String(_t2.children('.the-title').text()).toLowerCase();

                    //console.info('_t2 - ',_t2,_t.val().toLowerCase() );

                    if(title.indexOf(_t.val().toLowerCase())>-1 || _t.val()==''){
                        _t2.show();
                    }else{

                        _t2.hide();
                    }

                })
            }

        }

        if (e.type == 'submit') {
            if (_t.hasClass('messages-send-con')) {
                var data = {
                    action: 'ajax_submit_message',
                    postdata: $(this).serialize()
                };


                $.ajax({
                    type: "POST",
                    url: dzsap_settings.settings_php_handler,
                    data: data,
                    success: function (response) {
                        if (typeof window.console != "undefined") {
                            console.log('Submit message Got this from the server: ' + response);
                        }


                        //console.info($('input[name=message]'));

                        $('input[name=message]').val('');

                        load_messages();
                        load_messages_friends();

                        //_t.addClass('active');
                    },
                    error: function (arg) {
                        if (typeof window.console != "undefined") {
                            console.log('Got this from the server: ' + arg, arg);
                        }
                        ;

                    }
                });

                return false;
            }
            if (_t.hasClass('reportcopyright')) {

                // console.info(_t.find('*[name=track_id]'));
                _t.find('*[name=track_id]').val(($('.audioplayer').eq(0).attr('data-playerid')));


                var data = {
                    action: 'ajax_submit_report',
                    postdata: $(this).serialize()
                };

                $.ajax({
                    type: "POST",
                    url: dzsap_settings.settings_php_handler,
                    data: data,
                    success: function (response) {
                        if (typeof window.console != "undefined") {
                            console.log('Submit message Got this from the server: ' + response);
                        }

                        if(window.close_ultibox){

                            close_ultibox();
                        }


                    },
                    error: function (arg) {
                        if (typeof window.console != "undefined") {
                            console.log('Got this from the server: ' + arg, arg);
                        }
                        ;

                    }
                });

                return false;
            }


            if (_t.hasClass('comment-form-con')) {
                if ($('.comment-form-con *[name=email]').length > 0) {

                    if ($('.comment-form-con *[name=email]').val() == '') {
                        alert("You need to enter a email");

                        return false;
                    } else {

                        if (validateEmail($('.comment-form-con *[name=email]').val()) == false) {

                            alert("You need to enter a email");

                            return false;
                        }
                    }
                }


                if ($('.comment-form-con *[name=name]').length > 0) {


                    if ($('.comment-form-con *[name=name]').val() == '') {
                        alert("You need to enter a name");

                        return false;
                    }
                }




                var data = {
                    action: 'ajax_submit_comment_from_form'
                    , postdata: $('.comment-form-con').eq(0).serialize()
                    , comment_text: $('textarea[name=comment_text]').val()
                };




                $.ajax({
                    type: "POST",
                    url: dzsap_settings.settings_ajax_handler,
                    data: data,
                    success: function (response) {
                        if (typeof window.console != "undefined") {
                            console.log('Got this from the server: ' + response);
                        }

                        response = parse_response(response);

                        show_notice(response);




                        if (response.report=='success') {
                            $('.comment-form-con *[name=comment_text]').val('');

                            var _c = $('.shortcode-comments').eq(0);
                            if(_c.children('.comment-con').length){
                                _c.children('.comment-con').last().after(response.comment_text);
                            }else{

                                _c.prepend(response.comment_text);
                            }

                        }


                    },
                    error: function (arg) {
                        if (typeof window.console != "undefined") {
                            console.log('Got this from the server: ' + arg, arg);
                        }
                        ;

                    }
                })


                        ;

                return false;
            }
            if (_t.hasClass('usersettings-form')) {



                var data = {
                    action: 'save_usersettings',
                    postdata: $(this).serialize()
                };


                $.ajax({
                    type: "POST",
                    url: dzsap_settings.settings_php_handler,
                    data: data,
                    success: function (response) {
                        if (typeof window.console != "undefined") {
                            console.log('Submit message Got this from the server: ' + response);
                        }


                        //console.info($('input[name=message]'));

                        show_notice(response);


                        //_t.addClass('active');
                    },
                    error: function (arg) {
                        if (typeof window.console != "undefined") {
                            console.log('Got this from the server: ' + arg, arg);
                        }
                        ;

                        show_notice(arg);
                    }
                });




                // console.info('  $(\'form.user-meta\') - ',$('form.user-meta'));
                var data2 = {
                    action: 'save_usermeta',
                    postdata: $('form.user-meta').eq(0).serialize()
                };


                $.ajax({
                    type: "POST",
                    url: dzsap_settings.settings_php_handler,
                    data: data2,
                    success: function (response) {
                        if (typeof window.console != "undefined") {
                            console.log('Submit message Got this from the server: ' + response);
                        }


                        //console.info($('input[name=message]'));



                        //_t.addClass('active');
                    },
                    error: function (arg) {
                        if (typeof window.console != "undefined") {
                            console.log('Got this from the server: ' + arg, arg);
                        }
                        ;

                    }
                });

                return false;

            }
            if (_t.hasClass('install-form')) {



                var data = {
                    action: 'ajax_install',
                    postdata: $(this).serialize()
                };


                $.ajax({
                    type: "POST",
                    url: dzsap_settings.settings_php_handler,
                    data: data,
                    success: function (response) {
                        if (typeof window.console != "undefined") {
                            console.log('Submit message Got this from the server: ' + response);
                        }


                        //console.info($('input[name=message]'));

                        show_notice(response);

                        if (response.indexOf('success - ') == 0) {
                            setTimeout(function () {

                                window.location.href = 'index.php';
                                window.location.reload();
                            }, 1000);
                        }



                        //_t.addClass('active');
                    },
                    error: function (arg) {
                        if (typeof window.console != "undefined") {
                            console.log('Got this from the server: ' + arg, arg);
                        }
                        ;

                        show_notice(arg);
                    }
                });

                return false;

            }
            if (_t.hasClass('edit-panel')) {



                var data = {
                    action: 'save_track_settings',
                    postdata: $(this).serialize()
                };


                $.ajax({
                    type: "POST",
                    url: dzsap_settings.settings_php_handler,
                    data: data,
                    success: function (response) {
                        if (typeof window.console != "undefined") {
                            console.log('Submit message Got this from the server: ' + response);
                        }


                        //console.info($('input[name=message]'));

                        show_notice(response);


                        //_t.addClass('active');
                    },
                    error: function (arg) {
                        if (typeof window.console != "undefined") {
                            console.log('Got this from the server: ' + arg, arg);
                        }
                        ;

                        show_notice(arg);
                    }
                });

                return false;

            }
        }


    }

    function parse_response(response) {

        var arg = {};
        try{
            arg = JSON.parse(response);


        }catch(err){
            console.log('did not parse',response);
        }

        return arg;
    }

    function show_notice(response) {


        if(typeof response=='object'){
            if(response.report=='success'){

                _feedbacker.removeClass('is-error');
                _feedbacker.html(response.text);
                _feedbacker.fadeIn('fast');

                setTimeout(function () {

                    _feedbacker.fadeOut('slow');
                }, 1500)
            }
            if(response.report=='error'){

                _feedbacker.addClass('is-error');
                _feedbacker.html(response.text);
                _feedbacker.fadeIn('fast');

                setTimeout(function () {

                    _feedbacker.fadeOut('slow');
                }, 1500)
            }
        }else{
            if (response.indexOf('error -') == 0) {
                _feedbacker.addClass('is-error');
                _feedbacker.html(response.substr(7));
                _feedbacker.fadeIn('fast');

                setTimeout(function () {

                    _feedbacker.fadeOut('slow');
                }, 1500)
            }
            if (response.indexOf('success -') == 0) {
                _feedbacker.removeClass('is-error');
                _feedbacker.html(response.substr(9));
                _feedbacker.fadeIn('fast');

                setTimeout(function () {

                    _feedbacker.fadeOut('slow');
                }, 1500)
            }
        }


    }
    function click_btn_autogenerate_waveform_bg(e) {
        var _t = $(this);
        var _themedia = '';


        _themedia = $('.id-upload-mp3').eq(0).val();



        if (typeof dzsap_settings != 'undefined') {

            //console.info(_themedia);

            var s_filename_arr = _themedia.split('/');

            //console.info(s_filename_arr);
            var s_filename = s_filename_arr[s_filename_arr.length - 1];

            s_filename = encodeURIComponent(s_filename);
            s_filename = s_filename.replace('.', '');
            s_filename = s_filename.replace(/ /g, '');



            window.waves_filename = '{{dirname}}waves/scrubbg_' + s_filename + '.png';
            ///console.info(s_filename);

            var aux = '<object type="application/x-shockwave-flash" data="' + dzsap_settings.thepath + 'wavegenerator.swf" width="230" height="30" id="flashcontent" style="visibility: visible;"><param name="movie" value="' + dzsap_settings.thepath + 'wavegenerator.swf"><param name="menu" value="false"><param name="allowScriptAccess" value="always"><param name="scale" value="noscale"><param name="allowFullScreen" value="true"><param name="wmode" value="opaque"><param name="flashvars" value="settings_multiplier=' + dzsap_settings.waveformgenerator_multiplier + '&media=' + _themedia + '&savetophp_loc=' + dzsap_settings.thepath + 'savepng.php&savetophp_pngloc=' + window.waves_filename + '&savetophp_pngprogloc=waves/scrubprog.png&color_wavesbg=' + dzsap_settings.color_waveformbg + '&color_wavesprog=' + dzsap_settings.color_waveformprog + '&settings_wavestyle=' + dzsap_settings.settings_wavestyle + '&settings_onlyautowavebg=on&settings_enablejscallback=on';

            if (dzsap_settings.waves_generation == 'auto') {
                aux += '&settings_autogenerate_bg=on';
                //aux+='&settings_autogenerate_prog=on';
            }

            aux += '"></object>';



            _t.parent().append(aux);




            if (_t.parent().prev().hasClass('upload-prev')) {
                window.waves_fieldtaget = _t.parent().prev();
            } else {
                window.waves_fieldtaget = _t.parent().prev().prev();
            }


            _t.hide();
        }


        return false;
    }


    function click_btn_autogenerate_waveform_prog(e) {
        var _t = $(this);
        var _themedia = '';

        _themedia = $('.id-upload-mp3').eq(0).val();



        if (typeof dzsap_settings != 'undefined') {

            //console.info(_themedia);

            var s_filename_arr = _themedia.split('/');

            //console.info(s_filename_arr);
            var s_filename = s_filename_arr[s_filename_arr.length - 1];

            s_filename = encodeURIComponent(s_filename);
            s_filename = s_filename.replace('.', '');



            window.waves_filename = '{{dirname}}waves/scrubprog_' + s_filename + '.png';
            ///console.info(s_filename);

            var aux = '<object type="application/x-shockwave-flash" data="' + dzsap_settings.thepath + 'wavegenerator.swf" width="230" height="30" id="flashcontent" style="visibility: visible;"><param name="movie" value="' + dzsap_settings.thepath + 'wavegenerator.swf"><param name="menu" value="false"><param name="allowScriptAccess" value="always"><param name="scale" value="noscale"><param name="allowFullScreen" value="true"><param name="wmode" value="opaque"><param name="flashvars" value="settings_multiplier=' + dzsap_settings.waveformgenerator_multiplier + '&media=' + _themedia + '&savetophp_loc=' + dzsap_settings.thepath + 'savepng.php&savetophp_pngloc=' + window.waves_filename + '&savetophp_pngprogloc=' + window.waves_filename + '&color_wavesbg=' + dzsap_settings.color_waveformprog + '&color_wavesprog=' + dzsap_settings.color_waveformprog + '&settings_wavestyle=' + dzsap_settings.settings_wavestyle + '&settings_onlyautowaveprog=on&settings_enablejscallback=on';



            if (dzsap_settings.waves_generation == 'auto') {
                aux += '&settings_autogenerate_prog=on';
            }


            aux += '"></object>';

            _t.parent().append(aux);




            if (_t.parent().prev().hasClass('upload-prev')) {
                window.waves_fieldtaget = _t.parent().prev();
            } else {
                window.waves_fieldtaget = _t.parent().prev().prev();
            }


            _t.hide();
        }


        return false;
    }



    window.dzsapp_add_to_cart = function (arg) {
        //console.log(_con.attr('data-playerid'));



        var data = {
            action: 'ajax_add_to_cart'
            , prod_id: arg
        };


        $.ajax({
            type: "POST",
            url: dzsap_settings.settings_ajax_handler,
            data: data,
            success: function (response) {
                if (typeof window.console != "undefined") {
                    console.log('Got this from the server: ' + response);
                }


                load_cart();

                //console.info($('.menu-right-block-cart'));
                _cart_contents.addClass('active');

                setTimeout(function () {

                    _cart_contents.removeClass('active');
                }, 500);




                $('.mcon-mainmenu').prepend('<div class="purchase-confirmation-clip"></div>');

                var _pcc = $('.mcon-mainmenu').eq(0).children('.purchase-confirmation-clip');

                _pcc.append(response);

                setTimeout(function () {
                    _pcc.addClass('active');
                }, 50);

                _pcc.css('height', '0');
                _pcc.css('opacity', '0');
                _pcc.animate({
                    height: _pcc.children('.purchase-confirmation').eq(0).height()
                    , opacity: 1
                }, {
                    queue: false
                    , duration: 300
                });
                setTimeout(function () {

                    _pcc.animate({
                        height: 0
                        , opacity: 0
                    }, {
                        queue: false
                        , duration: 300
                    });
                    _pcc.removeClass('active');
                }, 2000);
                setTimeout(function () {

                    _pcc.remove();
                }, 3000);
            },
            error: function (arg) {
                if (typeof window.console != "undefined") {
                    console.log('Got this from the server: ' + arg, arg);
                }
                ;

            }
        });
    }
});



window.waves_fieldtaget = null;
window.waves_filename = null;


window.api_wavesentfromflash = function (arg) {
    console.info('api_wavesentfromflash', arg);


    if (window.waves_fieldtaget) {
        window.waves_filename = window.waves_filename.replace('{{dirname}}', dzsap_settings.thepath);
        window.waves_fieldtaget.val(window.waves_filename);
        window.waves_fieldtaget.trigger('change');
        if (window.waves_fieldtaget.next().hasClass('aux-wave-generator')) {

            window.waves_fieldtaget.next().find('button').show();
            window.waves_fieldtaget.next().find('object').remove();
        } else {

            window.waves_fieldtaget.next().next().find('button').show();
            window.waves_fieldtaget.next().next().find('object').remove();
        }
    }
    if (window.console) {
        console.info(arg);
    }
    ;


    if (window.wave_prog_generated === false) {

        window.wave_prog_generated = true;
        $('.btn-autogenerate-waveform-prog').trigger('click');
    } else {
        $('.upload-track-btn').removeClass('disabled');

        if ($('.upload-track-btn').prev().hasClass('dzstooltip')) {
            $('.upload-track-btn').prev().remove();
        }
        // $('.upload-track-btn').prev().removeClass('active');
    }
};


function can_history_api() {
    return !!(window.history && history.pushState);
}

function is_android() {
    //return true;
    var ua = navigator.userAgent.toLowerCase();
    return (ua.indexOf("android") > -1);
}

function selectText(arg) {
    if (document.selection) {
        var range = document.body.createTextRange();
        range.moveToElementText(arg);
        range.select();
    } else if (window.getSelection) {
        var range = document.createRange();
        range.selectNode(arg);
        window.getSelection().addRange(range);
    }
}

window.dzsapp_open_social_link = function (arg) {
    var leftPosition, topPosition;
    var w = 500, h = 500;
    //Allow for borders.
    leftPosition = (window.screen.width / 2) - ((w / 2) + 10);
    //Allow for title and status bars.
    topPosition = (window.screen.height / 2) - ((h / 2) + 50);
    var windowFeatures = "status=no,height=" + h + ",width=" + w + ",resizable=yes,left=" + leftPosition + ",top=" + topPosition + ",screenX=" + leftPosition + ",screenY=" + topPosition + ",toolbar=no,menubar=no,scrollbars=no,location=no,directories=no";
    window.open(arg, "sharer", windowFeatures);
}

//console.info(php_serialize([1,2,3]));

function php_serialize (mixedValue) {
    //  discuss at: http://locutus.io/php/serialize/
    // original by: Arpad Ray (mailto:arpad@php.net)
    // improved by: Dino
    // improved by: Le Torbi (http://www.letorbi.de/)
    // improved by: Kevin van Zonneveld (http://kvz.io/)
    // bugfixed by: Andrej Pavlovic
    // bugfixed by: Garagoth
    // bugfixed by: Russell Walker (http://www.nbill.co.uk/)
    // bugfixed by: Jamie Beck (http://www.terabit.ca/)
    // bugfixed by: Kevin van Zonneveld (http://kvz.io/)
    // bugfixed by: Ben (http://benblume.co.uk/)
    // bugfixed by: Codestar (http://codestarlive.com/)
    //    input by: DtTvB (http://dt.in.th/2008-09-16.string-length-in-bytes.html)
    //    input by: Martin (http://www.erlenwiese.de/)
    //      note 1: We feel the main purpose of this function should be to ease
    //      note 1: the transport of data between php & js
    //      note 1: Aiming for PHP-compatibility, we have to translate objects to arrays
    //   example 1: serialize(['Kevin', 'van', 'Zonneveld'])
    //   returns 1: 'a:3:{i:0;s:5:"Kevin";i:1;s:3:"van";i:2;s:9:"Zonneveld";}'
    //   example 2: serialize({firstName: 'Kevin', midName: 'van'})
    //   returns 2: 'a:2:{s:9:"firstName";s:5:"Kevin";s:7:"midName";s:3:"van";}'

    var val, key, okey
    var ktype = ''
    var vals = ''
    var count = 0

    var _utf8Size = function (str) {
        var size = 0
        var i = 0
        var l = str.length
        var code = ''
        for (i = 0; i < l; i++) {
            code = str.charCodeAt(i)
            if (code < 0x0080) {
                size += 1
            } else if (code < 0x0800) {
                size += 2
            } else {
                size += 3
            }
        }
        return size
    }

    var _getType = function (inp) {
        var match
        var key
        var cons
        var types
        var type = typeof inp

        if (type === 'object' && !inp) {
            return 'null'
        }

        if (type === 'object') {
            if (!inp.constructor) {
                return 'object'
            }
            cons = inp.constructor.toString()
            match = cons.match(/(\w+)\(/)
            if (match) {
                cons = match[1].toLowerCase()
            }
            types = ['boolean', 'number', 'string', 'array']
            for (key in types) {
                if (cons === types[key]) {
                    type = types[key]
                    break
                }
            }
        }
        return type
    }

    var type = _getType(mixedValue)

    switch (type) {
        case 'function':
            val = ''
            break
        case 'boolean':
            val = 'b:' + (mixedValue ? '1' : '0')
            break
        case 'number':
            val = (Math.round(mixedValue) === mixedValue ? 'i' : 'd') + ':' + mixedValue
            break
        case 'string':
            val = 's:' + _utf8Size(mixedValue) + ':"' + mixedValue + '"'
            break
        case 'array':
        case 'object':
            val = 'a'
            /*
             if (type === 'object') {
             var objname = mixedValue.constructor.toString().match(/(\w+)\(\)/);
             if (objname === undefined) {
             return;
             }
             objname[1] = php_serialize(objname[1]);
             val = 'O' + objname[1].substring(1, objname[1].length - 1);
             }
             */

            for (key in mixedValue) {
                if (mixedValue.hasOwnProperty(key)) {
                    ktype = _getType(mixedValue[key])
                    if (ktype === 'function') {
                        continue
                    }

                    okey = (key.match(/^[0-9]+$/) ? parseInt(key, 10) : key)
                    vals += php_serialize(okey) + php_serialize(mixedValue[key])
                    count++
                }
            }
            val += ':' + count + ':{' + vals + '}'
            break
        case 'undefined':
        default:
            // Fall-through
            // if the JS object has a property which contains a null value,
            // the string cannot be unserialized by PHP
            val = 'N'
            break
    }
    if (type !== 'object' && type !== 'array') {
        val += ';'
    }

    return val
}









/**
 * Tagify - jQuery tags input plugin
 * By Yair Even-Or (2016)
 * MIT License

 Copyright (c) 2017 Yair Even-Or

 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all
 copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE

 */
function Tagify( input, settings ){
    // protection
    if( !input ){
        console.warn('Tagify: ', 'invalid input element ', input)
        return this;
    }

    settings = typeof settings == 'object' ? settings : {}; // make sure settings is an 'object'

    this.settings = {
        duplicates      : settings.duplicates || false, // flag - allow tuplicate tags
        enforeWhitelist : settings.enforeWhitelist || false, // flag - should ONLY use tags allowed in whitelist
        maxtags : settings.maxtags || 15, // flag - should ONLY use tags allowed in whitelist
        autocomplete    : settings.autocomplete || true, // flag - show native suggeestions list as you type
        whitelist       : settings.whitelist || [], // is this list has any items, then only allow tags from this list
        blacklist       : settings.blacklist || [] // a list of non-allowed tags
    };

    this.id = Math.random().toString(36).substr(2,9), // almost-random ID (because, fuck it)
        this.value = []; // An array holding all the (currently used) tags
    this.DOM = {}; // Store all relevant DOM elements in an Object
    this.build(input);
    this.events();
}

Tagify.prototype = {
    build : function( input ){
        var that = this,
            value = input.value;

        this.DOM.originalInput = input;
        this.DOM.scope = document.createElement('tags');
        this.DOM.scope.innerHTML = '<div class="tag-suggestions-div dzstooltip-con for-hover"><input list="tagsSuggestions'+ this.id +'" class="tags-suggestion-input placeholder" placeholder="'+ input.placeholder +'"/><span></span></div>';

        this.DOM.input = this.DOM.scope.querySelector('input');
        input.parentNode.insertBefore(this.DOM.scope, input);
        this.DOM.scope.appendChild(input);

        // if "autocomplete" flag on toggeled & "whitelist" has items, build suggestions list
        if( this.settings.autocomplete && this.settings.whitelist.length )
            this.buildDataList();

        // if the original input already had any value (tags)
        if( value )
            this.addTag(value).forEach(function(tag){
                tag && tag.classList.add('tagify--noAnim');
            });

        if(window.jQuery){
            var _t = jQuery(input);

            that.DOM._tooltip = _t.parent().find('.dzstooltip').eq(0);
            that.DOM._tagsSuggestionInput = _t.parent().find('.tags-suggestion-input').eq(0);

            //console.info(_t.parent(), _t.parent().find('.dzstooltip').eq(0), that.DOM.tooltip);
            //console.info(_t);
            _t.addClass('taggified');

            _t.prev().on('click','.tag-options > li', function(){
                var _t2 = (jQuery(this));

                console.info(that, that.addTag);

                if(that && that.addTag){
                    that.addTag(jQuery(this).text());
                }

                _t2.parent().parent().removeClass('active');


                //jQuery(this).fadeOut('slow');
            })
        }
    },

    /**
     * DOM events binding
     */
    events : function(){
        var events = {
            //  event name / event callback / element to be listening to
            focus   : ['onFocusBlur'  , 'input'],
            blur    : ['onFocusBlur'  , 'input'],
            input   : ['onInput'      , 'input'],
            keydown : ['onKeydown'    , 'input'],
            click   : ['onClickScope' , 'scope']
        };

        for( var e in events )
            this.DOM[events[e][1]].addEventListener(e, this.callbacks[events[e][0]].bind(this));
    },

    /**
     * DOM events callbacks
     */
    callbacks : {
        onFocusBlur : function(e){
            var text =  e.target.value.trim();

            if( e.type == "focus" )
                e.target.className = 'input';
            else if( e.type == "blur" && text == "" ){
                e.target.className = 'input placeholder';
                this.DOM.input.removeAttribute('style');
            }
        },

        onKeydown : function(e){
            var s = e.target.value;
            if( e.key == "Backspace" && (s == "" || s.charCodeAt(0) == 8203) ){
                this.removeTag( this.DOM.scope.querySelectorAll('tag:not(.tagify--hide)').length - 1 );
            }
            if( e.key == "Escape" ){
                e.target.value = '';
                e.target.blur();
            }
            if( e.key == "Enter" ){
                e.preventDefault(); // solves Chrome bug - http://stackoverflow.com/a/20398191/104380
                if( this.addTag(s) )
                    e.target.value = '';
                return false;
            }

            var sugginput = e.target.value;

            console.info(sugginput);

            if(this.DOM._tooltip){
                this.DOM._tooltip.find('li').each(function(){
                    var _t4 = jQuery(this);


                    if(String(_t4.text()).toLowerCase().indexOf(String(sugginput).toLowerCase())>-1){
                        _t4.show()
                    }else{

                        _t4.hide()
                    }
                })
                this.DOM._tooltip.addClass('active');
            }
        },

        onInput : function(e){
            var value = e.target.value,
                lastChar = value[value.length - 1];

            e.target.style.width = ((e.target.value.length + 1) * 7) + 'px';

            if( value.indexOf(',') != -1 ){
                this.addTag( value );
                e.target.value = ''; // clear the input field's value
            }
        },

        onClickScope : function(e){


            console.info('click');
            if( e.target.tagName == "TAGS" ) {
                this.DOM.input.focus();

                console.info(this.DOM.input);

                this.DOM._tooltip.addClass('active');
                var that = this;
                setTimeout(function(){

                    that.DOM._tooltip.removeClass('active');
                },5000)
            }
            if( e.target.tagName == "X" ){
                this.removeTag( this.getNodeIndex(e.target.parentNode) );
            }
        }
    },

    /**
     * Build tags suggestions using HTML datalist
     * @return {[type]} [description]
     */
    buildDataList : function(){
        var OPTIONS = "",
            i,
            datalist = '<div class="dzstooltip arrow-top align-left style-black " style="width: 300px;"><ul class="tag-options">[OPTIONS]</ul>';

        for( i=this.settings.whitelist.length; i--; )
            OPTIONS += "<li>"+ this.settings.whitelist[i] +"</li>";

        datalist = datalist.replace('[OPTIONS]', OPTIONS); // inject the options string in the right place
        this.DOM.input.insertAdjacentHTML('afterend', datalist); // append the datalist HTML string in the Tags

        return datalist;
    },

    getNodeIndex : function( node ){
        var index = 0;
        while( (node = node.previousSibling) )
            if (node.nodeType != 3 || !/^\s*$/.test(node.data))
                index++;
        return index;
    },

    markTagByValue : function(value){
        var tagIdx = this.value.findIndex(function(item){ return value.toLowerCase() === item.toLowerCase() }),
            tag = this.DOM.scope.querySelectorAll('tag')[tagIdx];

        if( tag ){
            tag.classList.add('tagify--mark');
            setTimeout(function(){ tag.classList.remove('tagify--mark') }, 2000);
            return true;
        }
        return false;
    },

    /**
     * make sure the tag, or words in it, is not in the blacklist
     */
    isTagBlacklisted : function(v){
        v = v.split(' ');
        return this.settings.blacklist.filter(function(x){ return v.indexOf(x) != -1 }).length;
    },

    /**
     * make sure the tag, or words in it, is not in the blacklist
     */
    isTagWhitelisted : function(v){
        return this.settings.whitelist.indexOf(v) != -1;
    },

    addTag : function( value ){
        var that = this;

        this.DOM.input.removeAttribute('style');

        value = value.trim()+'';
        if( !value ) return;

        return value.split(',').filter(function(v){ return !!v }).map(function(v){
            var tagElm = document.createElement('tag');
            v = v.trim();

            if( !that.settings.duplicates && that.markTagByValue(v) ) {
                return false;
            }

            // check against blacklist & whitelist (if enforced)

            //console.info();

            var inputvalue = that.DOM.originalInput.value;

            var tags = inputvalue.split(',');
            var nroftags = tags.length;

            console.info('inputvalue - ',inputvalue);
            console.info('value - ',value);

            if( that.isTagBlacklisted(v) || (that.settings.enforeWhitelist && !that.isTagWhitelisted(v)) || nroftags > that.settings.maxtags || (!that.settings.duplicated && inputvalue.indexOf(value)>-1) ){
                tagElm.classList.add('tagify--notAllowed');
                setTimeout(function(){ that.removeTag(that.getNodeIndex(tagElm)) }, 1000);
            }

            // the space below is important - http://stackoverflow.com/a/19668740/104380
            tagElm.innerHTML = "<x></x><div><span title='"+ v +"'>"+ v +" </span></div>";
            that.DOM.scope.insertBefore(tagElm, that.DOM.input.parentNode);

            that.value.push(v);
            that.update();
            return tagElm;
        });
    },

    removeTag : function( idx ){
        var tagElm = this.DOM.scope.children[idx];
        if( !tagElm) return;

        tagElm.style.width = parseFloat(window.getComputedStyle(tagElm).width) + 'px';
        document.body.clientTop; // force repaint for the width to take affect before the "hide" class below
        tagElm.classList.add('tagify--hide');

        // manual timeout (hack, since transitionend cannot be used because of hover)
        setTimeout(function(){
            tagElm.parentNode.removeChild(tagElm);
        }, 400);

        this.value.splice(idx, 1);
        this.update();


        console.info('this delete - ',this);
    },

    // update the origianl (hidden) input field's value
    update : function(){
        this.DOM.originalInput.value = this.value.join(', ');
    }
}

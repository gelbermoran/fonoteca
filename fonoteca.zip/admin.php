<?php
define("DZSPGB_IS_ADMIN", "on");


date_default_timezone_set('America/Los_Angeles');
ini_set("log_errors", 1);
ini_set('display_errors', '0');
error_reporting(E_ALL);
ini_set("error_log", "soundportal.log");

if(!session_id()) {
    session_start();
}


include_once(dirname(__FILE__).'/dzs_functions.php');
include_once(dirname(__FILE__).'/class-portal.php');
include_once(dirname(__FILE__).'/pagebuilder/class-dzspgb.php');


$lang = 'en_EN';
$charset = 'utf-8';
$lang_index = 0;
if (isset($_GET['lang'])){
    $lang = $_GET['lang'];

    setcookie('dzsapp_lang',$lang, time()+3600);
}else{


    if(isset($_COOKIE['dzsapp_lang']) && $_COOKIE['dzsapp_lang']){

        $lang = $_COOKIE['dzsapp_lang'];
    }
}

if($lang=='pt_PT'){
    $charset = 'iso-8859-1';
}


putenv("LANG=$lang");
setlocale(LC_ALL, $lang);
if(function_exists("bindtextdomain")){
    bindtextdomain("wavecloud", "./locale/");
}

if(function_exists("textdomain")) {
    textdomain("wavecloud");
}







if(function_exists("bindtextdomain")){
    bindtextdomain("wavecloud", "./locale/");
}

if(function_exists("textdomain")) {
    textdomain("wavecloud");
}


if(function_exists('__')==false){
    function __($arg='',$arg2=''){

        return _($arg);
    }
}



//if (!function_exists("gettext"))
//{
//    echo "gettext is not installed\n";
//}
//else
//{
//    echo "gettext is supported\n";
//}

//print_r(get_defined_constants(true));

//$primary_dir = 'elements';
//if ($handle = opendir($primary_dir)) {
//
//    while (false !== ($entry = readdir($handle))) {
//
//
//        if ($entry == '.' || $entry == '..' || $entry == '.DS_Store') {
//            continue;
//        }
//
//
//        $auxfile = $primary_dir . '/' . $entry;
////        print_r($auxfile);
////			error_log('ceva'.$auxfile.'alceva');
//
//        if (file_exists($auxfile)) {
//            include_once($auxfile);
//        }
//
//    }
//}



    $menu_items = array(
        array(
            'label'=>__("Edit Pages"),
//            'subpage'=>"home",
            'page'=>'pagebuilder',
        ),
        array(
            'label'=>__("Player Configs"),
            'page'=>'apconfigs',
        ),
        array(
            'label'=>__("Menus"),
            'page'=>"menus",
        ),
        array(
            'label'=>__("Blog"),
//            'subpage'=>"home",
            'page'=>'blogs',
        ),
        array(
            'label'=>__("Events"),
//            'subpage'=>"home",
            'page'=>'posts',
        ),
        array(
            'label'=>__("Users"),
            'page'=>"users",
        ),
        array(
            'label'=>__("Tracks"),
            'page'=>"tracks",
        ),
        array(
            'label'=>__("Purchases"),
            'page'=>"purchases",
        ),
        array(
            'label'=>__("Statistics"),
            'page'=>"statistics",
        ),
        array(
            'label'=>__("Reports"),
            'page'=>"reports",
        ),
//        array(
//            'label'=>__("Widget Stacks"),
//            'page'=>"widget_stacks",
//        ),
        array(
            'label'=>__("Edit Templates"),
            'page'=>"templates",
        ),
        array(
            'label'=>__("Plugins"),
            'page'=>"plugins",
        ),
        array(
            'label'=>__("Settings"),
            'page'=>"settings",
        ),
        array(
            'label'=>__("User Roles"),
            'page'=>"user_roles",
        ),
        array(
            'label'=>__("Import Data"),
            'page'=>"importdata",
        ),
    );

$dzsap_portal = new DZSAP_Portal();
$dzspgb_forportal = new DZS_PageBuilder();



//    print_r($interval);






if($lang!='en_EN'){
    for($i6 = 1; $i6<7; $i6++){

        $aux = $dzsap_portal->main_settings['lang_'.$i6.'_code'];
        if($aux==$lang){
            $lang_index = $i6;
            break;
        }
    }
}

$str_html_dir='';
$str_html_lang='';
if($lang_index){

    $aux = $dzsap_portal->main_settings['lang_'.$lang_index.'_is_rtl'];


    if($aux == 'on'){

        $str_html_dir = ' dir="rtl"';

    }

    $auxarr = explode('_', $lang);

    $str_html_lang = ' lang="'.$auxarr[0].'"';


}


if(strpos(dzs_curr_url(), 'admin.php')!==false){


    $curr_url = dzs_curr_url();

    $url_arr = explode('admin.php',$curr_url);

//    print_r($url_arr);

    if(isset($dzsap_portal->main_settings['url_base']) && $dzsap_portal->main_settings['url_base']){

    }else{

        $dzsap_portal->main_settings['url_base'] = $url_arr[0];
    }
}else{

}



$datenow = date("Y-m-d H:i:s");




$date_now = new DateTime($datenow);


$date_last_checked = new DateTime($dzsap_portal->get_setting('pro_accounts_last_checked')) ;

//    print_r($date_last_checked);

$interval = $date_now->diff($date_last_checked);

//    print_r($interval);

$dzsap_portal->check_disable_pro_accounts();
if($dzsap_portal->get_setting('pro_accounts_last_checked')==false || $interval->d>0){
    $dzsap_portal->check_disable_pro_accounts();
}

$result = $dzsap_portal->dblink->query('select * from `users`');

if($result !== FALSE){
    //DO SOMETHING! IT EXISTS!

    $row_cnt = $result->num_rows;

    if($result->num_rows==0){
        $val2 = $dzsap_portal->dblink->query("INSERT INTO `users` (`id`, `username`, `email`, `password`, `date`, `avatar`, `capabilities`, `purchases`, `connections`, `ip_registered_from`, `location`) VALUES
(1, '".$dzsap_portal->main_config_settings['admin_user']."', '".$dzsap_portal->main_config_settings['admin_email']."', '".$dzsap_portal->main_config_settings['admin_password']."', '2015-09-25', '', 'a:1:{i:0;s:5:\"admin\";}', '', '', '', '');
");

//Output any connection error
        if ($dzsap_portal->dblink->errno) {
            error_log('Error : '. $dzsap_portal->dblink->error);
        }
    }

}else{

}



//    echo 'isadmin';
//print_r($dzspgb_templates);
dzsap_load_plugins();

$dzsap_portal->do_action('after_load_plugins');
$dzsap_portal->check_post();


$page = $dzsap_portal->currPage;
$subpage = 'none';
    if(isset($_GET['subpage'])){
        $subpage=$_GET['subpage'];
    }
    
    

if(isset($_POST['action']) && $_POST['action']==='save_mainfield'){

//    print_r($_GET);

    if($_GET['subpage']==='home'){

        $dzsap_portal->update_setting('text_home', $_POST['postdata']);
    }
    if($_GET['subpage']==='upload'){

        $dzsap_portal->update_setting('pagebuilder_data_upload', $_POST['postdata']);
//        echo 'saved upload';
    }

    
    die();
}

if(isset($_GET['action']) && $_GET['action']==='print_templates'){


//    print_r($dzspgb_templates);


    $fout = '';

    header("Content-Type: text/javascript");

    $fout .= 'window.dzspgb_templates = {';


    $ij =0 ;

//    print_r($dzspgb_templates);
    foreach($dzspgb_templates as $temp){
        if($ij>0){
            $fout.=',';
        }

        $fout.= $temp['id'];

        $fout.=':';

        $fout.='"';


        $aux = call_user_func($temp['admin_str_function'],array('txt_choose'=>'Edit'));


        $lb = array("\r\n","\n","\r");
        $aux = str_replace($lb,'',$aux);

        $aux = str_replace('"',"'q'",$aux);

        $fout.=$aux;

        $fout.='"';

        $ij++;

    }

    $fout .= '}';


    echo $fout;


    die();
}


    if($page=='normal'){
        $page = 'pagebuilder';
    }



function generate_admin_header($pargs = array()){

    $margs = array(
        'title' => '',
        'page' => '',
        'subpage' => '',
        'aux_template_type' => '',
        'extra_html_before_title-header' => '',
    );

    if($pargs){
        $margs = array_merge($margs,$pargs);
    }


    $aux = '<div class="admin-header-wrap">
            <div class="dzspb_lay_con">
                <div class="dzspb_layb_one_full">
'.$margs['extra_html_before_title-header'].'
                    <h2 class="title-header"><span class="the-actual-title">'.$margs['title'].'</span><a class="view-frontend" href="index.php">View Frontend</a>';


    if($margs['page']=='templates'){


//                echo '<div class="dzspgb-meta-con"><span class="dzspgb-page-name">Name: <strong>Home</strong> /</span> <span class="dzspgb-template-con  dzstooltip-con js">  Template Options <i class="fa fa-cubes" style="opacity:0.5"></i> <span class="dzstooltip arrow-top align-left skin-black " style="padding-bottom:10px; ">'.$aux_template_type.'</span></span><span class="dzspgb-logo"></span></div>';

        if($margs['subpage']){
            $aux.='<span class="view-frontend dzspgb-template-con  dzstooltip-con js" href=""><i class="fa fa-gear"></i>&nbsp;&nbsp;'.__("Template Settings").'<span class="dzstooltip arrow-top align-right skin-black " style="padding-bottom:10px; width: auto; white-space: nowrap; ">'.$margs['aux_template_type'].'</span></span></span>';
        }
    }
    if($margs['page']=='pagebuilder'){


//                echo '<div class="dzspgb-meta-con"><span class="dzspgb-page-name">Name: <strong>Home</strong> /</span> <span class="dzspgb-template-con  dzstooltip-con js">  Template Options <i class="fa fa-cubes" style="opacity:0.5"></i> <span class="dzstooltip arrow-top align-left skin-black " style="padding-bottom:10px; ">'.$aux_template_type.'</span></span><span class="dzspgb-logo"></span></div>';

        if($margs['subpage']){
            $aux.='<div class="view-frontend dzspgb-template-con  dzstooltip-con js  2"  href=""><i class="fa fa-gear"></i>&nbsp;&nbsp;'.__("Template Settings").'<div class="dzstooltip arrow-top align-right skin-black  " style="padding-bottom:10px; width: auto; white-space: nowrap; ">'.$margs['aux_template_type'].'</div></div>';
        }
    }

    $aux.='</h2>
                </div>
            </div>
        </div>';



    return $aux;



}


//print_r($dzsap_portal);
?><!doctype html>
<html <?php echo $str_html_dir; echo $str_html_lang;?>>
    <head>
        <meta charset="utf-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <meta http-equiv="X-UA-COMPATIBLE" content="IE=EDGE">
        <title>ZoomPortal Admin - <?php echo $page; ?></title>
        <script src="js/jquery.js"></script>
        <link href="./libs/bootstrap/bootstrap.css" rel="stylesheet">
        <link href="./libs/bootstrap/bootstrap-responsive.css" rel="stylesheet">
        <link rel='stylesheet' type="text/css" href="style/style.css"/>
        <link rel='stylesheet' type="text/css" href="admin/admin.css"/>
        <link rel='stylesheet' type="text/css" href="libs/audioplayer/audioplayer.css"/>
        <link rel='stylesheet' type="text/css" href="libs/dzstooltip/dzstooltip.css"/>
        <script src="libs/dzstooltip/dzstooltip.js" type="text/javascript"></script>

        <link rel='stylesheet' type="text/css" href="libs/dzstabsandaccordions/dzstabsandaccordions.css"/>
        <script src="libs/dzstabsandaccordions/dzstabsandaccordions.js" type="text/javascript"></script>

        <link rel='stylesheet' type="text/css" href="./libs/advancedscroller/plugin.css"/>
        <script src="libs/advancedscroller/plugin.js" type="text/javascript"></script>
        <script src="admin.php?action=print_templates" type="text/javascript"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

        <?php
        if($dzsap_portal->main_settings['google_fonts_enable']=='on'){
        ?>
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:300,300italic,400,500,600,700' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Lato:100,400,700,900' rel='stylesheet' type='text/css'>
        <?php
        }

        ?>
        <link rel='stylesheet' type="text/css" href="libs/dzsselector/dzsselector.css"/>


        <?php
        if ($page == 'statistics') {
            ?>
            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
            <?php
        }
        ?>

        <?php
        if ($page == 'upload' || $page == 'usersettings' || isset($_GET['media'])) {
            ?>
            <link rel="stylesheet" href="libs/dzstabsandaccordions/dzstabsandaccordions.css">
            <script src="libs/dzstabsandaccordions/dzstabsandaccordions.js" type="text/javascript"></script>
            <link rel="stylesheet" href="libs/dzsuploader/upload.css">
            <script src="libs/dzsuploader/upload.js" type="text/javascript"></script>
        <?php } ?>
        <?php
        if($page==='pagebuilder' || $page==='templates' || $page==='menus' || $page==='apconfigs'){

            $struct_dzspgb_section = str_replace(array("\r","\r\n","\n"),'',$dzspgb_forportal->generate_admin_section_part1(array()).$dzspgb_forportal->generate_admin_section_part2(array()));

            $args = array();

            if($page==='templates'){

                $args = array(
                    'admin_args' => array(
                        'this_is_template_admin'=>true
                    ),
                );
            }

            $struct_dzspgb_container = str_replace(array("\r","\r\n","\n"),'',$dzspgb_forportal->generate_admin_container_part1($args).$dzspgb_forportal->generate_admin_container_part2($args));

            $struct_dzspgb_row = str_replace(array("\r","\r\n","\n"),'',$dzspgb_forportal->generate_admin_row_part1(array()).$dzspgb_forportal->generate_admin_row_part2(array()));

            $struct_dzspgb_row_empty = str_replace(array("\r","\r\n","\n"),'',$dzspgb_forportal->generate_admin_row_part1(array('empty' => false )).$dzspgb_forportal->generate_admin_row_part2(array()));
            $struct_dzspgb_row_part = str_replace(array("\r","\r\n","\n"),'',$dzspgb_forportal->generate_admin_row_part_part1(array()).$dzspgb_forportal->generate_admin_row_part_part2(array()));
            $struct_dzspgb_row_part_nonactive = str_replace(array("\r","\r\n","\n"),'',$dzspgb_forportal->generate_admin_row_part_part1(array('part'=>'nonactive')).$dzspgb_forportal->generate_admin_row_part_part2(array('part'=>'nonactive')));

?>
            <!-- butz why -->
            <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
            <script src="jqueryui/jquery-ui.min.js" type="text/javascript"></script>
            <script src="pagebuilder/pagebuilder.js" type="text/javascript"></script>
            <link rel="stylesheet" href="pagebuilder/pagebuilder.css">
            <script src="libs/ultibox/ultibox.js" type="text/javascript"></script>
            <link rel="stylesheet" href="libs/ultibox/ultibox.css">
            <script type="text/javascript" src="tinymce/jquery.tinymce.min.js"></script>

            <script>
                var dzspgb_settings={
                    is_admin: 'on'
                    <?php


        if($page==='pagebuilder' || $page==='templates'){
                    ?>
                    ,struct_section: '<?php echo $struct_dzspgb_section; ?>'
                    , struct_container: '<?php echo $struct_dzspgb_container; ?>'
                    , struct_row: '<?php echo $struct_dzspgb_row; ?>' // -- this is from appending PLUS
                    , struct_row_empty: '<?php echo $struct_dzspgb_row_empty; ?>' // -- this is for appending from the form
                    , struct_row_part: '<?php echo $struct_dzspgb_row_part; ?>'
                    , struct_row_part_nonactive: '<?php echo $struct_dzspgb_row_part_nonactive; ?>'

                    <?php
                    }

    if($page==='pagebuilder'||$page==='menus'||$page==='apconfigs' ){



        if(($subpage!='none')){
echo ',page_id:"'.$subpage.'"';
        }
        }
                    ?>
                }
            </script>
        <?php
        }
        if($page==='posts'||$page==='users'||$page==='blogs'){

            ?>

            <script type="text/javascript" src="tinymce/jquery.tinymce.min.js"></script>
            <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
            <script src="jqueryui/jquery-ui.min.js" type="text/javascript"></script>

        <?php
        }



        ?>
        <script>
            var dzsap_settings = {
                thepath: "<?php echo $dzsap_portal->url_base; ?>"
                ,page: "<?php echo $page; ?>"
                , waveformgenerator_multiplier: "1"
                , color_waveformbg: "<?php echo substr($dzsap_portal->main_settings['color_waveformbg'], 1); ?>"
                , color_waveformprog: "<?php echo substr($dzsap_portal->main_settings['color_waveformprog'], 1); ?>"
                , settings_wavestyle: "reflect"<?php
//                echo ',settings_php_handler: "publisher.php"'; // -- why ?
                echo ',settings_ajax_handler: "admin.php"';
                if(isset($_GET['media'])){
                    echo ',mediaid:"'.$_GET['media'].'"';
                }
            ?>};</script>
        <?php

        $dzsap_portal->do_action('admin_before_head_end');
        ?>
    </head>
    <body class="is-admin page-<?php echo $page; ?>">
    <?php

    $cu = $dzsap_portal->get_user($dzsap_portal->currUserId);

//    print_r($cu); echo $dzsap_portal->currUserId;
    $caps = unserialize($cu['capabilities']);

    if($caps==false || is_array($caps)==false){
        $caps = array();
    }


//    print_r($caps);
    if(in_array("admin", $caps)==false && $cu['role']!='admin'){
        echo '<br>';

        $urs = $dzsap_portal->get_users();

        $sw = false;

        foreach ($urs as $us){
            $caps2 = unserialize($us['capabilities']);




            if(is_array($caps2)){

//                print_r($caps2);

                if(in_array("admin", $caps2)){
                    $sw = true;



                    if($us['role']==''){
                        $us['role']='admin';



                        $dzsap_portal->mysql_update_user_settings($us['id'],array(
                            'role'=>'admin'
                        ));

                    }
                }else{

                    if($us['role']=='') {
                        $us['role'] = 'user';
                        $dzsap_portal->mysql_update_user_settings($us['id'],array(
                            'role'=>'user'
                        ));
                    }
                }
            }
        }


        echo '
                    <form class="login-form login-form-from-main-admin" method="POST">
        '.__("you need admin access to access this page").'<br><br>
        ';

        if($sw===false){
            echo ' <p>'.__("No admin account found on the server. A admin account with the credentials U: <strong>temp_admin@gmail.com</strong> P: <strong>temp_admin</strong> has been created. ").'</p>';

//            echo 'ceva';
            $aux = $dzsap_portal->mysql_create_user('temp_admin@gmail.com', 'temp_admin', array(
                'username'=>'temp_admin',
                'capabilities'=>'a:1:{i:0;s:5:"admin";}',
            ));

            if($aux===true){
                echo '<p>'.__("User created").'</p>';
            }else{

                echo ' error - '.$aux;
            }
        }

        echo '
                        <input type="hidden" name="action" value="login"/>
                        <h5 class="input-label">Email</h5>
                        <input type="email" class="fullwidth simple-input-field" name="email"/>
                        <h5 class="input-label">Password</h5>
                        <input type="password" class="fullwidth simple-input-field" name="pass"/>
                        <br>
                        <br>
                        <div style="float:left;">
                        <button class="button-primary register-btn">Login</button>
                        </div>
                        <div style="float:right;">
                        or <a href="index.php?page=register">Create New Account</a>
                        </div>
                        <div class="clear"></div>
                    </form>';

        echo '</body></html>';
        die();
    }


    ?>
    <div class="dzsap-portal-nav-con">

        <ul class="the-nav">
            <?php

            foreach($menu_items as $menu_item){

//                echo $subpage.' '.$menu_item['subpage'];
                echo '<li class="nav-item';

                if(isset( $menu_item['page']) && $page == $menu_item['page']){
                    echo ' active';
                }

                if(isset($menu_item['page'])){
                    echo ' nav-item-for-page-'.$menu_item['page'];
                }

                $icon = 'fa-book';

                if(isset($menu_item['page'])){
                    if($menu_item['page']=='apconfigs'){
                        $icon = 'fa-file-audio-o';
                    }
                    if($menu_item['page']=='menus'){
                        $icon = 'fa-bars';
                    }
                    if($menu_item['page']=='templates'){
                        $icon = 'fa-print';
                    }
                    if($menu_item['page']=='settings'){
                        $icon = 'fa-gear';
                    }
                    if($menu_item['page']=='plugins'){
                        $icon = 'fa-plug';
                    }
                    if($menu_item['page']=='tracks'){
                        $icon = 'fa-music';
                    }
                    if($menu_item['page']=='blogs'){
                        $icon = 'fa-newspaper-o';
                    }
                    if($menu_item['page']=='statistics'){
                        $icon = 'fa-dashboard';
                    }
                    if($menu_item['page']=='reports'){
                        $icon = 'fa-copyright';
                    }
                    if($menu_item['page']=='importdata'){
                        $icon = 'fa-download';
                    }
                    if($menu_item['page']=='users'){
                        $icon = 'fa-user';
                    }
                    if($menu_item['page']=='purchases'){
                        $icon = 'fa-money';
                    }
                    if($menu_item['page']=='user_roles'){
                        $icon = 'fa-users';
                    }
                }

                echo '">
<a href="admin.php?zoomit=1';

            if(isset($menu_item['page']) && $menu_item['page']){
                echo '&page='.$menu_item['page'];
            }
            if(isset($menu_item['subpage']) && $menu_item['subpage']){
                echo '&subpage='.$menu_item['subpage'];
            }

            echo '"><i class="fa '.$icon.'"></i><span class="item-name">'.$menu_item['label'].'</span></a>
</li>';
            }
            ?>

        </ul>
    </div>
    <div class="dzsap-portal-nav-con-placeholder">
        </div>
    <?php

    $mode_pb = 'Full';
    if($page==='pagebuilder' ){



        if(($subpage!='none')){

            $permalink = '';

//            include_once(dirname(__FILE__).'/pagebuilder/class-dzspgb.php');


            $page_data = $dzspgb_forportal->select_page($subpage);

//            print_r($page);
            $data = $page_data['content'];

            echo '<div class="dzspgb-builder--wrap admin-wrap">';

            $aux_template_type='';




            $mode = 'Full';

            $use_template = $dzsap_portal->get_page_meta($subpage,'use_template');



            if($use_template && $use_template!='none'){
                $mode="Row";
            };


            $arr_opts = array(
                0=>array('lab'=> 'No template', 'val'=>'none'),
            );

            $auxa = $dzspgb_forportal->select_templates_array();

//        print_r($auxa);

//            print_r($auxa);
//        $struct_item.= '<div class="dzspb_layb_layout">';
            foreach($auxa as $template){
                $auxb = array();
                parse_str($template['template_data'], $auxb);
//            print_r($auxb);

                if(isset($auxb['dzspgb']['type']) && $auxb['dzspgb']['type']!=='Row'){

                    array_push($arr_opts, array('lab'=> $template['template_name'], 'val'=>$template['id']));
                }

            }

//            print_r($arr_opts);

//            $nam = 'ceva';

            $nam = 'use_template';

//            echo $use_template;



            $aux_template_type .= '<div class="setting"><div class="setting-label">'.__('Use Template').'</div><div style="display: block; width:300px;">'.DZSHelpers::generate_select($nam, array('class'=>'dzs-style-me skin-beige ', 'options'=>$arr_opts, 'seekval'=>$use_template)).'</div></div>';
            $aux_template_type .= '<div class="edit-template-type-con setting"><div class="setting-label">'.__('Template Type').'</div><a href="">'.__('Full').'</a><a href="">'.__('Row').'</a></div>';
            $aux_templates = '<div class="select-template-con setting">No templates saved.</div>';



            $aux_template_type .= '<div class="setting"><button class="button button--secondary btn-show-classic-editor"><span class="button-label">'.__("Show Classic Editor").'</span></button></div>';


            $subpage=$_GET['subpage'];
            $pagetitle = __('Pages');


            echo generate_admin_header(array(

                'title'=> $pagetitle,
                'page'=>$page,
                'subpage'=>$subpage,
                'aux_template_type'=>$aux_template_type
            ));


            $ind_sect = 0;


            ?><div class="dzspb_lay_con">
                <div class="dzspb_layb_one_full">
                    <div class="admin-breadcrumps">
                        <a href="admin.php"><i class="fa fa-home"></i>&nbsp;&nbsp;<?php echo __('Home'); ?></a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;<a href="admin.php?page=templates">Pages</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;<span class="current-page" ><?php echo $page_data['title']; ?></span>
                    </div>
                </div>
            </div><?php




//            echo '<div class="dzspgb-meta-con"><span class="dzspgb-page-name">Name: <strong>Home</strong> /</span> <span class="dzspgb-template-con  dzstooltip-con js">  Template Options <i class="fa fa-cubes" style="opacity:0.5"></i> <span class="dzstooltip arrow-top align-left skin-black " style="padding-bottom:10px; ">'.$aux_template_type.$aux_templates.'<span class="create-new-template-con setting"><span class="setting-label">Create new Template</span><span style="position:relative;"><input class="translucent-field" name="template_name"/><i style="position:absolute;font-size: 23px; right: 9px;top: -1px;" class="fa fa-caret-right button-save-template"></i></span></span></span></span><span class="dzspgb-logo"></span></div>';

//        echo '<i class="fa fa-plus-square"></i>';


//            $data = $dzsap_portal->get_setting('text_home');




            if($subpage==='upload'){

//                $data = $dzsap_portal->get_setting('pagebuilder_data_upload');
            }


//            echo 'seekval - '.$use_template;

            echo '<input type="hidden" name="type" value="page"/>';


            $real_link = $dzsap_portal->get_permalink($subpage, array(
                'type'=>'page'
            ));


//            echo 'real link - '.$real_link;

            echo '<div class="edit-slug-box"><strong>'.__("Permalink").':</strong> <a class="the-link" href="'.$real_link.'">'.$dzsap_portal->optional_url_base;





            if($dzsap_portal->main_settings['use_pretty_links']=='on'){

                $permalink = $dzsap_portal->get_permalink($subpage, array(
                    'only_from_table'=>true,
                    'type'=>'page',
                ));

//                echo 'hmm permalink - '.$permalink;

                echo '</a>'.' <input class="ajax-link-changer" type="text" value="';


                if($permalink){
                    echo $permalink;
                }


    echo '"/> <i class="ajax-permalink-preloader fa fa-spin fa-circle-o-notch" aria-hidden="true"';


                if($permalink){
                    echo ' style="display:none;"';
                }

                echo '></i>';

//                echo $permalink;
            }else{
                echo 'index.php?page=page&page_id='.$subpage.'</a>';
            }


            echo '</div>';



            echo '<textarea id="pgbcontent" class="">'.$data.'</textarea>';

            echo '<div class="dzspgb-saver-con"><button class="dzspgb-saver-field dzspgb-button">'.__('Save Page').'</button></div>';
            echo '</div>';

            ?><script><?php
        echo 'window.init_ultibox_settings = {
settings_disableSocial:"on"
};jQuery(document).ready(function($){';


                    if($permalink==''){

                        echo ' update_page_permalink({ page_label: "'.$page_data['title'].'",target_id: "'.$page_data['id'].'",type: "page" });';

                    }
       echo ' $("#pgbcontent").dzspgb({mode:"'.$mode.'"}); setTimeout( function() { $(".feedbacker").fadeOut("slow"); },1000); ';
        ?>
                });</script>
            <?php
            echo '';
        }else{
            include_once('admin_parts/admin-pages.php');

            part_pages();
        }





    }



    if($page==='posts' ){



        if(($subpage!='none')){

//            echo 'hmm';
//            enqueue_script('tinymce','tinymce/jquery.tinymce.min.js');

//            include_once(dirname(__FILE__).'/pagebuilder/class-dzspgb.php');


            $page_data = $dzspgb_forportal->select_page($subpage, array(
                'post_type'=>'post',
            ));

//            print_r($page);
            $data = $page_data['content'];

            echo '<div class="dzspgb-builder--wrap admin-wrap">';



            $subpage=$_GET['subpage'];
            $pagetitle = __('Pages');


            echo generate_admin_header(array(

                'title'=> $pagetitle,
                'page'=>$page,
                'subpage'=>$subpage,
                'aux_template_type'=>$aux_template_type
            ));


            $ind_sect = 0;


            ?><div class="dzspb_lay_con">
                <div class="dzspb_layb_one_full">
                    <div class="admin-breadcrumps">
                        <a href="admin.php"><i class="fa fa-home"></i>&nbsp;&nbsp;Home</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;<a href="admin.php?page=templates">Pages</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;<span class="current-page" ><?php echo $page_data['title']; ?></span>
                    </div>
                </div>
            </div><?php






            if($subpage==='upload'){

            }



            echo '<div class="edit-slug-box"><strong>Permalink:</strong> <a class="the-link" href="'.$dzsap_portal->optional_url_base.'index.php?page=page&page_id='.$subpage.'">'.$dzsap_portal->optional_url_base.'index.php?page=page&page_id='.$subpage.'</a></div>';



            ?>
            <br>
            <h2><?php echo __("Post Main"); ?></h2>
            <form class="edit-panel-post--main-fields">



            <?php



//            print_r($page_data_meta_all);

            $fout.='<input type="hidden" name="post_id" value="'.$page_data['id'].'"/>';


//            print_r($page_data);

            $fout.='<div class="row">';

            $fout.='<div class="col-md-8">';



            $lab = 'title';

            $fout.='<div class="setting">';
            $fout.='<div class="label-for-ujarak">'.__("Title").'</div>';
            $fout.='<input type="text" name="'.$lab.'" class="input-ujarak-style" value="'.$page_data[$lab].'"/>';
            $fout.='</div>';




            $lab = 'content';

            $fout.='<div class="setting">';
            $fout.='<div class="label-for-ujarak">'.__("Content").'</div>';
            $fout.='<textarea name="'.$lab.'" class="tinymce-me-global" value="">'.$page_data[$lab].'</textarea>';
            $fout.='</div>';









            $fout.='</div>'; // -- end col-md-8




            $fout.='<div class="col-md-4">';



            $lab = 'published_date';

            $fout.='<div class="setting">';
            $fout.='<div class="label-for-ujarak">'.__("Date").'</div>';
            $fout.='<input name="'.$lab.'" class=" input-ujarak-style" value="'.$page_data[$lab].'"/>';
            $fout.='</div>';

            $lab = 'author_id';

            $fout.='<div class="setting">';
            $fout.='<div class="label-for-ujarak">'.__("Published by ( ID )").'</div>';
            $fout.='<input name="'.$lab.'" class=" input-ujarak-style" value="'.$page_data[$lab].'"/>';
            $fout.='</div>';







            $fout.= '<div class="dzspgb-saver-con"><button class="btn-save-post button button--secondary"><span class="button-label">'.__('Save Post').'</span></button></div>';

            $fout.='</div>'; // -- end col-md-4




            $fout.='</div>'; // -- end row



            echo $fout;

            ?>


            </form>
            <h2><?php echo __("Post Meta"); ?></h2>
    <form class="edit-panel-post--meta-fields">
        <?php



        $page_data_meta_all = $dzsap_portal->get_post_meta_all($page_data['id']);


        $fout = '';
        $fout.='<input type="hidden" name="post_id" value="'.$page_data['id'].'"/>';

        $fout.='<div class="row">';

        $fout.='<div class="col-md-8">';

        $fout.='<div class="row">';

        $fout.='<div class="col-md-6">';



        $lab = 'location_name';

        $fout.='<div class="setting">';
        $fout.='<div class="label-for-ujarak">'.__("Location Name").'</div>';
        $fout.='<input type="text" name="'.$lab.'" class="input-ujarak-style" value="'.$page_data_meta_all[$lab].'"/>';
        $fout.='</div>';



        $lab = 'location_lat';

        $fout.='<div class="setting">';
        $fout.='<div class="label-for-ujarak">'.__("Location Latitude").'</div>';
        $fout.='<input type="text" name="'.$lab.'" class="input-ujarak-style" value="'.$page_data_meta_all[$lab].'"/>';
        $fout.='</div>';



        $lab = 'thumbnail';

        $fout.='<div class="setting">';
        $fout.='<div class="label-for-ujarak">'.__("Thumbnail").'</div>';

        $fout.='<div class="dzs-upload-con container-with-input-and-button">
                        <span class="dzs-single-upload the-button">
                                                            <input class="" name="file_field" type="file" accept="" >
                                                        </span>
                        <div class="the-input-con">
                                                        <input type="text" class="simple-input-field target-field input-ujarak-style source-for-autogenerate" name="'.$lab.'" value="'.$page_data_meta_all[$lab].'" style="box-shadow:none; "/></div>
                                                        ';

        $fout.='</div>';


        $fout.='</div>'; // -- end .setting



        $fout.='</div>'; // -- end col-md-6






        $fout.='<div class="col-md-6">';



        $lab = 'time_hour';

        $fout.='<div class="setting">';
        $fout.='<div class="label-for-ujarak">'.__("The hour").'</div>';
        $fout.='<input type="text" name="'.$lab.'" class="input-ujarak-style" value="'.$page_data_meta_all[$lab].'"/>';
        $fout.='</div>';




        $lab = 'location_long';

        $fout.='<div class="setting">';
        $fout.='<div class="label-for-ujarak">'.__("Location Longitude").'</div>';
        $fout.='<input type="text" name="'.$lab.'" class="input-ujarak-style" value="'.$page_data_meta_all[$lab].'"/>';
        $fout.='</div>';




        $lab = 'buy_html';

        $fout.='<div class="setting">';
        $fout.='<div class="label-for-ujarak">'.__("Buy Text").'</div>';
        $fout.='<input type="text" name="'.$lab.'" class="input-ujarak-style" value="'.htmlspecialchars($page_data_meta_all[$lab]).'"/>';
        $fout.='</div>';




        $fout.='</div>'; // -- end col-md-6



        $fout.='</div>'; // -- end row





        $fout.='</div>'; // -- end col-md-8



        $fout.='</div>'; // -- end row

        echo $fout;



        ?>


    </form>



<?php

        }else{
            include_once('admin_parts/admin-posts.php');

            part_posts();
        }





    }




    if($page==='blogs' ){



        if(($subpage!='none')){

//            echo 'hmm';
//            enqueue_script('tinymce','tinymce/jquery.tinymce.min.js');

//            include_once(dirname(__FILE__).'/pagebuilder/class-dzspgb.php');


            $page_data = $dzspgb_forportal->select_page($subpage, array(
                'post_type'=>'post',
            ));

//            print_r($page);
            $data = $page_data['content'];

            echo '<div class="dzspgb-builder--wrap admin-wrap">';



            $subpage=$_GET['subpage'];
            $pagetitle = __('Pages');


            echo generate_admin_header(array(

                'title'=> $pagetitle,
                'page'=>$page,
                'subpage'=>$subpage,
                'aux_template_type'=>$aux_template_type
            ));


            $ind_sect = 0;


            ?><div class="dzspb_lay_con">
                <div class="dzspb_layb_one_full">
                    <div class="admin-breadcrumps">
                        <a href="admin.php"><i class="fa fa-home"></i>&nbsp;&nbsp;Home</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;<a href="admin.php?page=templates">Pages</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;<span class="current-page" ><?php echo $page_data['title']; ?></span>
                    </div>
                </div>
            </div><?php






            if($subpage==='upload'){

            }



            echo '<div class="edit-slug-box"><strong>Permalink:</strong> <a class="the-link" href="'.$dzsap_portal->optional_url_base.'index.php?page=page&page_id='.$subpage.'">'.$dzsap_portal->optional_url_base.'index.php?page=post&id='.$subpage.'</a></div>';



            ?>
            <br>
            <h2><?php echo __("Post Main"); ?></h2>
            <form class="edit-panel-post--main-fields">



            <?php



//            print_r($page_data_meta_all);

            $fout.='<input type="hidden" name="post_id" value="'.$page_data['id'].'"/>';


//            print_r($page_data);

            $fout.='<div class="row">';

            $fout.='<div class="col-md-8">';



            $lab = 'title';

            $fout.='<div class="setting">';
            $fout.='<div class="label-for-ujarak">'.__("Title").'</div>';
            $fout.='<input type="text" name="'.$lab.'" class="input-ujarak-style" value="'.$page_data[$lab].'"/>';
            $fout.='</div>';




            $lab = 'content';

            $fout.='<div class="setting">';
            $fout.='<div class="label-for-ujarak">'.__("Content").'</div>';
            $fout.='<textarea name="'.$lab.'" class="tinymce-me-global" value="">'.$page_data[$lab].'</textarea>';
            $fout.='</div>';









            $fout.='</div>'; // -- end col-md-8




            $fout.='<div class="col-md-4">';



            $lab = 'published_date';

            $fout.='<div class="setting">';
            $fout.='<div class="label-for-ujarak">'.__("Date").'</div>';
            $fout.='<input name="'.$lab.'" class=" input-ujarak-style" value="'.$page_data[$lab].'"/>';
            $fout.='</div>';

            $lab = 'author_id';

            $fout.='<div class="setting">';
            $fout.='<div class="label-for-ujarak">'.__("Published by ( ID )").'</div>';
            $fout.='<input name="'.$lab.'" class=" input-ujarak-style" value="'.$page_data[$lab].'"/>';
            $fout.='</div>';






            $fout.= '<div class="dzspgb-saver-con"><button class="btn-save-post button button--secondary"><span class="button-label">'.__('Save Post').'</span></button></div>';

            $fout.='</div>'; // -- end col-md-4




            $fout.='</div>'; // -- end row



            echo $fout;

            ?>


            </form>




            <h2><?php echo __("Post Meta"); ?></h2>
            <form class="edit-panel-post--meta-fields">
                <?php



                $page_data_meta_all = $dzsap_portal->get_post_meta_all($page_data['id']);


                $fout = '';
                $fout.='<input type="hidden" name="post_id" value="'.$page_data['id'].'"/>';

                $fout.='<div class="row">';

                $fout.='<div class="col-md-8">';

                $fout.='<div class="row">';

                $fout.='<div class="col-md-6">';



                $lab = 'thumbnail';

                $fout.='<div class="setting">';
                $fout.='<div class="label-for-ujarak">'.__("Thumbnail").'</div>';

                $fout.='<div class="dzs-upload-con container-with-input-and-button">
                        <span class="dzs-single-upload the-button">
                                                            <input class="" name="file_field" type="file" accept="" >
                                                        </span>
                        <div class="the-input-con">
                                                        <input type="text" class="simple-input-field target-field input-ujarak-style source-for-autogenerate" name="'.$lab.'" value="'.$page_data_meta_all[$lab].'" style="box-shadow:none; "/></div>
                                                        ';

                $fout.='</div>';


                $fout.='</div>'; // -- end .setting






                $fout.='</div>'; // -- end col-md-6






                $fout.='<div class="col-md-6">';






                $fout.='</div>'; // -- end col-md-6



                $fout.='</div>'; // -- end row





                $fout.='</div>'; // -- end col-md-8



                $fout.='</div>'; // -- end row

                echo $fout;



                ?>


            </form>




<?php

        }else{
            include_once('admin_parts/admin-blogs.php');

            part_blogs();
        }





    }



    if($page==='users' ){



        if(($subpage!='none')){

            $fout = '';

//            echo 'hmm';
//            enqueue_script('tinymce','tinymce/jquery.tinymce.min.js');

//            include_once(dirname(__FILE__).'/pagebuilder/class-dzspgb.php');


            $page_data = $dzspgb_forportal->select_page($subpage, array(
                'post_type'=>'user',
            ));

//            print_r($page);




            $data = '';

            if(isset($page_data['content'])){
                $data = $page_data['content'];
            }


            echo '<div class="dzspgb-builder--wrap admin-wrap">';



            $subpage=$_GET['subpage'];
            $pagetitle = __('Pages');


            echo generate_admin_header(array(

                'title'=> $pagetitle,
                'page'=>$page,
                'subpage'=>$subpage,
//                'aux_template_type'=>$aux_template_type
            ));



            $title = '';

            if(isset($page_data['title'])){
                $title = $page_data['title'];
            }

            $ind_sect = 0;


            ?><div class="dzspb_lay_con">
                <div class="dzspb_layb_one_full">
                    <div class="admin-breadcrumps">
                        <a href="admin.php"><i class="fa fa-home"></i>&nbsp;&nbsp;Home</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;<a href="admin.php?page=templates">Pages</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;<span class="current-page" ><?php echo $title; ?></span>
                    </div>
                </div>
            </div><?php






            if($subpage==='upload'){

            }

//            print_r($page_data);



//            echo 'seekval - '.$use_template;

            echo '<input type="hidden" name="type" value="user"/>';


            $real_link = $dzsap_portal->get_permalink($subpage, array(
                'type'=>'user'
            ));
            echo '<div class="edit-slug-box"><strong>'.__("Permalink").':</strong> <a class="the-link" href="'.$real_link.'">'.$dzsap_portal->optional_url_base;





            if($dzsap_portal->main_settings['use_pretty_links']=='on'){

                $permalink = $dzsap_portal->get_permalink($subpage, array(
                    'only_from_table'=>true,
                    'type'=>'user',
                ));

                echo '</a>'.' <input class="ajax-link-changer" type="text" value="';


                if($permalink){
                    echo $permalink;
                }


                echo '"/> <i class="ajax-permalink-preloader fa fa-spin fa-circle-o-notch" aria-hidden="true"';


                if($permalink){
                    echo ' style="display:none;"';
                }

                echo '></i>';

//                echo $permalink;
            }else{
                echo 'index.php?page=user&user_id='.$subpage.'</a>';
            }


            echo '</div>';



            ?>
            <br>
            <h2><?php echo __("Post Main"); ?></h2>
            <form class="edit-panel-post--main-fields">



            <?php



//            print_r($page_data_meta_all);

            $fout.='<input type="hidden" name="post_id" value="'.$page_data['id'].'"/>';
            $fout.='<input type="hidden" name="table_name" value="users"/>';


//            print_r($page_data);

            $fout.='<div class="row">';

            $fout.='<div class="col-md-8">';



            $lab = 'username';

            $fout.='<div class="setting">';
            $fout.='<div class="label-for-ujarak">'.__("User Name").'</div>';
            $fout.='<input type="text" name="'.$lab.'" class="input-ujarak-style" value="'.$page_data[$lab].'"/>';
            $fout.='</div>';




            $lab = 'description';

            $fout.='<div class="setting">';
            $fout.='<div class="label-for-ujarak">'.__("Content").'</div>';
            $fout.='<textarea name="'.$lab.'" class="tinymce-me-global" value="">'.$page_data[$lab].'</textarea>';
            $fout.='</div>';









            $fout.='</div>'; // -- end col-md-8




            $fout.='<div class="col-md-4">';



            $lab = 'avatar';

            $fout.='<div class="setting">';
            $fout.='<div class="label-for-ujarak">'.__("Avatar").'</div>';
            $fout.='<input name="'.$lab.'" class=" input-ujarak-style" value="'.$page_data[$lab].'"/>';
            $fout.='</div>';

            $lab = 'second_avatar';

            $fout.='<div class="setting">';
            $fout.='<div class="label-for-ujarak">'.__("Second Avatar").'</div>';
            $fout.='<input name="'.$lab.'" class=" input-ujarak-style" value="'.$page_data[$lab].'"/>';
            $fout.='</div>';


            $lab = 'new_password';

            $val = '';

            if(isset($page_data[$lab])){
                $val = $page_data[$lab];
            }

            $fout.='<div class="setting">';
            $fout.='<div class="label-for-ujarak">'.__("New Password").'</div>';
            $fout.='<input name="'.$lab.'" class=" input-ujarak-style" value="'.$val.'"/>';
            $fout.='</div>';





            $lab = 'role';

            $opts = array(
                array(
                    'lab'=>__("User"),
                    'val'=>"user",
                ),
                array(
                    'lab'=>__("Pro Account"),
                    'val'=>"pro",
                ),
                array(
                    'lab'=>__("Admin"),
                    'val'=>"admin",
                ),
            );

            $fout.='<div class="setting">';
            $fout.='<div class="label-for-ujarak">'.__("Role").'</div>';
            $fout.= DZSHelpers::generate_select($lab, array('options' => $opts, 'class' => 'dzs-style-me skin-beige   ', 'seekval' => $page_data[$lab]));
            $fout.='</div>';


            
            
            $lab = 'capabilities';
            
            $caps = $dzsap_portal->get_user_capabilities($page_data['id'],array(
                'get_only_extra'=>true
            ));
            
//            print_r($caps);
            
            if(is_array($caps)==false){
                $caps = array();
            }
            
            
            $arr_opts = array(
              'admin',
              'proaccount',
              'verified',
              'upload_tracks',
              'track_stats',
              'download_free_track',
              'sell_track',

            );





            $fout.='<div class="setting">';
            $fout.='<div class="label-for-ujarak">'.__("Capabilities").'</div>';
            foreach($arr_opts as $opt){
                
                $fout.='<label>';
                $fout.=DZSHelpers::generate_input_checkbox($lab.'[]', array(
                    'val'=>$opt,
                    'seekval'=>$caps,
                ));
                $fout.=' '.$opt;
                $fout.='</label><br>';
            }
            $fout.='</div>';
            
            
            
            $fout.='</div><!-- end col-md-4-->';



            $fout.= '<div class="dzspgb-saver-con"><button class="btn-save-post btn-save-post-for-user button button--secondary"><span class="button-label">'.__('Save Post').'</span></button></div>';

            $fout.='</div><!-- end .row -->';  // -- end row






            echo $fout;

            ?>


            </form>
            <h2><?php echo __("User Meta"); ?></h2>
    <form class="edit-panel-post--meta-fields">
        <?php



        $page_data_meta_all = $dzsap_portal->get_user_meta_all($page_data['id']);


        $fout = '';
        $fout.='<input type="hidden" name="post_id" value="'.$page_data['id'].'"/>';

        $fout.='<div class="row">';

        $fout.='<div class="col-md-8">';

        $fout.='<div class="row">';

        $fout.='<div class="col-md-6">';



        $lab = 'user_credit';

        $fout.='<div class="setting">';
        $fout.='<div class="label-for-ujarak">'.__("User Credit").'</div>';

        $val = '';

        if(isset($page_data_meta_all[$lab])){
            $val = $page_data_meta_all[$lab];
        }

        $fout.='<input type="text" name="'.$lab.'" class="input-ujarak-style" value="'.$val.'"/>';
        $fout.='</div>';




        $fout.='</div>'; // -- end col-md-6






        $fout.='<div class="col-md-6">';





        $fout.='</div>'; // -- end col-md-6



        $fout.='</div>'; // -- end row





        $fout.='</div>'; // -- end col-md-8



        $fout.='</div>'; // -- end row

        echo $fout;



        ?>


    </form>



<?php

        }else{
            include_once('admin_parts/admin-users.php');

            part_users();
        }





    }



    if($page==='purchases' ){


        include_once('admin_parts/admin_purchases.php');

        part_purchases();





    }

    if($page==='reports' ){


        include_once('admin_parts/admin_reports.php');

        part_reports();





    }
    if($page==='statistics' ){


        include_once('admin_parts/admin_statistics.php');

        part_statistics();





    }

    if($page==='plugins' ){


        include_once('admin_parts/admin_plugins.php');

        part_plugins();





    }



    echo '<script> window.dzs_upload_path = "'.'upload/";</script>';

//    echo 'alceva'.$page;
    if($page==='templates'){

        //-- templates handle
//        echo 'ceva';

        include_once(dirname(__FILE__).'/pagebuilder/class-dzspgb.php');

        echo '<div class="dzspgb-templates--wrap admin-wrap">';


        if(isset($_GET['subpage'])){



            $auxa = $dzspgb_forportal->select_template_array($_GET['subpage']);


            if($auxa[0]){
                $auxa = $auxa[0];
            }



            if(isset($auxa['template_data'])){
                $auxtem = array();
                parse_str($auxa['template_data'], $auxtem);





//                print_r($auxtem);

                $template_type = 'Full';

                if(isset($auxtem['dzspgb']['type'])){

                    $template_type = $auxtem['dzspgb']['type'];
                    $mode_pb = $template_type;
//                    echo 'alceva'.$mode_pb;
                }


                $aux_template_type = '<span class="edit-template-type-con setting"><span class="setting-label">'.__('Template Type').'</span><a class="';
                if($template_type==='Full'){
                    $aux_template_type.=' active';
                }

                $aux_template_type.='" href="">'.__('Full').'</a><a class="';

                if($template_type==='Row'){
                    $aux_template_type.=' active';
                }

                $aux_template_type.='" href="">'.__('Row').'</a></span>';



                $aux_template_type .= '<div class="setting"><button class="button button--secondary btn-show-serialized-template-data"><span class="button-label">'.__("Show Serialized Data").'</span></button></div>';

//                echo '<div class="dzspgb-meta-con"><span class="dzspgb-page-name">Name: <strong>Home</strong> /</span> <span class="dzspgb-template-con  dzstooltip-con js">  Template Options <i class="fa fa-cubes" style="opacity:0.5"></i> <span class="dzstooltip arrow-top align-left skin-black " style="padding-bottom:10px; ">'.$aux_template_type.'</span></span><span class="dzspgb-logo"></span></div>';


                $page='templates';
                $subpage=$_GET['subpage'];
                $pagetitle = __('Templates');


                echo generate_admin_header(array(

                    'title'=> $pagetitle,
                    'page'=>$page,
                    'subpage'=>$subpage,
                    'aux_template_type'=>$aux_template_type
                ));


                $ind_sect = 0;


                ?><div class="dzspb_lay_con">
                    <div class="dzspb_layb_one_full">
                        <div class="admin-breadcrumps">
                            <a href="admin.php"><i class="fa fa-home"></i>&nbsp;&nbsp;<?php echo __('Home');?></a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;<a href="admin.php?page=templates"><?php echo __('Templates');?></a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;<span class="current-page" ><?php echo $auxa['template_name']; ?></span>
                        </div>
                    </div>
                </div><?php

                echo '<div class="the-form dzspgb-form">';

                // -- template parsing

                $special_labs = array("type","extra_classes", "use_template", "is_content");


                echo '<input type="hidden" name="dzspgb[type]" value="'.$template_type.'"/>';


                if(isset($auxtem['dzspgb']['type']) && $auxtem['dzspgb']['type']==="Row"){

                    // -- this is ROW type

                    echo '<div class="area-rows">';
                    $ind_row = 0;
                    foreach($auxtem['dzspgb'] as $lab0 => $row){

                        if($lab0==='type'||$lab0==='extra_classes'){
                            continue;
                        }

                        $args = array(
                            'row_index' => $ind_row,
                            'type_pb'=>'Row',
                            'empty' => false,
                            'extra_classes' => '',
                            'hide_when_logged_in' => 'off',
                            'hide_when_not_logged_in' => 'off',
                        );


                        foreach($row as $lab_row => $val_row){
                            if(is_numeric($lab_row)===false){
                                $args[$lab_row] = $val_row;
                            }
                        }


                        echo $dzspgb_forportal->generate_admin_row_part1($args);

                        $ind_row_part = 0;
                        if(isset($row[0])){
//                        echo ' row is --> ';print_r($row);
                            foreach($row as $lab => $row_part){

                                if($lab==='type' || $lab==='extra_classes' || $lab==='hide_when_logged_in' || $lab==='hide_when_not_logged_in' || (isset($row_part) && isset($row_part['part']) && $row_part['part']==='o') || (isset($row_part) && isset($row_part['part']) && $row_part['part']==='d')){
                                    continue;
                                }

//                            print_r($row_part);

                                $args = array(
                                    'row_index' => $ind_row,
                                    'type_pb'=>'Row',
                                    'row_part_index' => $ind_row_part,
                                    'part' => $row_part['part'],
                                );
                                echo $dzspgb_forportal->generate_admin_row_part_part1($args);



                                $ind_element = 0;
                                if(isset($row_part[0])){

                                    foreach($row_part as $lab4 => $el){


                                        if($lab4==='type' || $lab4==='extra_classes' || $lab4==='part'){
                                            continue;
                                        }


                                        $type = '';

                                        if($el && is_array($el) && $el['type_element']){
                                            $type = $el['type_element'];
                                        }


//                                            print_r($el);
                                        $args = array(
                                            'type' => 'element',
                                            'type_element' => $type,
                                            'type_elements' => 'dzspgb',
                                        );


                                        if($el && is_array($el)){

                                            $args = array_merge($args, $el);
                                        }




                                        $args['row_index'] = $ind_row;
                                        $args['row_part_index'] = $ind_row_part;
                                        $args['element_index'] = $ind_element;
                                        $args['txt_choose'] = __("Edit");
                                        $args['type_pb'] = $template_type;


//                                                        echo 'hmm'.$ind_sect.$ind_cont.$ind_row.$ind_row_part.$ind_element;




//                                                        print_r($el);
//                                                        print_r($dzspgb_templates);

                                        $k='';
                                        $i9=0;
//                                                        echo 'ceva'; echo count($dzspgb_templates);
                                        foreach($dzspgb_templates as $lab => $temp){

                                            if(isset($args['type_element']) && $args['type_element']=== $lab){
                                                $k=$lab;
                                                break;
                                            }

                                            $i9++;
                                        }

                                        foreach($args as $lab=>$arg){
//                                            $args[$lab] = str_replace('{replacequotquot}','"', $arg);
                                        }

//                                                        echo $k;

                                        if($k){


//                                                            print_r($dzspgb_templates[$k]); print_r($args);
                                            echo call_user_func($dzspgb_templates[$k]['admin_str_function'],$args);
                                        }




                                        $ind_element++;
                                    }
                                }


                                echo $dzspgb_forportal->generate_admin_row_part_part2($args);

                                $ind_row_part++;

                            }
                        }

                        echo $dzspgb_forportal->generate_admin_row_part2($args);


                        $ind_row++;
                    }
                    echo '</div>';

                }else{


                    // -- this is FULL type for templates

//                    print_r($auxtem);
                    foreach($auxtem['dzspgb'] as $lab0 => $sect){

                        if($lab0==='type'){
                            continue;
                        }

                        $args = array();

                        foreach($special_labs as $special_lab){
                            if(isset($sect[$special_lab])){
                                $args[$special_lab] = $sect[$special_lab];
                            }

                        }

                        $args['section_index'] = $ind_sect;

//                        print_r($sect);
                        echo $dzspgb_forportal->generate_admin_section_part1($args);

                        $ind_cont = 0;
                        if(isset($sect[0])){
                            foreach($sect as $lab => $cont){

                                if($lab==='type' || $lab==='extra_classes' || $lab==='is_content'){
                                    continue;
                                }


                                // -- nasty occurance ridance
//                                if($cont && is_array($cont) && $cont['type']==='element'){
//                                    echo 'get rid of it !!';
//                                    continue;
//                                }

//                                echo 'her is container --> '; print_r($cont); echo '<-- her |||| ';


                                $args = array(
                                    'section_index' => $ind_sect,
                                    'container_index' => $ind_cont,
                                    'admin_args' => array(
                                        'this_is_template_admin'=>true
                                    ),
                                );


                                foreach($special_labs as $special_lab){
                                    if(isset($cont[$special_lab])){

                                        $args[$special_lab] = $cont[$special_lab];
                                    }
                                }

//                                echo 'ceva';
                                echo $dzspgb_forportal->generate_admin_container_part1($args);

                                $ind_row=0;
                                if(isset($sect[0])){

                                    foreach($cont as $lab2 => $row){


//                                        echo $lab2;
                                        if($lab2!==0 && in_array($lab2, $special_labs)){

                                            continue;
                                        }


//                                        echo 'her is new row - '; print_r($row);



                                        $args = array(
                                            'section_index' => $ind_sect,
                                            'container_index' => $ind_cont,
                                            'row_index' => $ind_row,
                                            'empty' => false,
                                        );
                                        echo $dzspgb_forportal->generate_admin_row_part1($args);

                                        $ind_row_part = 0;
                                        if(isset($row[0])){

                                            foreach($row as $lab3 => $row_part){

                                                if($lab==='type' || $lab==='extra_classes' || $lab==='hide_when_logged_in' || $lab==='hide_when_not_logged_in' || $lab==='column_padding' || (isset($row_part) && isset($row_part['part']) && $row_part['part']==='o') || (isset($row_part) && isset($row_part['part']) && ( $row_part['part']==='d' || $row_part['part']==='r'  ) ) || (isset($row_part) && (isset($row_part['part'])==false || $row_part['part']=='' ) ) ){
                                                    continue;
                                                }

//                                            print_r($row_part);
                                                $args = array(
                                                    'section_index' => $ind_sect,
                                                    'container_index' => $ind_cont,
                                                    'row_index' => $ind_row,
                                                    'row_part_index' => $ind_row_part,
                                                    'part' => $row_part['part'],
                                                );
                                                echo $dzspgb_forportal->generate_admin_row_part_part1($args);




                                                $ind_element = 0;
                                                if(isset($row_part[0])){

                                                    foreach($row_part as $lab4 => $el){


                                                        if($lab4==='type' || $lab4==='extra_classes' || $lab4==='part'){
                                                            continue;
                                                        }



//                                            print_r($el);
                                                        $args = array(
                                                            'type' => 'element',
                                                            'type_element' => $el['type_element'],
                                                            'type_elements' => 'dzspgb',
                                                        );


                                                        $args = array_merge($args, $el);



                                                        $args['section_index'] = $ind_sect;
                                                        $args['container_index'] = $ind_cont;
                                                        $args['row_index'] = $ind_row;
                                                        $args['row_part_index'] = $ind_row_part;
                                                        $args['element_index'] = $ind_element;
                                                        $args['txt_choose'] = __("Edit");


//                                                        echo 'hmm'.$ind_sect.$ind_cont.$ind_row.$ind_row_part.$ind_element;




//                                                        print_r($el);
//                                                        print_r($dzspgb_templates);

                                                        $k='';
                                                        $i9=0;
//                                                        echo 'ceva'; echo count($dzspgb_templates);
                                                        foreach($dzspgb_templates as $lab => $temp){

                                                            if($args['type_element']=== $lab){
                                                                $k=$lab;
                                                                break;
                                                            }

                                                            $i9++;
                                                        }

//                                                        echo $k;

                                                        if($k){

                                                            $aux_multiple_items = array();
                                                            foreach($el as $lab5=>$val5){
//                                                                print_r($val5);
                                                                if($val5 && is_array($val5) && $val5['type']=='multipleitems'){
//                                                                    echo 'ceva24'.$lab5;

                                                                    $aux_multiple_items[$lab5] = $val5;


                                                                }
                                                            }

//                                                            print_r($aux_multiple_items);

                                                            if($aux_multiple_items && is_array($aux_multiple_items) && count($aux_multiple_items)>0){
                                                                $args['multiple_items'] = $aux_multiple_items;
                                                            }

//                                                            print_r($dzspgb_templates[$k]); print_r($args);
                                                            echo call_user_func($dzspgb_templates[$k]['admin_str_function'],$args);
                                                        }




                                                        $ind_element++;
                                                    }
                                                }




                                                echo $dzspgb_forportal->generate_admin_row_part_part2($args);

                                                $ind_row_part++;
                                            }
                                        }




                                        echo $dzspgb_forportal->generate_admin_row_part2($args);

                                        $ind_row++;
                                    }
                                }



                                echo $dzspgb_forportal->generate_admin_container_part2($args);

                                $ind_cont++;

                            }
                        }

                        echo $dzspgb_forportal->generate_admin_section_part2($args);


                        $ind_sect++;
                    }

                }
                echo '</div>';

            }

        }else{

            // -- show all templatse

            $auxa = $dzspgb_forportal->select_templates_array();


            $page = 'template';
            $pagetitle = __('Templates');
//        print_r($auxa);
            ?>
            <?php
        echo generate_admin_header(array(

            'title'=> $pagetitle,
            'page'=>$page
        ));
        ?>


            <div class="dzspb_lay_con">
                <div class="dzspb_layb_one_full">
                    <div class="admin-breadcrumps">
                        <a href="admin.php"><i class="fa fa-home"></i>&nbsp;&nbsp;Home</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;<span class="current-page" >Templates</span>
                    </div>
                </div>
            </div>
            <?php

            echo '<div class="dzspb_layb_layout templates-collection">';

            echo '</div>'; // -- end dzspb_layb_layout


            echo '    <div class="separator general-margin"></div>
    <h2>Create New Template</h2>
    <div class="big-field-con">
        <button class="btn-add-template">Create</button>
        <div class="big-field-div" placeholder="'.__("enter here a new page name... ").'"><input class="bigfield" name="newtemplate_name"/></div>

    </div>';
        }







    if(isset($_GET['subpage'])){
//        echo 'ceva'.$mode_pb;

        echo '<div class="dzspgb-saver-con"><button class="dzspgb-saver-template dzspgb-button">'.__('Save').'</button></div>';

        echo '<div class="saveconfirmer" style=""><i class="fa fa-circle-o-notch fa-spin"></i> Loading...</div>';
        ?><script><?php

        echo 'window.init_ultibox_settings = {
settings_disableSocial:"on"
};';

        echo 'jQuery(document).ready(function($){';
        echo '$(".the-form.dzspgb-form").dzspgb({type:"templateedit",mode:"'.$mode_pb.'"}); setTimeout( function() { $(".saveconfirmer").fadeOut("slow"); },1000); ';
        ?>



            setTimeout(function(){
            $('.elements-area > .dzspgb-element-con textarea').each(function(){
                var _t = $(this);
//                    console.info(_t);

                var aux = _t.val();


                aux = String(aux).replace(/"{replacequotquot}/g, '"');
                aux = String(aux).replace(/{replacequotquot}"/g, '"');
                aux=String(aux).replace(/{replacequotquot}/g, '"');


                console.info(_t.val(), aux);
                _t.val(aux);



            });
            },1400);

            $(document).on('click','.dzspgb-saver-template', function(){
//                console.log('continue here');
                $(".saveconfirmer").eq(0).html('Saving.. ');
                $(".saveconfirmer").fadeIn('fast');

//                $('.dzspgb-builder--wrap').get(0).api_update_elements_name();
                $('.dzspgb-builder--wrap').get(0).api_remove_non_actives();

                $('.elements-area > .dzspgb-element-con textarea').each(function(){
                    var _t = $(this);
                    console.info(_t.val(),_t);

                    var orig_t_val = _t.val();

                    if(orig_t_val){

                        var aux = _t.val();
                        if(_t.parent().parent().parent().find('.dzspgb-element-type').eq(0).attr('data-type')=='text'){

                        }else{
                        }
                        aux = String(_t.val()).replace(/"/g, '{replacequotquot}');



                        _t.val(aux);

                        console.info(aux, '||| save templateoriginal - ' + orig_t_val);

                        setTimeout(function(){
                            _t.val(orig_t_val);
                        },2000);
                    }



                });

                var data = {
                    action: 'save_template_by_id'
                    ,template_id: <?php echo $_GET['subpage']; ?>
                    ,postdata : $('.dzspgb-form').eq(0).serializeAnything()
                };

                // -- template_updated
                $.ajax({
                    type: "POST",
                    url: 'admin.php?page=<?php echo $page ?>&subpage=<?php echo $subpage ?>"',
                    data: data,
                    success: function(res){
                        setTimeout(function(){

                                console.info(res);

                            $(".saveconfirmer").fadeOut('fast');
                        },1000);
                    }
                });


                return false;
            })

            $(document).on('click','.dzspgb-save-serialized', function(){
//                console.log('continue here');
                var data = {
                    action: 'save_template_by_id'
                    ,template_id: <?php echo $_GET['subpage']; ?>
                    ,postdata : $('.serialized-template-content').val()
                };
                $(".saveconfirmer").eq(0).html('Saving.. ');
                $(".saveconfirmer").fadeIn('fast');

                // -- template_updated
                $.ajax({
                    type: "POST",
                    url: 'admin.php?page=<?php echo $page ?>&subpage=<?php echo $subpage ?>"',
                    data: data,
                    success: function(res){
                        setTimeout(function(){

                                console.info(res);

                            $(".saveconfirmer").fadeOut('fast');
                        },1000);
                    }
                });


                return false;
            })

            $('.edit-template-type-con > a').bind('click', function(){
                var _t = $(this);
                if(_t.hasClass('active')){
                    return false;
                }
                $('.dzspgb-builder--wrap').get(0).api_update_template_type(_t.html());

                return false;
            });
            });</script>
    <?php
    }


        echo '</div>';

        echo '';



    }





    if($page==='menus' ){



    if(($subpage!='none')){

        $page = 'menus';
        $pagetitle = __('Menus');
        ?>
        <div class="admin-wrap admin-wrap-for-menus">


            <?php
            echo generate_admin_header(array(

                'title'=> $pagetitle,
                'page'=>$page
            ));


            $args = array(
                'for_ajax'=>false
            );
            $menus = json_decode($dzspgb_forportal->ajax_select_pages_array($args));

            //        print_r($menus);

            ?>





            <div class="dzspb_lay_con">
                <div class="dzspb_layb_one_full">
                    <div class="admin-breadcrumps">
                        <a href="admin.php"><i class="fa fa-home"></i>&nbsp;&nbsp;Home</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;<span class="current-page" >Menus</span>
                    </div>
                </div>
            </div>
            <div class="dzspb_lay_con">



                <div class="dzspb_layb_one_third">
                    <div class="admin-block-container">
                        <div class="admin-block-container--header">
                            Pages
                        </div>
                        <div class="admin-block-container--content">
                            <p class="sidenote">Drag Pages into the Menu to the right</p>

                            <div class="admin-menu-pages">
                                <?php
                                foreach($menus as $menu){
//                            print_r($menu);

                                    echo '<label><input type="checkbox" name="checkbox" value="value" data-id="'.$menu->id.'" data-label="'.$menu->title.'" data-type="menupage" data-content=""><span>'.$menu->title.'</span></label>';
                                }



                                echo '<label class="custom-html"><input type="checkbox" name="checkbox" value="value" data-id="0" data-label="'.__('Custom HTML').'" data-type="customhtml" data-content=""><span>'.__('Custom HTML').'</span></label>';

                                ?>

                                <button class="button button--secondary button--border-thin button--text-thick insert-pages-in-menu"><span class="button-label"><?php echo __('Insert'); ?></span></button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="dzspb_layb_two_third">
                    <div class="admin-block-container">
                        <div class="admin-block-container--header">
                            Menu
                        </div>
                        <div class="admin-block-container--subheader">
                            Menu Name:
                        </div>
                        <div class="admin-block-container--content">
                            <div class="dd" id="nestable3" style="width: 100%; max-width: none; margin: 0 auto;">
                                <ol class="dd-list">
                                <?php


                                $page_data = $dzspgb_forportal->select_page($subpage,array(
                                    'post_type'=>'menu',
                                ));

//                                            print_r($page_data);


                                $data = $page_data['content'];

//                                echo $data;


                                $data_arr = json_decode($data);

//                                print_r($data_arr);


                                foreach($data_arr as $menuitem){

//                                    print_r($menuitem);

                                    echo '<li class="dd-item dd3-item';


                                if($menuitem->type=='customhtml'){
                                    echo ' '.'active-extra-options';
                                }


                                    echo '" data-id="'.$menuitem->id.'" data-label="'.$menuitem->label.'" data-type="'.$menuitem->type.'" data-content="'.$menuitem->content.'"><div class="dd-handle dd3-handle">Drag</div><div class="dd3-content">'.$menuitem->label.'</div>';


                                    $lab_extra_html = __("Content");

                                    if($menuitem->type=='menupage'){
                                        $lab_extra_html = __("Replace Label");
                                    }


                                    echo '<div class="extra-html">
                                    <h4>'.$lab_extra_html.'</h4><textarea name="item_content">';

                                    if($menuitem->content){
                                        $aux = $menuitem->content;

                                        $aux = str_replace(';quot;','"', $aux);
                                        $aux = str_replace('{replacequotquot}','"', $aux);

                                        echo $aux;
                                    }

                                    echo '</textarea>';



                                    echo '<h4>'.__("Extra Classes").'</h4><input type="text" name="extra_classes" value="';

                                    if(isset($menuitem->extra_classes) && $menuitem->extra_classes){
                                        $aux = $menuitem->extra_classes;

                                        $aux = str_replace('{replacequotquot}','"', $aux);

                                        echo $aux;
                                    }

                                    echo '"/>';







                                    echo '<h4>'.__("Visibility Type").'</h4>';


//                                print_r($menuitem);


                                    $lab = 'visibility_type';

                                    $opts = array(
                                        array(
                                            'lab'=>__("Always"),
                                            'val'=>"always",
                                        ),
                                        array(
                                            'lab'=>__("Only for Logged In"),
                                            'val'=>"logged",
                                        ),
                                        array(
                                            'lab'=>__("Only for Visitors"),
                                            'val'=>"not_logged",
                                        ),
                                    );

                                    echo DZSHelpers::generate_select($lab, array('options' => $opts, 'class' => 'dzs-style-me skin-beige   ', 'seekval' => $menuitem->visibility_type));





                                    echo '</div>';





                                    if(isset($menuitem->children) && is_array($menuitem->children)){

                                        echo '<ol class="dd-list">';
                                        foreach($menuitem->children as $mi2){

//                                            print_r($mi2);

                                            echo '<li class="dd-item dd3-item" data-id="'.$mi2->id.'" data-label="'.$mi2->label.'" data-type="'.$mi2->type.'" data-content="'.$mi2->content.'"><div class="dd-handle dd3-handle">Drag</div><div class="dd3-content">'.$mi2->label.'</div>';


                                            echo '<div class="delete-menuitem-con"><i class="fa fa-times"></i></div></li>';

                                            echo '</li>';


                                        }

                                        echo '</ol>';
                                    }
                                    echo '<div class="extra-options-menuitem-con btn-menuitem-con"><i class="fa fa-plug"></i></div>';
                                    echo '<div class="delete-menuitem-con btn-menuitem-con"><i class="fa fa-times"></i></div></li>';

                                }

                                ?>
                                </ol>
                            </div>
                        </div>

                    </div>

                </div>
            </div>


            <div class="dzspgb-saver-con"><button class="dzspgb-saver-field dzspgb-button "><?php echo __('Save Menu');?></button></div>


        </div>
        <script>
            jQuery(document).ready(function($){

                $('#nestable3').nestable({
                    'maxDepth':3
                });
            })
        </script>
        <?php
    }else{
        include_once('admin_parts/admin-menus.php');

        part_menus();
    }
    }





    if($page==='tracks' ){



        if(($subpage!='none')){

            $page = 'tracks';
            $pagetitle = __('Tracks');
            ?>
            <div class="admin-wrap admin-wrap-for-tracks">


                <?php
                echo generate_admin_header(array(

                    'title'=> $pagetitle,
                    'page'=>$page
                ));


                $args = array(
                    'for_ajax'=>false
                );
                $menus = json_decode($dzspgb_forportal->ajax_select_pages_array($args));

                //        print_r($menus);

                ?>





                <div class="dzspb_lay_con">
                    <div class="dzspb_layb_one_full">
                        <div class="admin-breadcrumps">
                            <a href="admin.php"><i class="fa fa-home"></i>&nbsp;&nbsp;Home</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;<span class="current-page" >Tracks</span>
                        </div>
                    </div>
                </div>
                <div class="dzspb_lay_con">





                    <div class="dzspb_layb_one_full">
                        <?php

                        $player_db_args = $dzsap_portal->get_track($subpage);

//                        print_r($player_db_args);

                        $fout  = '';

                        $fout.='<form class="edit-panel" style="">';




                        $fout.='<input type="hidden" name="track_id" value="'.$player_db_args['id'].'">';

                        $theid = $player_db_args['id'];


                        $fout.="<h2>".__("Main Info")."</h2>";

                        $fout.='<div class="row"><div class="col-md-6">';


                        $lab = 'content';

                        $fout.='<div class="setting">';
                        $fout.='<div class="label-for-ujarak">'.__("Source").'</div>';

                        $fout.='<div class="dzs-upload-con container-with-input-and-button">
                        <span class="dzs-single-upload the-button">
                                                            <input class="" name="file_field" type="file" accept=".mp3" >
                                                        </span>
                        <div class="the-input-con">
                                                        <input type="text" class="simple-input-field target-field input-ujarak-style source-for-autogenerate" name="'.$lab.'" value="'.$player_db_args[$lab].'" style="box-shadow:none; "/></div>
                                                        ';

                        $fout.='</div>';



                        $fout.='</div>';


                        $lab = 'title';

                        $fout.='<div class="setting">';
                        $fout.='<div class="label-for-ujarak">'.__("Title").'</div>';
                        $fout.='<input type="text" name="'.$lab.'" class="input-ujarak-style" value="'.$player_db_args[$lab].'"/>';
                        $fout.='</div>';



                        $lab = 'thumbnail';

                        $fout.='<div class="setting">';
                        $fout.='<div class="label-for-ujarak">'.__("Thumbnail").'</div>';
                        $fout.='<input type="text" name="'.$lab.'" class="input-ujarak-style" value="'.$player_db_args[$lab].'"/>';
                        $fout.='</div>';



                        $lab = 'type';

                        $fout.='<div class="setting">';
                        $fout.='<div class="label-for-ujarak">'.__("Type").'</div>';
                        $fout.='<input type="text" name="'.$lab.'" class="input-ujarak-style" value="'.$player_db_args[$lab].'"/>';
                        $fout.='</div>';







                        $fout.='</div>';

                        $fout.='<div class="col-md-6">';

                        // -- track


                        $lab = 'tags';

                        $fout.='<div class="setting">';
                        $fout.='<div class="label-for-ujarak">'.__("Tags").'</div>';
                        $fout.='<input type="text" name="'.$lab.'" class="input-ujarak-style" value="'.$player_db_args[$lab].'"/>';
                        $fout.='</div>';





                        $lab = 'description';

                        $fout.='<div class="setting">';
                        $fout.='<div class="label-for-ujarak">'.__("Description").'</div>';
                        $fout.='<textarea type="text" name="'.$lab.'" class="input-ujarak-style" >'.htmlentities($player_db_args[$lab]).'</textarea>';
                        $fout.='</div>';



                        $lab = 'cover_image';

                        $fout.='<div class="setting">';
                        $fout.='<div class="label-for-ujarak">'.__("Cover Image").'</div>';
                        $fout.='<input type="text" name="'.$lab.'" class="input-ujarak-style" value="'.$player_db_args[$lab].'"/>';
                        $fout.='</div>';



                        $lab = 'author_id';

                        $fout.='<div class="setting">';
                        $fout.='<div class="label-for-ujarak">'.__("Published By ( ID )").'</div>';
                        $fout.='<input type="text" name="'.$lab.'" class="input-ujarak-style" value="'.$player_db_args[$lab].'"/>';
                        $fout.='</div>';



                        $lab = 'extra_html';

                        $fout.='<div class="setting">';
                        $fout.='<div class="label-for-ujarak">'.__("Extra HTML").'</div>';
                        $fout.='<input name="'.$lab.'" class="input-ujarak-style" value="'.htmlspecialchars($player_db_args[$lab]).'"/>';
                        $fout.='</div>';




                        $fout.='</div>';//--end .col-md-6
                        $fout.='</div>';//--end .row










                        $fout.="<h2>".__("Waveforms")."</h2>";










                        $fout.='<div class="row"><div class="col-md-6">';


                        $lab = 'waveform_bg';

                        $fout.='<div class="setting">';
                        $fout.='<div class="label-for-ujarak">'.__("Waveform Background").'</div>';

                        $fout.='<div class="container-with-input-and-button">';
                        $fout.='<span class="aux-wave-generator the-button"> <a class="btn-autogenerate-waveform-bg button button--secondary smaller-padding dashed-border"><span class="button-label">'.__('Auto Generate').'</span></a></span>';
                        $fout.='<div class="the-input-con">';
                        $fout.='<input type="text" name="'.$lab.'" class="input-ujarak-style waves-field-target" value="'.$player_db_args[$lab].'"/>';
                        $fout.='</div>';

                        $fout.='</div>';
                        $fout.='</div>';





                        $fout.='</div>';

                        $fout.='<div class="col-md-6">';



                        $lab = 'waveform_prog';

                        $fout.='<div class="setting">';
                        $fout.='<div class="label-for-ujarak">'.__("Waveform Progress").'</div>';

                        $fout.='<div class="container-with-input-and-button">';
                        $fout.='<span class="aux-wave-generator the-button"> <a class="btn-autogenerate-waveform-prog button button--secondary smaller-padding dashed-border"><span class="button-label">'.__('Auto Generate').'</span></a></span>';
                        $fout.='<div class="the-input-con">';
                        $fout.='<input type="text" name="'.$lab.'" class="input-ujarak-style waves-field-target" value="'.$player_db_args[$lab].'"/>';
                        $fout.='</div>';

                        $fout.='</div>';
                        $fout.='</div>';



                        $fout.='</div>';//--end .col-md-6
                        $fout.='</div>';//--end .row















                        $fout.="<h2>".__("Shop Options")."</h2>";








                        $fout.='<div class="row"><div class="col-md-6">';





                        $lab = 'is_buyable';

                        $fout.= DZSHelpers::generate_input_text($lab,array('id' => $lab, 'val' => 'off','input_type'=>'hidden'));
                        $fout.='<div class="setting">';
                        $fout.='<div class="label-for-ujarak">'.__("Is Buyable?").'</div>';


                        $fout.='<div class="dzscheckbox skin-nova">
                            '.DZSHelpers::generate_input_checkbox($lab,array('id' => $lab, 'val' => 'on','seekval' => $player_db_args[$lab])).'
                            <label for="'.$lab.'"></label>
                        </div>
';
                        $fout.='</div>';


                        $lab = 'download_link_new_tab';


                        $fout.= DZSHelpers::generate_input_text($lab,array('id' => $lab, 'val' => 'off','input_type'=>'hidden'));

                        $fout.='<div class="setting">';
                        $fout.='<div class="label-for-ujarak">'.__("Download link opens in new tab ?").'</div>';
//                        $fout.='<input type="text" name="'.$lab.'" class="input-ujarak-style" value="'.$player_db_args[$lab].'"/>';


                        $fout.='<div class="dzscheckbox skin-nova">
                            '.DZSHelpers::generate_input_checkbox($lab,array('id' => $lab, 'val' => 'on','seekval' => $player_db_args[$lab])).'
                            <label for="'.$lab.'"></label>
                        </div>
';
                        $fout.='</div>';











                        $fout.='</div>';





                        $fout.='<div class="col-md-6">';




                        $lab = 'price';

                        $fout.='<div class="setting">';
                        $fout.='<div class="label-for-ujarak">'.__("Price").'</div>';
                        $fout.='<input type="text" name="'.$lab.'" class="input-ujarak-style" value="'.$player_db_args[$lab].'"/>';
                        $fout.='</div>';


                        $lab = 'download_link';

                        $fout.='<div class="setting">';
                        $fout.='<div class="label-for-ujarak">'.__("Download Link").'</div>';
                        $fout.='<input type="text" name="'.$lab.'" class="input-ujarak-style" value="'.$player_db_args[$lab].'"/>';
                        $fout.='</div>';






                        $fout.='</div>';//--end .col-md-6
                        $fout.='</div>';//--end .row















                        $fout.='<button class="button button--secondary"><span class="button-label">'.__("Save").'</span></button>';
                        $fout.='<div class="delete-track-btn" data-playerid="'.$theid.'"><span>delete</span> <i class="fa fa-times-circle"></i></div>';

                        $fout.='</form>';


                        echo $fout;
                        ?>
                    </div>
                </div>





            </div>
            <script>
                jQuery(document).ready(function($){

                    $('#nestable3').nestable({
                        'maxDepth':3
                    });
                })
            </script>
            <?php
        }else{
            include_once('admin_parts/admin-tracks.php');

            part_tracks();
        }
    }



    if($page==='widget_stacks' ){



    if(($subpage!='none')){

        $page = 'widget_stacks';
        $pagetitle = __('Widget Stacks');
        ?>
        <div class="admin-wrap admin-wrap-for-widget_stacks">


            <?php
            echo generate_admin_header(array(

                'title'=> $pagetitle,
                'page'=>$page
            ));


            $args = array(
                'for_ajax'=>false
            );
            $menus = json_decode($dzspgb_forportal->ajax_select_pages_array($args));

            //        print_r($menus);

            ?>





            <div class="dzspb_lay_con">
                <div class="dzspb_layb_one_full">
                    <div class="admin-breadcrumps">
                        <a href="admin.php"><i class="fa fa-home"></i>&nbsp;&nbsp;Home</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;<span class="current-page" >Widget Stacks</span>
                    </div>
                </div>
            </div>
            <div class="dzspb_lay_con">



                <div class="dzspb_layb_one_third">
                    <div class="admin-block-container">
                        <div class="admin-block-container--header">
                            Pages
                        </div>
                        <div class="admin-block-container--content">
                            <p class="sidenote">Drag Pages into the Menu to the right</p>

                            <div class="admin-menu-pages">
                                <?php
                                foreach($menus as $menu){
//                            print_r($menu);

                                    echo '<label><input type="checkbox" name="checkbox" value="value" data-id="'.$menu->id.'" data-label="'.$menu->title.'" data-type="menupage" data-content=""><span>'.$menu->title.'</span></label>';
                                }



                                echo '<label class="custom-html"><input type="checkbox" name="checkbox" value="value" data-id="0" data-label="'.__('Custom HTML').'" data-type="customhtml" data-content=""><span>'.__('Custom HTML').'</span></label>';

                                ?>

                                <button class="button button--secondary button--border-thin button--text-thick insert-pages-in-menu"><span class="button-label"><?php echo __('Insert'); ?></span></button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="dzspb_layb_two_third">
                    <div class="admin-block-container">
                        <div class="admin-block-container--header">
                            Stack
                        </div>
                        <div class="admin-block-container--subheader">
                            Stack Name:
                        </div>
                        <div class="admin-block-container--content">
                            <div class="dd" id="nestable3" style="width: 100%; max-width: none; margin: 0 auto;">
                                <ol class="dd-list">
                                <?php


                                $page_data = $dzspgb_forportal->select_page($subpage,array(
                                    'post_type'=>'menu',
                                ));

//                                            print_r($page_data);


                                $data = $page_data['content'];

//                                echo $data;


                                $data_arr = json_decode($data);

//                                print_r($data_arr);


                                foreach($data_arr as $menuitem){

//                                    print_r($menuitem);

                                    echo '<li class="dd-item dd3-item" data-id="'.$menuitem->id.'" data-label="'.$menuitem->label.'" data-type="'.$menuitem->type.'" data-content="'.$menuitem->content.'"><div class="dd-handle dd3-handle">Drag</div><div class="dd3-content">'.$menuitem->label.'</div>';

                                    echo '<div class="extra-html">
                                    <h4>'.__("Content").'</h4><textarea name="item_content">';

                                    if($menuitem->content){
                                        $aux = $menuitem->content;

                                        $aux = str_replace(';quot;','"', $aux);
                                        $aux = str_replace('{replacequotquot}','"', $aux);

                                        echo $aux;
                                    }

                                    echo '</textarea>';



                                    echo '<h4>'.__("Extra Classes").'</h4><input type="text" name="extra_classes" value="';

                                    if(isset($menuitem->content) && $menuitem->content){
                                        $aux = $menuitem->extra_classes;

                                        $aux = str_replace('{replacequotquot}','"', $aux);

                                        echo $aux;
                                    }

                                    echo '"/>';




                                    echo '</div>';





                                    if(isset($menuitem->children) && is_array($menuitem->children)){

                                        echo '<ol class="dd-list">';
                                        foreach($menuitem->children as $mi2){

//                                            print_r($mi2);

                                            echo '<li class="dd-item dd3-item" data-id="'.$mi2->id.'" data-label="'.$mi2->label.'" data-type="'.$mi2->type.'" data-content="'.$mi2->content.'"><div class="dd-handle dd3-handle">Drag</div><div class="dd3-content">'.$mi2->label.'</div>';


                                            echo '<div class="delete-menuitem-con"><i class="fa fa-times"></i></div></li>';

                                            echo '</li>';


                                        }

                                        echo '</ol>';
                                    }
                                    echo '<div class="delete-menuitem-con"><i class="fa fa-times"></i></div></li>';

                                }

                                ?>
                                </ol>
                            </div>
                        </div>

                    </div>

                </div>
            </div>


            <div class="dzspgb-saver-con"><button class="dzspgb-saver-field dzspgb-button "><?php echo __('Save Menu');?></button></div>


        </div>
        <script>
            jQuery(document).ready(function($){

                $('#nestable3').nestable({
                    'maxDepth':1
                });
            })
        </script>
        <?php
    }else{
        include_once('admin_parts/admin-widget_stacks.php');

        part_widget_stacks();
    }
    }





    if($page==='apconfigs' ){



    if(($subpage!='none')){

        $page = 'menus';
        $pagetitle = __('Player Configs');
        ?>
        <div class="admin-wrap admin-wrap-for-apconfigs">


            <?php
            echo generate_admin_header(array(

                'title'=> $pagetitle,
                'page'=>$page
            ));


            $args = array(
                'for_ajax'=>false,
                'post_type'=>'vpconfig',
            );
            $menus = json_decode($dzspgb_forportal->ajax_select_pages_array($args));

            //        print_r($menus);

            $page_data = $dzspgb_forportal->select_page($subpage,array(
                'post_type'=>'apconfig',
            ));
            $config_settings = array();


            parse_str($page_data['content'],$config_settings);

//            print_r($config_settings);

            ?>




            <div class="dzspb_lay_con">
                <div class="dzspb_layb_one_full">
                    <div class="admin-breadcrumps">
                        <a href="admin.php"><i class="fa fa-home"></i>&nbsp;&nbsp;Home</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;<span class="current-page" >Menus</span>
                    </div>
                </div>
            </div>


            <form class="apconfig-form" action="" method="POST">
            <div class="dzspb_lay_con">
                <div class="dzspb_layb_one_half">

                    <h3><?php echo __('General Options', 'dzsap')?></h3>
                    <div class="setting styleme">
                        <div class="setting-label"><?php echo __('Audio Player Skin', 'dzsap')?></div>

                        <?php

                        $opts = array(
                            'skin-wave',
                            'skin-default',
                            'skin-minimal',
                            'skin-minion',
                            'skin-justthumbandbutton',
                            'skin-pro',
                            'skin-aria',
                            'skin-silver',
                        );

                        $lab = 'skin_ap';

                        echo DZSHelpers::generate_select($lab, array('options' => $opts, 'class' => 'dzs-style-me skin-beige   ', 'seekval' => $config_settings[$lab]));
                        ?>


                        <div class="sidenote"><?php echo __('choose a skin.', 'dzsap')?></div>
                    </div>
                    <div class="setting styleme">
                        <div class="setting-label"><?php echo __('Flash Backup', 'dzsap')?></div>


                        <?php

                        $opts = array(
                            'simple',
                            'full',
                        );

                        $lab = 'settings_backup_type';

                        echo DZSHelpers::generate_select($lab, array('options' => $opts, 'class' => 'dzs-style-me skin-beige   ', 'seekval' => $config_settings[$lab]));
                        ?>


                        <div class="sidenote"><?php echo __('the flash backup type that will appear for browsers that do not have mp3 support and no ogg file has been specified. simple is seamless but may be unstable, full shows the full flash player.', 'dzsap')?></div>
                    </div>
                    <div class="setting styleme">
                        <div class="setting-label"><?php echo __('Disable Volume', 'dzsap')?></div>


                        <?php

                        $opts = array(
                            'default',
                            'on',
                            'off',
                        );

                        $lab = 'disable_volume';

                        echo DZSHelpers::generate_select($lab, array('options' => $opts, 'class' => 'dzs-style-me skin-beige   ', 'seekval' => $config_settings[$lab]));
                        ?>

                        <div class="sidenote"><?php echo __('the flash backup type that will appear for browsers that do not have mp3 support and no ogg file has been specified. simple is seamless but unstable, full shows the full flash player.', 'dzsap')?></div>
                    </div>
                    <div class="setting styleme">
                        <div class="setting-label"><?php echo __('Enable Embed Button', 'dzsap')?></div>


                        <?php

                        $opts = array(
                            'off',
                            'on',
                        );

                        $lab = 'enable_embed_button';

                        echo DZSHelpers::generate_select($lab, array('options' => $opts, 'class' => 'dzs-style-me skin-beige   ', 'seekval' => $config_settings[$lab]));
                        ?>

                        <div class="sidenote"><?php echo __('enable a embed button for visitors to be able the embed the player on their sites.', 'dzsap')?></div>
                    </div>
                    <div class="setting styleme">
                        <div class="setting-label"><?php echo __('Preload Method', 'dzsap')?></div>


                        <?php

                        $opts = array(
                            'metadata',
                            'none',
                        );

                        $lab = 'preload_method';

                        echo DZSHelpers::generate_select($lab, array('options' => $opts, 'class' => 'dzs-style-me skin-beige   ', 'seekval' => $config_settings[$lab]));
                        ?>

                        <div class="sidenote"><?php echo __('preload metadata for faster play', 'dzsap')?></div>
                    </div>
                    <div class="setting type_all">
                        <div class="setting-label"><?php echo __('Play From', 'dzsap')?></div>
                        <?php

                        $lab = 'playfrom';
                        ?>
                        <input type="text" class="textinput mainsetting" name="<?php echo $lab; ?>" value="<?php echo $config_settings[$lab]; ?>"/>
                        <div class="sidenote"><?php echo __('This is a default setting, it can be changed individually per item ( it will be overwritten if set ) . - choose a number of seconds from which the track to play from ( for example if set "70" then the track will start to play from 1 minute and 10 seconds ) or input "last" for the track to play at the last position where it was.', 'dzsap')?></div>
                    </div>

                    <div class="setting type_all">
                        <div class="setting-labellabel"><?php echo __("Highlight Color"); ?></div>
                        <?php

                        $lab = 'colorhighlight';
                        ?>
                        <input type="text"  class="textinput mainsetting colorpicker-nohash with-colorpicker"  name="<?php echo $lab; ?>" value="<?php echo $config_settings[$lab]; ?>"/><div class="picker-con"><div class="the-icon"></div><div class="picker"></div></div>
                    </div>
                </div>
                <div class="dzspb_layb_one_half" style="top: -22px; padding-top: 22px; width: calc(50% - 17px);
    background-color: #E6ECEC;">



                    <h3><?php echo __('Skin-Wave Options', 'dzsap')?></h3>


                    <div class="setting styleme">
                        <div class="setting-label"><?php echo  __('Dynamic Waves', 'dzsap');?></div>


                        <?php

                        $opts = array(
                            'off',
                            'on',
                        );

                        $lab = 'skinwave_dynamicwaves';

                        echo DZSHelpers::generate_select($lab, array('options' => $opts, 'class' => 'dzs-style-me skin-beige   ', 'seekval' => $config_settings[$lab]));
                        ?>

                        <div class="sidenote"><?php echo  __('*only on skin-wave - dynamic waves that act on volume change', 'dzsap');?></div>
                    </div>

                    <div class="setting styleme">
                        <div class="setting-label"><?php echo  __('Button Style', 'dzsap');?></div>


                        <?php

                        $opts = array(
                            'default',
                            'button-aspect-noir',
                            'button-aspect-noir button-aspect-noir--filled',
                        );

                        $lab = 'button_aspect';

                        echo DZSHelpers::generate_select($lab, array('options' => $opts, 'class' => 'dzs-style-me skin-beige   ', 'seekval' => $config_settings[$lab]));
                        ?>

                        <div class="sidenote"><?php echo  __('*only on skin-wave - button aspect skin', 'dzsap');?></div>
                    </div>
                    <div class="setting styleme">
                        <div class="setting-label"><?php echo  __('Layout', 'dzsap');?></div>


                        <?php

                        $opts = array(
                            'default',
                            'alternate-layout',
                        );

                        $lab = 'skinwave_layout';

                        echo DZSHelpers::generate_select($lab, array('options' => $opts, 'class' => 'dzs-style-me skin-beige   ', 'seekval' => $config_settings[$lab]));
                        ?>

                        <div class="sidenote"><?php echo  __('*only on skin-wave - button aspect skin', 'dzsap');?></div>
                    </div>
                    <div class="setting styleme">
                        <div class="setting-label"><?php echo  __('Enable Spectrum', 'dzsap');?></div>


                        <?php

                        $opts = array(
                            'off',
                            'on',
                        );

                        $lab = 'skinwave_enablespectrum';

                        echo DZSHelpers::generate_select($lab, array('options' => $opts, 'class' => 'dzs-style-me skin-beige   ', 'seekval' => $config_settings[$lab]));
                        ?>

                        <div class="sidenote"><?php echo  __('*only on skin-wave - enable a realtime spectrum analyzer instead of the static generated waveform / the file must be on the same server for security issues', 'dzsap');?></div>
                    </div>
                    <div class="setting styleme">
                        <div class="setting-label"><?php echo  __('Enable Reflect', 'dzsap');?></div>


                        <?php

                        $opts = array(
                            'on',
                            'off',
                        );

                        $lab = 'skinwave_enablereflect';

                        echo DZSHelpers::generate_select($lab, array('options' => $opts, 'class' => 'dzs-style-me skin-beige   ', 'seekval' => $config_settings[$lab]));
                        ?>

                        <div class="sidenote"><?php echo  __('*only on skin-wave - enable a small reflection of the waves / spectrum', 'dzsap');?></div>
                    </div>
                    <div class="setting styleme">
                        <div class="setting-label"><?php echo  __('Enable Commenting', 'dzsap');?></div>


                        <?php

                        $opts = array(
                            'off',
                            'on',
                        );

                        $lab = 'skinwave_comments_enable';

                        echo DZSHelpers::generate_select($lab, array('options' => $opts, 'class' => 'dzs-style-me skin-beige   ', 'seekval' => $config_settings[$lab]));
                        ?>

                        <div class="sidenote"><?php echo  __('*only on skin-wave - enable time-based commenting', 'dzsap');?></div>
                    </div>
                    <div class="setting styleme">
                        <div class="setting-label"><?php echo  __('Mode', 'dzsap');?></div>

                        <?php

                        $opts = array(
                            array(
                                'lab'=>__('Normal'),
                                'val'=>'normal',
                            ),
                            array(
                                'lab'=>__('Slick'),
                                'val'=>'small',
                            ),
                            array(
                                'lab'=>__('Alternate'),
                                'val'=>'alternate',
                            ),
                        );

                        $lab = 'skinwave_mode';

                        echo DZSHelpers::generate_select($lab, array('options' => $opts, 'class' => 'dzs-style-me skin-beige   ', 'seekval' => $config_settings[$lab]));
                        ?>

                        <div class="sidenote"><?php echo  __('choose the normal or slick theming', 'dzsap');?></div>
                    </div>
                </div>
            </div>
            </form>


            <hr/>


            <div class="dzstoggle toggle1" rel="">
                <div class="toggle-title" style=""><?php echo  __('Skin-Wave Options', 'dzsap');?></div>
                <div class="toggle-content">

                </div>
            </div>



            <div class="dzspgb-saver-con"><button class="dzspgb-saver-field dzspgb-button "><?php echo __('Save Config');?></button></div>


        </div>

        <?php
    }else{
        include_once(dirname(__FILE__).'/admin_parts/admin-apconfigs.php');

        part_apconfigs();
    }
    }

    if($page=='settings'){
        include_once(dirname(__FILE__).'/admin_parts/admin-settings.php');

        part_settings();
    }
    if($page=='user_roles'){
        include_once(dirname(__FILE__).'/admin_parts/admin-user_roles.php');

        part_user_roles();
    }
    if($page=='importdata'){
        include_once(dirname(__FILE__).'/admin_parts/admin-importdata.php');

        part_importdata();
    }
    ?>

    <div class="feedbacker"><i class="fa fa-circle-o-notch fa-spin"></i> Loading... </div>
    <script src="colorpicker/farbtastic.js" type="text/javascript"></script>
    <link rel='stylesheet' type="text/css" href="colorpicker/farbtastic.css"/>
    <script src="libs/audioplayer/audioplayer.js" type="text/javascript"></script>
    <script src="js/main.js"></script>
    <script src="admin/admin.js" type="text/javascript"></script>
        <script src="js/jquery.nestable.js"></script>
    <script src="libs/dzsselector/dzsselector.js" type="text/javascript"></script>
    <link rel='stylesheet' type="text/css" href="libs/dzsuploader/upload.css"/>
<!--    <script src="dzscheckbox/dzscheckbox.js" type="text/javascript"></script>-->
    <link rel='stylesheet' type="text/css" href="libs/dzscheckbox/dzscheckbox.css"/>
    <script src="libs/dzsuploader/upload.js" type="text/javascript"></script>
    <link rel='stylesheet' type="text/css" href="libs/dzsiconselector/dzsiconselector.css"/>
    <script type="text/javascript" src="libs/dzsiconselector/dzsiconselector.js"></script>
    <link rel='stylesheet' type="text/css" href="libs/dzstoggle/dzstoggle.css"/>
    <script type="text/javascript" src="libs/dzstoggle/dzstoggle.js"></script>


    </body>
</html>

<?php




if(file_exists(dirname(__FILE__).'/config.php')){

    require_once(dirname(__FILE__).'/config.php');
}else{


    require_once(dirname(__FILE__).'/admin_parts/admin-install.php');

    die();
}

if(function_exists('str_replace_first')==false){
    function str_replace_first($from, $to, $subject){
        $from = '/'.preg_quote($from, '/').'/';

        return preg_replace($from, $to, $subject, 1);
    }
}

$scripts_tobeloaded = array();
$styles_tobeloaded = array();
if(function_exists('enqueue_script')==false){

    function enqueue_script($arglab, $argval){

        global $scripts_tobeloaded;

        foreach($scripts_tobeloaded as $script){
            if($script['lab']===$arglab){
                return false;
            }
        }

        $aux = array('lab'=>$arglab,'val'=>$argval,);

        array_push($scripts_tobeloaded, $aux);
    }
}
if(function_exists('enqueue_style')==false){

    function enqueue_style($arglab, $argval){

        global $styles_tobeloaded;

        foreach($styles_tobeloaded as $script){
            if($script['lab']===$arglab){
                return false;
            }
        }

        $aux = array('lab'=>$arglab,'val'=>$argval,);

        array_push($styles_tobeloaded, $aux);
    }
}

if(function_exists('__')==false){
    function __($arg='',$arg2=''){

        if($arg===''){
            return '';
        }

        if(function_exists("_")){
            return _($arg);
        }else{
            return $arg;
        }

    }
}


//This function is used to encrypt data.
if(function_exists('simple_encrypt')==false) {
    function simple_encrypt($text, $salt = "20"){


        if(strlen($salt)>16){
            $salt = substr($salt, 0 ,16);
        }
        if($salt=='' || strlen($salt)!=16){
            $salt = '1111222233334444';
        }

        return trim(base64_encode(mcrypt_encrypt(MCRYPT_RIJNDAEL_256, $salt, $text, MCRYPT_MODE_ECB, mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB), MCRYPT_RAND))));
    }
}
// This function will be used to decrypt data.
if(function_exists('simple_decrypt')==false) {
    function simple_decrypt($text, $salt = ""){

        if(strlen($salt)>16){
            $salt = substr($salt, 0 ,16);
        }
        if($salt=='' || strlen($salt)!=16){
            $salt = '1111222233334444';
        }
        return trim(mcrypt_decrypt(MCRYPT_RIJNDAEL_256, $salt, base64_decode($text), MCRYPT_MODE_ECB, mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB), MCRYPT_RAND)));
    }
}

if(function_exists('sortByViews')==false) {
    function sortByViews($a, $b)
    {
        return $a['views'] - $b['views'];
    }
}
if(function_exists('sortByLikes')==false) {
    function sortByLikes($a, $b)
    {
        return $a['likes'] - $b['likes'];
    }
}
if(function_exists('sortByTagCount')==false) {
    function sortByTagCount($a, $b)
    {
        return $a['tag_count'] - $b['tag_count'];
    }
}


if(function_exists('sort_by_published_date')==false) {
    function sort_by_published_date($a, $b) {
        $t1 = 2;
        $t2 = 1;
        if(isset($a['published_date'])){

            $t1 = strtotime($a['published_date']);
            $t2 = strtotime($b['published_date']);
        }
        return $t2 - $t1;
    }
}
if(function_exists('sort_by_date')==false) {
    function sort_by_date($a, $b) {
        $t1 = strtotime($a['date']);
        $t2 = strtotime($b['date']);
        return $t2 - $t1;
    }
}






$dzspgb_templates = array();
$dzspgb_shortcodes=array();


$primary_dir = 'shortcodes';
/* looping elements. */



if ($handle2 = opendir($primary_dir)) {

    while (false !== ($entry = readdir($handle2))) {


        if ($entry == '.' || $entry == '..' || $entry == '.DS_Store') {
            continue;
        }


        $auxfile = $primary_dir . '/' . $entry;

        if (file_exists($auxfile)) {
            include_once($auxfile);
        }

    }
}



$primary_dir = 'elements';
if ($handle3 = opendir($primary_dir)) {

    while (false !== ($entry = readdir($handle3))) {


        if ($entry == '.' || $entry == '..' || $entry == '.DS_Store') {
            continue;
        }


        $auxfile = $primary_dir . '/' . $entry;
//        print_r($auxfile);
//			error_log('ceva'.$auxfile.'alceva');

        if (file_exists($auxfile)) {
            include_once($auxfile);
        }

    }
}




class DZSAP_Portal {

    public $url_portalphp = '';
    public $currPage = 'normal';
    public $currPageId = 0;
    public $track_id = 0;
    public $currPage_type = 'normal';


    public $currUserId = '0';
    public $jsapid = 0;
    public $jsagid = 0;
    public $currUser = null;
    public $dblink = null;
    private $userAvatar = '';
    public $notices_html = '';
    public $notices_array = array();
    public $path_base = '';
    public $url_base = '';

    public $cart_arr = array();

    public $optional_url_base = '';

    public $main_config_settings;


    public $hooks = array();

    public $main_settings = array();
    public $main_settings_default = array();

    public $functional_do_shortcode_call_index = 0;

    public $query_params = array();
    public $query1 = '';
    public $query2 = '';
    public $query3 = '';
    public $query4 = '';
    public $query2_processed = '';
    public $last_user_meta;
    public $site_encryption_key;

    public $target_user_id = 0; // -- for plugin actions

    public $action_submit_track_data = array();


    public $translate_free = '';
    public $current_uploaded_file_path = '';
    public $translate_drag_drop = '';

    public $number_of_pro_account_options = 0;


    public $user_types = array();
    public $user_roles = array();
    public $user_capabilities = array();

    public $page_user_use_slashes = true;
    public $page_user_show_count = true;



    function __construct() {
        global $dzsap_config;


        $this->main_config_settings = $dzsap_config;

        $this->path_base = dirname(__FILE__).'/';

        $this->url_portalphp = $this->main_config_settings['url_portalphp'];




        $loca = explode("?",dzs_curr_url());
        $loc = $loca[0];

//        print_r($_SERVER);

//        echo $loc;

        if(strpos($loc, 'index.php')===false){

            if(strpos($loc, 'admin.php')===false){

            }else{
                $loc = substr($loc,0,strlen($loc) - 10);
            }
        }else{
            $loc = substr($loc,0,strlen($loc) - 10);
        }
        $basepath_location = $this->path_base."db/location.txt";
        $aux = '';

        $this->url_base = $loc;

//        echo strrpos($this->url_base,'/'). ' ' . strlen($this->url_base);
        if(strrpos($this->url_base,'/')!==strlen($this->url_base)-1){
            $this->url_base = $this->url_base.'/';
        }

//        echo $this->url_base;
        $this->user_types = array(
            array(
                'label'=>__("User"),
                'value'=>'user',
            ),
            array(
                'label'=>__("Pro"),
                'value'=>'pro',
            ),
            array(
                'label'=>__("Admin"),
                'value'=>'admin',
            ),
        );
//        echo $this->url_base;
        $this->user_capabilities = array(
            array(
                'label'=>__("Upload Tracks"),
                'value'=>'upload_tracks',
            ),
            array(
                'label'=>__("Statistics Access"),
                'value'=>'track_stats',
            ),
//            array(
//                'label'=>__("Own watermark"),
//                'value'=>'own_watermark',
//            ),
            array(
                'label'=>__("Download Free Track"),
                'value'=>'download_free_track',
            ),
            array(
                'label'=>__("Sell Track"),
                'value'=>'sell_track',
            ),
            array(
                'label'=>__("Allow to Submit for Track Free Download"),
                'value'=>'place_track_free_download',
            ),
            array(
                'label'=>__("Force submitting into free download"),
                'value'=>'force_submit_free_download',
            ),
        );

        $this->translate_free = __("Free");
        $this->translate_drag_drop = __("drag &amp; drop the file 2 ");

        $this->main_settings_default = array(
            'extra_css'=>'',


            'skinwave_wave_mode' => 'canvas',
            'skinwave_wave_mode_canvas_reflection_size' => '0.25',
            'skinwave_wave_mode_canvas_waves_number' => '3',
            'pcm_data_try_to_generate' => 'on',

            'color_waveformbg'=>'#111111',
            'color_waveformprog'=>'#ef6b13',
            'waveformgenerator_multiplier'=>'1',
            'logo'=>'img/logo.png',
            'logo_max_width'=>'',
            'logo_max_height'=>'',
            'default_thumb'=>'http://dummyimage.com/300x300/3d363d/707180',
            'has_default_thumb_on_empty_tracks'=>'off',
            'translate_free'=>'',
            'home_is_stream'=>'off',
            'use_ajax'=>'on',
            'download_ad_link'=>'',
            'use_parallaxer'=>'off',
            'debug_pagebuilder'=>'off',
            'use_pretty_links'=>'off',
            'paths_are_absolute'=>'off',
            'footer_player_config'=>'off',
            'soundcloud_api_key'=>'',
            'autoplay_next'=>'on',
            'api_google_recapcha_secret'=>'',
            'api_google_recapcha_sitekey'=>'',
            'api_facebook_app_id'=>'',
            'api_facebook_app_secret'=>'',
            'developer_paypal_sandbox_mode'=>'off',
            'enable_shop'=>'on',
            'paypal_use_author_email'=>'on',
            'add_to_cart_str'=>'',
            'google_fonts_enable'=>'on',
            'gzip_start_styles'=>'off',
            'enable_user_credit'=>'off',
            'tags_suggested'=>'hip-hop,rap,dance,electro,dubstep,100bpm',
            'tags_allow_only_suggested'=>'off',
            'tags_max_nr'=>'5',
            'allow_register'=>'on',
            'new_users_need_verification'=>'off',
            'enable_reposts'=>'on',
            'comments_allow_post_if_not_logged_in'=>'on',
            'likes_allow_post_if_not_logged_in'=>'on',
            'play_remember_time'=>'120',
            'cache_album_download'=>'off',
            'enable_notifications'=>'on',
            'disable_commenting'=>'off',
            'delete_track_on_track_removal'=>'on',
            'delete_previous_upload'=>'on',
            'mail_user_on_register'=>'on',
            'mail_on_register'=>'on',
            'pro_account_price'=>'',
            'pro_account_price_90'=>'',
            'pro_account_price_year'=>'',
            'upload_limit_normal'=>'100',
            'upload_limit_pro'=>'500',
            'upload_nr_limit_normal'=>'5',
            'upload_nr_limit_pro'=>'25',
            'allow_only_logged_in_users_to_download_free_tracks'=>'off',
            'theme'=>'theme-default',
            'paypal_receiver_account'=>'digitalzoomstudio@gmail.com',
            'paypal_currency_code'=>'USD',
            'lang_1_text'=>'English',
            'lang_1_img'=>'img/usa.png',
            'lang_1_code'=>'en_EN',
            'lang_1_is_rtl'=>'',
            'lang_2_text'=>'Germany',
            'lang_2_img'=>'img/germany.png',
            'lang_2_code'=>'da_DK',
            'lang_2_is_rtl'=>'',
            'lang_3_text'=>'Spain',
            'lang_3_img'=>'img/spain.png',
            'lang_3_code'=>'es_ES',
            'lang_3_is_rtl'=>'',
            'lang_4_text'=>'',
            'lang_4_img'=>'',
            'lang_4_code'=>'',
            'lang_4_is_rtl'=>'',
            'lang_5_text'=>'',
            'lang_5_img'=>'',
            'lang_5_code'=>'',
            'lang_5_is_rtl'=>'',
            'lang_6_text'=>'',
            'lang_6_img'=>'',
            'lang_6_code'=>'',
            'lang_6_is_rtl'=>'',
            'url_base'=>'',
            'currency_label'=>'$',
            'www_handle'=>'',
            'site_title'=>'ZoomPortal',
            'site_encryption_key'=>'',
            'bitrate_limit_upload'=>'',
            'bitrate_limit_watermark'=>'',
            'ga_tracking_code'=>'',
            'enable_facebook_share'=>'on',
            'enable_twitter_share'=>'on',
            'enable_google_share'=>'on',
            'enable_linkedin_share'=>'on',
            'enable_pinterest_share'=>'on',
            'tls_protocol'=>'',
            'ssl_protocol'=>'',
            'active_plugins'=>'',
            'mail_type'=>'mail',
            'mail_target'=>$this->main_config_settings['admin_email'],
            'mail_sender'=>$this->main_config_settings['admin_email'],
            'smtp_host'=>'smtp.gmail.com',
            'smtp_port'=>'587',
            'smtp_username'=>'',
            'smtp_password'=>'',
            'str_likes_part1'=>'<span class=" btn-zoomsounds btn-like"><span class="the-icon"><svg xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" version="1.0" width="15" height="15" viewBox="0 0 645 700" id="svg2"> <defs id="defs4"></defs> <g id="layer1"> <path d="M 297.29747,550.86823 C 283.52243,535.43191 249.1268,505.33855 220.86277,483.99412 C 137.11867,420.75228 125.72108,411.5999 91.719238,380.29088 C 29.03471,322.57071 2.413622,264.58086 2.5048478,185.95124 C 2.5493594,147.56739 5.1656152,132.77929 15.914734,110.15398 C 34.151433,71.768267 61.014996,43.244667 95.360052,25.799457 C 119.68545,13.443675 131.6827,7.9542046 172.30448,7.7296236 C 214.79777,7.4947896 223.74311,12.449347 248.73919,26.181459 C 279.1637,42.895777 310.47909,78.617167 316.95242,103.99205 L 320.95052,119.66445 L 330.81015,98.079942 C 386.52632,-23.892986 564.40851,-22.06811 626.31244,101.11153 C 645.95011,140.18758 648.10608,223.6247 630.69256,270.6244 C 607.97729,331.93377 565.31255,378.67493 466.68622,450.30098 C 402.0054,497.27462 328.80148,568.34684 323.70555,578.32901 C 317.79007,589.91654 323.42339,580.14491 297.29747,550.86823 z" id="path2417" style=""></path> <g transform="translate(129.28571,-64.285714)" id="g2221"></g> </g> </svg> </span><span class="the-label hide-on-active">{{translate_like}}</span><span class="the-label show-on-active">{{translate_liked}}</span></span>',
            'str_likes_part2' => '<div class="counter-likes"><i class="fa fa-heart"></i><span class="the-number">{{get_likes}}</span></div>',
            'str_views' => '<a  class="counter-comments ajax-link  custom-a" href="{{posturl}}#comments" ><i class="fa fa-comments"></i><span class="the-number">{{get_comments_nr}}</span></a><div class="counter-hits"><i class="fa fa-play"></i><span class="the-number">{{get_plays}}</span></div>',
            'str_rates' => '<div class="counter-rates"><span class="the-number">{{get_rates}}</span> rates</div>',
            'mail_template_new_user' => '<p>' . sprintf(__("new user registered %s user - %s"), '<br>', '{{theemail}}') . '</p>',
            'mail_template_admin_new_user' => '<p>' . sprintf(__("new user registered %s user - %s"), '<br>', '{{theemail}}') . '</p>',
            'mail_template_forgot_password' => '<p><strong>'.__("Click this link to change password").':</strong> {{thelink}}</p>',
            'mail_template_verify_account' => '<p><strong>'.__("Click this link to verify email").':</strong> '.'{{thelink}}'.'</p>',
            'mail_template_login_details' => '<p>'.sprintf(__("you registered %s user - %s %s password - %s"),'<br>', '{{theemail}}', '<br>', '{{thepassword}}').'</p>',
            'mail_template_new_like' => '<p>'.sprintf(__("New like from user %s on %strack %s"), '{{theusername}}', ' ','{{thetrackid}}').'</p>',
            'mail_template_new_comment' => '<p>'.sprintf(__("New comment from user %s on track %s"), '{{theusername}}', '{{thetrackid}}').'</p>',
            'mail_template_new_purchase' => '<p><strong>'.__("You just purchased").':</strong> <a href="'.'{{thelink}}'.'">'.'{{thetrackname}}'.'</a></p>',
        );



        if (isset($_GET['page'])) {
            $this->currPage = $_GET['page'];
        }

        if (isset($_COOKIE['currUserId'])) {
            $this->currUserId = $_COOKIE['currUserId'];
//            setcookie("username",$this->currUserId,time() + 3600);
        }

        if (isset($_SESSION['currUserId'])) {
            $this->currUserId = $_SESSION['currUserId'];
            setcookie("currUserId",$this->currUserId,time() + 3600);
//            $_COOKIE['currUserId'] = $this->currUserId
        }




//        print_r($_COOKIE);
//        print_r($_SESSION);
//
//        echo 'eeva - '.$this->currUserId;

        $this->connect_database();



        if($this->currUserId){
            $this->currUser = $this->get_user($this->currUserId);
        }


        $this->main_settings = $this->select_mainsettings_array();


        if(isset($this->main_settings['url_base']) && $this->main_settings['url_base']){
            $this->url_base = $this->main_settings['url_base'];

            $pos = strrpos($this->url_base,'/');

//            echo 'pos - '.$pos.' strlen - '.strlen($this->url_base);

            if(strrpos($this->url_base,'/') !== strlen($this->url_base)-1 ){

                $this->url_base.='/';

            }
        }

//        echo 'url base - '.$this->url_base;






//        $this->main_settings['active_plugins'] = json_decode($this->main_settings['active_plugins']);

//        print_r($this->main_settings['active_plugins']);


        if(is_array($this->main_settings['active_plugins'])==false){
            $this->main_settings['active_plugins'] = array();
        }


        if($this->main_settings['translate_free']){
            $this->translate_free = $this->main_settings['translate_free'];
        }

        if($this->main_settings['pro_account_price']){
            $this->number_of_pro_account_options++;
        }
        if($this->main_settings['pro_account_price_90']){
            $this->number_of_pro_account_options++;
        }

        if($this->main_settings['pro_account_price_year']){
            $this->number_of_pro_account_options++;
        }
        if($this->main_settings['site_encryption_key']==''){
            $this->site_encryption_key='1111222233334444';
        }else{
            $this->site_encryption_key = $this->main_settings['site_encryption_key'];
        }

        if(isset($this->main_config_settings['theme'])){
            $this->main_settings['theme'] = $this->main_config_settings['theme'];
        }
        if(isset($this->main_config_settings['url_base'])){
            $this->main_settings['url_base'] = $this->main_config_settings['url_base'];
        }


        if($this->main_settings['use_pretty_links']=='on'){
            $this->main_settings['paths_are_absolute']='on';



            $ok = true;
            if(isset($this->main_settings['url_base']) && $this->main_settings['url_base']){

                $ok = true;
            }else{

                $this->main_settings['use_pretty_links']='off';
                $ok = false;



                $arr = array(
                    'notice_type' => 'registration_error',
                    'notice_for' => 'content_section',
                    'notice_html' => '<div class="alert alert-danger">'.__("You need to set URL Base for pretty links to work").'</div>',
                );

                array_push($this->notices_array, $arr);

//                echo 'hmm';

            }


            if($ok){

//            print_r($_SERVER);
                $self_uri = $_SERVER['SCRIPT_NAME'];

                $request = $_SERVER['REQUEST_URI'];
//            echo '$self_uri - '.$self_uri.'<-';
                if(strpos($self_uri, 'index.php')!==false){

                    $self_uri = str_replace('index.php','',$self_uri);


                    $request  = str_replace_first($self_uri, "",$request );
                }

                #split the path by '/'

//            echo $request.' ';
                $this->query_params     = explode("/", $request);

//            echo ' query params - '; print_r($this->query_params);

                if(isset($this->query_params[0])){
                    $this->query1 = $this->query_params[0];
                }
                if(isset($this->query_params[1])){
                    $this->query2 = $this->query_params[1];
                }
                if(isset($this->query_params[2])){
                    $this->query3 = $this->query_params[2];
                }
                if(isset($this->query_params[3])){
                    $this->query4 = $this->query_params[3];
                }


//                print_r($this->query_params);


            }



        }


        if($this->main_settings['paths_are_absolute']=='on'){
            $this->optional_url_base = $this->url_base;
        }

        $auxa = $this->get_setting('user_roles');

        if($auxa){

            $this->user_roles = (json_decode($auxa,true));
        }else{

            $aux = '{"user":["upload_tracks","download_free_track"],"pro":["upload_tracks","track_stats","sell_track"],"admin":["upload_tracks","track_stats","download_free_track","sell_track"]}';
            $this->update_setting('user_roles', $aux, array(
                'from_ajax'=>false
            ));
            $this->user_roles = (json_decode($auxa,true));
        }



//        print_r($this->main_settings['active_plugins']);


//        dzspap_load_plugins();


        if(isset($_COOKIE['dzspor_cart'])==false){
            $defcart_arr = array();

//            $_COOKIE[] = serialize($defcart_arr);


            setcookie('dzspor_cart', serialize($defcart_arr), time()+(24*3600));
        }else{

        }

//        print_r($_SESSION);

//        print_r($_COOKIE);

        if(isset($_COOKIE['dzspor_cart'])){

            $this->cart_arr = unserialize($_COOKIE['dzspor_cart']);
        }

//        print_r($this->cart_arr);







//        $this->backup_tables();



//        print_r($this->cart_arr);
    }


    function add_action($arglab = '', $argfunc=''){
        $aux_arr = array();


        if(isset($this->hooks[$arglab])){
            $aux_arr = $this->hooks[$arglab];
        }

        if(is_array($aux_arr)==false){
            $aux_arr = array();
        }

        array_push($aux_arr, $argfunc);


        $this->hooks[$arglab] = $aux_arr;


    }


    function do_action($arglab = '', $argfunc=''){



//        print_r($this->hooks);
        if(isset($this->hooks[$arglab])){
            if(is_array($this->hooks[$arglab])){


                foreach ($this->hooks[$arglab] as $func){
                    $func();
                }
            }
        }



    }



    function get_theheaders() {
        //$headers = array();
        //print_r($_SERVER);
        return $_SERVER;
    }

    function human_filesize($bytes, $decimals = 2) {
        $size = array('B','kB','MB','GB','TB','PB','EB','ZB','YB');
        $factor = floor((strlen($bytes) - 1) / 3);
        return sprintf("%.{$decimals}f", $bytes / pow(1024, $factor)) . @$size[$factor];
    }


    function clean($string) {
        $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.

        return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
    }


    function seo_friendly_url($string){
        $string = str_replace(array('[\', \']'), '', $string);
        $string = preg_replace('/\[.*\]/U', '', $string);
        $string = preg_replace('/&(amp;)?#?[a-z0-9]+;/i', '-', $string);
        $string = htmlentities($string, ENT_COMPAT, 'utf-8');
        $string = preg_replace('/&([a-z])(acute|uml|circ|grave|ring|cedil|slash|tilde|caron|lig|quot|rsquo);/i', '\\1', $string );
        $string = preg_replace(array('/[^a-z0-9]/i', '/[-]+/') , '-', $string);
        return strtolower(trim($string, '-'));
    }
    function clean_mp3($string){
        // Strip HTML Tags
        $string=preg_replace('/[^A-Za-z0-9 _\-\+\&]/','',$string);

        return $string;
    }

    function check_post() {
        global $dzsap_config;

        $headers = $this->get_theheaders();


//        print_r($headers);

        // -- upload
        if (isset($headers['HTTP_X_FILE_NAME'])) {

//            echo 'hmm';


            if($this->currUserId>0){

                $disallowed_filetypes = array('.php', '.exe', '.htaccess', '.asp', '.py', '.jsp', '.pl', '.phtml', '.ptxt');



//
                $allowed_filetypes = array('.jpg','.jpeg','.png','.gif','.tiff','.mp4','.m4v','.ogg','.ogv','.webm','.sql','.mp3','.wav','.m4a');
                $upload_dir = dirname(__FILE__) . '/upload/';



                error_log('headers - '.print_rr($headers,array(
                        'echo'=>false,
                    ))) ;
                $file_name = $headers['HTTP_X_FILE_NAME'];
                $file_name = str_replace(" ", "_", $file_name); // strip spaces
//                $target = $upload_dir . "/" . $file_name;
                $target = $file_name;


                //==== checking for disallowed file types
                $sw = true;

                foreach ($allowed_filetypes as $dft) {
//            print_r($dft);
                    $pos = strpos(strtolower($file_name), $dft);


//            error_log($pos);
                    if ($pos > strlen($file_name)-6) {
                        $sw = false;
                    }
                }




                if ($sw == true) {
                    die('<div class="error">invalid extension - disallowed_filetypes</div>');
                }

                if (!is_writable($upload_dir)) {
                    die('<div class="error">dir not writable - check permissions</div>');
                }

                $auxindex = 0;

//                echo '$file_name - '.$file_name;
//                $file_name = $this->seo_friendly_url($file_name);
//                $file_name = $this->clean_mp3($file_name);
                $auxname = $file_name;
                $auxpath = $target;


                $arr_nams = explode('.',$file_name);

                $file_lab = '';
                $file_ext = '';

                for($i=0;$i<count($arr_nams);$i++){
                    if($i<count($arr_nams)-1){

                        $file_lab.=$this->clean_mp3($arr_nams[$i]);
                    }else{
                        $file_ext = $arr_nams[$i];
                    }
                }


                $target = $file_lab.'.'.$file_ext;
//                error_log("target - ".$target);
//                error_log('$file_name - '.$file_name);
                error_log('$upload_dir.$target - '.($upload_dir.$target));

//                $path_dir = $this->path_base.'upload/';
//                $path_dir = '';



                if(file_exists($upload_dir.$auxpath)){

//            die('<div class="error">file already exists</div>');


                    $breaker = 150;
                    while(file_exists($upload_dir.$auxpath)===true){
                        $auxindex++;

                        $auxpath = $file_lab.'_'.$auxindex.'.'.$file_ext;
                        $auxname = $file_lab.'_'.$auxindex.'.'.$file_ext;
//                        error_log('$auxpath - '.$auxpath);
//                        error_log('$auxname - '.$auxname);

                        $breaker--;
                        if($breaker<0){
                            break;
                        }
                    }
                }

//                error_log("target semifinal - ".$target);
                $target = $auxpath;

//                error_log("target semifinal - ".$target);


                //echo $target;
                $content = file_get_contents("php://input");



                $filesize = 0;

                try{

                    error_log("target final - ".$target);
//                    error_log('$_SERVER[\'CONTENT_LENGTH\'] - '.$_SERVER['CONTENT_LENGTH']);

//                    $filesize = $_SERVER['CONTENT_LENGTH'];
//                    $filesize = filesize($target);
                } catch (Exception $ex) {

                    error_log('filesize does not work .. why ? '. print_rr($ex, array('echo'=>false)));
                }

                $filesize = $_FILES['myfile']['size'];




                $limit = $this->main_settings['upload_limit_normal'];

                $caps = $this->get_user_capabilities($this->currUserId);

                if(in_array('proaccount',$caps)){
                    $limit = $this->main_settings['upload_limit_pro'];
                }
                if(in_array('admin',$caps) ){
                    $limit = 50000;
                }




                if($limit=='unlimited'){
                    $limit = 50000;
                }else{

                    $limit = intval($limit);

                }




//                echo 'is admin - '.in_array('admin',$caps);

                if($limit=='0.1' && in_array('admin',$caps)==false){

                    die('error - '.__('this is demo mode, you cannot upload'));
                }
                if($this->get_user_total_uploaded($this->currUserId) + intval($filesize) > intval($limit) * 1048576){

                    die('error - '.__('no more space available')) . ' / '.__("upgrade to PRO");

                }






                $this->current_uploaded_file_path = $upload_dir.$target;
                error_log('$this->current_uploaded_file_path -  '.$this->current_uploaded_file_path);


//                print_r($_FILES);


//                print_r($_FILES);
                if(move_uploaded_file($_FILES['myfile']['tmp_name'], $upload_dir.$target)){

                }else{

                    die('<div class="error">error at file_put_contents</div>');
                }

                if(isset($headers['HTTP_X_UPLOAD_FROM'])){

                    if($this->main_settings['delete_previous_upload']=='on'){
                        if($headers['HTTP_X_UPLOAD_FROM']=='change-user-media'||$headers['HTTP_X_UPLOAD_FROM']=='main-mp3'){

                            if(isset($headers['HTTP_X_UPLOAD_LAST_VAL']) && $headers['HTTP_X_UPLOAD_LAST_VAL']){

                                unlink($headers['HTTP_X_UPLOAD_LAST_VAL']);

                            }
                        }
                    }

                }


                $this->do_action("after_track_upload");
                echo 'success - file written {{filename-'.$auxname.'}} {{filesize-'.$filesize.'}}';




                /*
               if (file_put_contents($upload_dir.$target, $content)) {
//                    file_put_contents($target, $content);
                    $filesize = filesize($upload_dir.$target);




                    if(isset($headers['HTTP_X_UPLOAD_FROM'])){

                        if($this->main_settings['delete_previous_upload']=='on'){
                            if($headers['HTTP_X_UPLOAD_FROM']=='change-user-media'||$headers['HTTP_X_UPLOAD_FROM']=='main-mp3'){

                                if(isset($headers['HTTP_X_UPLOAD_LAST_VAL']) && $headers['HTTP_X_UPLOAD_LAST_VAL']){

                                    unlink($headers['HTTP_X_UPLOAD_LAST_VAL']);

                                }
                            }
                        }

                    }


                    $this->do_action("after_track_upload");
                    echo 'success - file written {{filename-'.$auxname.'}} {{filesize-'.$filesize.'}}';
                } else {
                    die('<div class="error">error at file_put_contents</div>');
                }
                */
                die();
            }else{

                die('<div class="error">error - not logged in</div>');
            }

            die();
        }
        if(isset($_GET['upload_from_dzs']) && $_GET['upload_from_dzs']=='on'){
            die("not for direct access");
        }


        if(isset($_GET['st']) && $_GET['st']==='Completed'){

            $this->cart_arr = array();
            setcookie('dzspor_cart', serialize(array()), time()+7200);
        }


        if(isset($_GET['activate_plugin']) && $_GET['activate_plugin']){
//            echo $_GET['activate_plugin'];

            $user_caps = $this->get_user_capabilities($this->currUserId);

            if(in_array('admin', $user_caps)){


                if(in_array($_GET['activate_plugin'],$this->main_settings['active_plugins'])==false){

                    array_push($this->main_settings['active_plugins'], $_GET['activate_plugin']);
                }
//                print_r($this->main_settings['active_plugins']);


                $this->mysql_update_main_settings($this->main_settings);
            }
        }

        if(isset($_GET['deactivate_plugin']) && $_GET['deactivate_plugin']){
//            echo $_GET['activate_plugin'];

            $user_caps = $this->get_user_capabilities($this->currUserId);

            if(in_array('admin', $user_caps)){



                foreach ($this->main_settings['active_plugins'] as $lab2=> $val2){

                    if($val2 == $_GET['deactivate_plugin']){
                        unset($this->main_settings['active_plugins'][$lab2]);
                    }
                }


                $this->mysql_update_main_settings($this->main_settings);
            }
        }


        if (isset($_POST['action']) && $_POST['action']=='dzsapp_update_page_permalink') {


            echo $this->permalinks_overwrite(array(
                'permalink'=>$_POST['page_label'],
                'target_id'=>$_POST['target_id'],
                'type'=>$_POST['type'],
            ));

            die();

        }


        if (isset($_POST['action']) && $_POST['action']=='forgotpassword') {



            if($this->main_settings['site_encryption_key'] && strlen($this->main_settings['site_encryption_key'])==16){
                $to = $_POST['email'];
                $feedback = '<a href="'.$this->url_base.'?action=changepassword_from_email&code='.simple_encrypt($to, $this->main_settings['site_encryption_key']).'">'.__("here").'</a>';

//                echo $feedback;
                $subject = $this->main_settings['site_title'].' - '.__("Password Change");
                $message = '';



                $message = $this->main_settings['mail_template_forgot_password'];
                $message = str_replace('{{thelink}}', $feedback, $message);

                $send = $this->portal_mail(array(

                    'sender'=>$this->main_settings['mail_sender'],
                    'target'=>$to,
                    'message'=>$message,
                    'subject'=>$subject,
                ));

                if( $send){
//                echo 'success - mail sent';
                    //do something


                    $arr = array(
                        'notice_type' => 'emailconfirmation',
                        'notice_for' => 'content_section',
                        'notice_html' => '<div class="alert alert-success">'.__("Mail Sent").'</div>',
                    );

                    array_push($this->notices_array, $arr);


                }else{
                    //do something


                    $arr = array(
                        'notice_type' => 'emailconfirmation',
                        'notice_for' => 'content_section',
                        'notice_html' => '<div class="alert alert-danger">'.__("Mail Not Sent - maybe mail() function disabled on your host ? ").'</div>',
                    );

                    array_push($this->notices_array, $arr);
                }
            }else{

                $arr = array(
                    'notice_type' => 'emailconfirmation',
                    'notice_for' => 'content_section',
                    'notice_html' => '<div class="alert alert-danger">'.__("encryption key not set or not correct 16 length - please inform your site administrator to set this for forgot password functionality").'</div>',
                );

                array_push($this->notices_array, $arr);
            }


        }


        if (isset($_POST['action']) && $_POST['action']=='changepassword') {



//            print_r($_POST);
            $email = simple_decrypt($_POST['code'], $this->main_settings['site_encryption_key']);


//            echo $email.' - '.$_POST['email'];
            if($email==$_POST['email']){




                $pass = md5($_POST['new_password']);

                $pass = $this->dblink->real_escape_string($pass);


                $query = "UPDATE users SET ";

                $query.="password='".$pass."'";



                if ($this->dblink->query($query) === true) {


                    $arr = array(
                        'notice_type' => 'emailconfirmation',
                        'notice_for' => 'content_section',
                        'notice_html' => '<div class="alert alert-success">'.__("password updated").'</div>',
                    );

                    array_push($this->notices_array, $arr);


                }else{

                    $arr = array(
                        'notice_type' => 'emailconfirmation',
                        'notice_for' => 'content_section',
                        'notice_html' => '<div class="alert alert-danger">'.__("mysql error - ").mysqli_error($this->dblink).'</div>',
                    );

                    array_push($this->notices_array, $arr);
                }

            }else{

                $arr = array(
                    'notice_type' => 'emailconfirmation',
                    'notice_for' => 'content_section',
                    'notice_html' => '<div class="alert alert-danger">'.__("email does not match").'</div>',
                );

                array_push($this->notices_array, $arr);
            }
        }
        if (isset($_GET['action']) && $_GET['action']=='changepassword_from_email') {



            $email = simple_decrypt($_GET['code'], $this->main_settings['site_encryption_key']);


            $users = $this->get_users();

//            echo $email;

//            echo $email; print_r($users);


            $sw = false;
            foreach ($users as $u){
                if($u['email']==$email){
                    $sw=true;
                }
            }

            if($sw){
                $arr = array(
                    'notice_type' => 'change_password',
                    'notice_for' => 'content_section',
                    'notice_html' => '<form action="index.php" class="change_password" method="post" style="text-align: center">
<input name="email" type="hidden" value="'.$email.'" />
<input name="code" type="hidden" value="'.$_GET['code'].'" />
<h4>'.__("New Password").'</h4>
<p><input name="new_password" type="password" class="simple-input-field" /></p>
<p><button name="action" value="changepassword" class="btn-skin-vive">'.__("Submit").'</button></p>
</form>',
                );                array_push($this->notices_array, $arr);

            }else{


                $arr = array(
                    'notice_type' => 'emailconfirmation',
                    'notice_for' => 'content_section',
                    'notice_html' => '<div class="alert alert-danger">'.__("code does not match any email").'</div>',
                );

                array_push($this->notices_array, $arr);
            }





        }

        if (isset($_GET['register_key']) && $_GET['register_key']) {



            $register_key = $_GET['register_key'];


            $email = simple_decrypt($register_key, $this->site_encryption_key);


            $users = $this->get_users();

//            echo 'email - '.$email;
//            echo "\n".'$this->site_encryption_key - '.$this->site_encryption_key;

//            $ceva = simple_encrypt('razorflashmedia@gmail.com');

//            echo "\n".'encrypt - '.simple_encrypt('razorflashmedia@gmail.com');
//            echo "\n".'decrypt - '.simple_decrypt($ceva);

//            echo $email; print_r($users);


            $sw = false;
            foreach ($users as $u){
                if($u['email']==$email){
                    $sw=true;
                }
            }

            if($sw){


                $query="UPDATE `users` SET `verify_status`='".'verified'."' WHERE email='".$email."' ";

                $aux2 = $this->dblink->query($query);



                $arr = array(
                    'notice_type' => 'emailconfirmation',
                    'notice_for' => 'content_section',
                    'notice_html' => '<div class="alert alert-warning">'.__("email confirmed - you can now login").'</div>',
                );

                array_push($this->notices_array, $arr);




                if($this->main_settings['new_users_need_verification']=='on') {
                    if ($this->main_settings['mail_on_register'] == 'on') {

                        $subject = $this->main_settings['site_title'] . ' - ' . __("New User");
                        $message = '';
//                        $message .= '<p>' . sprintf(__("new user registered %s user - %s"), '<br>', '{{theemail}}') . '</p>';






                        $message = $this->main_settings['mail_template_new_user'];
                        $message = str_replace('{{theemail}}', $_POST['email'], $message);



                        $send = $this->portal_mail(array(

                            'sender' => $this->main_settings['mail_sender'], 'target' => $this->main_settings['mail_sender'], 'message' => $message, 'subject' => $subject,));
                    }
                }

            }else{


                $arr = array(
                    'notice_type' => 'emailconfirmation',
                    'notice_for' => 'content_section',
                    'notice_html' => '<div class="alert alert-danger">'.__("code does not match any email").'</div>',
                );

                array_push($this->notices_array, $arr);
            }





        }


        if (isset($_POST['pay_with']) && $_POST['pay_with']=='user_credit') {


//            $this->notices_html.='ceva';

//            echo 'ceva';

            if($this->currUserId){


//                if()

                $user_meta = $this->get_user_meta_all($this->currUserId);
                $user_credit = intval($user_meta['user_credit']);

                if($user_credit - intval($_POST['amount']) >= 0){
                    $this->validate_purchase($_POST);

//                    print_r($_POST);

                    $track_id = '';

                    if(strpos($_POST['item_number'], ',')!==false){

                        $arr = explode(',',$_POST['item_number']);
                        $track_id = $arr[0];
                    }else{
                        $track_id = $_POST['item_number'];
                    }

                    $user_credit = $user_credit - intval($_POST['amount']);

//                    echo $user_credit;
                    $this->update_user_meta($this->currUserId,'user_credit',$user_credit);


                    $arr = array(
                        'notice_type' => 'purchaseconfirmation',
                        'notice_for' => 'checkout',
                        'notice_html' => '<a href="'.$this->get_permalink($track_id, array(
                                'type'=>'track',
                            )).'">The purchase</a> has been validated and you can now download the track from the Explore page.',
                    );

                    array_push($this->notices_array, $arr);


                    setcookie('dzspor_cart', serialize(array()), time()+7200);
                }else{

                    $arr = array(
                        'notice_type' => 'warning',
                        'notice_for' => 'checkout',
                        'notice_html' => __('Sorry, not enough credits.'),
                    );

                    array_push($this->notices_array, $arr);

                }


            }else{

                $arr = array(
                    'notice_type' => 'warning',
                    'notice_for' => 'checkout',
                    'notice_html' => __('You need to be logged in.'),
                );

                array_push($this->notices_array, $arr);
            }
        }


        if (isset($_POST['action'])) {
            if ($_POST['action'] == 'register') {

//                print_r($_POST);

                $sw = false;

                if($this->main_settings['api_google_recapcha_sitekey']){
                    if(function_exists('curl_version')){
                        $fields_string = '';
                        $url = 'https://www.google.com/recaptcha/api/siteverify';
                        $fields = array(
                            'secret'=>$this->main_settings['api_google_recapcha_secret'],
                            'response'=>$_POST['g-recaptcha-response'],
                            'remoteip'=>$_SERVER["REMOTE_ADDR"]
                        );

//url-ify the data for the POST
                        foreach($fields as $key=>$value) { $fields_string .= $key.'='.$value.'&'; }
                        rtrim($fields_string,'&');

//open connection
                        $ch = curl_init();

//set the url, number of POST vars, POST data
                        curl_setopt($ch,CURLOPT_URL,$url);
                        curl_setopt($ch,CURLOPT_POST,count($fields));
                        curl_setopt($ch,CURLOPT_POSTFIELDS,$fields_string);
                        curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);

//execute post
                        $result = curl_exec($ch);
//                    print_r($result);

                        $result_arr = json_decode($result);

//                    echo 'ceva-> '; print_r($result_arr);

                        if($result_arr->success){
                            $sw = true;
                        }

                    }else{
                        $sw = true;
                    }

                }else{
                    $sw = true;
                }


                if($sw){


                    $args = array_merge(array(), $_POST);

                    $usrs = $this->get_users();

                    foreach($usrs as $usrit){
//                        print_r($usrit);

                        if($usrit['username']==$_POST['username']){

                            $arr = array(
                                'notice_type' => 'registration_error',
                                'notice_for' => 'content_section',
                                'notice_html' => '<div class="alert alert-danger">'.__("Username Already Registered").'</div>',
                            );

                            array_push($this->notices_array, $arr);

                            return;
                        }

                        if($usrit['email']==$_POST['email']){

                            $arr = array(
                                'notice_type' => 'registration_error',
                                'notice_for' => 'content_section',
                                'notice_html' => '<div class="alert alert-danger">'.__("Email Already Registered").'</div>',
                            );

                            array_push($this->notices_array, $arr);

                            return;
                        }
                    }

                    $aux = $this->mysql_create_user($_POST['email'],$_POST['password'], $args);
                    if ($aux===true) {

//                        $this->currUserId = $aux;
                        if($this->main_settings['new_users_need_verification']!='on') {
                            setcookie("currUserId", $this->currUserId, time() + 3600);











                        }else{


                            $to = $_POST['email'];
                            $feedback = '<a href="'.$this->url_base.'?register_key='.urlencode(simple_encrypt($to, $this->site_encryption_key)).'">'.__("here").'</a>';

                            //                echo $feedback;
                            $subject = $this->main_settings['site_title'].' - '.__("Verify Account");
                            $message = '';
                            $message.= '';



                            $message = $this->main_settings['mail_template_verify_account'];
                            $message = str_replace('{{theusername}}', $_POST['username'], $message);
                            $message = str_replace('{{thelink}}', $feedback, $message);
                            $message = str_replace('{{thelink_href}}', $this->url_base.'?register_key='.urlencode(simple_encrypt($to, $this->site_encryption_key)), $message);




                            $send = $this->portal_mail(array(

                                'sender'=>$this->main_settings['mail_sender'],
                                'target'=>$to,
                                'message'=>$message,
                                'subject'=>$subject,
                            ));
                        }
//                        print_r($_COOKIE);

//                    header('Location: portal.php');
                        ;


                        if($this->main_settings['mail_user_on_register']=='on'){

                            $subject = $this->main_settings['site_title'].' - '.__("Login Details");
                            $message = '';
                            $message.= '';





                            $message = $this->main_settings['mail_template_login_details'];
                            $message = str_replace('{{theemail}}', $_POST['email'], $message);
                            $message = str_replace('{{thepassword}}', $_POST['password'], $message);

                            $send = $this->portal_mail(array(

                                'sender'=>$this->main_settings['mail_sender'],
                                'target'=>$_POST['email'],
                                'message'=>$message,
                                'subject'=>$subject,
                            ));
                        }



                        if($this->main_settings['new_users_need_verification']!='on') {
                            if ($this->main_settings['mail_on_register'] == 'on') {

                                $subject = $this->main_settings['site_title'] . ' - ' . __("New User");
                                $message = '';
                                $message .= '';





                                $message = $this->main_settings['mail_template_new_user'];
                                $message = str_replace('{{theemail}}', $_POST['email'], $message);






                                $send = $this->portal_mail(array(

                                    'sender' => $this->main_settings['mail_sender'], 'target' => $this->main_settings['mail_sender'], 'message' => $message, 'subject' => $subject,));
                            }
                        }
                    } else {
                        $this->notices_html.='<li class="notice notice-user-error">'.$aux.'</li>';
                    }
                }else{

                    $this->notices_html.='<li class="notice notice-user-error">'.__("Could not register, check capcha..").'</li>';
                }


            }
            if ($_POST['action'] == 'login') {

//                print_r($_POST);

                if(isset($_POST['transform_pass_to_md5']) && $_POST['transform_pass_to_md5']=='on'){
                    $_POST['pass'] = MD5($_POST['pass']);
                }

                $aux = $this->mysql_login_user($_POST['email'],$_POST['pass']);



//                echo 'cevaalceva'.$aux;
                if ($aux === true) {

                    setcookie("currUserId",$this->currUserId,time() + 3600);

                    if(isset($_POST['redir_url']) && $_POST['redir_url']){
                        header('Location: '.$_POST['redir_url']);
                    }

//                    header('Location: portal.php');
                    ;
                } else {


                    $arr = array(
                        'notice_type' => 'emailconfirmation',
                        'notice_for' => 'content_section',
                        'notice_html' => '<div class="alert alert-danger">'.$aux.'</div>',
                    );

                    array_push($this->notices_array, $arr);

//                    $this->notices_html.='<li class="notice notice-user-error">'.$aux.'</li>';
//                    error_log("password not true");
                }
            }
            if ($_POST['action'] == 'logout') {

                setcookie("currUserId",$this->currUserId,time() - 3600);
                $_SESSION['currUserId'] = '';


                session_destroy();

                header('Location: index.php');
            }
            if ($_POST['action'] == 'addtrack') {
//                print_r($_POST);
//                $aux_id = $this->mysql_add_track($_POST['source'],$_POST['source_ogg'],$_POST['title'],$_POST['desc'],$_POST['thumb'],$_POST['waveform_bg'],$_POST['waveform_prog']);


//                if($aux_id){
//                    header("Location:".$dzsap_config->url_portalphp.'?page=track&track_id='.$aux_id);
//                }



                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }

//            echo $_POST['action'];
//            echo $_POST['action'];
            if ($_POST['action'] === 'ajax_submit_message') {
//                print_r($_POST);

//                print_r($_POST);

                $aux_arr = array();

                parse_str($_POST['postdata'], $aux_arr);

//                print_r($aux_arr);
                $aux = $this->mysql_add_message($this->currUserId, $aux_arr['id_receiver'], $aux_arr['message']);

                if($aux===true){
                    echo 'success - playlist added';
                }else{
                    echo $aux;
                }

                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }
            if ($_POST['action'] === 'ajax_get_user_card') {
//                print_r($_POST);

//                print_r($_POST);

                $arr = array();




                $user_id = $_POST['user_id'];
                $us = $this->get_user($user_id);

                $aux = $this->sanitize_source($this->get_avatar($user_id));
                $aux_username = $this->get_user_field($user_id, 'username');
                $user = $this->get_user($user_id);
                $aux_cover = '';
                $aux_cover = $this->sanitize_source($user['second_avatar'], array(
                        'resize_image'=>true,
                        'resize_w'=>'250',
                        'resize_h'=>'100',
                ));


                $followers = $this->get_tracks(array(
                    'id'=>$user_id,
                    'table'=>'users',
                    'query_type'=>'followers',
                    'get_only_count'=>false,
                ));

                $cover_set = 'off';

                $cover_src = $aux;

                if($aux_cover){
                    $cover_src = $aux_cover;
                }
                if($aux_cover){
                    $cover_set = 'on';
                }



                $arr['avatar'] = $aux;
                $arr['cover'] = $cover_src;
                $arr['cover_set'] = $cover_set;
                $arr['user_id'] = $user_id;
                $arr['followers'] = count($followers);




                echo json_encode($arr);

                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }
            if ($_POST['action'] === 'ajax_save_user_roles') {
//                print_r($_POST);




                $postdata = $_POST['postdata'];




                parse_str($_POST['postdata'],$post_arr);

//                print_r($post_arr);


                $this->update_setting('user_roles',json_encode($post_arr));

                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }
            if ($_POST['action'] === 'ajax_delete_comment') {
//                print_r($_POST);

//                print_r($_POST);

                $aux_arr = array();



//                print_r($aux_arr);

                $comment_id = $_POST['comment_id'];

                if($_SESSION['nonce_comment_'.$comment_id]==$_POST['nonce']){

                    $tableName = 'comments';
                    $query      = "DELETE FROM $tableName WHERE id='".$comment_id."' ";



                    $result = $this->dblink->query($query);


                    if ($result) {


                        echo 'success - '.__("comment removed");
//                    echo ' query ( '.$query.' )';
                    }else{

                        echo 'error - '.__("Cannot delete - "). mysqli_error($this->dblink);
                    }

                }

//                print_r($_POST);
//                print_r($_SESSION);


                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }
            if ($_POST['action'] === 'ajax_get_notifications') {
//                print_r($_POST);

//                print_r($_POST);

                echo $this->get_notifications();

                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }
            if ($_POST['action'] === 'ajax_get_statistics_html') {
//                print_r($_POST);

//                print_r($_POST);

                echo $this->ajax_get_statistics_html();

                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }
            if ($_POST['action'] === 'ajax_submit_stream_read') {
//                print_r($_POST);

                print_r($_POST);

                $this->ajax_submit_stream_read($_POST['postdata']);

//                echo $this->get_notifications();

                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }
            if ($_POST['action'] === 'ajax_submit_report') {
//                print_r($_POST);

//                print_r($_POST);

                $aux_arr = array();

                parse_str($_POST['postdata'], $aux_arr);

//                print_r($aux_arr);


                $details = array(
                    'report'=>$aux_arr['report'],
                    'track_id'=>$aux_arr['track_id'],
                );
                $aux = $this->mysql_insert_activity(array(

                    'id_user'=>$this->currUserId,
                    'target_track_id'=>$aux_arr['track_id'],
                    'type'=>'report',
                    'details'=>serialize($details),
                ));


                if($aux===true){
                    echo 'success - report added';
                }else{
                    echo $aux;
                }

                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }
            if ($_POST['action'] === 'ajax_import_sample_db') {
//                print_r($_POST);

//                print_r($_POST);

                if($_SESSION['dzsapp_import_data_nonce'] == $_POST['dzsapp_import_data_nonce']){

                    $file=$this->path_base.'sample_dbs/db-backup-sample_config_1.sql';


                    if($_POST['sample_nr']==2){
                        $file=$this->path_base.'sample_dbs/db-backup-sample_config_2.sql';
                    }
                    if($_POST['sample_nr']==3){
                        $file=$this->path_base.'sample_dbs/db-backup-sample_config_3.sql';
                    }


                    $query = file_get_contents($file);

//                    $result = $this->dblink->query($query);
                    $result = $this->dblink->multi_query($query);



                    while ($this->dblink->more_results()) {
                        $result2 = $this->dblink->next_result();

                        //important to make mysqli_more_results false:
                        $discard = $this->dblink->store_result();

                        if (!$result2){

                            echo 'error - '.__("Cannot import - "). mysqli_error($this->dblink). ' result ( '.$discard.' ) ';
                        }
                    }


                    if ($result) {


                        echo 'success - data imported';

//                        echo ' - '.$file;
                    }else{

                        echo 'error - '.__("Cannot import - "). mysqli_error($this->dblink);
                    }

                }


//                if($aux===true){
//                    echo 'success - playlist added';
//                }else{
//                    echo $aux;
//                }
                $this->backup_curr_user();
                $this->dblink->close();

                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }


            if ($_POST['action'] === 'ajax_dzsapp_admin_import_db') {
//                print_r($_POST);

//                print_r($_POST);



//                $urs = $this->get_users();
//                $admin_urs = array();
//                foreach($urs as $us){
////                    print_r($us);
//
//                    $caps = unserialize($us['capabilities']);
//
//
//                    if(in_array('admin', $caps)){
//                        array_push($admin_urs, $us);
//                    }
//                }
//
//                print_r($admin_urs);




                $file = $_POST['source'];

//                echo $file.' '.$this->optional_url_base.' '.strpos($this->optional_url_base, $file);
                if(strpos($file,$this->optional_url_base)!==false){
//                    echo 'iz hier';

                    $file = substr($file, strlen($this->optional_url_base));


                }
                $file=$this->path_base.$file;


                $query = file_get_contents($file);
//                $result = $this->dblink->multi_query($query);









                $result2 = '';
                if ($result2 = $this->dblink->multi_query($query)) {
                    do {
                        /* store first result set */
                        if ($result = $this->dblink->store_result()) {
                            while ($row = $result->fetch_row()) {
//                                printf("%s\n", $row[0]);
                            }
                            $result->free();
                        }
                        /* print divider */
                        if ($this->dblink->more_results()) {
//                            printf("-----------------\n");
                        }
                    } while ($this->dblink->next_result());
                }


                if ($result2) {


                    echo 'success - '.__("data imported").'';
                }else{

                    echo 'error - '.__("Cannot import - "). mysqli_error($this->dblink);
                }


                $this->backup_curr_user();





                die();
            }



            if ($_POST['action'] === 'ajax_repair_database') {
//                print_r($_POST);

//                print_r($_POST);


                include_once('class_parts/db_repair.php');


//                if($aux===true){
//                    echo 'success - playlist added';
//                }else{
//                    echo $aux;
//                }

                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }
            if ($_POST['action'] === 'ajax_reset_statistics') {
//                print_r($_POST);

//                print_r($_POST);

                $val = $this->dblink->query('DELETE  FROM views;');

                if($val){

                    echo 'success - '.__("statistics deleten");

                }else{
                    echo 'error - '.__("").'<br><br>'.mysqli_error($this->dblink);
                }


//                if($aux===true){
//                    echo 'success - playlist added';
//                }else{
//                    echo $aux;
//                }

                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }
            if ($_POST['action'] === 'ajax_reset_permalinks') {
//                print_r($_POST);

//                print_r($_POST);

                $val = $this->dblink->query('DELETE FROM permalinks;');

                if($val){

                    echo 'success - '.__("permalinks deleten");

                }else{
                    echo 'error - '.__("").'<br><br>'.mysqli_error($this->dblink);
                }


//                if($aux===true){
//                    echo 'success - playlist added';
//                }else{
//                    echo $aux;
//                }

                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }

            if ($_POST['action'] === 'ajax_dzsapp_admin_import_data') {
//                print_r($_POST);

//                print_r($_POST);


                $file = $_POST['source'];

//                echo $file.' '.$this->optional_url_base.' '.strpos($this->optional_url_base, $file);
                if(strpos($file,$this->optional_url_base)!==false){
//                    echo 'iz hier';

                    $file = substr($file, strlen($this->optional_url_base));


                }
                $file=$this->path_base.$file;


                $tableName  = $_POST['label'];
                $backupFile = $file;
                $query      = "LOAD DATA INFILE '$backupFile' INTO TABLE $tableName";

//                echo $query;
                $result = $this->dblink->query($query);


                if ($result) {


                    echo 'success - data imported';
                }else{

                    echo 'error - '.__("Cannot import - "). mysqli_error($this->dblink);
                }




                die();
            }


            if ($_POST['action'] === 'ajax_delete_from_table') {


                $tableName  = $_POST['table'];
                $query      = "DELETE FROM $tableName";

//                echo $query;
                $result = $this->dblink->query($query);


                if ($result) {


                    echo 'success - '.__("Table Data Deleten");
                }else{

                    echo 'error - '.__("Cannot delete - "). mysqli_error($this->dblink);
                }




                die();
            }


            if ($_POST['action'] === 'save_usersettings') {
//                print_r($_POST);

//                print_r($_POST);

                $aux_arr = array();

                parse_str($_POST['postdata'], $aux_arr);

//                print_r($aux_arr);


                // -- prevalidation

                if($aux_arr['new_password']){
                    if($aux_arr['new_password']!=$aux_arr['confirm_password']){
                        echo 'error - '.__('password confirm does not match');
                        die();
                    }

                    if($this->get_user_field($this->currUserId, 'password')){

                        if(MD5($aux_arr['password'])!=$this->get_user_field($this->currUserId, 'password')){
                            echo 'error - '.__('password does not match old password');
                            die();
                        }
                    }


                }


                $aux = $this->mysql_update_user_settings('', $aux_arr);

//                $aux = $this->mysql_add_message($this->currUserId, $aux_arr['id_receiver'], $aux_arr['message']);

                if($aux===true){
                    echo 'success - '.__('User Settings Updated');
                }else{
                    echo 'error - '.$aux;
                }

                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }


            if ($_POST['action'] === 'save_usermeta') {
//                print_r($_POST);

//                print_r($_POST);

                $aux_arr = array();

                parse_str($_POST['postdata'], $aux_arr);

//                print_r($aux_arr);


                // -- prevalidation

                $aux = $this->update_user_meta_all($this->currUserId, $aux_arr);
                if($aux===true){
                    echo 'success - '.__('User Meta Updated');
                }else{
                    echo 'error - '.$aux;
                }

                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }


            if ($_POST['action'] === 'save_track_settings') {
//                print_r($_POST);

//                print_r($_POST);

                $aux_arr = array();

                parse_str($_POST['postdata'], $aux_arr);

//                print_r($aux_arr);


//                $aux_arr2 = array_merge(array(), $aux_arr);


                $meta_arr = array();

                foreach ($aux_arr as $lab=>$val){
                    if($lab==='extra_buttons_right'){
                        $meta_arr[$lab]=$val;
                        unset($aux_arr[$lab]);
//                        unset($aux_arr2[$lab]);

                    }
                }

                foreach ($meta_arr as $lab=>$val){
                    $this->update_post_meta($aux_arr['track_id'], $lab, $val, array(
                        'post_type'=>'track',
                        'for_ajax'=>false,
                    ));
                }

//                echo 'ceva';


//                print_r($aux_arr2);
                $aux = $this->mysql_update_track_settings($aux_arr);

//                $aux = $this->mysql_add_message($this->currUserId, $aux_arr['id_receiver'], $aux_arr['message']);

                if($aux===true){
                    echo 'success - '.__('Track Settings Updated / refresh to see changes');
                }else{
                    echo 'error - '.$aux;
                }

                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }
            if ($_POST['action'] === 'ajax_update_user_meta') {
//                print_r($_POST);

//                print_r($_POST);

                $aux_arr = array();



//                print_r($aux_arr);
                $aux = $this->update_user_meta($this->currUserId, $_POST['arglab'], $_POST['argval']);

                if($aux===true){
                    echo 'success - '.__('user meta updated');
                }else{
                    echo $aux;
                }

                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }
            if ($_POST['action'] === 'ajax_unfollow_user') {
//                print_r($_POST);

//                print_r($_POST);

                $aux_arr = array();



//                print_r($aux_arr);
                $aux = $this->mysql_unfollow_user($_POST['target_user_id']);


                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }


            if ($_POST['action'] === 'ajax_submit_comment_from_form') {


//                print_r($_POST);



                $aux_arr = array();

                parse_str($_POST['postdata'], $aux_arr);


                $aux = $this->submit_comment($aux_arr);

                if(intval($aux)){

                    $query = "SELECT * FROM comments WHERE `id` = '$aux'";

//        echo $query;

                    $aux = $this->dblink->query($query);
                    while($aux2 = mysqli_fetch_assoc($aux)){

                        $comment_text = $this->generate_comment_str($aux2, array(

                            'type'=>'comments'
                        ));
                    }



                    echo json_encode(array(
                            'type'=>'comment_submitted',
                            'report'=>'success',
                            'text'=>__('comment submitted'),
                            'comment_text'=>$comment_text,
                            'comment_id'=>$aux,
                    ));
                }else{
                    echo json_encode(array(
                        'type'=>'comment_submitted',
                        'report'=>'error',
                        'text'=>__('error - ').$aux,
                    ));
                }

                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }


            if ($_POST['action'] === 'ajax_repost_track') {


//                print_r($_POST);



                $aux_arr = array();

//                parse_str($_POST['postdata'], $aux_arr);


                $aux = $this->submit_repost($_POST['track_id']);

                if(intval($aux) || $aux===true){
//                    echo $aux;




                    echo json_encode(array(
                        'type'=>'repost_submitted',
                        'report'=>'success',
                        'text'=>__('repost submitted'),
                        'repost_id'=>$aux,
                    ));

                }else{
                    echo json_encode(array(
                        'type'=>'repost_submitted',
                        'report'=>'error',
                        'text'=>__('repost submitted'),
                    ));
                }




                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }



            if ($_POST['action'] === 'ajax_delete_repost') {


                $tableName  =  "activity";


                if(isset($_POST['repost_id']) && $_POST['repost_id']){
                    $query      = "DELETE FROM $tableName WHERE id='".$_POST['repost_id']."' ";

                }else{
                    $query      = "DELETE FROM $tableName WHERE target_track_id='".$_POST['player_id']."' AND id_user='".$this->currUserId."' ";

                }


//                echo $query;
                $result = $this->dblink->query($query);


                if ($result) {


                    echo 'success - '.__("repost removed");
//                    echo ' query ( '.$query.' )';
                }else{

                    echo 'error - '.__("Cannot delete - "). mysqli_error($this->dblink);
                }




                die();
            }






            // -- from the player

            if ($_POST['action'] === 'dzsap_submit_like') {


                $aux = $this->submit_like();

                if($aux===true){
                    echo 'success - '.__('like submitted');
                }else{
                    echo $aux;
                }

                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }
            // -- from the player

            if ($_POST['action'] === 'dzsap_get_pcm') {



                echo '';
                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }


            if ($_POST['action'] === 'dzsap_submit_pcm') {



                $aux = 'pcm';

                if (isset($_POST['playerid'])) {
                    $aux.=$this->clean($_POST['playerid']);
                }

                $content = $_POST['postdata'];
                $current = $content;



                $auxcall = $this->update_setting($aux, $content, array(
                    'from_ajax'=>false
                ));



                if($auxcall===true){
                    echo 'success - '.__('pcm submitted');
                }else{
                    echo $auxcall;
                }

                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }


            // -- from the player

            if ($_POST['action'] === 'dzsap_retract_like') {


                $aux = $this->retract_like();

                if($aux===true){
                    echo 'success - '.__('like submitted');
                }else{
                    echo $aux;
                }

                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }
            if ($_POST['action'] === 'dzsap_submit_views') {


                $aux = $this->submit_view();

                if($aux===true){
                    echo 'success - '.__('view submitted');
                }else{
                    echo $aux;
                }

                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }

            if ($_POST['action'] === 'dzsap_front_submitcomment') {


                $aux = $this->submit_comment();

                if($aux===true){
                    echo 'success - '.__('comment submitted');
                }else{
                    echo $aux;
                }

                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }
            if ($_POST['action'] === 'ajax_follow_user') {
//                print_r($_POST);

//                print_r($_POST);

                $aux_arr = array();



//                print_r($aux_arr);
                $aux = $this->mysql_follow_user($_POST['target_user_id']);

//                echo 'hmm'; print_r($aux);


                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }
            if ($_POST['action'] === 'ajax_add_playlist') {
//                print_r($_POST);

//                print_r($_POST);

                $aux_arr = array();

                parse_str($_POST['postdata'], $aux_arr);

//                print_r($aux_arr);
                $aux = $this->mysql_add_playlist($this->currUserId, $aux_arr['playlist_name'], $aux_arr['description']);

                if($aux===true){
                    echo 'success - '. __('playlist added');
                }else{
                    echo $aux;
                }

                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }
            if ($_POST['action'] === 'ajax_remove_playlist') {

//                print_r($aux_arr);
                $aux = $this->mysql_remove_playlist($_POST['playlist_id']);

                if($aux===true){
                    echo 'success - '.__('playlist removed');
                }else{
                    echo $aux;
                }

                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }
            if ($_POST['action'] === 'ajax_add_to_playlist_id') {
                $aux = $this->mysql_submit_playlist_entry($_POST['playlist_id'],$_POST['track_id']);

                if($aux===true){
                    echo 'success - playlist added';
                }else{
                    echo $aux;
                }

                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }
            if ($_POST['action'] === 'ajax_show_playlists') {
//                print_r($_POST);
                $user_id = $this->currUserId;

                if(isset($_POST['user_id']) && $_POST['user_id']){
                    $user_id = $_POST['user_id'];
                }

                $this->show_playlists(array(
                        'track_id' => $_POST['track_id'],
                        'user_id' => $user_id,
                    )
                );

                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }
            if ($_POST['action'] === 'ajax_remove_to_playlist_id') {
                $aux = $this->mysql_submit_playlist_entry($_POST['playlist_id'],$_POST['track_id'], array(
                    'remove_track'=>true
                ));

                if($aux===true){
                    echo 'success - playlist remove';
                }else{
                    echo $aux;
                }

                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }
            if ($_POST['action'] == 'dzsap_submit_track') {
//                print_r($_POST);
                $this->ajax_submit_track();


                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }
            if ($_POST['action'] == 'dzsap_delete_track') {
//                print_r($_POST);


                $aux = $this->mysql_delete_track($_POST['postdata']);

                if($aux===true){
                    echo 'success - '.__("track deleten");
                }else{

                    echo 'error - '.$aux;
                }


                die();
                //$source, $source_ogg, $title, $desc, $thumbnail, $waveform_bg, $waveform_prog
            }
            if ($_POST['action'] == 'ajax_add_to_cart') {


                $this->ajax_add_to_cart();


            }
            if ($_POST['action'] == 'ajax_remove_to_cart') {


                $this->ajax_remove_to_cart();


            }
            if ($_POST['action'] == 'ajax_get_query') {


//                print_r($_POST);

                echo $this->get_query($_POST);

                die();


            }
            if ($_POST['action'] == 'ajax_show_cart') {


                $this->show_cart(array('for_ajax'=>true));


            }
            if ($_POST['action'] == 'ajax_load_results') {


                $this->show_search_results(array(
                    'for_ajax'=>true,
                    'search_query'=>$_POST['postdata'],
                ));


            }
            if ($_POST['action'] == 'ajax_messages_friends_get_array') {

//                print_r($_POST);

                $this->ajax_messages_friends_get_array(array(
                    'for_ajax'=>true,
                    'author_id'=>$this->currUserId,
                    'id_receiver'=>$_POST['id_receiver'],
                ));


            }
            if ($_POST['action'] == 'ajax_messages_get_array') {

//                print_r($_POST);

                $this->ajax_messages_get_array(array(
                    'for_ajax'=>true,
                    'author_id'=>$this->currUserId,
                    'id_receiver'=>$_POST['id_receiver'],
                ));


            }
        }
        if (isset($_GET['action'])) {

            if ($_GET['action'] == 'playlists_iframe') {


                include('frontend_parts/part_playlistadd.php');

                die();

            }
        }
    }

    function select_mainsettings_array(){

        $query = "SELECT setting_value FROM `settings` WHERE setting_name='mainsettings'";

        $auxa = array();

        $aux = $this->dblink->query($query);

        if ($aux && $aux->num_rows > 0) {

            while($row = mysqli_fetch_assoc($aux)){

//                print_r($row['setting_value']);

                parse_str($row['setting_value'],$auxa);

//                print_r($auxa);
            }


        }


        if(count($auxa)==0){


            $auxa = array_merge(array(), $this->main_settings_default);
        }else{
            $auxa = array_merge($this->main_settings_default, $auxa);
        }


        return $auxa;
    }


    function get_cart_arr($pargs = array()){


        $margs = array(
            'for_ajax'=>false,
            'include_checkout_link'=>true,
        );



        $fout = '';




        if($this->cart_arr && is_array($this->cart_arr) && count($this->cart_arr)>0){

            $fout = serialize($this->cart_arr);

        }else{

        }



        if($margs['for_ajax']){

            echo $fout;
            die();
        }else{

            return $fout;
        }
    }

    function ajax_messages_update_to_read($pargs = array()){

        $margs = array(
            'for_ajax'=>true,
            'table'=>'users',
            'author_id'=>'',
            'id_receiver'=>'',
            'id_receiver'=>'',
            'get_only_count'=>false,
        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        }



        $query="UPDATE `messages` SET `read_status`='".'read'."' WHERE author_id='".$margs['author_id']."' AND id_receiver='".$margs['id_receiver']."'";

        $aux2 = $this->dblink->query($query);




    }


    function ajax_messages_friends_get_array($pargs = array()){

        $margs = array(
            'for_ajax'=>true,
            'table'=>'users',
            'author_id'=>'',
            'id_receiver'=>'',
            'get_only_count'=>false,
        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        }



        if($pargs){
            $margs = array_merge($margs, $pargs);
        }

        $query = "SELECT connections FROM `".$margs['table']."`";


        $query.="  ";
        if($margs['author_id']){
            $query.=" WHERE id='".$margs['author_id']."'";
        }else{
            echo 'error - not logged in';

            if($margs['for_ajax']){

                die();
            }
        }

//        echo $query;

//        print_r($margs);


        $fout = '';

        $auxa = array();

        $aux_str = '';

        $aux = $this->dblink->query($query);


        if($margs['get_only_count']){

            if($aux){
                return $aux->num_rows;
            }
        }

        $return_arr = array();

        if ($aux && $aux->num_rows > 0) {

            while($row = mysqli_fetch_assoc($aux)){


                $auxa = unserialize($row['connections']);


                if($auxa==false){
                    $auxa = array();
                }

//                print_r($row['connections']);
//                print_r($auxa);



                foreach($auxa as $lab=>$frend){

                    $aux3 = $this->get_user($lab);

//                    print_r($aux3);


                    // -- if user does not exist anymore
                    if(isset($aux3['id'])===false ){
                        continue;
                    }

                    if($frend!='blocked'){

                        $fout.='<a href="'.$this->optional_url_base.'index.php?page=messages&user_id='.$lab.'" class="chat-friend" data-userid="'.$lab.'">';

                        $fout.='<div class="user-avatar" style="background-image: url('.$this->get_avatar($lab).');">';

                        $fout.='</div>';

                        $fout.='<h4 class="user-name">'.$this->get_username($lab);
                        $fout.='</h4>';


                        $fout.='<div class="clear"></div>';
                        $fout.='</a>';
                    }

                }




            }


        }

//        $fout.=__('Cart is empty. ');

        if($margs['for_ajax']){

            echo $fout;
            die();
        }else{

            return $return_arr;
        }
    }
    function ajax_messages_get_array($pargs = array()){

        $margs = array(
            'for_ajax'=>true,
            'table'=>'messages',
            'author_id'=>'',
            'id_receiver'=>'',
            'get_only_count'=>false,
        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        }



        if($pargs){
            $margs = array_merge($margs, $pargs);
        }

        $query = "SELECT * FROM `".$margs['table']."`";


        $query.=" WHERE (id_receiver='".$margs['id_receiver']."' ";
        if($margs['author_id']){
            $query.=" AND author_id='".$margs['author_id']."')";
            $query.=" OR (id_receiver='".$margs['author_id']."'";
            $query.=" AND author_id='".$margs['id_receiver']."')";
        }else{
            echo 'error - not logged in';

            if($margs['for_ajax']){

                die();
            }
        }

//        echo $query;

//        print_r($margs);



        $auxa = array();

        $aux_str = '';

        $aux = $this->dblink->query($query);


        if($margs['get_only_count']){

            if($aux){
                return $aux->num_rows;
            }
        }

        if ($aux && $aux->num_rows > 0) {

            while($row = mysqli_fetch_assoc($aux)){

                $auxa_b = $row;

                $auxa_b['author_username'] = $this->get_username($row['author_id']);
                $auxa_b['author_avatar'] = $this->get_avatar($row['author_id']);

                $auxa_b['content'] = str_replace('&lt;br&gt;', '<br>', $auxa_b['content']);

                array_push($auxa, $auxa_b);

            }


        }

//        $fout.=__('Cart is empty. ');

        if($margs['for_ajax']){

            echo json_encode($auxa);
            die();
        }else{

            return $auxa;
        }
    }


    function show_cart($pargs = array()){

        $margs = array(
            'for_ajax'=>false,
            'include_checkout_link'=>true,
        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        }


        $str_curr = $this->main_settings['currency_label'];
        $total_price = 0;

        $fout = '';
        if($this->cart_arr && is_array($this->cart_arr) && count($this->cart_arr)>0){


            $fout.=__('');


            foreach($this->cart_arr as $lab=>$cart_arr_item){

                $aux_arr = $this->get_page($lab, array(
                    'post_type'=>'track',
                ));


                $price = '100';


//                print_r($lab);

                $desc = '';
                if(isset($aux_arr['title'])){

                    $desc = $aux_arr['title'];
                }


                $fout.='<div class="cart-item">';

                $fout.='<div class="cart-item-thumb';

                if(isset($aux_arr['price']) && $aux_arr['price']){
                    $price = $aux_arr['price'];
                }

                if($lab==='proaccount'){
                    $fout.=' thumb-for-proaccount';
                    $desc = 'Pro Account';

                    $price = $this->main_settings['pro_account_price'];
                }
                if($lab==='proaccount_90'){
                    $fout.=' thumb-for-proaccount';
                    $desc = 'Pro Account 90 Days';

                    $price = $this->main_settings['pro_account_price_90'];
                }
                if($lab==='proaccount_year'){
                    $fout.=' thumb-for-proaccount';
                    $desc = 'Pro Account One Year';

                    $price = $this->main_settings['pro_account_price_year'];
                }

                $thumb = '';

                if(isset($aux_arr['thumbnail'])){
                    $thumb = $this->sanitize_source($aux_arr['thumbnail']);
                }



                $fout.='" style="background-image: url('.$thumb.');">';


                if($lab==='proaccount'){
                    $fout.='<i class="fa fa-star"></i>';
                }

                $fout.='</div>';

                $fout.='<div class="cart-item-content">';
                $fout.='<span class="cart-item-label">'.$desc.'</span>';

                $fout.='<span class="cart-item-quantity">'.$cart_arr_item.' x</span> <span class="cart-item-price">'.$str_curr.$price.'</span>';

                $fout.='<div class="cart-delete-item-btn"  data-playerid="'.$lab.'"><i class="fa fa-times"></i></div>';

                $fout.='</div>';




                $fout.='</div>';




//                print_r($aux_arr);

                $total_price+=doubleval($cart_arr_item) * doubleval($price);
            }


            $fout.='<div class="cart-subtotal-con">';


            $fout.=__("Subtotal").', <strong>'.$str_curr.$total_price.'</strong>';

            if($margs['include_checkout_link']){

                $fout.='<div class="go-to-checkout-link-con"><a href="'.$this->optional_url_base.'index.php?page=checkout"><i class="fa fa-cc-paypal"></i> <span class="checkout-label">'.__('Checkout').'</span></a></div>';
            }


            $fout.='</div>';

        }else{

            $fout.=__('Cart is empty. ');
        }


//        $fout.=__('Cart is empty. ');

        if($margs['for_ajax']){

            echo $fout;
            die();
        }else{

            return $fout;
        }
    }


    function show_search_results($pargs = array()){

        $margs = array(
            'for_ajax'=>false,
            'include_checkout_link'=>true,
            'search_query'=>'',
            'get_only_count'=>'',
        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        }



        $fout = '';

        $query = "SELECT * FROM `tracks`";


        $query.=" WHERE title LIKE '%".$margs['search_query']."%'";

//        echo $query;

        $aux = $this->dblink->query($query);


        if($margs['get_only_count']){

            if($aux){
                return $aux->num_rows;
            }
        }

        if ($aux && $aux->num_rows > 0) {

            $fout.='<h6>'.__("Tracks").'</h6>';

            while ($row = mysqli_fetch_assoc($aux)) {

//                print_r($row);

                $fout.='<a href="'.$this->optional_url_base.'index.php?page=track&track_id='.$row['id'].'" class="result-con ajax-link">';
                $fout.='<span class="result-label">'.$row['title'].'</span>';
                $fout.='<i class="fa fa-music"></i>';
                $fout.='</a>';
            }
        }




        $query = "SELECT * FROM `users`";


        $query.=" WHERE username LIKE '%".$margs['search_query']."%' ";

//        echo $query;

        $aux = $this->dblink->query($query);


        if($margs['get_only_count']){

            if($aux){
                return $aux->num_rows;
            }
        }

        if ($aux && $aux->num_rows > 0) {

            $fout.='<h6>'.__("Artists").'</h6>';

            while ($row = mysqli_fetch_assoc($aux)) {

//                print_r($row);

                $fout.='<a href="'.$this->optional_url_base.'index.php?page=user&user_id='.$row['id'].'" class="result-con">';
                $fout.='<span class="result-label">'.$row['username'].'</span>';
                $fout.='<i class="fa fa-user"></i>';
                $fout.='</a>';
            }
        }

        if($fout){

        }else{
            $fout.=__("No results found ");
        }

//        $fout.=__('Cart is empty. ');

        if($margs['for_ajax']){

            echo $fout;
            die();
        }else{

            return $fout;
        }
    }

    function check_disable_pro_accounts(){

        global $datenow;

        $query = "SELECT * FROM `activity`";


        $query.=" WHERE type IN ('purchase', 'purchase_paypal') ";

//        echo $query;

        $aux = $this->dblink->query($query);



        $date_now = new DateTime($datenow);
        if ($aux && $aux->num_rows > 0) {

            while($row = $aux->fetch_assoc()){
//                print_r($row);


                $date2 = new DateTime($row['date']);
                $interval = $date_now->diff($date2);

//                print_r($interval->h);

                $dets = unserialize($row['details']);

                $caps = $this->get_user_capabilities($row['id_user']);

                $user = $this->get_user($row['id_user']);

//                print_r($user);


                $role = '';

                if($caps == false || is_array($caps)==false){

                    $caps = array();
                }

                if($dets['item_number']=='proaccount'){

//                    print_r($interval);

//                    $interval->m=2;
                    if($interval->m>0){

                        foreach ($caps as $lab=>$val){
                            if($val=='proaccount'){
                                unset($caps[$lab]);
                            }
                        }

                        if($user['role']=='pro'){
                            $user['role'] = 'user';
                            $role = 'user';
                        }
                    }else{


                        if(in_array('proaccount', $caps)==false){

                            array_push($caps, 'proaccount');


                        }


                        if($user['role']=='' || $user['role']=='user'){
                            $user['role'] = 'pro';
                            $role = 'pro';
                        }



                    }

//                    print_r($user);


                }

                if($dets['item_number']=='proaccount_90'){
                    if($interval->m>2){

                        foreach ($caps as $lab=>$val){
                            if($val=='proaccount'){
                                unset($caps[$lab]);
                            }
                        }
                        if($user['role']=='pro'){
                            $user['role'] = 'user';
                            $role = 'user';
                        }
                    }else{


                        if(in_array('proaccount', $caps)==false){

                            array_push($caps, 'proaccount');


                        }

                        if($user['role']=='' || $user['role']=='user'){
                            $user['role'] = 'pro';
                            $role = 'pro';
                        }

                    }

                }

                if($dets['item_number']=='proaccount_year'){
                    if($interval->y>0){

                        foreach ($caps as $lab=>$val){
                            if($val=='proaccount'){
                                unset($caps[$lab]);
                            }
                        }
                        if($user['role']=='pro'){
                            $user['role'] = 'user';
                            $role = 'user';
                        }
                    }else{


                        if(in_array('proaccount', $caps)==false){

                            array_push($caps, 'proaccount');


                        }
                        if($user['role']=='' || $user['role']=='user'){
                            $user['role'] = 'pro';
                            $role = 'pro';
                        }

                    }

                }


                $args = array(
                    'capabilities'=>serialize($caps),
                );

                if($role){
                    $args['role'] = $role;
                }



                $this->mysql_update_user_settings($row['id_user'], $args);
            }

        }else{

        }

        $this->update_setting('pro_accounts_last_checked', $datenow, array(
            'from_ajax'=>false
        ));

    }

    function ajax_add_to_cart(){


        $prod_id = $_POST['prod_id'];



//        print_r($_POST);
//        print_r($this->cart_arr);

        if($prod_id === 'proaccount' || $prod_id === 'proaccount_90' || $prod_id === 'proaccount_year'){
            $this->cart_arr = array();
//            echo 'UNSET IT pro';
        }


        foreach ($this->cart_arr as $lab => $ca){
            if($lab === 'proaccount' || $lab === 'proaccount_90' || $lab === 'proaccount_year'){
                unset($this->cart_arr[$lab]);
//                echo 'UNSET IT pro2';
                continue;
            }

            if($this->main_settings['paypal_use_author_email']=='on'){
                if(is_numeric($prod_id)){
                    $orig_author_id = $this->get_track_field($prod_id,'author_id');


                    $cart_it_author_id = $this->get_track_field($lab,'author_id');

//                    echo $prod_id.' - '.$lab. ' .... || ';
//                    echo $orig_author_id.' - '.$cart_it_author_id. ' ....';
                    if($orig_author_id!=$cart_it_author_id){
//                        echo 'UNSET IT MORE';
                        unset($this->cart_arr[$lab]);

                    }

                }
            }
        }

//        echo '$this->cart_arr[$prod_id] - '.$this->cart_arr[$prod_id];
        if(isset($this->cart_arr[$prod_id]) && $this->cart_arr[$prod_id]){
//            echo 'whatttt';
            $this->cart_arr[$prod_id]++;
        }else{
            $this->cart_arr[$prod_id] = 1;
        }

//        print_r($this->cart_arr);

        if($this->currUserId){

            setcookie('dzspor_cart', serialize($this->cart_arr), time()+(31*24*3600));

            ?>
            <div class="purchase-confirmation">
                <i class="fa fa-shopping-cart"></i>
                <span class="the-text"> &nbsp; &nbsp;<?php echo __("Track added to cart"); ?></span>
            </div>
            <?php

        }else{

            ?>
            <div class="purchase-confirmation is-error">
                <i class="fa fa-times"></i>
                <span class="the-text"> &nbsp; &nbsp;<?php echo __("You should login before purchase"); ?></span>
            </div>
            <?php

        }


//        $_COOKIE['dzspor_cart'] = serialize();
//
//        print_r($_COOKIE);
//        print_r($this->cart_arr);
        die();

    }
    function ajax_remove_to_cart(){


        $prod_id = $_POST['prod_id'];



//        print_r($this->cart_arr);

        if(isset($this->cart_arr[$prod_id])){
            unset($this->cart_arr[$prod_id]);
        }


        setcookie('dzspor_cart', serialize($this->cart_arr), time()+7200);

//        $_COOKIE['dzspor_cart'] = serialize();
//
//        print_r($_COOKIE);
//        print_r($this->cart_arr);
        die();

    }

    function update_post_meta($post_id,$arglab,$argval,$pargs=array()){

        $margs = array(
            'post_type'=>'post',
            'for_ajax'=>true,
        );

        if($pargs){
            $margs = array_merge($margs,$pargs);
        }





        $query = "SELECT `id` FROM `post_meta` WHERE `lab` = '$arglab' AND post_id='$post_id'  AND post_type='".$margs['post_type']."'";

//        echo $query;


        $aux = $this->dblink->query($query);

        if($aux){




//            print_r($aux);


            if($aux->num_rows > 0){

                $query="UPDATE `post_meta` SET `val`='".$argval."' WHERE `lab` = '$arglab' AND post_id='$post_id' AND post_type='".$margs['post_type']."'";
                $aux2 = $this->dblink->query($query);



                if($margs['for_ajax']) {
                    echo 'success - settings updated';
                }
            }else{




                $query="INSERT INTO `post_meta` (post_id,lab, val,post_type) VALUES ('$post_id', '".$arglab."', '".$argval."','".$margs['post_type']."')";
                $aux2 = $this->dblink->query($query);


//                echo $query;
                if($margs['for_ajax']) {
                    echo 'success - settings added';
                }
            }

            $auxa = array();

//                parse_str($_POST['postdata'], $auxa);
//                echo $_POST['postdata']; print_r($auxa);


        }else{
            if($margs['for_ajax']) {
                echo 'error - sql error';
            }
        }


        if($margs['for_ajax']){
            die();
        }else{
            return 1;
        }



    }


    function ajax_submit_track(){
//        print_r($_POST);

        global $dzsap_config;

        $auxarr = array();

        parse_str($_POST['postdata'], $auxarr);


//        print_r($auxarr);

        $caps = $this->get_user_capabilities($this->currUserId);

        if(isset($this->main_config_settings['is_preview']) && $dzsap_config['is_preview']=='on'  && in_array('admin',$caps)==false){

            echo 'error - '.__("preview mode / track submit allowed only on purchase version");
            die();
        }

        $this->action_submit_track_data = $auxarr;


        if(isset($auxarr['source']) && $auxarr['source']){

        }else{

            echo 'error - '.__("track not submitted - you need to enter track");
            die();
        }

        if(isset($auxarr['type']) && $auxarr['type']=='album'){


            $arr_ids = array();



            error_log("trying to upload album / $auxarr - ".print_rr($auxarr, array('echo'=>false)) );


            foreach($auxarr['track_source'] as $lab => $tr){

                $auxarr_child = array(
                    'source'=>$tr,
                    'title'=>$auxarr['track_title'][$lab],
                    'type'=>'album_part',
                );


                $auxid = $this->mysql_submit_track($auxarr_child);

                $this->action_submit_track_data['track_id']=$auxid;
                $this->do_action("submit_track");

                array_push($arr_ids, $auxid);
            }


            $auxarr['source'] = serialize($arr_ids);
            $auxid = $this->mysql_submit_track($auxarr);

            $this->action_submit_track_data['track_id']=$auxid;
            $this->do_action("submit_track");

        }else{





            $args_get_tracks = array();

            if($args_get_tracks){
                $args_get_tracks['author_id'] = $this->currUserId;
            }

            $trs = $this->get_tracks($args_get_tracks);


            foreach ($trs as $tr){
                if($tr['title']==$auxarr['title']){

                    echo json_encode(array(
                        'type'=>'track_submit',
                        'report'=>'error',
                        'text'=>__('error - ').__('a track already has this name'),
                    ));
                    die();
                }
            }

            $auxid = $this->mysql_submit_track($auxarr);

            $this->action_submit_track_data['track_id']=$auxid;
            $this->do_action("submit_track");
        }





            if(isset($auxid) && is_numeric($auxid)){








                echo json_encode(array(
                    'type'=>'track_submit',
                    'report'=>'success',
                    'text'=>__('success - ').__('Submitted track ').$auxid,
                    'permalink'=>$this->get_permalink($auxid),
                ));



//                print_r($auxarr);
            }else{
                echo 'error - '.__("track not submitted - ");

                print_r($auxid);
            }


    }

    function portal_mail($pargs = array()){




        $margs = array(
            'sender'=>'{{admin}}',
            'target'=>'{{admin}}',
            'message'=>'',
            'subject'=>'',
        );



        $margs = array_merge($margs, $pargs);

        $to = $margs['target'];
        $from = $margs['sender'];



        if($from=='{{admin}}'){
            $urs = $this->get_users();

            foreach ($urs as $ur){
                $caps = $this->get_user_capabilities($ur['id']);

                if(in_array("admin", $caps)){

//                    print_r($ur);

                    $from = $ur['email'];
                    break;
//                    $from = $ur->

                }
            }
        }

        if($to=='{{admin}}'){
            $urs = $this->get_users();

            foreach ($urs as $ur){
                $caps = $this->get_user_capabilities($ur['id']);

                if(in_array("admin", $caps)){

//                    print_r($ur);

                    $to = $ur['email'];
                    break;
//                    $from = $ur->

                }
            }
        }



        $subject = $margs['subject'];
        $message = '';
        $message.= $margs['message'];
        $headers  = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $headers.= 'From: '. $from . "\r\n" .
            'Reply-To: '. $from  . "\r\n" .
            'X-Mailer: PHP/' . phpversion();


//        echo $this->main_settings['mail_type'];

        if($this->main_settings['mail_type']=='smtp'){

            require 'libs/phpmailer/PHPMailerAutoload.php';

            $mail = new PHPMailer();

//$mail->SMTPDebug = 3;                               // Enable verbose debug output

            $mail->isSMTP();                                      // Set mailer to use SMTP
            $mail->Host = $this->main_settings['smtp_host'];  // Specify main and backup SMTP servers
            $mail->SMTPAuth = true;                               // Enable SMTP authentication
            $mail->Username = $this->main_settings['smtp_username'];                 // SMTP username
            $mail->Password = $this->main_settings['smtp_password'];                           // SMTP password
            $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
            $mail->Port = $this->main_settings['smtp_port'];                                    // TCP port to connect to
//$mail->Port = 465;                                    // TCP port to connect to

            $mail->From = $_POST['email'];
            $mail->FromName = 'Mail '.$from;
            $mail->addAddress($to, 'Joe User');     // Add a recipient
            $mail->addReplyTo($from, 'Information');

            $mail->isHTML(true);                                  // Set email format to HTML

            $mail->Subject = $subject;

            $mail->Body    = $message;

//            print_r($mail);

            if(!$mail->send()) {
                $aux= 'Message could not be sent.';
                $aux.= 'Mailer Error: ' . $mail->ErrorInfo;
                return $aux;
            } else {
                return true;
            }
        }else{

            $aux = mail($to, $subject, $message, $headers);
            return $aux;
        }





    }

    function mysql_delete_track($arg){
//        print_r($_POST);


        $margs = array(
            'table'=>'tracks'
        );



        if($this->main_settings['delete_track_on_track_removal']=='on'){



            $query = "SELECT * FROM `".$margs['table']."` WHERE `id` = '".$arg."'";


            $aux = $this->dblink->query($query);

            if($aux){

                $row = mysqli_fetch_assoc($aux);

//                        print_r($row);
                $path = $row['content'];

                unlink($path);
            }


        }


        $query = "DELETE FROM tracks WHERE id='$arg'";

        $aux = $this->dblink->query($query);

        if ($aux) {




            return true;
        } else {
            return mysqli_error($this->dblink);
        }
    }



    function mysql_get_track_activity($track_id, $pargs = array()){



        $margs = array(
            'get_last'=>'off',
            'interval'=>'24',
            'type'=>'view',
            'table'=>'detect',
            'day_start'=>'3',
            'day_end'=>'2',
            'get_count'=>'on',
        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        }



        $format_track_id = 'track_id';
        if($margs['type']=='repost'||$margs['type']=='download'){

            if($margs['table']=='detect'){
                $margs['table']='activity';
                $format_track_id = 'target_track_id';
            }
        }

        if($margs['table']=='detect'){
            $margs['table']='views';
        }



        if($margs['table']=='activity'){


            if($margs['type']=='repost'){

                $format_track_id = 'id_user';
            }else{

                $format_track_id = 'target_track_id';
            }
        }
        if($margs['table']=='views'){

            $format_track_id = 'track_id';

        }

        $query = "SELECT ";


        if($margs['get_count']=='on'){

            $query.='COUNT(*)';
        }else{

            $query.='*';
        }

        $query.=" FROM `".$margs['table']."` WHERE `".$format_track_id."` = '".$track_id;


        if(strpos($margs['type'], '%')!==false){

            $query.="' AND type LIKE '".$margs['type']."'";
        }else{

            $query.="' AND type='".$margs['type']."'";
        }


        if($margs['get_last']=='on'){
            $query.=' AND date > DATE_SUB(NOW(), INTERVAL '.$margs['interval'].' HOUR)';
        }

        if($margs['get_last']=='day'){
            $query.=' AND date BETWEEN DATE_SUB(NOW(), INTERVAL '.$margs['day_start'].' DAY)
    AND DATE_SUB(NOW(), INTERVAL  '.$margs['day_end'].' DAY)';

//            echo ' query - '.$query;
        }

        // -- interval start / end


//        echo 'query - '.$query."\n"."\n";

        $aux = $this->dblink->query($query);


        $auxa = array();
        if($aux){
            while($aux2 = mysqli_fetch_assoc($aux)) {

//                print_r($aux2);

                if($margs['get_count']=='on'){

                    if(isset($aux2[0])){

                        return $aux2[0];
                    }else{
                        return 0;
                    }
                }else{
                    array_push($auxa, $aux2);
                }
            }
        }
        return $auxa;
    }
    function mysql_get_track_likes($track_id){

        $query = "SELECT COUNT(*) FROM `views` WHERE `track_id` = '$track_id' AND type='like'";


        $aux = $this->dblink->query($query);


        if($aux){
            while($aux2 = mysqli_fetch_row($aux)) {

                return $aux2[0];
            }
        }
        return 0;
    }
    function mysql_get_track_ratings_count($track_id){

        $query = "SELECT COUNT(*) FROM `ratings` WHERE `track_id` = '$track_id'";


        $aux = $this->dblink->query($query);


        if($aux){
            while($aux2 = mysqli_fetch_row($aux)) {

                return $aux2[0];
            }
        }
        return 0;
    }

    function regex_get_attr($argtext, $arg){

        $output_array = array();
        preg_match("/".$arg."=\"(.*?)\"/", $argtext, $output_array);
        return $output_array;
    }

    function get_published_time($arg){

        $now_time = strtotime(date('Y-m-d'));
        $from_time = strtotime($arg);

//                echo 'to time -> '.$from_time;


        if(round(abs($now_time - $from_time) / 60/60/24,2)=='0'){
            return __("Today");
        }elseif(round(abs($now_time - $from_time) / 60/60/24,2)=='1'){
            return __("1 day ago");
        }else{

            $aux_str = '';
            $aux = round(abs($now_time - $from_time) / 60/60/24,2);
            if($aux>30){

                $aux = round(abs($now_time - $from_time) / 60/60/24/30,0);
                $aux_str = $aux.__(' months ago');

            }else{
                $aux_str = intval($aux).__(' days ago');
            }

            return $aux_str;
        }

    }

    function get_query($pargs){



        $margs = array(
            'style' => 'auto', // -- auto or default or list or slider ...tbc :: for explore
            'type' => 'auto', // -- auto or explore or mytracks or playlist or playlists or "stream" or "custom_ids"
            'query_type' => '', // -- auto or explore or mytracks or playlist or playlists or "stream" or "custom_ids"
            'pagination' => 'auto', // -- auto or none or ajax or pages or pagesajax
            'apconfig' => '', // -- the audio player configuration
            'limit_posts' => '', // -- limit the number of posts displayed. if pagination is set to ajax, the other next posts will come up.
            'custom_ids' => '', // -- for ajax
            'get_only_tracks' => false, // -- get only the tracks for a ajax approach ( no container )
            'call_from_ajax' => 'off', // -- get only the tracks for a ajax approach ( no container )
            'paged' => '0', // -- for ajax
            'query_query' => '', // -- the query arguments
            'currpage_type' => '', // -- the query arguments
            'call_from' => 'default', // -- developer call_from
        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        }

        if($margs['call_from']=='page_user'){

//            echo 'can you feel the change';print_r($margs);
        }


        $track_id = 1;

        $fout = '';

        $tracks = array();

        if($margs['query_type'] && $margs['query_type']!='auto'){
            $margs['type']=$margs['query_type'];
        }

        // -- just so we know if this is a auto query so we can assign auto vars
        $type_was_auto = false;


//        print_r($this);


        if($margs['type']==='auto' || $margs['type']===''){
            $type_was_auto = true;
            if($this->currPage_type=='explore'){
                $margs['type']='explore';
            }
            if($this->currPage_type=='track'){
                $margs['type']='track';
            }
            if($this->currPage_type=='stream'){
                $margs['type']='stream';
            }
            if($this->currPage_type=='playlist'){
                $margs['type']='playlist';
            }
            if($this->currPage_type=='tag'){
                $margs['type']='tag';
            }
            if($this->currPage=='post'){
//                echo 'hmm';
                $margs['type']='post';


                if($margs['style']=='auto') {
                    $margs['style'] = 'post_display';
                }
            }

            if($this->currPage=='user'){
//                echo 'alceva';
                if($this->currPage_type=='playlists'){

                    $margs['type']='playlists';
//                    echo 'alceva';

                }

//                echo $this->currPage_type.$this->query3;
                if($this->currPage_type=='following'){

                    $margs['type']='following';
//                    echo 'alceva';

                }
                if($this->currPage_type=='followers'){

                    $margs['type']='followers';
//                    echo 'alceva';

                }
                if($this->currPage_type=='likes'){

                    $margs['type']='likes';
//                    echo 'alceva';

                }
            }
            if($this->currPage=='embed'){

                $margs['type']='track';


                if($margs['style']=='auto') {
                    $margs['style'] = 'under';
                }


            }

        }
        if($margs['type']==='auto'){
            $margs['type'] = 'explore';


        }

        $args_get_tracks = array();


        $args_get_tracks['limit_posts'] = $margs['limit_posts'];
        $args_get_tracks['call_from'] = $margs['call_from'];
        $args_get_tracks['custom_ids'] = $margs['custom_ids'];
        $args_get_tracks['pagination'] = $margs['pagination'];
        $args_get_tracks['apconfig'] = $margs['apconfig'];
        $args_get_tracks['call_from_ajax'] = $margs['call_from_ajax'];
        $args_get_tracks['paged'] = $margs['paged'];
        $args_get_tracks['thumbs_per_row'] = $margs['thumbs_per_row'];

        $margs['limit_posts'] = intval($margs['limit_posts']);


        if($this->currPage=='user'){
            $arg_user_id = $_GET['user_id'];


            if($this->main_settings['use_pretty_links']=='on') {
                $searched_title = $_GET['user_id'];
                $auxarr = $this->get_users();


                foreach ($auxarr as $lab => $it) {
//                    print_r($it);

//                    echo $dzsap_portal->sanitize_title_for_pretty($it['username']).' '.$searched_title.' --- ';
                    if ($this->sanitize_title_for_pretty($it['username'], array(
                            'type' => 'user'
                        )) == $searched_title
                    ) {

                        $arg_user_id = $it['id'];
                        break;
                    }
                }
            }


            if($type_was_auto){
                $args_get_tracks['author_id'] = $arg_user_id;
            }


            if($margs['call_from']==='page_user'){

//                print_r($margs);
//                print_r($args_get_tracks);
            }

        }



        if($margs['type']=='stream'){

//            echo 'get_query margs - ';print_r($margs);
        }

        if($margs['type']=='explore'){


//            print_r($margs);

            if(strpos($margs['post_type'],'album')!==false){
                if(isset($args_get_tracks['type'])==false){
                    $args_get_tracks['type']='';
                }

                $args_get_tracks['type'].='album,';
            }
            if($margs['post_type']=='album'){
                $args_get_tracks['type'].='album';

            }

            if(strpos($margs['post_type'],'track')!==false){
                if(isset($args_get_tracks['type'])==false){
                    $args_get_tracks['type']='';
                }

                $args_get_tracks['type'].='track,';
            }

            if(strpos($margs['post_type'],'soundcloud')!==false){
                if(isset($args_get_tracks['type'])==false){
                    $args_get_tracks['type']='';
                }

                $args_get_tracks['type'].='soundcloud,';
            }



            if($margs['call_from']==='page_user'){

//                echo ' ___ page_user ___';
//                print_r($margs);
//                print_r($args_get_tracks);
            }

            $args_get_tracks['query_type'] = 'sortbydate';
            $tracks = $this->get_tracks($args_get_tracks);


            if($margs['style']=='auto'){
                $margs['style'] = 'under-with-timeline';
            }
        }
        if($margs['type']=='mostliked'){


            $args_get_tracks['query_type'] = 'mostliked';
            $tracks = $this->get_tracks($args_get_tracks);
        }
        if($margs['type']=='track'){



            if($this->track_id==0){
                if(isset($_GET['id'])){
                    $this->track_id = $_GET['id'];
                }
                if(isset($_GET['track_id'])){
                    $this->track_id = $_GET['track_id'];
                }
            }

        }
        if($margs['type']=='mostviewed'){


            $args_get_tracks['query_type'] = 'mostviewed';
            $args_get_tracks['interval'] = $margs['interval'];
            $tracks = $this->get_tracks($args_get_tracks);



//            print_r($tracks);
        }
        if($margs['type']=='post'){


            $args_get_tracks['query_type'] = 'post';
            $args_get_tracks['table'] = 'posts';


            if($this->currPage=='post'){
                $arg_post_id = $_GET['post_id'];

                $args_get_tracks['track_id'] = $arg_post_id;
            }

            $tracks = $this->get_tracks($args_get_tracks);


        }
        if($margs['type']=='posts'){


            $args_get_tracks['query_type'] = 'posts';

            if($margs['post_type']){
                $args_get_tracks['table'] = $margs['post_type'].'s';
            }
            if($margs['post_type']=='event'){

                $args_get_tracks['table'] = 'posts';
                $args_get_tracks['post_type_type'] = 'event';
            }
            if($margs['post_type']=='post'){

                $args_get_tracks['table'] = 'posts';
                $args_get_tracks['post_type_type'] = 'post';
            }

//            print_r($margs); echo 'hier args get tracks -> ';print_r($args_get_tracks);
            $tracks = $this->get_tracks($args_get_tracks);
        }
        if($margs['type']=='blogs'){


            $args_get_tracks['query_type'] = 'posts';

            if($margs['post_type']){
                $args_get_tracks['table'] = $margs['post_type'].'s';
            }
            if($margs['post_type']=='post'){

                $args_get_tracks['table'] = 'posts';
                $args_get_tracks['post_type_type'] = 'post';
            }

//            echo 'hier args get tracks -> ';print_r($args_get_tracks);
            $tracks = $this->get_tracks($args_get_tracks);
        }
        if($margs['type']=='custom_ids'){


            $args_get_tracks['query_type'] = 'custom_ids';
            if($margs['custom_ids']){
                $args_get_tracks['custom_ids'] = $margs['custom_ids'];
            }
            if($margs['query_query']){
                $args_get_tracks['custom_ids'] = $margs['query_query'];
            }

//            print_r($args_get_tracks);
            $tracks = $this->get_tracks($args_get_tracks);
        }
        if($margs['type']=='stream'){


            $args_get_tracks['query_type'] = 'stream';
            $tracks = $this->get_tracks($args_get_tracks);

//            echo 'stream results - '; print_r($tracks);

            if(count($tracks)==0){

                $fout.='<div class="stream-empty-notice">'.__("You don't have any following artists. Choose some track artists to follow from the public stream:").'</div>';;

                $this->currPage_type='explore';
                $args = array_merge(array(), $margs);

                $args['type']='explore';
                $fout.=$this->get_query($args);


            }
        }


        if($margs['type']=='playlist'){


            $args_get_tracks['query_type'] = 'playlist';
            if($margs['query_query']){

                $args_get_tracks['query_query'] = $margs['query_query'];
            }else{

                $args_get_tracks['query_query'] = DZSHelpers::get_query_arg(dzs_curr_url(), 'playlist_id');
            }
            $tracks = $this->get_tracks($args_get_tracks);
        }


        if($margs['type']=='playlists'){


            $args_get_tracks['query_type'] = $margs['type'];
            if($margs['query_query']){

                $args_get_tracks['author_id'] = $margs['query_query'];
            }else{

                $args_get_tracks['author_id'] = $_GET['user_id'];
            }
            $args_get_tracks['table']='playlists';
            $args_get_tracks['call_from']='get_query | playlists';
            $tracks = $this->get_tracks($args_get_tracks);
        }

//        echo ' --- get_query() margs --';print_r($margs);
        if($margs['type']=='following'||$margs['type']=='followers'){


            $args_get_tracks['query_type'] = $margs['type'];
            if($margs['query_query']){

                $args_get_tracks['id'] = $margs['query_query'];
            }else{

//                print_r($_GET);
                $args_get_tracks['id'] = $_GET['user_id'];

                if($this->query2_processed){
                    $args_get_tracks['id'] = $this->query2_processed;
                }

//                echo 'user page - '.$this->query2_processed;
            }
            $args_get_tracks['table']='users';
            $args_get_tracks['author_id']='';

//            print_r($margs);

            if($margs['style']==='auto'){
                $margs['style'] = 'round';
            }

            $tracks = $this->get_tracks($args_get_tracks);

//            echo' hmm'; print_r($tracks);
        }
        if($margs['type']=='likes'){

            $args_get_tracks['query_type'] = $margs['type'];
            $args_get_tracks['id_user'] = $_GET['user_id'];
            $args_get_tracks['table']='likes';
            if($margs['style']==='auto'){
                $margs['style'] = 'under';
            }
            $args_get_tracks['author_id']='';
            $tracks = $this->get_tracks($args_get_tracks);

//            print_r($tracks);
        }
//        print_r($margs);
        if($margs['type']=='events'){


            $args_get_tracks['query_type'] = $margs['type'];
//            if($margs['query_query']){
//
//                $args_get_tracks['author_id'] = $margs['query_query'];
//            }else{
//
//                $args_get_tracks['author_id'] = DZSHelpers::get_query_arg(dzs_curr_url(), 'user_id');
//            }

            $args_get_tracks['table']='posts';
            $args_get_tracks['post_type_type']='event';
            $tracks = $this->get_tracks($args_get_tracks);
        }


        if($margs['type']=='tag'){


            $args_get_tracks['query_type'] = $margs['type'];
            if($margs['query_query']){

                $args_get_tracks['query_query'] = $margs['query_query'];
            }else{

                $args_get_tracks['query_query'] = DZSHelpers::get_query_arg(dzs_curr_url(), 'query');
            }
            $tracks = $this->get_tracks($args_get_tracks);
        }


        if($margs['type']=='similar'){


            $args_get_tracks['query_type'] = 'similar';
            if($margs['query_query']){

                $args_get_tracks['query_query'] = $margs['query_query'];
            }else{

                if($this->currPage=='track'){
//                    echo 'animal';

                    $track_id = 1;

                    if(isset($_GET['id'])){
                        $track_id = $_GET['id'];
                    }
                    if(isset($_GET['track_id'])){
                        $track_id = $_GET['track_id'];
                    }
                    $tr = $this->get_track($track_id);

//                    print_r($tr);


                    if(isset($tr['tags'])){
                        $args_get_tracks['query_query'] = $tr['tags'];
                    }

                }
            }
            $tracks = $this->get_tracks($args_get_tracks);
        }




        if($margs['type']=='track'){

//            $tracks = $this->get_tracks();

            $track_id = '0';

            if($this->track_id){
                $track_id = $this->track_id;
            }

//            print_r($margs);

            if($margs['query_query']){
                $track_id = $margs['query_query'];
            }

//            echo 'alceva';
            $tracks = $this->get_tracks(array(
                'track_id' => $track_id
            ));

        };

//        print_r($margs);

        $ajax_margs = array_merge(array(), $margs);


//        echo $this->currPage;





//        print_r($margs);


//        echo '---- get query $margs --> '; print_r($margs);
//
//
//
//        echo ' get tracks ---> '; print_r($tracks); echo ' <--- get tracks ||| ';


        $custom_ids = array();

        if(is_array($tracks)==false){
            return  '<div class="warning">'.$tracks.'</div>';
        }

        if($margs['call_from']=='page_user'){

//            echo ' get tracks ---> '; print_r($tracks); echo ' <--- get tracks ||| ';
        }

        foreach($tracks as $tr){
            if(isset($tr['id'])){

                array_push($custom_ids, $tr['id']);
            }
        }

        $ajax_margs['custom_ids'] = $custom_ids;
        $ajax_margs['pagination'] = 'auto';
//        $ajax_margs['type'] = 'custom_ids';
        $ajax_margs['type'] = $margs['type'];
        $ajax_margs['real_type'] = $margs['type'];
        $ajax_margs['get_only_tracks']=true;

        if($custom_ids){

            $ajax_margs['query_type'] = 'custom_ids';
        }

        if($margs['limit_posts']>0){

            if($margs['paged']>0){



                foreach($tracks as $tr){

//                    echo '  >> '.$tr['id'].'<< ';
                }

//                echo ' \n _______________ \n ('.(intval($margs['paged'])*intval($margs['limit_posts'])).') ('.((intval($margs['paged']) + 1)*  intval( $margs['limit_posts'] ) ).') ';

                $tracks = array_slice($tracks, (intval($margs['paged'])*intval($margs['limit_posts'])), intval( $margs['limit_posts'] ) );

                foreach($tracks as $tr){

//                    echo '  >> '.$tr['id'].'<< ';
                }
            }else{
                $tracks = array_slice($tracks, 0, $margs['limit_posts']);
            }
//            $tracks = array_slice($tracks, $margs['limit_posts'],100);
        }



//        echo ' new tracks -- COUNT: '.count($tracks).'- why? paged-'.intval($margs['paged']).' --> '.intval($margs['paged']*$margs['limit_posts']).' ---- '.(intval($margs['paged']) + 1)*( $margs['limit_posts'] ).' - ';
//        print_r($tracks);

        if($margs['style']=='auto'){
            $margs['style'] = 'under';

//            echo $this->currPage_type;
            if($this->currPage_type=='stream' || $margs['currpage_type']=='stream'){
                $margs['style']='under-with-timeline';
            }
        }





//        print_r($margs);






//        print_r($tracks);

        if($margs['get_only_tracks']!=true){

            $fout.='<div class="shortcode-query shortcode-query-type-'.$margs['type'].' style-'.$margs['style'].' pagination-'.$margs['pagination'].'';

            $fout.='"';






            if($margs['pagination']=='button'||$margs['pagination']=='scroll'||$margs['pagination']=='pagination'){

                $fout.=' data-currPage="1"';


                $nr_pages = 1;
                if(intval($ajax_margs['limit_posts'])){

                    $nr_pages = count($ajax_margs['custom_ids']) / intval($ajax_margs['limit_posts']);
                }

                $nr_pages = ceil($nr_pages);

                $fout.=' data-maxPages="'.$nr_pages.'"';

                $ajax_margs['call_from_ajax']='on';

//                print_r($ajax_margs);

                $fout.=' data-thequery=\''.json_encode($ajax_margs).'\'';
            }


            $fout.='>';
        }

//        print_r($margs);



        if($margs['style']==='under'){

//            echo $margs['type'];
            if($margs['type']==='playlists'){


                $fout .= '<div class="playlists-view-con">';

                foreach($tracks as $pl){





                    $fout .= '<div class="playlist-con">';



                    $aux_str = '';

                    $pl_items = unserialize($pl['content']);


                    $published_date = $pl['published_date'];

                    if($pl_items==false || is_array($pl_items)==false){
                        $pl_items = array();
                    }

                    foreach($pl_items as $pl_item2){

                        $tr = $this->get_track($pl_item2);

//                    print_r($tr);

                        if(isset($tr['thumbnail']) && $tr['thumbnail']){
                            $aux_str.='<li class="item-tobe needs-loading"><div class="imagediv" style="background-image:url('.$this->sanitize_source($tr['thumbnail']).')"></div></li>';
                        }
                    }





                    $fout .= '<div class="float-it-right">';

                    $fout .= '<div class="playlist-date">'.$published_date.'</div>';
                    $fout .= '<div class="playlist-count"><i class="fa fa-music"></i>&nbsp;&nbsp;'.count($pl_items).' '.__("Tracks").'</div>';

                    $fout .= '';
                    $fout .= '</div>';

                    $fout .= '<div class="overflow-it" style="text-align:left;">';

                    $fout .= '<div class="thumb-con"><div class="advancedscroller skin-nonav auto-init-from-dzsapp "  style="width:100%; height: 100px" data-options=\'{ settings_autoHeight: "off"
                ,settings_mode: "onlyoneitem"
                ,settings_slideshow: "on"
            ,settings_transition: "fade" // slide or fade
            ,settings_slideshowTime: "3" //in seconds
                 }\'>
        <ul class="items">'.$aux_str.'

    </ul></div></div>';

                    $fout .= '<a href="'.$this->optional_url_base.'index.php?page=tracklist&type=playlist&playlist_id='.$pl['id'].'" class="playlist-title ';

                    if($this->main_settings['use_ajax']=='on'){
                        $fout .= ' ajax-link';
                    }

                    $fout .= '">'.$pl['title'].'</a>';



//                print_r($pl_items);

                    $fout.='<div data-playerid="'.$pl['id'].'" style="float:none; " class="share-btn skin-simple" ><div class="hidden-content share-content" id="share-content-'.$pl['id'].'"><h6>'.__("Social Networks").'</h6><a class="social-icon" href="#"  onclick=\'window.dzsapp_open_social_link("http://www.facebook.com/sharer.php?t='.urlencode($pl['title']).'&u='.urlencode(dzs_curr_url()).'"); return false;\'><i class="fa fa-facebook-square"></i><span class="the-tooltip">'.__('SHARE ON ').' FACEBOOK</span></a>


                                <a class="social-icon" href="#" onclick=\'window.dzsapp_open_social_link("http://twitter.com/share?url='.urlencode(dzs_curr_url()).'&amp;=text=Check this out!&amp;via='.$this->clean($this->main_settings['site_title']).'&amp;related=yarrcat"); return false;\'><i class="fa fa-twitter"></i><span class="the-tooltip">SHARE ON TWITTER</span></a>
                                <a class="social-icon" href="#" onclick=\'window.dzsapp_open_social_link("https://plus.google.com/share?url='.urlencode(dzs_curr_url()).'"); return false; \'><i class="fa fa-google-plus-square"></i><span class="the-tooltip">'.__('SHARE ON ').' GOOGLE PLUS</span></a>


                                <a class="social-icon" href="#" onclick=\'window.dzsapp_open_social_link("https://www.linkedin.com/shareArticle?mini=true&url=mysite&title=Check%20this%20out%20{{replaceurl}}&summary=&source='.urlencode(dzs_curr_url()).'"); return false; \'><i class="fa fa-linkedin"></i><span class="the-tooltip">'.__('SHARE ON ').'  LINKEDIN</span></a>

                                <a class="social-icon" href="#" onclick=\'window.dzsapp_open_social_link("http://pinterest.com/pin/create/button/?url='.urlencode(dzs_curr_url()).'&amp;text=Check this out!&amp;via='.$this->clean($this->main_settings['site_title']).'&amp;related=yarrcat"); return false;\'><i class="fa fa-pinterest"></i><span class="the-tooltip">'.__('SHARE ON ').'  PINTEREST</span></a>

                                <h6>'.__("Share Link").'</h6>

                                <div class="field-for-view">'.$this->get_permalink($track_id, array(
                            'type'=>'track',
                        )).'</div>





                                </div><span class="the-icon"><i class="fa fa-share-alt"></i></span><span class="btn-label">'.__('Share').'</span></div>';



                    $fout .= '';
                    $fout .= '</div>';

                    $fout .= '</div>';
                }
                $fout .= '</div>';

            }else{
                $fout .= '<div class="style-under-con">';
                foreach($tracks as $track){


                    $fout .= '<div class="style-under--item">';
                    if(isset($track['id'])) {




                        $fout.=$this->generate_pre_track_info($track, $margs);

                        $args = array(
                            'apconfig' => $margs['apconfig']
                        );


                        $args['embedded_iframe_id'] = '';
                        if($this->currPage=='embed'){
                            $args['embedded']='on';
                            if(isset($_GET['embedded_iframe_id'])){
                                $args['embedded_iframe_id']=$_GET['embedded_iframe_id'];
                            }

                        }



//                        echo 'style under show_player args - '; print_r($args);
                        $fout .= $this->show_player($track['id'], $args);
                    }
                    $fout.='</div>';
                }
                $fout .= '</div>';

            }



        }

        if($margs['style']==='round'){

//            echo $margs['type'];
            if($margs['type']==='following' || $margs['type']==='followers'){


                if($margs['get_only_tracks']!=true) {
                    $fout .= '<div class="following-view-con row">';
                }

//                print_r($tracks);

                foreach($tracks as $pl){

                    if(isset($pl['post_type']) && $pl['post_type']=='repost'){
                        continue;
                    }

                    $l = $this->get_permalink($pl['id'], array(
                        'type'=>'user',
                    ));
                    $fout.='<a  href="'.$l.'" class="col-md-2 ajax-link user-round-view">';



                    $fout.='<div class="js-height-as-width the-avatar" style="background-image:url('.$this->sanitize_source($this->get_avatar($pl['id'])).'); " >';


                    $fout .= '</div>';


                    $fout.='<h4>'.$this->get_username($pl['id']).'</h4>';


//                    print_r($pl);

                    $fout.='</a>';
                }
                if($margs['get_only_tracks']!=true) {
                    $fout .= '</div>';
                }

            }else{

            }



        }

        if($margs['style']==='charts'){


            $fout .= '<div class="container-fluid dzsap-charts" style="margin-top: 10px">

                        <div class="table-row header">
                            <div class="wrapper text-4">
                                <div class="number-col">#</div>
                                <div class=" track-col"></div>
                                <div class="title-col">'.__("Track").'</div>
                                <div class="stats-col">'.__("Plays This Week").'
                                </div>

                            </div>
                        </div>

                        ';

            $i5 = 0;
            foreach($tracks as $che){


                $i5++;
//                    print_r($che);

                $track_link =$this->get_permalink($che['id'], array(
                    'type'=>'track',
                ));

                $track_author_link = $this->get_permalink($che['author_id'], array(
                    'type'=>'user',
                ));

//                print_r($che);

                if($che['type']=='album'){
//                    continue;
                }

                $track_author_name = $this->get_username($che['author_id']);

                $fout.='<div class="table-row body-row">
                            <div class="wrapper text-4">
                                <div class="number-col">'.$i5.'</div>
                                <div class=" track-col">
                                    <div class="track-con "  style="width: 60px ; height: 60px; margin-bottom: 0; ">


                                        <div class="dzsparallaxer-con" style="width: 100% ; border-width: 3px;">
                                            <div class="dzsparallaxer auto-init" data-options=\'{   direction: "reverse"}\' style=" height: 50px;">

                                                <div class="divimage dzsparallaxer--target " style="width: 100%;  height: 80px; background-image: url('.$this->sanitize_source($che['thumbnail'], array(

                        'resize_image'=>true,
                        'resize_w'=>'80',
                        'resize_h'=>'80',
                    )).')">
                                                </div>

                                            </div>

                                        </div>';




                $fout.=$this->show_player($che['id'],array(

                        'apconfig'=>array(
                                'skin_ap'=>'skin-customcontrols',
                        ),
                    'extra_classes'=>' from-charts',
                    'extra_classes_gallery'=>' from-charts',
                    'disable_extra_html'=>'on',
                    'disable_edit'=>'on',
                    'called_from'=>'charts',
                    'disable_tags'=>'on',
                    'inner_html'=>'<div class="custom-play-btn"><div class=" play-button-con"  style="color: #cb1919; width: 25px; height: 25px;"><i class="fa fa-play" style="font-size: 12px;"></i></div></div>
                                            <div class="custom-pause-btn"><div class=" play-button-con "  style="color: #cb1919; width: 25px; height: 25px;"><i class="fa fa-pause" style="font-size: 12px;"></i></div></div>',
                ));



                /*
                $fout.='

                                        <div class="audioplayer-tobe skin-customcontrols from-charts auto-init"  data-fakeplayer="#apapfooter" style=""    data-type="audio" data-source="'.$this->sanitize_source($che['content']).'" data-scrubbg="'.$che['waveform_bg'].'" data-scrubprog="'.$che['waveform_prog'].'"';


                if($this->get_setting('pcm'.$che['id'])){
                    $fout.=' data-pcm="'.$this->get_setting('pcm'.$che['id']).'"';
                }

                $fout.='>';



                $fout.='<div class="meta-artist"><span class="the-artist "><a class=" ajax-link" href="'.$track_link.'">'.$che['title'].'</a></span>&nbsp;<span class="the-name"><a class=" ajax-link" href="'.$track_author_link.'">'.$track_author_name.'</a></span></div>';

                $fout.='
                                            <div class="custom-play-btn"><div class=" play-button-con"  style="color: #cb1919; width: 25px; height: 25px;"><i class="fa fa-play" style="font-size: 12px;"></i></div></div>
                                            <div class="custom-pause-btn"><div class=" play-button-con "  style="color: #cb1919; width: 25px; height: 25px;"><i class="fa fa-pause" style="font-size: 12px;"></i></div></div>
                                        </div>


';

                */

                if($che['views']==''){
                    $che['views'] = '0';
                }
$fout.='

                                    </div>

                                </div>
                                <div class="title-col">

                                    <div class="the-track"><a href="'.$track_link.'">'.$che['title'].'</a></div>
                                    <div class="the-artist"><a class="custom-a"" href="'.$track_author_link.'">'.__('by').' '.$track_author_name.'</a></div>
                                </div>
                                <div class="stats-col">
                                    <i class="fa fa-play"></i> <span class="the-label play-count-label" data-player-id="'.$che['id'].'">'.($che['views']).'</span>
                                </div>

                            </div>';
                $fout .= '</div>';
            }
            $fout .= '</div>';



        }



        if($margs['style']==='simple_list'){

//            echo $margs['type'];

//            print_r($tracks);

            $fout.='<ul class="simple-list">';
            foreach($tracks as $po){



//                print_r($po);

                if($margs['post_type']==='comment'){


                    $author_name = '';
                    if($po['author_id']>0){
                        $author_name = $this->get_username($po['author_id']);
                    }else{

                        if($po['name']){
                            $author_name = $po['name'];
                        }else{

                            if($po['email']){
                                $aux_arr = explode('@', $po['email']);

                                $author_name = $aux_arr[0];

                            }
                        }
                    }


                    $the_target_po = $this->get_page($po['track_id'],array(
                        'post_type'=>'post'
                    ));



                    $fout.='<li><a href="#">'.$author_name.'</a> in <a class="ajax-link" href="index.php?page='.$po['for_type'].'&post_id='.$po['track_id'].'">'.$the_target_po['title'].'</a></li>';
                }

                if($margs['post_type']==='event'){





                    $str_mon= date("d F Y", strtotime($po['published_date']));


                    $fout.='<li><a class="ajax-link" href="index.php?page=post&post_id='.$po['id'].'">'.$po['title'].'</a> on '.$str_mon.'</li>';
                }

            }
            $fout.='</ul>';




        }


//        print_r($margs);
        if($margs['style']==='list-nova'){

//            echo $margs['type'];

//            print_r($tracks);

            if($margs['get_only_tracks']!=true) {
                $fout .= '<ul class="style-nova">';
            }
            foreach($tracks as $po){



                if(isset($po['id'])){

                }else{
                    continue;
                }


                $fakeplayer = '';

                if($this->main_settings['footer_player_config'] && $this->main_settings['footer_player_config']!='off'){

                    $fakeplayer = '#apapfooter';
                }else{

                    $fakeplayer = '';
                }


//                print_r($po);

                $fout.='<li>';

                $l = $this->get_permalink($po['id'], array(
                    'type'=>'track',
                ));



                $str_price =  $this->main_settings['currency_label'].''.$po['price'];

                if($po['price']==false || $po['price']=='0'){
                    $str_price = $this->translate_free;
                }



                $track_link = $this->sanitize_for_pretty($po['id']);
                $track_author_link = $this->sanitize_for_pretty($po['author_id'], array(
                    'type'=>'user',
                ));
                $track_author_name = $this->get_username($po['author_id']);
                $playerid = $po['id'];



                $soundcloud_api_key = $this->main_config_settings['soundcloud_api_key'];

                if($this->main_settings['soundcloud_api_key']){
                    $soundcloud_api_key = $this->main_settings['soundcloud_api_key'];
                }



                $fout.='<div class="li-thumb" style="background-image: url('.$this->sanitize_source($po['thumbnail']).')">';




                $fout.=$this->show_player($po['id'],array(

                    'apconfig'=>array(
                        'skin_ap'=>'skin-customcontrols',
                    ),
                    'extra_classes'=>' from-li-thumb',
                    'extra_classes_gallery'=>' ',
                    'disable_extra_html'=>'on',
                    'disable_edit'=>'on',
                    'called_from'=>'style-nova',
                    'disable_tags'=>'on',
                    'inner_html'=>'<div class="custom-play-btn playbtn-darkround"></div>
                            <div class="custom-pause-btn pausebtn-darkround"></div>',
                ));





                $fout.='</div>';
                $fout.='<div class="li-meta"><a class="ajax-link track-title" href="'.$l.'">'.$po['title'].'</a><div class=" track-by">'.__("by ").$this->get_username($po['author_id']).'</div><div class="the-price">'.$str_price.'</div></div>';



                $buy_button_str = '';

                $id = '1';

                if(isset($po['id'])){

                    $id = $po['id'];
                }

                $download_str = '<div class="buy-con"><a href="index.php?page=download&track_id='.$id.'" class="button button--vive padding-small custom-a" data-playerid="{{playerid}}"><i class="fa fa-download"></i> <span class="btn-label">'.__('Download').'</span></a></div>';


                if(isset($po['is_buyable']) && $po['is_buyable']=='on'){
                    if($this->main_settings['enable_shop']=='on') {
                        $buy_button_str = '<div class="buy-con">
<a href="#" class="button button--vive padding-small add-to-cart-btn" data-playerid="'.$po['id'].'" >' . __("Add to Cart") . '</a>
</div>';
                    }

                    if($this->currUserId>0 || $po['price']==0){
                        $purchases = $this->get_user_purchases($this->currUserId);

                        if(in_array($po['id'], $purchases) || $po['price']==0){

                            $buy_button_str = $download_str;
                        }
                    }
                }

                $fout.=$buy_button_str;



                $fout.='</li>';



            }
            if($margs['get_only_tracks']!=true) {
                $fout .= '</ul>';
            }




        }



        if($margs['style']==='blog_display'){

//            echo $margs['type'];

            foreach($tracks as $bi){


                $bi_meta = $this->get_post_meta_all($bi['id']);


                $str_posted_on = __("Posted on ");

                if($bi['post_type']=='event'){
                    $str_posted_on = __("Scheduled on ");
                }



                $fout.='<div class="blog-display-item">';




//                    print_r($bi);
//                    print_r($bi_meta);

                $str_mon= date("d F Y", strtotime($bi['published_date']));





                $aux = '';

                $aux = $this->get_comments_array($bi['id'], array(
                    'get_only_count'=>true,
                ));;

                if ($aux == false) {
                    $aux = 0;
                }



                $fout.='<h2>';


                $fout.='<a style="cursor:pointer; " href="index.php?page=post&post_id='.$bi['id'].'">';
                $fout.=''.$bi['title'];

                $fout.='</a>';


                $fout.='</h2>';


                $fout.='<div class="post-meta-con">';


                $fout.='<div class="post-meta post-meta-date"><i class="fa fa-pencil"></i> <span class="the-text">'.$str_posted_on.$str_mon.'</span></div>';
                $fout.='<div class="post-meta post-meta-comments"><i class="fa fa-user"></i> <span class="the-text">'.$aux." ".__("comments").'</span></div>';
                $fout.='</div>';

                if($bi_meta['thumbnail']){
                    $fout.='<img class="blog-display-thumb" src="'.$bi_meta['thumbnail'].'"/>';
                }

                if($bi['content']){

                    $cont = $bi['content'];

                    $cont = DZSHelpers::wp_get_excerpt(-1,array(
                        'content'=>$cont,
                        'maxlen'=>'390',
                        'readmore_markup'=>' [...] <br><p><a class="read-more ajax-link" href="index.php?page=post&post_id='.$bi['id'].'">'.__("Read More").' &#10141;</a></p>'
                    ));


                    $fout.='<div class="post-content">'.$cont.'</div>';
                }

                $fout.='</div>';
            }




        }



        if($margs['style']==='post_display'){

//            echo $margs['type'];

            foreach($tracks as $bi){


                $bi_meta = $this->get_post_meta_all($bi['id']);


                $str_posted_on = __("Posted on ");

                if($bi['post_type']=='event'){
                    $str_posted_on = __("Scheduled on ");
                }



                $fout.='<div class="blog-display-item">';




//                    print_r($bi);
//                    print_r($bi_meta);

                $str_mon= date("d F Y", strtotime($bi['published_date']));
                $fout.='<h2>'.$bi['title'].'</h2>';


                $fout.='<div class="post-meta-con">';


                $fout.='<div class="post-meta post-meta-date"><i class="fa fa-pencil"></i> <span class="the-text">'.$str_posted_on.$str_mon.'</span></div>';
                $fout.='<div class="post-meta post-meta-comments"><i class="fa fa-user"></i> <span class="the-text">'.'0'." ".__("comments").'</span></div>';
                $fout.='</div>';



                if($bi_meta['thumbnail']){
                    $fout.='<img class="blog-display-thumb" src="'.$bi_meta['thumbnail'].'"/>';
                }

                if($bi['content']){

                    $cont = $bi['content'];


                    $fout.='<div class="post-content">'.$cont.'</div>';
                }

                $fout.='</div>';
            }




        }





        if($margs['style']==='grid_display'){

//            echo $margs['type'];

            $fout.='<div class="row">';
            foreach($tracks as $bi){


                $bi_meta = $this->get_post_meta_all($bi['id']);


                $str_posted_on = '';


                $fout.='<div class="col-md-4 grid-display-item">';

                $l = 'index.php?page=post&post_id='.$bi['id'].'';

                if($bi_meta['thumbnail']){
                    $fout.='<div class="blog-display-thumb" style="background-image: url('.$bi_meta['thumbnail'].');"></div>';
                }


//                    print_r($bi);
//                    print_r($bi_meta);

                $str_mon= date("d M Y", strtotime($bi['published_date']));
                $fout.='<a class="ajax-link" href="'.$l.'">';
                $fout.='<h3>'.$bi['title'].'</h3>';
                $fout.='</a>';


                $fout.='<div class="post-meta-con">';


                $fout.='<div class="post-meta post-meta-date"><i class="fa fa-pencil"></i> <span class="the-text">'.$str_posted_on.$str_mon.'</span></div>';
                $fout.='<div class="post-meta post-meta-comments"><i class="fa fa-user"></i> <span class="the-text">'.'0'." ".__("").'</span></div>';
                $fout.='</div>';


                if($bi['content']){

                    $cont = $bi['content'];




                    $cont = DZSHelpers::wp_get_excerpt(-1,array(
                        'content'=>$cont,
                        'maxlen'=>150,
                        'readmore_markup' => ' <a class="ajax-link" href="'.$l.'">[...]</a>',
                    ));


                    $fout.='<div class="post-content">'.$cont.'</div>';
                }

                $fout.='</div>';
            }

            $fout.='</div>';



        }






//        print_r($tracks);
//
//        print_r($margs);


        if($margs['style']==='slider'){

            $fout.='<div class="advancedscroller skin-agata-inset auto-init-from-dzsapp animate-height" style="width:100%; height: 200px;" data-options=\'{
            settings_mode: "onlyoneitem"
            ,settings_swipe: "on"
            ,settings_swipeOnDesktopsToo: "off"
            ,settings_slideshow: "on"
            ,settings_slideshowTime: "300"
            ,settings_autoHeight:"on"
            ,settings_transition: "fade"
            ,settings_secondCon: ""
        }\'>
            <div class="preloader-semicircles"></div>
            <ul class="items">
            ';

            foreach($tracks as $track){



                if(isset($track['id'])) {
//                    $fout .= $this->show_player($track['id'], array(
//                        'apconfig' => $margs['apconfig']
//                    ));

                    $img = $this->sanitize_source($track['cover_image']);

                    $fout.='<li class="item-tobe ">
                <img class="fullwidth" src="'.$img.'" style="min-height:200px;"/>
             <a href="'.$this->get_permalink($track['id']).'" class="caption skin-white">'.$track['title'].'</a>
            </li>';
                }
            }

            $fout.='
        </ul>
        </div>';



        }


        $page_explore = $this->get_page('Explore', array(
            'query_by_title'=>true,
        ));

        if($margs['style']==='thumbs'){



            $item_width = '16.66%';








            $fout.='<div class="advancedscroller skin-black auto-init-from-dzsapp animate-height auto-height item-padding-20" style="" data-options=\'{
            settings_mode: "normal"
            ,settings_swipe: "on"
            ,settings_swipeOnDesktopsToo: "off"
            ,settings_slideshow: "on"
            ,settings_slideshowTime: "300"
            ,settings_autoHeight:"on"
            ,settings_transition: "slide"
            ,settings_secondCon: ""
            ,design_itemwidth: "'.$item_width.'%"
            ,responsive_720_design_itemwidth: "50%"
            ,design_itemheight: "200"
            ,design_arrowsize:"0"';

            if($margs['thumbs_disable_arrows']=='on'){
                $fout.=',design_disableArrows:"on"';
            }
            if($margs['design_bulletspos']){
                $fout.=',design_bulletspos:"'.$margs['design_bulletspos'].'"';
            }


            $translate_see_all = __("See All");

            if($margs['thumbs_see_all_text']){

                $translate_see_all = $margs['thumbs_see_all_text'];
            }


            if($margs['style_thumb_replace_page']){

                $link_explore = $this->get_permalink($margs['style_thumb_replace_page'], array(
                    'type'=>'page',
                ));
            }else{

                $link_explore = $this->get_permalink($page_explore['id'], array(
                    'type'=>'page',
                ));
            }


            $fout.='}\'>
        <div class="see-all-con" style="    position: absolute;
    right: 60px;
    top: -23px;
    text-transform: uppercase;
    font-size: 12px;
    color: #B1676F;
    font-weight: 700;"><a href="'.$link_explore.'">'.$translate_see_all.'</a></div>
            <div class="preloader-semicircles"></div>
            <ul class="items">
            ';


//            $fout.='<div>';
            foreach($tracks as $track){



                if(isset($track['id'])) {
//                    $fout .= $this->show_player($track['id'], array(
//                        'apconfig' => $margs['apconfig']
//                    ));

                    $img = $track['thumbnail'];


                    $link_track = $this->get_permalink($track['id'], array(
                        'type'=>'track',
                    ));

                    $fout.='<li class="item-tobe ">
                <a class="ajax-link" href="'.$link_track.'"><div class="fullsize height-same-as-item-width divimage" style="background-image:url('.$img.'); " ></div></a>';




                    $str_price =  $this->main_settings['currency_label'].''.$track['price'];

                    if( (isset($track['price']) && $track['price']==false ) || $track['price']=='0'){
                        $str_price = $this->translate_free;
                    }
                    if($margs['thumbs_display_title_and_price']=='on'){
                        $fout.='<h4 class="track-title">'.$track['title'].'</h4>';
                        $fout.='<em>'.$str_price.'</em>';
                    }

                    $fout.='</li>';
                }
            }

//            $fout.='</div>';
            $fout.='
        </ul>
        </div>';



        }
        if($margs['style']==='under-with-timeline'){


            if($margs['get_only_tracks']!=true) {
                $fout .= '<div class="zoomtimeline  auto-init" data-options="{
}">';
            }
            foreach($tracks as $track){

//                print_r($track);


                $fout.='<div class="ztm-item';


                if(isset($track['post_type']) && $track['post_type']=='repost'){
                    $fout.=' from-repost';
                }


                $fout.='" data-track-id="'.$track['id'].'">

                                <div class="hex-icon">

                                    <i class="the-icon fa fa-music"></i>

                                </div>

                                <div class="hex-desc-con">

                                    <div class="hex-desc">';


//                $fout.= $track['published_date'];




//                echo date('Y-m-d');


                $fout.=$this->get_published_time($track['published_date']);




                $fout.='</div>
                                </div>

                                <div class="ztm-content">
                                ';



//                print_r($margs);

//                echo 'print r from get_query'; print_r($track);

                $arg_margs = array(
                    'apconfig'=>$margs['apconfig']
                );

                if(isset($track['post_type'])){
                    $arg_margs['post_type'] = $track['post_type'];
                }
                if(isset($track['repost_id'])){
                    $arg_margs['repost_id'] = $track['repost_id'];
                }
                if(isset($track['repost_author_id'])){
                    $arg_margs['repost_author_id'] = $track['repost_author_id'];
                }


//                        echo 'style under-with-timeline show_player args - '; print_r($arg_margs);
//                        echo 'style under-with-timeline show_player track - '; print_r($track);


//                print_r($track);

                $fout.=$this->generate_pre_track_info($track, $margs);
                $fout.=$this->show_player($track['id'],$arg_margs);

                $fout.='</div>

                            </div>';
            }

            if($margs['get_only_tracks']!=true) {
                $fout .= '</div>';
            }


            enqueue_script('dzs.timeline', $this->optional_url_base.'zoomtimeline/zoomtimeline.js');
            enqueue_style('dzs.timeline', $this->optional_url_base.'zoomtimeline/zoomtimeline.css');



        }

//        echo $margs['style'];
        $i_number = 0;
        if($margs['style']==='list'){
            $fout.='<div class="list-tracks-con">';

//            print_r($margs);


            foreach($tracks as $track){

//                print_r($track);

                $link = $this->sanitize_for_pretty($track['id']);


                if($margs['type']=='posts'){
//                    print_r($track);

                    $link = 'index.php?page=post&post_id='.$track['id'];

                }

                $fout.='<a class="list-track ajax-link" href="'.$link.'">';

                $fout.='<div class="track-thumb"';

                $l = '';

                if(isset($track['thumbnail'])){

                    $l = $this->sanitize_source($track['thumbnail'], array(

                        'resize_image'=>true,
                        'resize_w'=>'80',
                        'resize_h'=>'80',
                    ));
                }

                if($margs['type']=='posts'){
//                    print_r($track);
                    $po_meta = $this->get_post_meta_all($track['id']);

                    $l = $this->sanitize_source($po_meta['thumbnail']);

                }

                $src_thumb = $l;


                $fout.=' style="background-image: url('.$src_thumb.')"';

                $fout.='>';
                $fout.='</div>';


                $fout.='<div class="track-meta">';
                $fout.='<span class="track-title"';
                $fout.='>';

                $fout.='<span href="">'.$track['title'].'</span>';

                $fout.='</span>';



                $fout.='<div class="track-author"';
                $fout.='>';

                $fout.='<span href="'.$this->optional_url_base.'index.php?page=user&user_id='.$track['author_id'].'">'.$this->get_username($track['author_id'], array(
                        'include_tooltip'=>false
                    )).'</span>';

                $fout.='</div>';

                $fout.='<div class="track-number"';
                $fout.='><span class="the-number">';

                $track_number = ($i_number+1);
                if($margs['paged']){
                    $track_number+=intval($margs['paged']) * $margs['limit_posts'];
                }

                $fout.=$track_number;

                $fout.='</span></div>';




                $fout.='</div>';

                $fout.='</a>';


                $i_number++;

            }
            $fout.='</div>';



        }



        if($margs['style']=='thumb_with_play'){
//            print_r($tracks);


            foreach($tracks as $track){


                $track_src = $this->sanitize_source($track['content']);





                $fout.='<div class=" track-con ">



                    <div class="dzsparallaxer-con">
                    <div class="dzsparallaxer auto-init" data-options=\'{   direction: "reverse"}\' style="height: 330px;">

                        <div class="divimage dzsparallaxer--target " style="width: 100%; height: 375px; background-image: url('.$track['cover_image'].')">
                        </div>

                    </div>

                    </div>




                    <div class="audioplayer-tobe skin-customcontrols auto-init-from-dzsapp" style=""    data-type="normal" data-source="'.$this->sanitize_source($track_src).'">
                        <div class="custom-play-btn"><div class=" play-button-con"  style="color: #cb1919;"><i class="fa fa-play"></i></div></div>
                        <div class="custom-pause-btn"><div class=" play-button-con "  style="color: #cb1919;"><i class="fa fa-pause"></i></div></div>
                    </div>

                    <h3>'.$track['title'].'</h3>


                </div>';


                $buy_button_str = '';

                $download_str = '<div class="buy-con"><a href="index.php?page=download&track_id='.$track['id'].'" class="button button--vive padding-small" data-playerid="{{playerid}}"><i class="fa fa-download"></i> <span class="btn-label">'.__('Download').'</span></a></div>';


                if($track['is_buyable']=='on'){
                    if($this->main_settings['enable_shop']=='on') {
                        $buy_button_str = '<div class="buy-con">
<a href="#" class="button button--vive padding-small">' . __("Add to Cart") . '</a>
</div>';
                    }

                    if($this->currUserId>0 || $track['price']==0){
                        $purchases = $this->get_user_purchases($this->currUserId);

                        if(in_array($track['id'], $purchases) || $track['price']==0){

                            $buy_button_str = $download_str;
                        }
                    }
                }


                $fout.=$buy_button_str;



            }
        }


//        print_r($tracks);

//        print_r($margs);



        if($margs['get_only_tracks']!=true) {

            if($margs['pagination']=='scroll'){
                $fout.='<div class="preloader-con"><div class="center-it"><i class="fa fa-spin-and-center fa-circle-o-notch"></i></div></div>';
            }

            if($margs['pagination']=='button'){
                $fout.='<div class="button-con"><div class="button button--secondary btn-pagination-button"><span class="button-label">'.__("Load More").'</span></div></div>';
            }
            if($margs['pagination']=='pagination'){
                $fout.='<ul class="pagination-con">';


                $nr_pages = count($ajax_margs['custom_ids']) / intval($ajax_margs['limit_posts']);

                $nr_pages = ceil($nr_pages);

//                echo $nr_pages;


                for($i2 = 1; $i2<=$nr_pages;$i2++){
                    $fout.='<li class="';


                    if($i2===1){

                        $fout.='active';
                    }

                    $fout.='">'.'<a class="pagination-a ';


                    $fout.='" data-index="'.$i2.'" href="#">'.$i2.'</a>'.'</li>';
                }

//                print_r($ajax_margs);


                $fout.='</ul>';
            }
            $fout .= '</div><!-- end shortcode-query-type-->';
        }


        return $fout;
    }

    function sanitize_for_pretty($arg, $pargs = array()){



        $margs = array(
            'type'=>'track',
            'page_type'=>'',
            'get_full_link'=>true,
        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        }

        $sw_found = false;

//        echo 'sanitize_for_pretty arg ( '.$arg.' ) margs -'; print_r($margs);


        $fout  = '';
//            echo '$this->main_settings[\'use_pretty_links\'] ( sanitize_for_pretty ) - '.($this->main_settings['use_pretty_links']=='on');
        if($this->main_settings['use_pretty_links']=='on'){


            $fout = $this->permalinks_search(array(
                'target_id'=>$arg,
                'type'=>$margs['type'],
            ));

//            $fout.='hmm';

            if($fout){
                $fout=$this->optional_url_base.$fout;
                if($margs['page_type']){
                    $fout.='/'.$margs['page_type'];

//                    echo ' fout - '.$fout;
                }
                return $fout;
            }

            if($margs['type']=='track'){

                $track = $this->get_track($arg);


//                print_r($track);


                $title_pretty = '';

                if(isset($track['title'])){

                    $title_pretty = $this->sanitize_title_for_pretty($track['title']);
                }

                $fout = '';
                if(isset($track['author_id'])){
                    $fout .= $this->get_permalink($track['author_id'],array(
                        'type'=>'user',
                    ));
                }


//                echo ' fout --- '.$fout."||||";
                $fout.='/'.$title_pretty;

                if($this->optional_url_base){
                    if(strpos($fout, $this->optional_url_base)===false){
                        $fout = $this->optional_url_base.$fout;
                    }
                }


//                echo ' fout --- '.$fout."||||";

//                $fout = $this->optional_url_base.'tracks/'.$title_pretty;
            }

//            print_r($margs);
            if($margs['type']=='user'){

                $track = $this->get_user($arg);



//                print_r($track);

                $fout = $this->sanitize_title_for_pretty($track['username']);

                if($margs['get_full_link']){
                    if($this->optional_url_base){
                        if(strpos($fout, $this->optional_url_base)===false){
                            $fout = $this->optional_url_base.$fout;
                        }
                    }
                }

//                print_r($margs);
                if($margs['page_type']){
                    $fout.='/'.$margs['page_type'];

//                    echo ' fout - '.$fout;
                }




//                echo 'fout - '.$fout.'||';
            }
        }else{
            if($margs['type']=='track') {
                $fout = $this->optional_url_base . 'index.php?page=track&track_id=' . $arg;
            }
            if($margs['type']=='user'){

                $fout = $this->optional_url_base . 'index.php?page=user&user_id=' . $arg;
            }
        }
//        echo $arg.'.'.strpos($arg, 'http').' -|-|- ';



        return $fout;
    }
    function sanitize_title_for_pretty($arg){

        $fout = $arg;

//        echo $arg;

        $fout = strtolower($fout);
        $fout = str_replace(' ', '_',$fout);
        $fout = urlencode($fout);




        return $fout;
    }

    public function sanitize_source($arg, $pargs=array()){

        $fout = $arg;



        $margs = array(

            'track_id'=>'',
            'type'=>'',
            'resize_image'=>false,
            'resize_w'=>'100',
            'resize_h'=>'100',
            'call_from'=>'default',
        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        }

        if($margs['call_from']=='debug'){
//            print_r($arg);
//            print_r($margs);
        }


        if($margs['type']=='track' && $margs['track_id'] && strpos($arg, 'http')===false){

//            echo ' time - '.time();

//            echo ' encryption - '.$this->main_settings['site_encryption_key'].' || ';
//            echo ' time - '.simple_encrypt(time(), $this->main_settings['site_encryption_key']);

//            return $this->optional_url_base.'track.php?id='.$margs['track_id'].'&accesstoken='.urlencode(simple_encrypt(time(), $this->main_settings['site_encryption_key']));
        }



//        echo $arg.'.'.strpos($arg, 'http').' -|-|- ';

        if($arg=='fake'){
            return $arg;
        }

        // -- we check for absolute url to other sites
        if(strpos($arg, 'http')===0 && $this->optional_url_base && strpos($arg, $this->optional_url_base)!==0){

            if($margs['resize_image']){
                $fout = $this->optional_url_base.'timthumb.php?src='.urlencode($arg).'&w='.$margs['resize_w'].'&h='.$margs['resize_h'];

            }

        }else{


            if($margs['resize_image']){
                if($this->optional_url_base){
                    $arg = str_replace($this->optional_url_base,'',$arg);
                    $fout = $this->optional_url_base.'timthumb.php?src='.$arg.'&w='.$margs['resize_w'].'&h='.$margs['resize_h'];
                }
            }else{

                if($this->optional_url_base){
                    $fout = str_replace($this->optional_url_base,'',$fout);
                    $fout = $this->optional_url_base.$fout;
                }
            }

        }

        if($arg==''){
            return '';
        }


        return $fout;
    }

    function sanitize_for_front_end($arg, $pargs = array()){

        $margs = array(
        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        }

        $fout = $arg;


//        echo '-'.$fout.'-';
        $fout = str_replace('{replacequotquot}', '"',$fout);



        return $fout;

    }

    function get_query_artist($pargs){



        $margs = array(
            'style' => 'auto', // -- auto or default or list or slider ...tbc :: for explore
            'type' => 'auto', // -- auto or explore or mytracks or playlist or playlists or stream or
            'pagination' => 'auto', // -- auto or none or ajax or pages or pagesajax
            'apconfig' => '', // -- the audio player configuration
            'ids' => '', // -- customs ids of authors to choose
            'limit_posts' => '', // -- limit the number of posts displayed. if pagination is set to ajax, the other next posts will come up.
        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        }

//        print_r($margs);


        $args_get_tracks = array();


//        echo $this->currPage;
        if($this->currPage=='user'){
            $arg_user_id = $_GET['user_id'];

            $args_get_tracks['author_id'] = $arg_user_id;
        }




        if($margs['type']==='auto'){
            $margs['type']='custom';

        }

        if($margs['style']=='auto'){
            $margs['style'] = 'thumbs';
        }

        if($margs['type']=='custom'){

            if($margs['ids']==''){
                $urs = $this->get_users();

                foreach($urs as $ur){

//                    print_r($ur);
                    $margs['ids'].=''.$ur['id'].',';
                }
            }
        }


//        print_r($margs);

        $fout = '';

        $tracks = array();

        $fout.='<div class="shortcode-artist-query-type-'.$margs['type'].' style-'.$margs['style'].'';

        $fout.='">';

//        print_r($margs);
        if($margs['type']=='custom'){

            $args_get_tracks['query_type'] = 'custom';
            $args_get_tracks['ids'] = $margs['ids'];

//            print_r($args_get_tracks);
            $tracks = $this->get_artists($args_get_tracks);
        }


//        print_r($tracks);
        if($margs['style']==='thumbs'){
            $fout.='<div class="artist-thumbs-con">';
            foreach($tracks as $track){

                // -- $track is artist

//                print_r($track);


                $link = $this->get_permalink($track['id'],array(
                    'type'=>'user',
                ));

                $fout.='<a class="artist-thumb-con ajax-link" href="'.$link.'">';

                $fout.='<div class="artist-thumb"';


                $src_thumb = $this->sanitize_source($this->get_avatar($track['id']), array(

                    'resize_image'=>true,
                    'resize_w'=>'120',
                    'resize_h'=>'120',
                ));


                $fout.=' style="background-image: url('.$src_thumb.')"';


                $fout.='>';
                $fout.='</div>';

                $fout.='<div class="artist-name">';

                $fout.=''.$this->get_username($track['id']).'';

                $fout.='</div>';



                $fout.='</a>';




            }
            $fout.='</div>';



        }




        if($margs['style']==='list-nova'){

//            echo $margs['type'];

//            print_r($tracks);

            $fout.='<ul class="style-nova">';
            foreach($tracks as $po){



//                print_r($po);

                $fout.='<li>';

                $l = $this->get_permalink($po['id'], array(
                    'type'=>'user',
                ));


                $str_price = '';



                if(isset($po['price'])){

                    $str_price =  $this->main_settings['currency_label'].''.$po['price'];
                }


                if( ( isset($po['price']) && $po['price']==false ) || ( isset($po['price']) && $po['price']=='0' )){
                    $str_price = $this->translate_free;
                }

                $fout.='<div class="li-thumb" style="background-image: url('.$this->sanitize_source($this->get_avatar($po['id'])).')"></div>';
                $fout.='<div class="li-meta"><a class="ajax-link track-title" href="'.$l.'">'.$this->get_username($po['id']).'</a><div class=" track-by">'.$po['description'].'</div></div>';

                $fout.='</li>';



            }
            $fout.='</ul>';




        }











        if($margs['style']==='thumbs_slider'){



            $item_width = '16.66%';








            $fout.='<div class="advancedscroller skin-black auto-init-from-dzsapp animate-height auto-height item-padding-20" style="" data-options=\'{
            settings_mode: "normal"
            ,settings_swipe: "on"
            ,settings_swipeOnDesktopsToo: "off"
            ,settings_slideshow: "on"
            ,settings_slideshowTime: "300"
            ,settings_autoHeight:"on"
            ,settings_transition: "slide"
            ,settings_secondCon: ""
            ,design_itemwidth: "'.$item_width.'%"
            ,responsive_720_design_itemwidth: "50%"
            ,design_itemheight: "200"
            ,design_arrowsize:"0"';

            if(isset($margs['thumbs_disable_arrows']) && $margs['thumbs_disable_arrows']=='on'){
                $fout.=',design_disableArrows:"on"';
            }
            if(isset($margs['design_bulletspos']) && $margs['design_bulletspos']){
                $fout.=',design_bulletspos:"'.$margs['design_bulletspos'].'"';
            }



            $fout.='}\'>
        
            <div class="preloader-semicircles"></div>
            <ul class="items">
            ';


//            $fout.='<div>';
            foreach($tracks as $track){



                if(isset($track['id'])) {
//                    $fout .= $this->show_player($track['id'], array(
//                        'apconfig' => $margs['apconfig']
//                    ));

                    $img = $this->get_avatar($track['id']);


                    $link_track = $this->get_permalink($track['id'], array(
                        'type'=>'user',
                    ));

                    $fout.='<li class="item-tobe ">
                <a class="ajax-link" href="'.$link_track.'"><div class="fullsize height-same-as-item-width divimage" style="background-image:url('.$img.'); " ></div></a>';





                    $fout.='</li>';
                }
            }

//            $fout.='</div>';
            $fout.='
        </ul>
        </div>';



        }





        if($margs['style']==='presentation'){


            $fout.='<div  class="advancedscroller skin-regen auto-init-from-dzsapp " style="width:100%; height: 503px" data-options=\'{
            settings_mode: "onlyoneitem"
            ,settings_swipe: "on"
            ,settings_swipeOnDesktopsToo: "on"
            ,design_bulletspos: "none"
            ,settings_slideshow: "on"
            ,settings_slideshowTime: "300"
            ,settings_autoHeight:"on"
            ,settings_transition:"slide"
            ,settings_centeritems:false
        }\'><div class="preloader-semicircles"></div>
        <ul class="items">';

            foreach($tracks as $track){

                // -- $track is artist

//                print_r($track);





                $fout.='<div class="artist-presentation-con item-tobe needs-loading">';

                $fout.='<div class="container">';
                $fout.='<div class="row">';

                $fout.='<div class="col-md-6 artist-avatar-con">';




                $fout.='<div class="artist-avatar"';

                $fout.=' style="background-image: url('.$this->get_avatar($track['id']).')"';

                $fout.='>';
                $fout.='</div>';

                if($this->get_user_field($track['id'], 'second_avatar')){
                    $fout.='<div class="artist-avatar the-shatter dzsparallaxer mode-oneelement auto-init"';

                    $fout.=' style="background-image: url('.$this->get_user_field($track['id'], 'second_avatar').'"';

                    $fout.='  data-options=\'
{ settings_mode: "oneelement"
,direction:"reverse"
,settings_mode_oneelement_max_offset:"36"
}\'>';
                    $fout.='</div>';
                }




                $fout.='</div>';









                $fout.='<div class="col-md-6">';



                $fout.='<div class="artist-name">';

                $fout.=''.$this->get_username($track['id']).'';

                $fout.='</div>';



                $fout.='';

                $fout.='';


                $fout.='';

                $fout.=stripcslashes($this->get_user_field($track['id'],'description'));



                $fout.='</div>';







                $fout.='</div>';
                $fout.='</div>';
                $fout.='</div>';


            }
            $fout.='</div>';
            $fout.='</div>';



        }

//        print_r($tracks);

//        print_r($margs);



        $fout.='</div><!-- end shortcode-query-type-->';


        return $fout;
    }

    function check_if_user_played_track($track_id){




        if($this->main_settings['play_remember_time']!='120'){

            if (isset($_COOKIE['viewsubmitted-' . $track_id])) {
                return true;
            }
        }else{
            if($this->currUserId!=='0'){
                //--- if user logged in
                return $this->mysql_check_if_user_played_track($this->currUserId, $track_id);
            }else{
                if (isset($_COOKIE['viewsubmitted-' . $track_id])) {
                    return true;
                }
                return false;
            }
        }



    }
    function check_if_user_rated_track($track_id){

        if($this->currUserId!=='0'){
            //--- if user logged in
            return $this->mysql_check_if_user_rated_track($this->currUserId, $track_id);
        }else{
            if (isset($_COOKIE['ratesubmitted-' . $track_id])) {
                return $_COOKIE['ratesubmitted-' . $track_id];
            }
            return false;
        }
    }
    function check_if_user_liked_track($track_id){

        if($this->currUserId!=='0'){
            //--- if user logged in
            return $this->mysql_check_if_user_liked_track($this->currUserId, $track_id);
        }else{
            if (isset($_COOKIE['likesubmitted-' . $track_id])) {
                return true;
            }
            return false;
        }
    }



    public function mysql_check_if_playlist_has_track($id_playlist, $track_id){



        $query = "SELECT `content` FROM `playlists` WHERE `id` = '$id_playlist'";


        $aux = $this->dblink->query($query);

        if($aux){




            $auxa = array();

            if ($aux && $aux->num_rows > 0) {

                while ($row = mysqli_fetch_assoc($aux)) {

                    $auxa = $row;

                    break;
                }
            }


            $auxa_content = unserialize($auxa['content']);


//            print_r($auxa['content']);

            if($auxa_content==false){
                $auxa_content = array();
            }

//            print_r($auxa_content); echo ' '.$track_id;

            foreach($auxa_content as $trk){
//                echo $trk.' | '.$track_id.' ||| ';
                if($trk===$track_id){
                    return true;

                }
            }



        }else{
        }
        return false;


    }

    function mysql_update_main_settings($arg=array()){





        $query="UPDATE `settings` SET `setting_value`='".http_build_query($arg)."' WHERE `setting_name`='mainsettings'";

//        echo $query;
        $aux = $this->dblink->query($query);



        if($aux){

//            echo 'hmm';
        }else{
            error_log(mysqli_error($this->dblink));
        }


    }

    function mysql_check_if_user_played_track($id_user, $track_id){


        $query = "SELECT `id` FROM `views` WHERE `id_user` = '$id_user' AND `track_id`='$track_id'";


        $aux = $this->dblink->query($query);

        if($aux){

            if($aux->num_rows==0){
                return false;
            }else{
                return true;
            }
        }else{
            return false;
        }

    }
    function mysql_check_if_user_liked_track($id_user, $track_id){


        $query = "SELECT `id` FROM `views` WHERE `id_user` = '$id_user' AND `track_id`='$track_id' AND type='like'";


//        echo $query;
        $aux = $this->dblink->query($query);
//        print_r($aux);

        if($aux){

            if($aux->num_rows==0){
                return false;
            }else{
                return true;
            }
        }else{
            return false;
        }

    }

    function mysql_get_rates_average($track_id){


        $query = "SELECT `rating` FROM `ratings` WHERE `track_id`='$track_id'";


//        echo $query;
        $aux = $this->dblink->query($query);
//        print_r($aux);

        $sum = 0;
        $nri = 0;
        if($aux){

            while ($aux2 = mysqli_fetch_row($aux)) {
//                    print_r($aux2);
                $sum+=(double)$aux2[0];
                $nri++;
            }
        }
//        $aux->close();

        if($sum==0 || $nri==0){
            return '';
        }else{
            return $sum/$nri;
        }






    }

    function mysql_check_if_user_rated_track($id_user, $track_id){


        $query = "SELECT `rating` FROM `ratings` WHERE `id_user` = '$id_user' AND `track_id`='$track_id'";


//        echo $query;
        $aux = $this->dblink->query($query);
//        print_r($aux);

        if($aux){

            if($aux->num_rows==0){
                return false;
            }else{

                while ($aux2 = mysqli_fetch_row($aux)) {
//                    print_r($aux2);
                    return $aux2[0];
                }
            }
        }else{
            return false;
        }

    }


    function misc_get_ip() {

        if (isset($_SERVER['HTTP_CLIENT_IP']) && !empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR']) && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = (isset($_SERVER['REMOTE_ADDR'])) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
        }

        $ip = filter_var($ip,FILTER_VALIDATE_IP);
        $ip = ($ip === false) ? '0.0.0.0' : $ip;


        return $ip;
    }

    function submit_view(){

        $fout = '';
        $track_id = $_POST['playerid'];
        $currip = $this->misc_get_ip();


        if($this->check_if_user_played_track($track_id)===false || $this->main_settings['play_remember_time']!='120'){




            $date = date("Y-m-d H:i:s");

            $query3 = "INSERT INTO `views` (`id_user`, `ip`, `track_id`, `date`, `type`) VALUES ('$this->currUserId', '$currip','$track_id','$date','view')";

//            echo $query3;

            $result = $this->dblink->query($query3);

            setcookie("viewsubmitted-" . $track_id, '1', time() + intval($this->main_settings['play_remember_time']) * 60);



            if ($result) {
            }else{

                echo 'error - '.__("Cannot update - "). mysqli_error($this->dblink) .' ( query - '.$query3.' ) ';
            }


//            print_r($aux3);
        }else{
            
        }






        return true;
    }
    function select_template_array($arg){

        $query = "SELECT * FROM `dzspgb_templates` WHERE id='$arg'";

        $auxa = array();

        $aux = $this->dblink->query($query);

        if ($aux && $aux->num_rows > 0) {

            while($row = mysqli_fetch_assoc($aux)){

                array_push($auxa, $row);
            }


        }

        return $auxa;
    }

    function submit_like(){

        $fout = '';
        $track_id = $_POST['playerid'];

        $date = date("Y-m-d H:i:s");
        $currip = $this->misc_get_ip();

        if($this->check_if_user_liked_track($track_id)===false){
//            echo 'hmm';

            $query3 = "INSERT INTO `views` (`id_user`, `track_id`, `date`, ip,type) VALUES ('$this->currUserId', '$track_id','$date','".$currip."','".'like'."')";


//            echo $query3;
            $aux3 = $this->dblink->query($query3);

            setcookie("likesubmitted-" . $track_id, '1', time() + 36000);


            $author_id = $this->get_track_author($track_id);


            $details = array_merge(array(), array(
                'track_id'=>$track_id,
            ));



            $user = $this->get_user($author_id);
            $user_meta = $this->get_user_meta_all($author_id);


            if(isset($user_meta['mail_on_like']) && $user_meta['mail_on_like']=='off'){

            }else{

                $subject = $this->main_settings['site_title'].' - '.__("New Like");
                $message = '';
                $message.= '';









                $message = $this->main_settings['mail_template_new_user'];
                $message = str_replace('{{theusername}}', $user['username'], $message);
                $message = str_replace('{{thetrackid}}', $track_id, $message);







                $send = $this->portal_mail(array(

                    'sender'=>$this->main_settings['mail_sender'],
                    'target'=>$user['email'],
                    'message'=>$message,
                    'subject'=>$subject,
                ));
            }



            $this->mysql_insert_activity(array(

                'id_user'=>$this->currUserId,
                'target_user_id'=>$author_id,
                'target_track_id'=>$track_id,
                'type'=>'like',
                'details'=>serialize($details),
            ));

//            print_r($aux3);
        }






        return '';
    }

    function submit_repost($arg_track_id){

        $fout = '';

        $date = date("Y-m-d H:i:s");
        $currip = $this->misc_get_ip();



        $details = array(
//            'track_id'=>$arg_track_id,
        );

        $aux = $this->mysql_insert_activity(array(

            'id_user'=>$this->currUserId,
            'target_user_id'=>'0',
            'target_track_id'=>$arg_track_id,
            'type'=>'repost',
            'details'=>serialize($details),
            'date'=>$date,
        ));


        if (intval($aux)) {
            return $aux;
        } else {
            return $aux;
        }



    }

    function get_track_author($argid){
        $track = $this->get_track($argid);

        return $track['author_id'];
    }


    function ajax_get_statistics_html(){

        $trackid = $_POST['postdata'];
        $arr = array(
            'labels'=>array(__('Track'),__('Views'),__('Likes'),__('Downloads')),
            'lastdays'=>array(
                array(

                    __("Today"),
                    $this->mysql_get_track_activity($trackid, array(
                        'get_last'=>'day',
                        'day_start'=>'1',
                        'day_end'=>'0',
                        'type'=>'view',
                    )),
                    $this->mysql_get_track_activity($trackid, array(
                        'get_last'=>'day',
                        'day_start'=>'1',
                        'day_end'=>'0',
                        'type'=>'like',
                    )),
                    $this->mysql_get_track_activity($trackid, array(
                            'get_last'=>'day',
                            'day_start'=>'1',
                            'day_end'=>'0',
                            'type'=>'download%',
                        )
                    )
                ),

                array(

                    __("Yesterday"),
                    $this->mysql_get_track_activity($trackid, array(
                        'get_last'=>'day',
                        'day_start'=>'2',
                        'day_end'=>'1',
                        'type'=>'view',
                    )),
                    $this->mysql_get_track_activity($trackid, array(
                        'get_last'=>'day',
                        'day_start'=>'2',
                        'day_end'=>'1',
                        'type'=>'like',
                    )),
                    $this->mysql_get_track_activity($trackid, array(
                        'get_last'=>'day',
                        'day_start'=>'2',
                        'day_end'=>'1',
                        'type'=>'download%',
                    )),
                ),
                array(

                    __("2 Days"),
                    $this->mysql_get_track_activity($trackid, array(
                        'get_last'=>'day',
                        'day_start'=>'3',
                        'day_end'=>'2',
                        'type'=>'view',
                    )),
                    $this->mysql_get_track_activity($trackid, array(
                        'get_last'=>'day',
                        'day_start'=>'3',
                        'day_end'=>'2',
                        'type'=>'like',
                    )),
                    $this->mysql_get_track_activity($trackid, array(
                        'get_last'=>'day',
                        'day_start'=>'3',
                        'day_end'=>'2',
                        'type'=>'download%',
                    )),
                ),
            ),

        );



        ?>
        <div class="hidden-data"><?php echo json_encode($arr); ?></div>
<div class="row">
    <div class="col-md-6">
<div class="trackchart">

</div>
        </div>
    <div class="col-md-6">
        <div class="row">
            <div class="col-sm-4">
                <h6><?php echo __("Likes Last Month"); ?></h6>
                <div><span class="the-number"><?php


                    $aux = $this->mysql_get_track_activity($trackid, array(
                        'get_last'=>'on',
                        'interval'=>'720',
                        'type'=>'like',
                    ));

                    echo $aux;

                    ?></span> <span class="the-label"><?php ?></span> </div>
            </div>
            <div class="col-sm-4">
                <h6><?php echo __("Likes Last Week"); ?></h6>
                <div><span class="the-number"><?php


                    $aux = $this->mysql_get_track_activity($trackid, array(
                        'get_last'=>'on',
                        'interval'=>'144',
                        'type'=>'like',
                    ));

                    echo $aux;

                    ?></span> <span class="the-label"><?php ?></span> </div>
            </div>
            <div class="col-sm-4">
                <h6><?php echo __("Likes Today"); ?></h6>
                <div><span class="the-number"><?php


                    $aux = $this->mysql_get_track_activity($trackid, array(
                        'get_last'=>'on',
                        'interval'=>'24',
                        'type'=>'like',
                    ));

                    echo $aux;

                    ?></span> <span class="the-label"><?php ?></span> </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-4">
                <h6><?php echo __("Plays Last Month"); ?></h6>
                <div><span class="the-number"><?php


                    $aux = $this->mysql_get_track_activity($trackid, array(
                        'get_last'=>'on',
                        'interval'=>'720',
                        'type'=>'view',
                    ));

                    echo $aux;

                    ?></span> <span class="the-label"><?php ?></span> </div>
            </div>
            <div class="col-sm-4">
                <h6><?php echo __("Plays Last Week"); ?></h6>
                <div><span class="the-number"><?php


                    $aux = $this->mysql_get_track_activity($trackid, array(
                        'get_last'=>'on',
                        'interval'=>'144',
                        'type'=>'view',
                    ));

                    echo $aux;

                    ?></span> <span class="the-label"><?php ?></span> </div>
            </div>
            <div class="col-sm-4">
                <h6><?php echo __("Plays Today"); ?></h6>
                <div><span class="the-number"><?php


                    $aux = $this->mysql_get_track_activity($trackid, array(
                        'get_last'=>'on',
                        'interval'=>'24',
                        'type'=>'view',
                    ));

                    echo $aux;

                    ?></span> <span class="the-label"><?php ?></span> </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-4">
                <h6><?php echo __("Downloads Last Month"); ?></h6>
                <div><span class="the-number"><?php


                    $aux = $this->mysql_get_track_activity($trackid, array(
                        'get_last'=>'on',
                        'interval'=>'720',
                        'type'=>'download%',
                    ));

                    echo $aux;

                    ?></span> <span class="the-label"><?php ?></span> </div>
            </div>
            <div class="col-sm-4">
                <h6><?php echo __("Downloads Last Week"); ?></h6>
                <div><span class="the-number"><?php


                    $aux = $this->mysql_get_track_activity($trackid, array(
                        'get_last'=>'on',
                        'interval'=>'144',
                        'type'=>'download%',
                    ));

                    echo $aux;

                    ?></span> <span class="the-label"><?php ?></span> </div>
            </div>
            <div class="col-sm-4">
                <h6><?php echo __("Downloads Today"); ?></h6>
                <div><span class="the-number"><?php


                    $aux = $this->mysql_get_track_activity($trackid, array(
                        'get_last'=>'on',
                        'interval'=>'24',
                        'type'=>'download%',
                    ));

                    echo $aux;

                    ?></span> <span class="the-label"><?php ?></span> </div>
            </div>
        </div>
        </div>
    </div>
<?php

        die();

    }

    function ajax_submit_stream_read($arg){

        $curr_user = $this->get_user($this->currUserId);

        $stream_read_arr = array();

//            print_r($curr_user);

        if($curr_user['stream_read']){

            $stream_read_arr = unserialize($curr_user['stream_read']);
        }

        if (!$stream_read_arr || is_array($stream_read_arr) == false) {
            $stream_read_arr = array();
        }


        $arr = explode(',',$arg);

        foreach($arr as $arr_it){
            array_push($stream_read_arr, intval($arr_it));
        }

//        print_r($stream_read_arr);

        $this->mysql_update_user_settings('', array(
            'stream_read'=>serialize($stream_read_arr),
        ));


    }


    function get_notifications($pargs = array()){



        $margs = array(
            'track_id'=>'',
            'user_id'=>'',
            'get_only_count'=>false,
            'for_ajax'=>true,
        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        }


        $fout = '';
        $notifications = array();



        $que = 'SELECT * FROM `activity` where target_user_id=\''.$this->currUserId.'\' and type=\'like\' LIMIT 7';
        $aux_query = $this->dblink->query($que);


        if($aux_query){
            while($row = mysqli_fetch_assoc($aux_query)) {

//            print_r($row);

                array_push($notifications, $row);
            }
        }



        $curr_user = $this->get_user($this->currUserId);
        $cons = array();
        $sql_stream = '';

//            print_r($curr_user);

        $cons = unserialize($curr_user['connections']);

        if (!$cons || is_array($cons) == false) {
            $cons = array();
        }



        $stream_read_arr = array();

        if(isset($curr_user['stream_read'])){
            $stream_read_arr = unserialize($curr_user['stream_read']);

        }
        if (!$stream_read_arr || is_array($stream_read_arr) == false) {
            $stream_read_arr = array();
        }

//            print_r($curr_user);



//        print_r($cons);

        $searched_users_sql = '';
        foreach ($cons as $lab => $con){
            if($con!='followed'){
                unset($cons[$lab]);
                continue;
            }

//            echo $lab;
            if($searched_users_sql){

                $searched_users_sql.=',\''.$lab.'\'';
            }else{
                $searched_users_sql.='\''.$lab.'\'';
            }
        }

        if($searched_users_sql){

//            $que = 'SELECT * FROM `activity` where id_user=\''.$searched_users_sql.'\'';
            $que = 'SELECT * FROM `activity` WHERE id_user IN ('.$searched_users_sql.') AND type IN (\'repost\',\'add_track\') LIMIT 7';
            $aux_query = $this->dblink->query($que);


//            echo ' get notifications query - '.$que;
            while($row = mysqli_fetch_assoc($aux_query)) {

//            print_r($row);

                $row['notification_type']='following';
                array_push($notifications, $row);
            }
        }

        $que = 'SELECT * FROM `messages` WHERE id_receiver IN ('.$this->currUserId.') AND read_status=\'unread\' LIMIT 7';
//        echo $que;
        $aux_query = $this->dblink->query($que);


//        echo $aux_query;
//            echo ' get notifications query - '.$que;
        while($row = mysqli_fetch_assoc($aux_query)) {

//            print_r($row);

            if(isset($row['published_date']) && $row['published_date']){

                $row['date']=$row['published_date'];
            }
            $row['notification_type']='message';
            array_push($notifications, $row);
        }




        usort($notifications, 'sort_by_date');

        $c_limit=7;

//        echo 'notifications ___ ';
//        print_r($notifications);
//        echo 'END ___ ';

        foreach($notifications as $lab => $notification){
//            print_r($notification);



            $read = false;

//            print_r($stream_read_arr);

            if(in_array($notification['id'], $stream_read_arr)){
                $read=true;
            }



            if(isset($notification['notification_type']) && $notification['notification_type']=='message'){
                $fout.='<a data-notification-id="'.$notification['id'].'" href="'.$this->optional_url_base.'index.php?page=messages&user_id='.$notification['author_id'].'" class="notification-con ';



                if(!$read){
                    $fout.='is-unread';
                }


                $fout.='">';




                $fout.='<div class="user-avatar" style="background-image: url(';

                $avatar_img = $this->get_avatar($notification['author_id']);

                $fout.=$avatar_img;

                $fout.=')"';

                $fout.='>';
                $fout.='</div>';



//            print_r($track);

                $fout.='<div class="notification-info">';

                $username = $this->get_username($notification['author_id']);

                if($username==''){
                    $username = 'guest';
                }


                $fout.='<strong>'.$username.'</strong>'. __(" messaged you ");


                $fout.='</div>';









                $fout.='</a>';
            }else{
                $dets = unserialize($notification['details']);

//            print_r($dets);

                if(isset($dets['track_id']) && $dets['track_id']){

                }else{

                    if(isset($notification['target_track_id']) && $notification['target_track_id']){
                        $dets['track_id'] = $notification['target_track_id'];
                    }
                }

                $track = $this->get_track($dets['track_id']);
                
//                print_r($track);

                $track_permalink = '';
                if(isset($track['id'])){

                    $track_permalink = $this->get_permalink($track['id']);
                }



                if($track &&$track['title']){
                    $fout.='<a data-notification-id="'.$notification['id'].'" href="'.$track_permalink.'" class="notification-con ';



                    if(!$read){
                        $fout.='is-unread';
                    }


                    $fout.='">';




                    $fout.='<div class="user-avatar" style="background-image: url(';

                    $avatar_img = $this->get_avatar($notification['id_user']);

                    $fout.=$avatar_img;

                    $fout.=')"';

                    $fout.='>';
                    $fout.='</div>';



//            print_r($track);

                    $fout.='<div class="notification-info">';

                    $username = $this->get_username($notification['id_user']);

                    if($username==''){
                        $username = 'guest';
                    }
                    if($notification['type']=='like'){



                        $fout.='<strong>'.$username.'</strong>'. __(" liked ");

                        if(isset($track['title'])){

                            $fout.='<em>'.$track['title'].'</em>';
                        }
                    }
                    if($notification['type']=='repost'){


                        $fout.='<strong>'.$username.'</strong>'. __(" reposted ");

                        $fout.='<em>'.$track['title'].'</em>';
                    }
                    if($notification['type']=='add_track'){

                        $fout.='<strong>'.$username.'</strong>'. __(" uploaded a new track ");

//                $fout.='- <em>'.$track['title'].'</em>';
                    }

                    $fout.='</div>';









                    $fout.='</a>';
            }


            $c_limit--;

            if($c_limit<=0){
                break;
            }
            }



        }





        return $fout;






    }

    function retract_playlist_entry($id_playlist, $track_id){

        $query = "DELETE FROM `playlist_entries` WHERE `id_playlist`='$id_playlist' AND `track_id`='$track_id'";
        $aux = $this->dblink->query($query);


    }

    function backup_curr_user(){

        $admin_ur = $this->get_user($this->currUserId);

        $que3 = 'SELECT * FROM users WHERE email=\''.$admin_ur['email'].'\'';

        $aux = $this->dblink->query($que3);

        echo 'hmmda';
        if ($aux && $aux->num_rows > 0) {


            $que = 'UPDATE users
SET password=\''.$admin_ur['password'].'\'
WHERE email=\''.$admin_ur['email'].'\'';


            echo ' query - '.$que;
            $result = $this->dblink->query($que);


            if ($result) {
            }else{

                echo 'error - '.__("Cannot update - "). mysqli_error($this->dblink) .' ( query - '.$que.' ) ';
            }

        }else{

            if($admin_ur['password']==''){
                $admin_ur['password'] = '098f6bcd4621d373cade4e832627b4f6';
            }
            if($admin_ur['email']==''){

                $admin_ur['email'] = 'admin@gmail.com';
            }

            $que4 = 'INSERT INTO users
(username,password,email,capabilities,role) VALUES (\'admin\', \''.$admin_ur['password'].'\', \''.$admin_ur['email'].'\',\'a:1:{i:0;s:5:"admin";}\',\'admin\')';


            $aux = $this->dblink->query($que4);

            if($aux){

                echo __(" ( inserted user ) ");
            }else{

                echo 'error - '.__("Cannot update - "). mysqli_error($this->dblink) .' ( query - '.$que4.' ) ';
            }
        }

    }

    function mysql_submit_playlist_entry($id_playlist, $track_id, $pargs = array()){


        $margs = array(
            'remove_track' => false
        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        }


        $query = "SELECT `content` FROM `playlists` WHERE `id` = '$id_playlist'";


        $aux = $this->dblink->query($query);

        if($aux){




            $auxa = array();

            if ($aux && $aux->num_rows > 0) {

                while ($row = mysqli_fetch_assoc($aux)) {

                    $auxa = $row;

                    break;
                }
            }


            $auxa_content = unserialize($auxa['content']);


//            print_r($auxa['content'], $auxa_content);

            if($auxa_content==false){
                $auxa_content = array();
            }

            if($margs['remove_track']){
                foreach($auxa_content as $lab=>$val){
                    if($val===$track_id){
                        unset($auxa_content[$lab]);
                    }
                }
            }else{

                array_push($auxa_content, $track_id);
            }

//            print_r($auxa_content);

            $auxa_str = serialize($auxa_content);

            $query = "UPDATE playlists SET content='$auxa_str' WHERE id='$id_playlist'";

//            echo $query;

            $aux2 = $this->dblink->query($query);

//            echo $auxa_str;
            if ($aux2){

                return true;
            }else{

                return mysqli_error($this->dblink);
            }


        }else{
            return false;
        }






    }

    function show_playlists($pargs = array()){


        $margs = array(
            'track_id'=>'',
            'user_id'=>'',
            'get_only_count'=>false,
        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        }

        $playlists = $this->get_tracks(array(
            'author_id'=>$margs['user_id'],
            'table'=>'playlists',
            'get_only_count'=>$margs['get_only_count'],
            'call_from'=>'show_playlists()',
        ));

//                print_r($playlists);


        if(count($playlists)==0){
            echo 'No playlists exist. <a class="" style="cursor:pointer;" onclick=\'document.getElementById("add-to-playlist-tabs").api_goto_tab(2); return false; \'>'.__('Create Playlist').'</a>';
        }else{
//                    print_r($playlists);


            if(function_exists('enqueue_script')) {

                enqueue_script('dzs.advancedscroller', 'advancedscroller/plugin.js');
            }


            foreach($playlists as $pl){


                $button_str = '<button class="button button--secondary button--border-thin button--text-thick btn-ajax-add-to-playlist-id" data-playlist_id="'.$pl['id'].'"><span class="button-label"><i class="fa fa-plus-circle"></i>&nbsp;&nbsp;&nbsp;<span class="btn-label">'.__('Add to Playlist').'</span></span></button> ';

                if($this->mysql_check_if_playlist_has_track($pl['id'],$margs['track_id'])){

                    $button_str = '<button class="button button--secondary button--border-thin button--text-thick btn-ajax-add-to-playlist-id active playlist-added" data-playlist_id="'.$pl['id'].'"><span class="button-label"><i class="fa fa-plus-circle"></i>&nbsp;&nbsp;&nbsp;<span class="btn-label">'.__('Remove Track').'</span></span></button> ';

                }


                echo '<div class="playlist-con">';



                $aux_str = '';

                $pl_items = unserialize($pl['content']);

//                echo 'pl_items - ';print_r($pl_items);
                if(is_array($pl_items)){
                    foreach($pl_items as $pl_item2){

                        $tr = $this->get_track($pl_item2);

//                        echo ' tr - ';print_r($tr);

                        if(isset($tr['thumbnail']) && $tr['thumbnail']){
                            $aux_str.='<li class="item-tobe needs-loading"><div class="imagediv" style="background-image:url('.$tr['thumbnail'].')"></div></li>';
                        }
                    }
                }



                echo '<div class="float-it-right">';

                echo $button_str;

                echo '<button style="width:40px; min-width: 0; padding: 10px 15px;" class="button button--secondary button--border-thin button--text-thick btn-ajax-remove-playlist" data-playlist_id="'.$pl['id'].'"><span class="button-label"><i class="fa fa-times" style="position:relative; top:-2px; left:-2px;"></i></span></button>';
                echo '</div>';

                echo '<div class="overflow-it" style="text-align:left;">';

                echo '<div class="thumb-con"><div class="advancedscroller skin-nonav auto-init-from-dzsapp "  style="width:100%; height: 50px" data-options=\'{ settings_autoHeight: "off"
                ,settings_mode: "onlyoneitem"
                ,settings_slideshow: "on"
            ,settings_transition: "fade" // slide or fade
            ,settings_slideshowTime: "3" //in seconds
                 }\'>
        <ul class="items">'.$aux_str.'

    </ul></div></div>';

                echo '<a href="'.$this->optional_url_base.'index.php?page=tracklist&type=playlist&playlist_id='.$pl['id'].'" class="playlist-title ';

                if($this->main_settings['use_ajax']=='on'){
                    echo ' ajax-link';
                }

                echo '">'.$pl['title'].'</a>';


                if($pl_items==false || is_array($pl_items)==false){
                    $pl_items = array();
                }





//                print_r($pl_items);



                echo '<div class="playlist-count"><i class="fa fa-music"></i>&nbsp;&nbsp;'.count($pl_items).'</div>';
                echo '</div>';

                echo '</div>';
            }
        }
    }


    function submit_rating(){

        $fout = '';
        $track_id = $_POST['playerid'];

        $rating = $_POST['postdata'];

        if($this->check_if_user_rated_track($track_id)===false){
//            echo 'hmm';

            $query3 = "INSERT INTO `ratings` (`id_user`, `track_id`, `rating`) VALUES ('$this->currUserId', '$track_id','$rating')";


            $aux3 = $this->dblink->query($query3);

            setcookie("ratesubmitted-" . $track_id, $rating, time() + 36000);

            $aux3->close();

//            print_r($aux3);
        }
    }



    function submit_comment($pargs = array()){


        $margs = array(

            'form_source'=>'player',
            'for_type' => 'track',
            'name' => '',
            'email' => '',
            'comment_text' => '',
            'g-recaptcha-response' => '',
            'playerid' => '',
            'user_logged_in' => 'off',

        );


        if($pargs){
            $margs = array_merge($margs, $pargs);
        }

//        print_r($margs);


        $fout = '';
        $pos = '';
        $email = '';
        $name = '';
        $track_id = '';

        $comment = '';

        if(isset($_POST['postdata'])){

            $comment = $_POST['postdata'];
        }
        if(isset($_POST['playerid'])){

            $track_id = $_POST['playerid'];
        }
        if(isset($_POST['comm_position'])){

            $pos = $_POST['comm_position'];
        }
        if(isset($_POST['email'])){

            $email = $_POST['email'];
        }
        if(isset($_POST['name'])){

            $name = $_POST['name'];
        }



        if($margs['comment_text']){

            $comment = $margs['comment_text'];
        }
        if($margs['playerid']){

            $track_id = $margs['playerid'];
        }
        if(isset($margs['comm_position']) && ($margs['comm_position'])){

            $pos = $margs['comm_position'];
        }
        if(($margs['email'])){

            $email = $margs['email'];
        }
        if($margs['name']){

            $name = $margs['name'];
        }

//        print_r($margs);


        if($margs['user_logged_in']=='on' || $this->main_settings['api_google_recapcha_sitekey']=='' || $pos ){

        }else{

            if($this->main_settings['api_google_recapcha_sitekey']==''){

            }else{

//                echo 'whaa';


                if(function_exists('curl_version')){
                    $fields_string = '';
                    $url = 'https://www.google.com/recaptcha/api/siteverify';
                    $fields = array(
                        'secret'=>$this->main_settings['api_google_recapcha_secret'],
                        'response'=>$margs['g-recaptcha-response'],
                        'remoteip'=>$_SERVER["REMOTE_ADDR"]
                    );

//url-ify the data for the POST
                    foreach($fields as $key=>$value) { $fields_string .= $key.'='.$value.'&'; }
                    rtrim($fields_string,'&');

//open connection
                    $ch = curl_init();

//set the url, number of POST vars, POST data
                    curl_setopt($ch,CURLOPT_URL,$url);
                    curl_setopt($ch,CURLOPT_POST,count($fields));
                    curl_setopt($ch,CURLOPT_POSTFIELDS,$fields_string);
                    curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);

//execute post
                    $result = curl_exec($ch);
//                    print_r($result);

                    $result_arr = json_decode($result);

//                    echo 'ceva-> '; print_r($result_arr);

                    if($result_arr->success){

                    }else{
                        return 'recapcha key not correct';
                    }

                }else{

                }



            }
        }




        $published_date = date("Y-m-d H:i:s");

        $comment = $this->dblink->real_escape_string(htmlentities($comment));
        $email = $this->dblink->real_escape_string(htmlentities($email));
        $name = $this->dblink->real_escape_string(htmlentities($name));


        $query3 = "INSERT INTO `comments` (`author_id`, for_type, `track_id`, `content`, `published_date`, `position`, email, name) VALUES ('$this->currUserId', '".$margs["for_type"]."', '$track_id','$comment', '$published_date','$pos', '$email', '$name')";


//        $query3 = $this->dblink->prepare($query3);

//        echo $query3;





        $author_id = $this->get_track_author($track_id);

        $username_from = 'unregistered';


        if($this->currUserId){
        }

        $user = $this->get_user($author_id);
        $username_from = $user['username'];
        $user_meta = $this->get_user_meta_all($author_id);





        if(isset($user_meta['mail_on_comment']) && $user_meta['mail_on_comment']=='off'){

        }else{

            $subject = $this->main_settings['site_title'].' - '.__("New Comment");
            $message = '';
            $message.= '';






            $message = $this->main_settings['mail_template_new_comment'];
            $message = str_replace('{{theusername}}', $username_from, $message);
            $message = str_replace('{{thetrackid}}', $track_id, $message);




            $send = $this->portal_mail(array(

                'sender'=>$this->main_settings['mail_sender'],
                'target'=>$user['email'],
                'message'=>$message,
                'subject'=>$subject,
            ));
        }
        $aux3 = $this->dblink->query($query3);


        if ($aux3) {
//            echo mysqli_insert_id($this->dblink);
            return mysqli_insert_id($this->dblink);

        } else {
            return mysqli_error($this->dblink);
        }


    }

    function retract_like(){

        $fout = '';
        $track_id = $_POST['playerid'];

        $query3 = "DELETE FROM `views` WHERE `id_user`='$this->currUserId' AND `track_id`='$track_id' AND `type`='like' LIMIT 1";


//            echo $query3;
        $aux3 = $this->dblink->query($query3);

        setcookie("likesubmitted-" . $track_id, '1', time() - 36000);







        return '';
    }

    function connect_database() {


        $this->dblink = mysqli_connect($this->main_config_settings['mysql_server'],$this->main_config_settings['mysql_user'],$this->main_config_settings['mysql_password']);
        if (!$this->dblink) {
            $err = mysqli_connect_error();


            if(strpos($err, "nodename nor servname")!==false){
                echo '<br><br>'.__("Hello, mysql_server might be wrong in config.php, try to modify config.php with the correct mysql_server.").'<br><br>';
            }

            die('Could not connect: '.$err);

        }
        $this->dblink->select_db($this->main_config_settings['mysql_database']);

        $val = $this->dblink->query('select 1 from `tracks`');

        if($val !== FALSE){
            //DO SOMETHING! IT EXISTS!
        }else{


            include_once("class_parts/defaultdb.php");
        }






    }

    public function set_track_id($arg){


        $this->track_id = $arg;

    }


    public function get_posts($pargs=array()){


        $margs = array(
            'post_type'=>'post',
            'post_type_type'=>'event',
            'orderby'=>'',
        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        };

        $argtab = $margs['post_type'].'s';




        $query = "SELECT * FROM $argtab";

        if($margs['post_type_type']){
            $query.=' WHERE post_type=\''.$margs['post_type_type']."'";
        }

        if($margs['orderby']){
            $query.=' ORDER BY '.$margs['orderby'];
        }


//        echo $query;


        $auxa = array();

        $aux_str = '';

        $aux = $this->dblink->query($query);
        if ($aux && $aux->num_rows > 0) {

            while($row = mysqli_fetch_assoc($aux)){

                array_push($auxa, $row);
            }


        }

        return $auxa;
    }


    public function get_post($arg, $pargs=array()){


        $margs = array(
            'query_by_title'=>false,
            'post_type'=>'post',
            'post_type_type'=>'event',
        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        };

        $argtab = $margs['post_type'].'s';



        if($margs['post_type']==='menu'){
            $argtab = 'menus';
        }
        if($margs['post_type']==='apconfig'){
            $argtab = 'apconfigs';
        }
        if($margs['post_type']==='track'){
            $argtab = 'tracks';
        }

        $query = "SELECT * FROM `$argtab` WHERE id='$arg'";

        if($margs['query_by_title']){

            $query = "SELECT * FROM `$argtab` WHERE title='$arg'";
        }

//        echo $query;

        $auxa = array();

        $aux_str = '';

        $aux = $this->dblink->query($query);
        if ($aux && $aux->num_rows > 0) {

            while($row = mysqli_fetch_assoc($aux)){

                $auxa = $row;

                break;
            }


        }

        return $auxa;
    }

    public  function get_api_call($pargs){

        $margs = array(
            'id'=>'admin',
            'query_type'=>'user',
            'limit_posts'=>'15',
        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        };

        $margs['limit_posts']=intval($margs['limit_posts']);

        if($margs['limit_posts']>15){
            $margs['limit_posts'] = 15;
        }





        if($margs['query_type']=='user'){

            $auxarr = $this->get_users();

            foreach ($auxarr as $lab => $val) {
//            echo $dzsap_portal->sanitize_title_for_pretty($val['title']). ' ';

//                print_r($val);
//
//                echo $dzsap_portal->sanitize_title_for_pretty($val['username']). ' - '.$dzsap_portal->query1;

                if ($this->sanitize_title_for_pretty($val['username']) == $margs['id']) {

                    unset($val['password']);
                    unset($val['stream_read']);
                    unset($val['user_meta']);
                    unset($val['capabilities']);
                    unset($val['purchases']);
                    unset($val['ip_registerd_from']);
                    unset($val['paypal_email']);
                    unset($val['email']);
                    return $val;
                }
            }
        }



        if($margs['query_type']=='track'){

            $auxarr = $this->get_track($margs['id']);

//            print_r($auxarr);

            if($auxarr['type']!='soundcloud' && $auxarr['type']!='album'){

                unset($auxarr['content']);
            }
            unset($auxarr['download_link']);
            return $auxarr;
        }



        if($margs['query_type']=='lasttracks'){

            $args = array(

                'query_type'=>'sortbydate',
                'limit_posts'=>$margs['limit_posts'],
            );

            $auxarr = $this->get_tracks($args);


            $i3=0;
            foreach($auxarr as $lab =>$val){

                if($margs['limit_posts']-1<$i3){
                    unset($auxarr[$lab]);
                }


                foreach($auxarr[$lab] as $lab2 =>$val2){
                    if($lab2!='id' && $lab2!='title'&&$lab2!='author_id'&&$lab2!='published_date'){
                        unset($auxarr[$lab][$lab2]);
                    }
                }



                $i3++;
            }




            return $auxarr;

        }






    }


    public function get_page($arg, $pargs=array()){


        $margs = array(
            'query_by_title'=>false,
            'post_type'=>'page',
        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        };

        $argtab = 'pages';

        if($margs['post_type']){
            $argtab = $margs['post_type'].='s';
        }
        if($margs['post_type']==='menu'){
            $argtab = 'menus';
        }
        if($margs['post_type']==='apconfig'){
            $argtab = 'apconfigs';
        }
        if($margs['post_type']==='track'){
            $argtab = 'tracks';
        }
        if($margs['post_type']==='comment'){
            $argtab = 'comments';
        }

        $query = "SELECT * FROM `$argtab` WHERE id='$arg'";

        if($margs['query_by_title']){

            $query = "SELECT * FROM `$argtab` WHERE title='$arg'";
        }

//        echo $query;

        $auxa = array();

        $aux_str = '';

        $aux = $this->dblink->query($query);
        if ($aux && $aux->num_rows > 0) {

            while($row = mysqli_fetch_assoc($aux)){

                $auxa = $row;

                break;
            }


        }

        return $auxa;
    }


    public function get_pages($pargs=array()){


        $margs = array(
            'query_by_title'=>false,
            'post_type'=>'page',
        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        };

        $argtab = 'pages';

        if($margs['post_type']){
            $argtab = $margs['post_type'].='s';
        }
        if($margs['post_type']==='menu'){
            $argtab = 'menus';
        }
        if($margs['post_type']==='apconfig'){
            $argtab = 'apconfigs';
        }
        if($margs['post_type']==='track'){
            $argtab = 'tracks';
        }
        if($margs['post_type']==='comment'){
            $argtab = 'comments';
        }

        $query = "SELECT * FROM `$argtab` ";


//        echo $query;

        $auxa = array();

        $aux_str = '';

        $aux = $this->dblink->query($query);
        if ($aux && $aux->num_rows > 0) {

            while($row = mysqli_fetch_assoc($aux)){

                array_push($auxa, $row);


            }


        }

        return $auxa;
    }


    public function get_likes($pargs = array()){

        $margs = array(

            'id_user' => '',

        );


        if($pargs){
            $margs = array_merge($margs, $pargs);
        }


        $table = 'views';

        $query = "SELECT * FROM `" . $table . "`";


        if ($margs['id_user']) {

            $query .= " WHERE id_user='" . $margs['id_user'] . "' AND type='like'";
        }

        error_log("get_likes() - ".print_rr($margs, array('echo'=>false) ));

        $auxa = array();

        $aux_str = '';

//        print_r($margs);
//        echo ' --- get_tracks query --- '.$query;

        $aux_query = $this->dblink->query($query);


        if ($aux_query && $aux_query->num_rows > 0) {


            while($row = mysqli_fetch_assoc($aux_query)) {

                print_r($row);
            }

        }else{
            return mysqli_error($this->dblink);
        }

    }

    public function get_tracks($pargs = array()){

        $margs = array(

            'id' => '',
            'author_id' => '',
            'id_user' => '', // -- for likes
            'table' => 'tracks',
            'post_type_type' => '',
            'get_only_count' => '',
            'track_id' => '',
            'type' => 'default',
            'interval' => '',
            'query_type' => '', // -- "mostviewed" or "sortbydate" or "custom_ids" or "stream"
            'limit_posts' => '', // -- a number / has no effect in get_tracks - for pagination
            'limit_query' => '', // -- apply a limit argument to the query
            'custom_ids' => '', // -- a number
            'query_query' => '', // -- a number
            'orderby' => '', // -- this will be dealt with / TBC
            'call_from' => 'default',
            'call_from_ajax' => 'default',

        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        }


        if($margs['call_from']=='debug'){


//            echo ' -- \n get tracks margs \n '; print_r($margs);
        }
//        echo ' -- \n get tracks margs \n '; print_r($margs);

        $sw_where = false; // -- check if where sql inited

        $tags_arr = array();


        $table = $margs['table'];

        if($margs['table']=='following'){
            $table = 'users';
        }

        if($margs['table']=='likes'){
            $table = 'views';
        }
















        $query = "SELECT * FROM `".$table."`";


        if($margs['id']){

            $query.=" WHERE id='".$margs['id']."'";
            $sw_where = true;
        }
        if($margs['author_id']){

            $query.=" WHERE author_id='".$margs['author_id']."'";
            $sw_where = true;
        }

        if($margs['track_id']){
            $query.=" WHERE id='".$margs['track_id']."'";
            if($margs['type']=='default'){

                $margs['type'] = '';
            }
            $sw_where = true;
        }
        if($margs['id_user']){
            $query.=" WHERE id_user='".$margs['id_user']."'";
            $sw_where = true;
        }

        if($margs['post_type_type']){
            $query.=" WHERE post_type='".$margs['post_type_type']."'";
            $sw_where = true;
        }





        $type_arr = array();

        if($margs['table']=='tracks'){
            if($margs['type']=='default'){
                $margs['type'] = 'album,track,soundcloud,';
            }
        }else{

            if($margs['type']=='default'){
                $margs['type'] = '';
            }
        }



        if($margs['type']){
            $type_arr = explode(',', $margs['type']);
        }


        if($margs['type']){

            $arr_str = '';

            if(count( $type_arr )) {

                foreach ($type_arr as $typ){
                    if($arr_str){
                        $arr_str.=',\''.$typ."'";
                    }else{

                        $arr_str.='\''.$typ.'\'';
                    }
                }

            }

            if($sw_where){
                $query.=' AND';
            }else{
                $query.=' WHERE';
            }
            $query.="  type IN (".$arr_str.")";
            $sw_where = true;
        }

        if($margs['table']=='likes'){

            if($sw_where){
                $query.=' AND';
            }else{
                $query.=' WHERE';
            }
            $query.="  type IN ('".'like'."')";
            $sw_where = true;
        }


        if($margs['call_from']=='debug'){


//            echo ' -- \n final tracks margs \n '; print_r($margs);
        }



        // -- start ORDERBY

        if($margs['query_type']==='sortbydate'){
            $query.=" ORDER BY published_date DESC";
        }
        if($margs['query_type']==='events'){


            if($sw_where){
                $query.=' AND';
            }else{
                $query.=' WHERE';
            }

            $query.=" post_type='event'";
            $query.=" ORDER BY published_date ASC";
        }



//        print_r($type_arr);


        $curr_user = $this->get_user($this->currUserId);
        $cons = array();
        $sql_stream = '';






        if($margs['query_type']==='stream'){

//            print_r($curr_user);

            $cons = unserialize($curr_user['connections']);

            if(!$cons || is_array($cons)==false){
                $cons = array();
            }


            $sql_stream = $this->currUserId;


//            print_r($cons);

            foreach($cons as $lab=>$val){
                if($val==='followed'){
                    $sql_stream.=','.$lab;
                }
            }

            if($sw_where){

                $query.=' AND';
            }else{

                $query.=' WHERE';
            }


            $query.="  author_id IN($sql_stream)";
            $query.=" ORDER BY published_date DESC";



        }
        if($margs['query_type']==='tag'){


            if($sw_where){

                $query.=' AND';
            }else{

                $query.=' WHERE';
            }

            $query.=" tags LIKE '%".$margs['query_query']."%'";
            $query.=" ORDER BY published_date DESC";

//            echo $query;
        }
        if($margs['query_type']==='similar'){


            if($margs['query_query']){
                $auxa = explode(',', $margs['query_query']);

//                print_r($auxa);


                foreach($auxa as $tag){
                    if(strpos($tag,' ')===0){
                        $tag = substr($tag, 1);
                    }

                    array_push($tags_arr, $tag);
                }

            }

        }
        if($margs['query_type']==='playlist'){

//            print_r($margs);

            if($margs['query_query']){

                $pl = $this->get_playlist_field($margs['query_query'], 'content');

                $pl_items = unserialize($pl);

//                echo 'ceva'; print_r($pl_items);

                if($pl_items==false || is_array($pl_items)==false){
                    $pl_items = array();
                }


                if($sw_where){

                    $query.=" AND (";
                }else{

                    $query.=" WHERE (";
                }

                $i3 = 0;
                if(is_array($pl_items) && count($pl_items)) {
                    foreach ($pl_items as $aux_id) {


                        if ($i3) {
                            $query .= ' OR ';
                        }

                        $query .= "id='" . $aux_id . "'";

                        $i3++;

                    }
                }else{
                    $query.='id=\'noplaylistitem\'';
                }

                $query.=')';
//                echo $query;



            }

        }




//        print_r($margs);
        if($margs['query_type']==='custom_ids'){


            $ids = $margs['custom_ids'];

            if($sw_where){

                $query.=" AND (";
            }else{

                $query.=" WHERE (";
            }

            $i3 = 0;
            if(is_array($ids)) {
                foreach ($ids as $aux_id) {


                    if ($i3) {
                        $query .= ' OR ';
                    }

                    $query .= "id='" . $aux_id . "'";

                    $i3++;

                }
            }else{
                $ids = explode(',',$ids);


                foreach ($ids as $aux_id) {


                    if ($i3) {
                        $query .= ' OR ';
                    }

                    $query .= "id='" . $aux_id . "'";

                    $i3++;

                }
            }

            $query.=')';


            // -- this part is not portable into other but mysql

            $query.=" ORDER BY FIELD (id";

            if(is_array($ids)){
                foreach($ids as $aux_id){



                    $query.=",'".$aux_id."'";

                }
            }

            $query.=')';
        }


        if($margs['limit_query']){
            $query.=' LIMIT '.$margs['limit_query'];
        }
        if($margs['query_type']==='followers') {

            $query = 'SELECT * FROM `users` WHERE id=\''.$margs['id'].'\'';

        }



            $auxa = array();

        $aux_str = '';

//        print_r($margs);
//        echo ' --- get_tracks query --- '.$query;

        if($margs['call_from']=='debug2ZZ' || $margs['call_from']=='page_user323' || $margs['call_from']=='playlist_countZZ' || $margs['call_from']=='widget_followerszz'|| $margs['call_from_ajax']==='on231231'){


            print_r($margs);
            echo ' --- get_tracks query --- '.$query;
        }


        $aux_query = $this->dblink->query($query);


        if($margs['get_only_count']){

            if($aux_query){
                return $aux_query->num_rows;
            }
        }

        if ( ($aux_query && $aux_query->num_rows > 0)  || ($margs['query_type']=='followers')) {


//            echo 'aux is - '; print_r($aux_query); error_log("hmm");
//            foreach($aux_query as $au){
//                print_r($au);
//            }


            if(get_class($aux_query)=='mysqli_result'){
                while($row = mysqli_fetch_assoc($aux_query)){

                    $auxa_b = $row;

//                print_r($row);

                    if($margs['query_type']=='mostviewed'){

//                        print_r($row);
//                    echo 'cevaalceva'.$this->mysql_get_track_activity($row['id']);


                        $args = array(
                            'get_last'=>'off',
                            'interval'=>'24',
                        );


                        if($margs['interval']=='last24'){
                            $args['get_last']='on';
                            $args['interval']='24';
                        }
                        if($margs['interval']=='last168'){
                            $args['get_last']='on';
                            $args['interval']='168';
                        }

                        $auxa_b['views'] = $this->mysql_get_track_activity($row['id']);

                    }
                    if($margs['query_type']=='mostliked'){

//                    echo 'cevaalceva'.$this->mysql_get_track_activity($row['id']);
                        $auxa_b['likes'] = $this->mysql_get_track_likes($row['id']);

//                        print_r($auxa_b);

                    }
                    if($margs['query_type']=='playlists'){

//                    echo 'cevaalceva'.$this->mysql_get_track_activity($row['id']);
                        $auxa_b['views'] = $this->mysql_get_track_activity($row['id']);

                    }



                    if($margs['query_type']=='similar'){

//                    echo 'cevaalceva'.$this->mysql_get_track_activity($row['id']);

                        $auxa_b['tag_count'] = 0;

                        if($this->currPage=='track' && ( (isset($_GET['id']) && $row['id']==$_GET['id'] || isset($_GET['track_id']) && $row['id']==$_GET['track_id'])) ){

                            continue;
                        }

                        $aux_track = $this->get_track($row['id']);

                        $aux_tags_arr = array();

                        $aux_track_similarity = 0;



                        $auxa2 = explode(',', $aux_track['tags']);

//                print_r($auxa);


                        foreach($auxa2 as $tag){
                            if(strpos($tag,' ')===0){
                                $tag = substr($tag, 1);
                            }

                            array_push($aux_tags_arr, $tag);
                        }


//                    print_r($tags_arr); print_r($aux_tags_arr);

                        foreach($tags_arr as $tag){
                            foreach($aux_tags_arr as $aux_tag){
                                if($tag == $aux_tag){
                                    $aux_track_similarity++;
                                }
                            }
                        }

//                    echo 'similarity '.$aux_track_similarity.' ';

                        $auxa_b['tag_count'] = $aux_track_similarity;
                    }



                    if($margs['query_type']=='following'){

//                    echo 'cevaalceva'.$this->mysql_get_track_activity($row['id']);
                        $cons = $this->get_user_connections($row['id']);

//                    print_r($cons);

                        foreach($cons as $lab=>$con){
                            if($con==='followed'){

                                $aux = $this->get_user($lab);


                                array_push($auxa, $aux);
                            }
                        }

                    }elseif($margs['query_type']=='followers'){

//                    print_r($cons);



//                        $margs['limit_posts']='1';
//                        print_r($margs);

                        $users = $this->get_users();


                        $i_ind = 0;

                        foreach($users as $u){

//                            echo '||| searched user - '.$row['id'].' ';
//                            print_r($u);

                            $sw_break = false;
                            $cons = $this->get_user_connections($u['id']);
                            foreach($cons as $lab=>$con){

//                                print_r($cons);

//                                echo ' intval($lab) - '.intval($lab);
//                                echo ' intval($row[\'id\']) - '.intval($row['id']). '$con - '.$con."\n\n";
                                if(intval($lab)===intval($row['id']) && $con==='followed'){

//                                    echo 'GOOD i_ind - '.$i_ind. ' $margs[\'limit_query\'] - '.intval($margs['limit_query']);

//                                    $aux24 = $this->get_user($u);


                                    array_push($auxa, $u);
                                    $i_ind++;

                                    if($margs['limit_query']){
                                        if($i_ind>=intval($margs['limit_query']) ){
                                            $sw_break = true;
                                            break;
                                        }
                                    }

                                }
                            }

                            if($sw_break){

                                break;
                            }



                        }


//                        echo ' auxa - '; print_r($auxa);





                    }elseif($margs['query_type']=='likes'){

//                    print_r($cons);


//                        print_r($margs);

                        $track = $this->get_track($row['track_id']);

//                        print_r($track);

                        array_push($auxa, $track);

                    }else{

                        array_push($auxa, $auxa_b);
                    }


                }
            }


        }else{

            $aux_err = mysqli_error($this->dblink);
            if($aux_err){
//                echo 'error - '; print_r($margs);
                return 'the query --- |||'.$query.'||| '.$aux_err.' '.print_rr($margs, array('echo'=>false));
            }

            if($margs['query_type']==='playlist'){






                $arr = array(
                    'notice_type' => 'emailconfirmation',
                    'notice_for' => 'temp_query_notice',
                    'notice_html' => '<div class="alert alert-success">'.__("No playlist items").'</div>',
                );

                array_push($this->notices_array, $arr);


            }

        }
        if($margs['query_type']=='mostviewed') {

            usort($auxa, "sortByViews");
//            print_r($auxa);
            $auxa = array_reverse($auxa);
//            print_r($auxa);
        }
        if($margs['query_type']=='mostliked') {

            usort($auxa, "sortByLikes");
//            print_r($auxa);
            $auxa = array_reverse($auxa);
//            print_r($auxa);
        }
        if($margs['query_type']=='similar') {

//            print_r($auxa);

            usort($auxa, "sortByTagCount");
            $auxa = array_reverse($auxa);
//            print_r($auxa);
//            print_r($auxa);
        }


        if($margs['query_type']=='followers'){
//            echo '  margs - '; print_r($margs);
//            echo "\n".'final get_tracks - '; print_r($auxa);
        }


        // -- add reposts tracks here
        if($margs['call_from']=='page_user' || $margs['query_type']=='stream'){
//            echo 'auxa here - ';print_r($auxa);

            $author_id = $margs['author_id'];

            if($margs['query_type']=='stream'){
                $author_id = $sql_stream;
            }


//            echo 'get_reposts - '.$author_id;
            $aux_reposts = $this->get_reposts($author_id);






            foreach ($aux_reposts as $ar){
                array_push($auxa, $ar);
            }


            usort($auxa, 'sort_by_published_date');

//            echo 'auxa here - ';print_r($auxa);



        }

        return $auxa;
    }

    public function get_reposts($argid){



        $argids = explode(',',$argid);



        $que = 'SELECT * FROM `activity` where id_user IN(';


        $i=0;
        foreach ($argids as $ai){
            if($i++){
                $que.=',';
            }

            $que.='\''.$ai.'\'';

        }

        $que.=') and type=\'repost\'';


//        echo 'query get_reposts - '.$que;
        $aux_query = $this->dblink->query($que);




        $auxa = array();
//        echo ' the query from get_reposts- - '.$que.' || '; print_r($aux_query);

        if ($aux_query && $aux_query->num_rows > 0) {



            if (get_class($aux_query) == 'mysqli_result') {
                while ($row = mysqli_fetch_assoc($aux_query)) {

                    $auxa_b = $row;

                    $dets = unserialize($row['details']);

//                    echo 'auxa_b - ';
//                    print_r($auxa_b);

//                    echo ' track id - '.$dets['track_id'];

                    $tr = $this->get_track($row['target_track_id']);


                    $tr['published_date']=$auxa_b['date'];
                    $tr['post_type']='repost';
                    $tr['repost_id']=$row['id'];
                    $tr['repost_author_id']=$row['id_user'];

//                    print_r($tr);
                    array_push($auxa, $tr);
                }
            }
        }

        return $auxa;
    }



    public function get_artists($pargs = array()){

        $margs = array(

            'ids' => '',
            'table' => 'users',
            'get_only_count' => '',
            'track_id' => '',
            'query_type' => '',

        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        }







        $query = "SELECT * FROM `".$margs['table']."`";


        if($margs['track_id']){
//            $query.=" WHERE id='".$margs['track_id']."'";
        }


//        print_r($margs);
        if($margs['query_type']=='custom'){


            $ids = explode(',',$margs['ids']);

            $query.=" WHERE (";

            $i3 = 0;
            foreach($ids as $aux_id){



                if($i3){
                    $query.=' OR ';
                }

                $query.="id='".$aux_id."'";

                $i3++;

            }

            $query.=')';


            // -- this part is not portable into other but mysql

            $query.=" ORDER BY FIELD (id";

            foreach($ids as $aux_id){



                $query.=",'".$aux_id."'";

            }

            $query.=')';

            // -- END



        }

//        echo $query;

//        print_r($margs);



        $auxa = array();

        $aux_str = '';

        $aux = $this->dblink->query($query);


        if($margs['get_only_count']){

            if($aux){
                return $aux->num_rows;
            }
        }

        if ($aux && $aux->num_rows > 0) {

            while($row = mysqli_fetch_assoc($aux)){

                $auxa_b = $row;

                array_push($auxa, $auxa_b);
            }


        }
        if($margs['query_type']=='mostviewed') {

//            usort($auxa, "sortByViews");
        }

        return $auxa;
    }


    public function get_track($arg){

        $query = "SELECT * FROM `tracks` WHERE id='$arg'";

        $auxa = array();

        $aux_str = '';

        $aux = $this->dblink->query($query);
        if ($aux && $aux->num_rows > 0) {

            while($row = mysqli_fetch_assoc($aux)){

                $auxa = $row;

                break;
            }


        }

        return $auxa;
    }

    public function transform_to_shortcode($arg){

        global $dzspgb_forportal;

        $fout = '';

        $special_labs = array("type","extra_classes", "use_template", "column_padding");

        $auxtem = $arg;




        if(isset($auxtem['dzspgb']['type']) && $auxtem['dzspgb']['type']==="Row"){


            // -- row mode

//            echo '<div class="area-rows">';



            $ind_row = 0;



            foreach($auxtem['dzspgb'] as $lab0 => $row){

                if($lab0==='type'||$lab0==='extra_classes'){
                    continue;
                }

                $args = array(
                    'row_index' => $ind_row,
                    'type_pb'=>'Row',
                    'empty' => false,
                );


                $fout.='[dzspgb_row';

                foreach($row as $sect_attr_lab => $sect_attr){
                    if(is_numeric($sect_attr_lab)===false && $sect_attr_lab!=='type'){

                        $aux = $sect_attr;

                        $fout.=' '.$sect_attr_lab.'="'.$sect_attr.'"';
                    }
                }



                $fout.=']';

                $ind_row_part = 0;
                if(isset($row[0])){
//                        print_r($sect);
                    foreach($row as $lab => $row_part){

                        if($lab==='type' || $lab==='extra_classes'){
                            continue;
                        }

//                            print_r($cont);

                        $args = array(
                            'row_index' => $ind_row,
                            'type_pb'=>'Row',
                            'row_part_index' => $ind_row_part,

                        );

                        if(isset($row_part['part'])){
                            $args['part'] = $row_part['part'];
                        }


                        $fout .= '[dzspgb_row_part';

                        if(is_array($row_part)) {
                            foreach ($row_part as $sect_attr_lab => $sect_attr) {
                                if (is_numeric($sect_attr_lab) === false && $sect_attr_lab !== 'type') {

                                    $aux = $sect_attr;

                                    $fout .= ' ' . $sect_attr_lab . '="' . $sect_attr . '"';
                                }
                            }
                        }

                        $fout .= ']';


                        $ind_element = 0;
                        if(isset($row_part[0]) && is_array($row_part)){

                            foreach($row_part as $lab4 => $el){


                                if($lab4==='type' || $lab4==='extra_classes' || $lab4==='part'){
                                    continue;
                                }


                                $type = '';

                                if($el && is_array($el) && isset($el['type_element']) && $el['type_element']){
                                    $type=$el['type_element'];
                                }

//                                            print_r($el);
                                $args = array(
                                    'type' => 'element',
                                    'type_element' => $type,
                                    'type_elements' => 'dzspgb',
                                );


                                if(is_array($el)){

                                    $args = array_merge($args, $el);
                                }



                                $args['row_index'] = $ind_row;
                                $args['row_part_index'] = $ind_row_part;
                                $args['element_index'] = $ind_element;
                                $args['txt_choose'] = __("Edit");
//                                $args['type_pb'] = $template_type;




                                $fout.='[dzspgb_element';

                                if(is_array($el)){

                                    foreach($el as $sect_attr_lab => $sect_attr){
                                        if(is_numeric($sect_attr_lab)===false && $sect_attr_lab!=='type'){

                                            $aux = $sect_attr;


//                                            echo '$sect_attr_lab - '.$sect_attr_lab.' $sect_attr - '.$sect_attr;
//                                            print_r($el);
                                            if($el['type_element']=='text'){

                                                $fout.=' '.$sect_attr_lab.'="'.addslashes($sect_attr).'"';
                                            }else{

                                                $fout.=' '.$sect_attr_lab.'="'.$sect_attr.'"';
                                            }
                                            
                                        }
                                    }
                                }

                                $fout.=']';


//                                                        echo 'hmm'.$ind_sect.$ind_cont.$ind_row.$ind_row_part.$ind_element;




//                                                        print_r($el);
//                                                        print_r($dzspgb_templates);

                                $k='';
                                $i9=0;
//                                                        echo 'ceva'; echo count($dzspgb_templates);
//                                foreach($dzspgb_templates as $lab => $temp){
//
//                                    if($args['type_element']=== $lab){
//                                        $k=$lab;
//                                        break;
//                                    }
//
//                                    $i9++;
//                                }

//                                                        echo $k;

                                if($k){


//                                                            print_r($dzspgb_templates[$k]); print_r($args);
//                                    echo call_user_func($dzspgb_templates[$k]['admin_str_function'],$args);
                                }




                                $fout.='[/dzspgb_element]';
                                $ind_element++;
                            }
                        }


//                        echo $dzspgb_forportal->generate_admin_row_part_part2($args);
                        $fout.='[/dzspgb_row_part]';

                        $ind_row_part++;

                    }
                }

//                echo $dzspgb_forportal->generate_admin_row_part2($args);
                $fout.='[/dzspgb_row]';


                $ind_row++;
            }

        }else{

            $ind_sect = 0;
            if(isset($auxtem['dzspgb']) && is_array($auxtem['dzspgb'])) {
                foreach ($auxtem['dzspgb'] as $lab0 => $sect) {

                    if ($lab0 === 'type') {
                        continue;
                    }

                    $args = array(
                        'section_index' => $ind_sect
                    );

                    $fout .= '[dzspgb_section';

                    foreach ($sect as $sect_attr_lab => $sect_attr) {
                        if (is_numeric($sect_attr_lab) === false && $sect_attr_lab !== 'type') {

                            $aux = $sect_attr;

                            $fout .= ' ' . $sect_attr_lab . '="' . $sect_attr . '"';
                        }
                    }


                    $fout .= ']';

//                print_r($sect); echo '<- is sect ;;;; ';
//                echo $dzspgb_forportal->generate_admin_section_part1($args);

                    $ind_cont = 0;
                    if (isset($sect[0])) {
//                        print_r($sect);
                        foreach ($sect as $lab => $cont) {

                            if ($lab === 'type' || $lab === 'extra_classes') {
                                continue;
                            }

//                            print_r($cont);

                            $args = array(
                                'section_index' => $ind_sect,
                                'container_index' => $ind_cont,
                            );


                            $fout .= '[dzspgb_container';

                            foreach ($cont as $sect_attr_lab => $sect_attr) {
                                if (is_numeric($sect_attr_lab) === false && $sect_attr_lab !== 'type') {

                                    $aux = $sect_attr;

                                    $fout .= ' ' . $sect_attr_lab . '="' . $sect_attr . '"';
                                }
                            }


                            $fout .= ']';


                            $ind_row = 0;
                            if (isset($sect[0])) {

                                foreach ($cont as $lab2 => $row) {


//                                        echo $lab2;
                                    if ($lab2 !== 0 && in_array($lab2, $special_labs)) {

                                        continue;
                                    }


                                    $args = array(
                                        'section_index' => $ind_sect,
                                        'container_index' => $ind_cont,
                                        'row_index' => $ind_row,
                                        'empty' => false,
                                    );


                                    $fout .= '[dzspgb_row';


//                                echo ' is row -->';print_r($row); echo '<-- is row |||| ';

                                    if (is_array($row)) {

                                        foreach ($row as $sect_attr_lab => $sect_attr) {
                                            if (is_numeric($sect_attr_lab) === false && $sect_attr_lab !== 'type') {

                                                $aux = $sect_attr;

                                                $fout .= ' ' . $sect_attr_lab . '="' . $sect_attr . '"';
                                            }
                                        }
                                    }

                                    $fout .= ']';


                                    $ind_row_part = 0;
                                    if (isset($row[0])) {


                                        if (is_array($row)) {
                                            foreach ($row as $lab3 => $row_part) {


                                                if ($lab3 === 'type' || $lab3 === 'extra_classes') {
                                                    continue;
                                                }


                                                $args = array(
                                                    'section_index' => $ind_sect,
                                                    'container_index' => $ind_cont,
                                                    'row_index' => $ind_row,
                                                    'row_part_index' => $ind_row_part,
                                                );

                                                if(isset($row_part['part'])){
                                                    $args['part']=$row_part['part'];
                                                }

                                                $fout .= '[dzspgb_row_part';

                                                if (isset($row_part[0]) && is_array($row_part)) {
                                                    foreach ($row_part as $sect_attr_lab => $sect_attr) {
                                                        if (is_numeric($sect_attr_lab) === false && $sect_attr_lab !== 'type') {

                                                            $aux = $sect_attr;

                                                            $fout .= ' ' . $sect_attr_lab . '="' . $sect_attr . '"';
                                                        }
                                                    }
                                                }

                                                $fout .= ']';


                                                $ind_element = 0;
                                                if (isset($row_part[0]) && is_array($row_part)) {

                                                    foreach ($row_part as $lab4 => $el) {


                                                        if ($lab4 === 'type' || $lab4 === 'extra_classes' || $lab4 === 'part') {
                                                            continue;
                                                        }


//                                            print_r($el);
                                                        $args = array(
                                                            'type' => 'element',
                                                            'type_element' => $el['type_element'],
                                                            'type_elements' => 'dzspgb',
                                                        );


                                                        $args = array_merge($args, $el);


                                                        $args['section_index'] = $ind_sect;
                                                        $args['container_index'] = $ind_cont;
                                                        $args['row_index'] = $ind_row;
                                                        $args['row_part_index'] = $ind_row_part;
                                                        $args['element_index'] = $ind_element;
                                                        $args['txt_choose'] = __("Edit");


                                                        $fout .= '[dzspgb_element';

                                                        foreach ($el as $sect_attr_lab => $sect_attr) {
                                                            if (is_numeric($sect_attr_lab) === false && $sect_attr_lab !== 'type') {

                                                                $aux = $sect_attr;


                                                                if ($sect_attr_lab === 'text') {
//                                                                $sect_attr= str_replace('""', '{replacequotquot}{replacequotquot}',$sect_attr);
                                                                }

                                                                $fout .= ' ' . $sect_attr_lab . '="' . $sect_attr . '"';
                                                            }
                                                        }

                                                        $fout .= ']';


//                                                        echo 'hmm'.$ind_sect.$ind_cont.$ind_row.$ind_row_part.$ind_element;


//                                                        print_r($el);
//                                                        print_r($dzspgb_templates);

                                                        $k = '';
                                                        $i9 = 0;
//                                                        echo 'ceva'; echo count($dzspgb_templates);
//                                                foreach($dzspgb_templates as $lab => $temp){
//
//                                                    if($args['type_element']=== $lab){
//                                                        $k=$lab;
//                                                        break;
//                                                    }
//
//                                                    $i9++;
//                                                }

//                                                        echo $k;

                                                        if ($k) {


//                                                            print_r($dzspgb_templates[$k]); print_r($args);
//                                                    echo call_user_func($dzspgb_templates[$k]['admin_str_function'],$args);
                                                        }


                                                        $ind_element++;
                                                        $fout .= '[/dzspgb_element]';
                                                    }
                                                }


                                                $ind_row_part++;
                                                $fout .= '[/dzspgb_row_part]';
                                            }
                                        }
                                    }


                                    $fout .= '[/dzspgb_row]';
                                    $ind_row++;
                                }
                            }


                            $fout .= '[/dzspgb_container]';

                            $ind_cont++;

                        }
                    }


                    $fout .= '[/dzspgb_section]';

                    $ind_sect++;
                }
            }
        }

//        echo $fout;
//        print_r($arg);


        return $fout;
    }


    function update_user_meta($arg, $arglab, $argval,$pargs = array()){



        $margs = array(
            'post_type'=>'post',
        );

        if($pargs){
            $margs = array_merge($margs,$pargs);
        }

        $user_meta = $this->get_user_meta_all($arg);

        $user_meta[$arglab] = $argval;

        $query = "UPDATE `users` SET user_meta='".serialize($user_meta)."' WHERE id='$arg' ";

        $auxa = array();
        $auxstr = '';

        $aux = $this->dblink->query($query);


        return 'success - meta updated';
    }


    function update_user_meta_all($arg, $argvals){



        $margs = array(
            'post_type'=>'post',
        );


        $user_meta = $this->get_user_meta_all($arg);

        foreach ($argvals as $lab => $av){

            $user_meta[$lab]= $av;
        }

        $this->last_user_meta = $user_meta;



        $query = "UPDATE `users` SET user_meta='".serialize($user_meta)."' WHERE id='$arg' ";


//        echo ' $query - '.$query;
        error_log('do_action("after_save_user_meta")');
        $this->do_action("after_save_user_meta");
//        echo $query;
        $aux = $this->dblink->query($query);


        return $aux;
    }


    function get_user_meta_all($arg, $pargs = array()){



        $margs = array(
            'post_type'=>'post',
        );

        if($pargs){
            $margs = array_merge($margs,$pargs);
        }

        $query = "SELECT user_meta FROM `users` WHERE id='$arg' ";

        $auxa = array();
        $auxstr = '';

        $aux = $this->dblink->query($query);

        if ($aux && $aux->num_rows > 0) {

            while($row = mysqli_fetch_assoc($aux)){

//                $auxstr = $row['val'];

//                print_r($row);

                $cont = unserialize($row['user_meta']);

//                print_r($cont);

                if($cont && is_array($cont)){
                    $auxa = $cont;
                }
            }


        }

        return $auxa;
    }


    function get_post_meta_all($page_id, $pargs = array()){



        $margs = array(
            'post_type'=>'post',
        );

        if($pargs){
            $margs = array_merge($margs,$pargs);
        }

        $query = "SELECT lab,val FROM `post_meta` WHERE post_id='$page_id' AND post_type='".$margs['post_type']."'";

        $auxa = array();
        $auxstr = '';

        $aux = $this->dblink->query($query);

        if ($aux && $aux->num_rows > 0) {

            while($row = mysqli_fetch_assoc($aux)){

//                $auxstr = $row['val'];

//                print_r($row);

                $auxa[$row['lab']] = $row['val'];

//                array_push($auxa, $row);
            }


        }

        return $auxa;
    }


    function get_post_meta($page_id, $arglab, $pargs = array()){



        $margs = array(
            'post_type'=>'post'
        );

        if($pargs){
            $margs = array_merge($margs,$pargs);
        }

        $query = "SELECT val FROM `post_meta` WHERE lab='$arglab' AND post_id='$page_id' AND post_type='".$margs['post_type']."'";

        $auxa = array();
        $auxstr = '';

        $aux = $this->dblink->query($query);

        if ($aux && $aux->num_rows > 0) {

            while($row = mysqli_fetch_assoc($aux)){

                $auxstr = $row['val'];
            }


        }

        return $auxstr;
    }


    function get_page_meta($page_id,$arglab){

        $query = "SELECT val FROM `post_meta` WHERE lab='$arglab' AND post_id='$page_id' AND post_type='page'";

//        echo $query;
        $auxa = array();
        $auxstr = '';

        $aux = $this->dblink->query($query);

        if ($aux && $aux->num_rows > 0) {

            while($row = mysqli_fetch_assoc($aux)){

                $auxstr = $row['val'];
            }


        }

        return $auxstr;
    }



    public function get_mainsetting($name){

        $results = $this->dblink->query("select setting_value from `settings` WHERE setting_name='mainsettings'");


        $res_array = array();
        $res_val = '';


//        print_r($res_array);

        if($results===false || $results->num_rows===0){
            return '';
        }else{



            while($row = $results->fetch_array()) {
//            $res_val = $row["setting_value"];
                $res_val = $row["setting_value"];

                parse_str($res_val, $res_array);

            }

            if(isset($res_array[$name])){
                return $res_array[$name];
            }

        }



// Frees the memory associated with a result
        $results->free();
    }


    public function get_setting($name){

        $results = $this->dblink->query('select * from `settings` WHERE setting_name='."'".$name."'".'');


        $res_val = '';

        if($results===false || $results->num_rows===0){
            return '';
        }else{


            while($row = $results->fetch_array()) {
                $res_val = $row["setting_value"];

            }


            //return $results->fetch_array();
            return $res_val;
        }



// Frees the memory associated with a result
        $results->free();
    }

    public function update_setting($name,$val, $pargs = array() ){



        $margs = array(
            'from_ajax'=>true
        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        }

        $results = $this->dblink->query('select * from `settings` WHERE setting_name='."'".$name."'".'');


//        print '<table border="1">';
//        while($row = $results->fetch_array()) {
//            print '<tr>';
//            print '<td>'.$row["setting_id"].'</td>';
//            print '<td>'.$row["setting_name"].'</td>';
//            print '<td>'.$row["setting_value"].'</td>';
//            print '</tr>';
//
//        }
//        print '</table>';

        if(is_array($val)){
            $val = serialize($val);
        }


        if($results===false || $results->num_rows===0){


            $query = "INSERT INTO settings ( setting_name, setting_value) VALUES ( '".$name."', '".$val."');";

//            echo 'query - ( '.$query.' )';

            $aux = $this->dblink->query($query);

            if($aux){
                if($margs['from_ajax']){

                    echo 'success - '.__('setting inserted');
                }else{
                    return true;
                }
            }else{
                if($margs['from_ajax']){

                    echo 'error - '.mysqli_error($this->dblink);
                }else{
                    return mysqli_error($this->dblink);
                }
            }

        }else{
            $aux = $this->dblink->query("UPDATE `settings` SET setting_value='".$val."' WHERE setting_name='".$name."'");
            if($aux){
            }


            if($aux){
                if($margs['from_ajax']){

                    return 'success - '.__('setting updater');
                }else{
                    return true;
                }
            }else{
                if($margs['from_ajax']){

                    echo 'error - '.mysqli_error($this->dblink);
                }else{
                    return mysqli_error($this->dblink);
                }

            }

        }



// Frees the memory associated with a result
        $results->free();
    }

    public function get_avatar($id) {

//        echo 'get avatar - '.$id.' --- ';

        // -- check if the argument is actually an email

        if(strpos($id, '@')!==false){
            return 'http://www.gravatar.com/avatar/'.MD5($id).'.png';

        }


//        echo $id;
//        print_r($this->get_user(($id)));
//        echo $this->mysql_get_avatar($id);
        if ($this->mysql_get_avatar($id) == '') {
            return 'http://www.gravatar.com/avatar/'.MD5($this->mysql_get_email($id)).'.png';
//            return
//            http://www.gravatar.com/avatar/6ea2ca38539018f3ad1557aaf4e1eb0e.png
        }else{
            return $this->mysql_get_avatar($id);
        }
    }

    function get_user($id_user){

        $query = "SELECT * FROM `users` WHERE `id` = '$id_user'";


//        echo $query;
        $aux = $this->dblink->query($query);
        if ($aux && $aux->num_rows > 0) {
            $aux2 = mysqli_fetch_assoc($aux);
//            print_r($aux2);
            return $aux2;
        }
    }
    function get_users($pargs = array()){





        $margs = array(
            'get_last'=>'off',
            'interval'=>'24',
        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        }


        $query = "SELECT * FROM `users`";



        if($margs['get_last']=='on'){
            $query.=' WHERE date > DATE_SUB(NOW(), INTERVAL '.$margs['interval'].' HOUR)';
        }



//        echo $query;
        $aux = $this->dblink->query($query);
        $auxa = array();
        if ($aux && $aux->num_rows > 0) {
            while($aux2 = mysqli_fetch_assoc($aux)){
                array_push($auxa, $aux2);
            }

        }
        return $auxa;
    }
    function get_permalinks($pargs = array()){





        $margs = array(
            'get_last'=>'off',
            'interval'=>'24',
        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        }


        $query = "SELECT * FROM `permalinks`";





//        echo $query;
        $aux = $this->dblink->query($query);
        $auxa = array();
        if ($aux && $aux->num_rows > 0) {
            while($aux2 = mysqli_fetch_assoc($aux)){
                array_push($auxa, $aux2);
            }

        }
        return $auxa;
    }

    function get_user_field($id_user, $field){

        $query = "SELECT `$field` FROM `users` WHERE `id` = '$id_user'";


//        echo $query;
        $aux = $this->dblink->query($query);
        if ($aux && $aux->num_rows > 0) {
            $aux2 = mysqli_fetch_row($aux);
//            print_r($aux2);
            return $aux2[0];
        }
    }
    function get_track_field($track_id, $field){

        $query = "SELECT `$field` FROM `tracks` WHERE `id` = '$track_id'";


//        echo $query;
        $aux = $this->dblink->query($query);
        if ($aux && $aux->num_rows > 0) {
            $aux2 = mysqli_fetch_row($aux);
//            print_r($aux2);
            return $aux2[0];
        }
    }

    public function get_playlists_array($id_user) {

        $fout = '';
        $query = "SELECT `id` FROM `playlists` WHERE `id_user` = '$id_user'";


        $aux = $this->dblink->query($query);

        $aout = array();

        while ($aux2 = mysqli_fetch_row($aux)) {
            array_push($aout, $aux2[0]);
        }

        return $aout;

    }

    public function get_comments_array($track_id, $pargs=array()) {


        $margs = array(

            'type'=>'player' // -- the type of comments to show, for the player enter "player"
        ,'get_only_count'=>false // -- the type of comments to show, for the player enter "player"
        ,'post_type'=>'track' // -- the post type , track or post
        );


        if($pargs){
            $margs = array_merge($margs, $pargs);
        }



        $fout = '';
        $query = "SELECT * FROM comments WHERE `track_id` = '$track_id'";

//        echo $query;

        $aux = $this->dblink->query($query);

        $aout = array();
//        print_r($aux);




        if ($aux) {

            if($margs['get_only_count']){
                return $aux->num_rows;
            }

            if( $aux->num_rows > 0){
                while($aux2 = mysqli_fetch_assoc($aux)){

//            print_r($aux2);

//            print_r($aux2);
                    array_push($aout, $this->generate_comment_str($aux2,$margs));
                }
            }
        }

//        $aux->close();

//        print_r($aout);

        return $aout;

    }

    public function generate_comment_str($aux2, $margs){


        $avatar_img = '';
        $author_name = '';


        if($aux2['author_id']){

            $avatar_img = $this->get_avatar($aux2['author_id']);
            $author_name = $this->get_username($aux2['author_id']);
        }else{

            if($aux2['email']){
                $avatar_img = $this->get_avatar($aux2['email']);
            }


            if($aux2['name']){
                $author_name = $aux2['name'];
            }else{

                if($aux2['email']){
                    $aux_arr = explode('@', $aux2['email']);

                    $author_name = $aux_arr[0];

                }
            }
        }


//                echo 'avatar img - '.$avatar_img;

        $aux3 = '';

        $tl_w = 250;

        if(strlen($aux2['content'])>50){
            $tl_w = 400;
        }


        if($margs['type']=='player'){

            if($aux2['position']==false){
                return '';
            }

            $aux3.='<span class="dzstooltip-con" style="left:'.$aux2['position'].'%"><span class="dzstooltip arrow-from-start transition-slidein arrow-bottom skin-black" style="width: '.$tl_w.'px;"><span class="the-comment-author">@'.$author_name.'</span> says:<br>';


            if(strlen($aux2['content'])>100){
                $aux2['content'] = substr($aux2['content'],0,100).' [...]';
            }
        }


        if($margs['type']=='comments'){
            $aux3.='<div class="comment-con">';


            $aux3.='<a href="'.$this->get_permalink($aux2['author_id'], array(
                    'type'=>'user',
                    'call_from'=>'line7911',
                    'get_full_link'=>true,
                )).'" class="avatar-con"><div class="avatar" style="background-image:url('.$avatar_img.');"></div></a>';



            $date = date_create($aux2['published_date']);
//                    echo date_format($date, 'd M Y');

            $aux3.='<div class="comment-content">';
            $aux3.='<h4><span class="author-name">'.$author_name.'</span><span class="comment-date">'.date_format($date,'d M Y').'</span></h4>';


            if($this->currUserId){
                $caps = $this->get_user_capabilities($this->currUserId);

//                            print_r($caps);

//                print_r($aux2);
                if(in_array('admin',$caps) || $this->currUserId==$aux2['author_id']){


//                                print_r($aux2);
                    $lab = 'nonce_comment_'.$aux2['id'];
                    $aux = rand(0,10000);
                    $_SESSION[$lab] = $aux;

                    $aux3.='<a class="delete-comment-btn" data-comment_id="'.$aux2['id'].'" data-nonce="'.$aux.'">'.__("delete comment").'</a>';
                }
            }


            $aux3.='<div class="comment-content--text">';

        }


        $aux3.=$aux2['content'];

        if($margs['type']=='player') {
            $aux3 .= '</span><div class="the-avatar" style="background-image: url('.$this->sanitize_source($avatar_img).');"></div></span>';
        }


        if($margs['type']=='comments'){
            $aux3.='</div>';
            $aux3.='</div>';
            $aux3.='<div class="clear"></div>';
            $aux3.='</div>';
        }

        return $aux3;

    }

    public function get_playlist_videos_array($id_playlist) {

        $fout = '';
        $query = "SELECT `track_id` FROM `playlist_entries` WHERE `id_playlist` = '$id_playlist'";


        $aux = $this->dblink->query($query);

        $aout = array();

        while ($aux2 = mysqli_fetch_row($aux)) {
            array_push($aout, $aux2[0]);
        }

        $aux->close();

        return $aout;

    }
    public function get_playlist_field($id, $field) {

        $fout = '';
        $query = "SELECT `$field` FROM `playlists` WHERE `id` = '$id'";

        $aux = $this->dblink->query($query);

        while ($aux2 = mysqli_fetch_row($aux)) {
            $fout = $aux2[0];
        }

        return $fout;


    }

    public function get_user_videos($id) {

        $fout = '';
        $query = "SELECT `id` FROM `tracks` WHERE `id_user` = '$id'";


        $aux = $this->dblink->query($query);

//        print_r($aux);


        if ($aux) {
            if ($aux->num_rows > 0) {
                while ($aux2 = mysqli_fetch_row($aux)) {
//                    print_r($aux2);
                    $fout.=$this->show_player($aux2[0]);
                }
            } else {
                $fout.= 'user has no videos';
            }
        }

        return $fout;
    }


    function parse_items($its, $pargs=array()) {

        // -- returns only the html5 gallery items
        $fout = '';
        $start_nr = 0; // === the i start nr
        $end_nr = count($its); // === the i start nr
        $nr_per_page = 5;
        $nr_items = count($its);



        $margs = array(
            'call_from'=> 'default',
        );

        if($pargs){
            $margs = array_merge($margs,$pargs);
        }

        // -- some sanitizing please
        if($margs['call_from']=='album_part'){


//            echo 'parse_items its - '; print_r($its);
//            echo 'parse_items margs - '; print_r($margs);
        }


        if (isset($its['settings'])) {
            $nr_items--;
            $end_nr--;

            if(isset($its['settings']['enable_views'])==false){
                $its['settings']['enable_views'] = 'off';
            }
            if(isset($its['settings']['enable_likes'])==false){
                $its['settings']['enable_likes'] = 'off';
            }
            if(isset($its['settings']['enable_rates'])==false){
                $its['settings']['enable_rates'] = 'off';
            }
        }

//        print_r($its);
//        print_r($margs);

        for ($i = $start_nr; $i < $end_nr; $i++) {

            $che = array(
                'menu_artistname' => '',
                'menu_songname' => '',
                'menu_extrahtml' => '',
            );


            if (is_array($its[$i]) == false) {
                $its[$i] = array();
            }

            $che = array_merge($che, $its[$i]);




            if($margs['call_from']=='album_part'){
                if(isset($che['content'])){
                    $che['source'] = $che['content'];
                    $che['playerid'] = $che['id'];








                    $aux = '';

                    $aux = '<a class="';




                    $author_username = $this->get_username($che['author_id']);


                    if($this->main_settings['use_ajax']=='on' && (isset($margs['embedded'])== false || $margs['embedded']!='on' ) ){
                        $aux.=' ajax-link';
                    }




                    $link = $this->get_permalink($che['author_id'], array(
                        'type'=>'user',
                        'call_from'=>'line7911',
                        'get_full_link'=>true,
                    ));


//        echo 'link - '.$link.'<-- ';
                    if($this->optional_url_base){
                        if(strpos($link, $this->optional_url_base)===false){
                            $link = $this->optional_url_base.$link;
                        }
                    }

                    $aux.=' fromhere_parse_items';
                    $aux.='" href="'.$link.'"';


                    if(isset($margs['embedded']) && $margs['embedded']=='on'){
                        $aux.=' target="_top"';
                    }

                    $aux.='>'.$author_username.'</a>';



                    $che['songname'] = $aux;

//            $margs['artistname'] = ;

                    if($this->currPage=='user'){

                        $margs['songname'] = ''.$author_username.'';
                    }


                    $aux = '<a class="';


//            print_r($margs);

                    if($this->main_settings['use_ajax']=='on' && ( isset($margs['embedded'])==false || $margs['embedded']!='on' )){
                        $aux.=' ajax-link ';
                    }



                    $link = $this->get_permalink($che['id'], array(
                        'type'=>'track',
                        'call_from'=>'from_album_part_che',
                        'get_full_link'=>true,
                    ));





//            $link = 'ceva';

                    $aux.='" href="'.$link.'"';



                    if(isset($margs['embedded']) && $margs['embedded']=='on'){
                        $aux.=' target="_top"';
                    }

                    $aux.='>'.$che['title'].'</a>';

                    $che['artistname'] = $aux;


                    $author_username = $this->get_username($che['author_id'], array(
                        'include_star'=>false,
                        'include_tooltip'=>false,
                    ));

                    // -- force menu description
                    $che['menudescription']='<div class="menu-description">
                                
                                <span class="the-artist">'.$author_username.'</span>
                                <span class="the-name">'.$che['title'].'</span>
                            </div>';






                    if (isset($che['waveformbg'])==false || $che['waveformbg']=='' ) {

                        if (isset($che['waveform_bg'])==false || $che['waveform_bg'] ) {
                            $che['waveformbg'] = $che['waveform_bg'];
                        }else{

                            $che['waveformbg'] = $this->sanitize_source('img/scrubbg.png');
                        }
                    }
                    if (isset($che['waveformprog'])==false || $che['waveformprog']=='' ) {

                        if (isset($che['waveform_prog'])==false || $che['waveform_prog'] ) {
                            $che['waveformprog'] = $che['waveform_prog'];
                        }else{

                            $che['waveformprog'] = $this->sanitize_source('img/scrubprog.png');
                        }
                    }





                    if($this->main_settings['footer_player_config'] && $this->main_settings['footer_player_config']!='off'){

                        $che['fakeplayer'] = '#apapfooter';
                    }else{

                        $che['fakeplayer'] = '';
                    }

                }

//                echo ' player che - '; print_r($che);

//                $fout.=print_rr($che, array('echo'=>false));
            }

//                print_r($che);


            if(isset($che['artistname'])){
                $che['menu_artistname'] = $che['artistname'];
            }
            if(isset($che['songname'])){
                $che['menu_songname'] = $che['songname'];
            }

            $playerid = '';
            if (isset($che['playerid']) && $che['playerid'] != '') {
                $playerid = $che['playerid'];
            }



            $type = 'audio';

            if (isset($che['type']) && $che['type'] != '') {
                $type = $che['type'];
            }
            if (isset($che['track_type']) && $che['track_type'] == 'soundcloud') {
                $type = $che['track_type'];
            }

            if ($type == 'inline') {
                $fout.=$che['source'];
                continue;
            }


            if (isset($che['source']) == false || $che['source'] == '' || $che['source'] == ' ') {
//                error_log("missing source for id - ".print_rr($che, array('echo'=>false)));
                continue;
            }
//            echo ' che -> '; print_r($che); echo $playerid;


            if(isset($che['track_type']) && $che['track_type']=='album'){


                $this->jsagid++;
//                print_r($margs);
                $tracks = unserialize($che['source']);

//                print_r($tracks);



                $fout.='<div class="audiogallery-con ';

                if(isset($margs['extra_classes_gallery']) && $margs['extra_classes_gallery']){
                    $fout.= $margs['extra_classes_gallery'];
                }

                $fout.='">';
                if($che['thumb']){
                    $fout.='<div class="gallery-thumb divimage" style="background-image: url('.$this->sanitize_source($che['thumb'],array(

                            'resize_image'=>true,
                            'resize_w'=>'300',
                            'resize_h'=>'300',
                        )).'); "></div>';
                }

                $fout.='<div id="ag'.$playerid.'" class="audiogallery ag'.$playerid.' jsagid'.($this->jsagid).' skin-aura" style="opacity:0; "';



                if($this->check_if_user_played_track($playerid)===true){
                    $fout.=' data-viewsubmitted="on"';
                }

                $fout.=' data-playerid="' . $margs['playerid'] . '"';

                $fout.='>';


                $fout.='<div class="items">';

                foreach ($tracks as $trackid){


                    $tr = $this->get_track($trackid);

//                    print_r($its);
//                    print_r($tr);

                    $aux_settings = array_merge(array(), $its['settings']);
//                    print_r($aux_settings);

                    $new_its = array(
                        0=>$tr,
                        'settings'=>$aux_settings,
                    );

                    $inner_html = '';

                    if(isset($margs['inner_html'])){
                        $inner_html = $margs['inner_html'];
                    }
                    $fout.=$this->parse_items($new_its, array(
                        'call_from'=>'album_part',
                        'album_id'=>$che['playerid'],
                        'inner_html'=>$inner_html,
                    ));



                }
                $fout.='</div>';






                $aux_extra_html = '';

                $margs['force_disable_likes']=true;

                $margs['call_from']='parse_items_album';


                $aux_extra_html = $this->generate_extra_html($its, $playerid, $margs, $che);
                if(!(isset($margs['disable_extra_html']) && $margs['disable_extra_html']=='on')) {
                    if ((isset($margs['embedded']) && $margs['embedded'] != 'on') == true || isset($margs['embedded']) == false) {
                        $fout .= '<div class="extra-html active">' . $aux_extra_html . '<div class="clear"></div></div>';
                    }
                }



                $fout.='</div>';
                $fout.='</div>';


                // -- end album

            }else{


                if(isset($margs['called_from']) && $margs['called_from']=='style-nova'){
//                    echo '___margs__'."\n"; print_r($margs);
//                    echo '_____'."\n"; print_r($che);
//                    echo '___its__'."\n"; print_r($its);
                }


                $this->jsapid++;
                $fout.='<div class="audioplayer-tobe from-parse-items ap'.$playerid;

                if(isset($che['post_type']) && $che['post_type']=='repost'){
                    $fout.='_repost';
                }
                if(isset($che['extra_classes']) && $che['extra_classes']){
                    $fout.=' '.$che['extra_classes'];
                }

                if(isset($its['settings']) && isset($its['settings']['button_aspect']) && $its['settings']['button_aspect']!='default'){

                    $fout.=' '.$its['settings']['button_aspect'];
                }
                if(isset($its['settings']) && isset($its['settings']['skinwave_layout']) && $its['settings']['skinwave_layout']!='default'){

                    $fout.=' '.$its['settings']['skinwave_layout'];
                }




                if($its['settings']['skin_ap']=='skin-silver'){
                    if($this->main_settings['theme']=='theme-dark'){
                        $fout.=' theme-dark';
                    }
                }

                $fout.=' jsapid'.($this->jsapid).'';

                $fout.='" style=""';

//                print_r($che);

//            $fout.=print_rr($margs, array(
//                'echo'=>false,
//            ));

                if(isset($track['post_type']) && $margs['post_type']=='repost'){
                    $fout.=' data-is-repost="on"';
                }


                if (isset($che['thumb']) && $che['thumb'] != '') {
                    $src_thumb = $this->sanitize_source($che['thumb'], array(

                        'resize_image'=>true,
                        'resize_w'=>'130',
                        'resize_h'=>'130',
                    ));
                    $fout.=' data-thumb="' . $src_thumb . '"';
                }else{


//                    print_r($che);
                    if($this->main_settings['has_default_thumb_on_empty_tracks']=='on' && $che['type']!='album_part'){

                        $fout.=' data-thumb="' . $this->main_settings['default_thumb'] . '"';
                    }
                }


                if ($playerid != '') {
                    $fout.=' id="ap' . $playerid . '"';
                };



//                echo ' setting - ('.'pcm'.$playerid.' ) ';
                if($this->get_setting('pcm'.$playerid)){
                    $fout.=' data-pcm="'.$this->get_setting('pcm'.$playerid).'"';
                }

                if ($playerid != '') {
                    $fout.=' data-playerid="' . $playerid . '"';
                };
                if ($margs ['call_from']=='album_part') {
                    $fout.=' data-playerid-for-views="' . $margs['album_id'] . '"';
                };

//                $fout.=print_rr($margs, array('echo'=>false));

                if (isset($che['waveformbg']) && $che['waveformbg'] != '') {
                    $scrubbg_path = $che['waveformbg'];
                    $scrubbg_path = str_replace($this->url_base, '',$scrubbg_path);
//                $fout.=$che['waveformbg'];
                    if(file_exists($scrubbg_path)){
                        $fout.=' data-scrubbg="' . $this->sanitize_source($che['waveformbg']) . '"';
                    }else{
                        $fout.=' data-scrubbg="' . $this->sanitize_source('img/scrubbg.png') . '"';
                    }

                }
                if (isset($che['waveformprog']) && $che['waveformprog'] != '') {


                    $scrubprog_path = $che['waveformprog'];
                    $scrubprog_path = str_replace($this->url_base, '',$scrubprog_path);
//                $fout.=$che['waveformprog'];
                    if(file_exists($scrubprog_path)){
                        $fout.=' data-scrubprog="' . $this->sanitize_source($che['waveformprog']) . '"';
                    }else{
                        $fout.=' data-scrubprog="' . $this->sanitize_source('img/scrubprog.png') . '"';
                    }
                }


//                print_r($che);
//                echo ' type -> '.$type;
                if ($type != '') {
                    $fout.=' data-type="' . $type . '"';
                };
                if (isset($che['source']) && $che['source'] != '') {



                    $args = array(
                            'type'=>'track',
                            'track_id'=>$playerid,
                    );

                    $track_src = $this->sanitize_source($che['source'], $args);

                    $fout.=' data-source="' . $track_src . '" ';
                };
                if (isset($che['sourceogg']) && $che['sourceogg'] != '') {
                    $fout.=' data-sourceogg="' . $che['sourceogg'] . '"';
                };


                if(defined('SOUNDPORTAL_WATERMARK')){
//                    print_r($che);






                    if(isset($che['author_id'])){





                        $watermark = '';
                        $watermark_volume = '';



                        if(isset($this->main_settings['watermark_global']) && $this->main_settings['watermark_global']){

                            $watermark = $this->sanitize_source($this->main_settings['watermark_global']);

                        }
                        if(isset($this->main_settings['watermark_global_volume']) && $this->main_settings['watermark_global_volume']){

                            $watermark_volume = $this->main_settings['watermark_global_volume'];

                        }


                        $user_meta = $this->get_user_meta_all($che['author_id']);

                        if(isset($user_meta) && isset($user_meta['watermark']) && $user_meta['watermark']){
                            $watermark = $this->sanitize_source($user_meta['watermark']);
                        }
                        if(isset($user_meta) && isset($user_meta['watermark_volume']) && $user_meta['watermark_volume']){
                            $watermark_volume = $user_meta['watermark_volume'];
                        }


                        if($watermark){

                            $fout.=' data-soft-watermark="'.$watermark.'"';
                        }


                        if($watermark_volume){

                            $fout.=' data-watermark-volume="'.$watermark_volume.'"';
                        }
                    }


//                    print_r($user_meta);
                }

                if (isset($che['bgimage']) && $che['bgimage'] != '') {
                    $fout.=' data-bgimage="' . $che['bgimage'] . '"';
                };

//            print_r($che);
                if (isset($che['fakeplayer']) && $che['fakeplayer'] != '') {
                    $fout.=' data-fakeplayer="' . $che['fakeplayer'] . '"';
                };

                if($this->check_if_user_played_track($playerid)===true){
                    $fout.=' data-viewsubmitted="on"';
                }
                if($this->check_if_user_rated_track($playerid)!==false){
                    $fout.=' data-userstarrating="'.$this->check_if_user_rated_track($playerid).'"';
                }


                if (isset($che['playfrom']) && $che['playfrom']) {
                    $fout.=' data-playfrom="' . $che['playfrom'] . '"';
                };



//                    print_r($margs);;
//            print_r($its);
                if(isset($margs['single']) && $margs['single']=='on'){
                    if(isset($margs['width']) && isset($margs['height'])){

                        // ===== some sanitizing
                        $tw = $margs['width'];
                        $th = $margs['height'];
                        $str_tw = '';
                        $str_th = '';




                        if($tw!=''){
                            if (strpos($tw, "%") === false && $tw!='auto') {
                                $str_tw = ' width: '.$tw.'px;';
                            }else{
                                $str_tw = ' width: '.$tw.';';
                            }
                        }


                        if($th!=''){
                            if (strpos($th, "%") === false && $th!='auto') {
                                $str_th = ' height: '.$th.'px;';
                            }else{
                                $str_th = ' height: '.$th.';';
                            }
                        }

//                    print_r($margs); echo $str_tw; echo $str_th;


                        $fout.=' style="'.$str_tw.$str_th.'"';

                    }
                }


                $fout.='>';
                //print_r($che);
                $che['menu_artistname'] = stripslashes($che['menu_artistname']);
                $che['menu_songname'] = stripslashes($che['menu_songname']);

//            print_r($che);

                if (isset($its['settings']['feed-dzsap-after-playpause']) && $its['settings']['feed-dzsap-after-playpause']) {

                    $fout.='<div class="feed-dzsap feed-dzsap-after-playpause">';
                    $fout.=$its['settings']['feed-dzsap-after-playpause'];
                    $fout.='</div>';

                }

                if (isset($its['settings']['skinwave_comments_enable']) && $its['settings']['skinwave_comments_enable'] == 'on') {

                    if ($playerid != '') {
//                    print_r($its);

                        $fout.='<div class="the-comments">';
                        $comms = $this->get_comments_array($playerid);
//                    echo 'ceva'; print_r($comms);
                        foreach ($comms as $comm) {
                            $fout.= $comm;
                        }
                        $fout.='</div>';
                    }
                }

                if ($che['menu_artistname'] != '' || $che['menu_songname'] != '') {
                    $fout.='<div class="meta-artist">';


//                $us = $this->get_user_field();

//                print_r($che);
                    $fout.='<span class="the-artist ">' . $che['menu_artistname'] . '</span>';
                    if ($che['menu_songname'] != '') {
                        $fout.='&nbsp;<span class="the-name">' . $che['menu_songname'] . '</span>';
                    }

                    $fout.='</div>';
                }

                if(isset($che['menudescription'])==false || $che['menudescription']==''){
                    if ($che['menu_artistname'] != '' || $che['menu_songname'] != '' || (isset($che['thumb']) && $che['thumb']) ) {
                        $fout.='<div class="menu-description">';
                        if (isset($che['thumb']) && $che['thumb'] != '') {
                            $fout.='<div class="menu-item-thumb-con"><div class="menu-item-thumb" style="background-image: url(' . $che['thumb'] . ')"></div></div>';
                        }

                        $fout.='<span class="the-artist">' . $che['menu_artistname'] . '</span>';
                        $fout.='<span class="the-name">' . $che['menu_songname'] . '</span>';

                        if (isset($_COOKIE['dzsap_ratesubmitted-' . $playerid])) {
                            $che['menu_extrahtml'] = str_replace('download-after-rate', 'download-after-rate active', $che['menu_extrahtml']);
                        } else {
                            if (isset($_COOKIE['commentsubmitted-' . $playerid])) {
                                $che['menu_extrahtml'] = str_replace('download-after-rate', 'download-after-rate active', $che['menu_extrahtml']);
                            };
                        }


                        $fout.=$che['menu_extrahtml'];
                        $fout.='</div>';
                    }
                }


//                print_r($margs);

                if(isset($margs['inner_html']) && $margs['inner_html']){

                    $fout.=$margs['inner_html'];
                }

                //<div class="btn-like skin-simple"><i class="fa fa-heart-o"></i>Like</div><a class="skin-simple" href="#"><i class="fa fa-download"></i>Download</a><div class="counter-hits"><span class="the-number">{{get_plays}}</span> plays</div><div class="counter-likes"><span class="the-number">{{get_likes}}</span> likes</div><div class="counter-rates"><span class="the-number">{{get_rates}}</span> rates</div>


//            print_r($its);
                // --- extra html meta
                if (isset($its['settings']) && ($its['settings']['enable_views'] == 'on' || $its['settings']['enable_likes'] == 'on' || $its['settings']['enable_rates'] == 'on' || $its['settings']['extrahtml'])) {
                    $aux_extra_html = '';

                    $margs['call_from']='parse_items';

                    $aux_extra_html = $this->generate_extra_html($its, $playerid, $margs, $che);





//                print_r($margs);


//                    print_r($margs);

//                    echo '$aux_extra_html - '.$aux_extra_html;
//                    echo 'cond 1 - '.( (isset($margs['embedded']) && $margs['embedded']!='on')==true );
//                    echo 'cond 2 - '.( isset($margs['embedded'])==false );
//                    echo 'cond 2 - '.( isset($margs['embedded'])==false );
//                    echo 'cond 3 - '.( !(isset($margs['album_id']) && $margs['album_id']) );
//                    echo 'cond all - '.( (isset($margs['embedded']) && $margs['embedded']!='on')==true || isset($margs['embedded'])==false && !(isset($margs['album_id']) && $margs['album_id']) );


                if(!(isset($margs['disable_extra_html']) && $margs['disable_extra_html']=='on')){
                    if( (isset($margs['embedded']) && $margs['embedded']!='on')==true || isset($margs['embedded'])==false && !(isset($margs['album_id']) && $margs['album_id']) ){
                        $fout.='<div class="extra-html active">' . $aux_extra_html . '<div class="clear"></div></div>';
                    }
                }



                }

                if(isset($che['menudescription'])){
                    $fout.=$che['menudescription'];
                }



                $fout.='</div>';



                if (isset($che['apply_script'])) {

                }
            }
        }
        return $fout;
    }


    public function get_username($argid, $pargs=array()){


        $margs = array(
            'include_star'=>true,
            'include_tooltip'=>true,
        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        }

        $aux = '<span class="the-username from-get_username dzstooltip-con dzstooltip-con-user-summary for-hover" data-user-id="'.$argid.'">'.$this->get_user_field($argid, 'username').' ';



        if($margs['include_tooltip']){
            $aux.='<span class="dzstooltip user-tooltip skin-black arrow-left align-top transition-slidein" style="width: 250px; margin-left: 15px; margin-top: -10px; ">
        <span class="user-tooltip--content"><span class="user-summary-background-con"><span class="user-summary-background divimage" style="background-image: url(https://placeholdit.imgix.net/~text?txtsize=33&txt=placeholder&w=1400&h=600); "></span></span>
        <span href="#" class="user-avatar divimage" style="background-image: url(http://www.gravatar.com/avatar/75d23af433e0cea4c0e45a56dba18b30.png); "></span> 
        <span class="user-meta"><span class="flex-all"><i class="fa fa-users" title="'.__("Followers").'"></i> <span class="the-count followers-count">30</span></span><span class="flex-1">';


            $str_active = '';
            $str_follow =__("Follow");
            if($this->mysql_check_if_user_followed($argid)){
                $str_active=' active';
                $str_follow = __("Unfollow");
            }

            if($argid != $this->currUserId){

                $aux.='<span class="dzs-button '.$str_active.' btn-follow padding-small style-border-outside"  data-user-id="'.$argid.'"><span class="the-bg"></span><span class="the-text">'.$str_follow.'</span></span>';
            }



            $aux.='</span>  <span class="clear"></span> </span>
         </span>
    <span class=" preloader-fountain"> <span  class="fountainG fountainG_1 "></span> <span class="fountainG fountainG_2"></span> <span  class="fountainG fountainG_3"></span> <span class="fountainG fountainG_4" ></span> </span>
         </span>';
        }

        $aux.='
         </span>';




        $author_username = '';
        $str_star = '';

//        print_r($aux);

        if(isset($aux)){

            $author_username = $aux;

            $caps = $this->get_user_capabilities($argid);

//            print_r($caps);
            if($margs['include_star']){
                if(in_array('proaccount',$caps)){
                    $str_star = '&nbsp;&nbsp;<i class="fa fa-star"></i>';
                }
            }
            if($margs['include_star']){
                if(in_array('verified',$caps)){
                    $str_star = '&nbsp;&nbsp;<span class="user-meta-icon for-check "><i class="fa fa-check-circle"></i></span>';
                }
            }

        }


        if($author_username==''){

            $author_username = $this->get_user_field($argid, 'email');
        }

        return $author_username. $str_star;
    }

    function generate_extra_html($its, $playerid, $pargs, $che){
        $aux_extra_html = '';




        $margs = array(
            'force_disable_likes' => false,
            'call_from' => 'default',
        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        }



        if($margs['force_disable_likes']!==true){

            if (isset($its['settings']) && $its['settings']['enable_likes'] == 'on') {



                if(strpos($this->main_settings['str_likes_part1'],'{{translate_')!==false){
                    $this->main_settings['str_likes_part1'] = str_replace('{{translate_like}}',__("Like"), $this->main_settings['str_likes_part1']);
                    $this->main_settings['str_likes_part1'] = str_replace('{{translate_liked}}',__("Liked"), $this->main_settings['str_likes_part1']);

                }

                $aux_extra_html.=$this->main_settings['str_likes_part1'];
//                    $aux_extra_html.='';

                if ($this->check_if_user_liked_track($playerid) ) {
                    $aux_extra_html = str_replace('btn-like', 'btn-like active', $aux_extra_html);
                }
            }
        }



        if (isset($its['settings']) && $its['settings']['enable_rates'] == 'on') {
            $aux_extra_html.='<div class="star-rating-con"><div class="star-rating-bg"></div><div class="star-rating-set-clip" style="width: ';

//                    $aux = get_post_meta($playerid, '_dzsap_rate_index', true);
            $aux = $this->mysql_get_rates_average($playerid);


            if ($aux == '') {
                $aux_extra_html.='0px';
            } else {
                $aux_extra_html.=(122 / 5 * $aux) . 'px';
            }


            $aux_extra_html.=';"><div class="star-rating-prog"></div></div><div class="star-rating-prog-clip"><div class="star-rating-prog"></div></div></div>';
        }


//                print_r($its);

        $svg_repost = file_get_contents(dirname(__FILE__).'/assets/repost.svg');
        if($this->main_settings['enable_reposts']=='on'){

//            print_r($che);

            if($this->currUserId){

                if(isset($che['repost_id']) && $che['repost_id']){

                }else{

                    $reposted = $this->check_if_resposted($this->currUserId, $che['playerid']);



                    $aux_extra_html.='<span class=" btn-zoomsounds btn-repost';


                    if($reposted){
                        $aux_extra_html.=' active';
                    }

                    $aux_extra_html.='" data-track_id="'.$che['playerid'].'"';


                    if($reposted){
                        $aux_extra_html.=' data-repost-id="'.$reposted.'"';
                    }

                    $aux_extra_html.='><span class="the-icon">'.$svg_repost.'</span><span class="the-label hide-on-active">'.__("Repost").'</span><span class="the-label show-on-active">'.__("Reposted").'</span></span>';
                }
            }


        }


        if (isset($its['settings']) && $its['settings']['enable_views'] == 'on') {
            $aux_extra_html.=$this->main_settings['str_views'];
//                    $aux = get_post_meta($playerid, '_dzsap_views', true);

            $aux = '';



            if(strpos($aux_extra_html,'{{get_comments_nr}}')!==false){

                $aux = $this->get_comments_array($playerid, array(
                    'get_only_count'=>true,
                ));;

                if ($aux == false) {
                    $aux = 0;
                }




                $aux_extra_html = str_replace('{{get_comments_nr}}', $aux, $aux_extra_html);
            }





            if(strpos($aux_extra_html,'{{get_plays}}')!==false) {


                $aux = $this->mysql_get_track_activity($playerid);;

                if ($aux == '') {
                    $aux = 0;
                }


                $aux_extra_html = str_replace('{{get_plays}}', $aux, $aux_extra_html);

            }



            if(strpos($aux_extra_html,'{{get_downloads_nr}}')!==false) {


                $aux = $this->mysql_get_track_activity($playerid, array('type' => 'download',));;

                if ($aux == '') {
                    $aux = 0;
                }


                $aux_extra_html = str_replace('{{get_downloads_nr}}', $aux, $aux_extra_html);

            }



            if(strpos($aux_extra_html,'{{get_reposts_nr}}')!==false) {
                $aux = $this->mysql_get_track_activity($playerid, array('type' => 'repost',));;

                if ($aux == '') {
                    $aux = 0;
                }


                $aux_extra_html = str_replace('{{get_reposts_nr}}', $aux, $aux_extra_html);
            }
        }
        $aux_extra_html = str_replace('{{posturl}}', $this->get_permalink($playerid), $aux_extra_html);

//                print_r($this->main_config_settings);
        if($margs['force_disable_likes']!==true) {
            if (isset($its['settings']) && $its['settings']['enable_likes'] == 'on') {
                $aux_extra_html .= $this->main_settings['str_likes_part2'];
                $aux = $this->mysql_get_track_likes($playerid);
                if ($aux == '') {
                    $aux = 0;
                }
                $aux_extra_html = str_replace('{{get_likes}}', $aux, $aux_extra_html);
            }
        }




        if (isset($its['settings']) && $its['settings']['enable_rates'] == 'on') {
            $aux_extra_html.=$this->main_settings['str_rates'];
//                    $aux = get_post_meta($playerid, '_dzsap_rate_nr', true);
            $aux = $this->mysql_get_track_ratings_count($playerid);
            if ($aux == '') {
                $aux = 0;
            }
            $aux_extra_html = str_replace('{{get_rates}}', $aux, $aux_extra_html);

            if (isset($_COOKIE['dzsap_ratesubmitted-' . $playerid])) {
                $aux_extra_html.='{{ratesubmitted=' . $_COOKIE['dzsap_ratesubmitted-' . $playerid] . '}}';
            };
        }

//                echo 'generate_extra_html args -> '; print_r($its);           print_r($margs);echo '<-generate_extra_html args  ||| ';
//



        if(isset($margs['extra_html']) && $margs['extra_html']){
            $its[0]['extrahtml'].=$margs['extra_html'];
        }

        if(isset($margs['single']) && $margs['single']=='on'){
            if (isset($its[0]['extrahtml']) && $its[0]['extrahtml']) {
                $aux_extra_html.=$its[0]['extrahtml'];
//                    $aux = get_post_meta($playerid, '_dzsap_rate_nr', true);
                $aux_extra_html = str_replace('{{playerid}}', $playerid, $aux_extra_html);
                $aux_extra_html = str_replace('{{replaceurl}}', dzs_curr_url(), $aux_extra_html);
                $aux_extra_html = str_replace('{{replaceurl_escaped}}', urlencode(dzs_curr_url()), $aux_extra_html);
                $aux_extra_html = str_replace('{{baseurl}}', $this->url_base, $aux_extra_html);

            }
        }



        return $aux_extra_html;
    }
    public function generate_pre_track_info($track, $margs){
        $fout = '';
        if(isset($track['post_type']) && $track['post_type']=='repost'){


            $svg_repost = file_get_contents(dirname(__FILE__).'/assets/repost.svg');

            $fout.='<p class="reposted-by">';


            $fout.='<span class="the-avatar" style="background-image: url(';

            $fout.=$this->sanitize_source($this->get_avatar($track['repost_author_id']), array(

                'resize_image'=>true,
                'resize_w'=>'22',
                'resize_h'=>'22',
                'call_from'=>'debug',
            ));

            $fout.=')"></span>';



            $fout.='<span class="the-label">';


//                    print_r($track);




            $fout.='<strong>';
            $fout.='<a class="ajax-link" href="'.$this->get_permalink($track['repost_author_id'], array(
                    'type'=>'user',

                    'get_full_link'=>true,
                )).'">'.$this->get_username($track['repost_author_id'], array(
                    'include_star'=>false
                )).'</a>';
            $fout.='</strong>';


            $fout.='</span> '.$svg_repost.' <span class="the-label">';
            $fout.=__(' reposted ');

            $fout.='</span>';
            if($margs['style']!='under-with-timeline'){

                $fout.='<em class="the-date">'.$this->get_published_time($track['published_date']).'</em>';
            }
            $fout.='<span class="the-label">';

            $fout.='</span>';
            $fout.='</p>';
        }else{
//            print_r($margs);

            $fout.='<p class="reposted-by">';


            $fout.='<span class="the-avatar" style="background-image: url(';

//            echo '$track[\'repost_author_id\'] - '.$track['repost_author_id'].'  ';
//            echo $this->get_avatar($track['repost_author_id']);
            $fout.=$this->sanitize_source($this->get_avatar($track['author_id']), array(

                'resize_image'=>true,
                'resize_w'=>'22',
                'resize_h'=>'22',
                'call_from'=>'debug',
            ));


            $fout.=')"></span>';



            $fout.='<span class="the-label">';


//                    print_r($track);




            $fout.='<strong>';
            $fout.='<a class="ajax-link" href="'.$this->get_permalink($track['author_id'], array(
                    'type'=>'user',

                    'get_full_link'=>true,
                )).'">'.$this->get_username($track['author_id'], array(
                    'include_star'=>false
                )).'</a>';
            $fout.='</strong>';


            $fout.=__(' uploaded ');

//            print_r($track);

            if(isset($track['type']) && $track['type']=='album'){
                $fout.=__(" the album ");

                $link = $this->get_permalink($track['id'], array(
                    'type'=>'track',

                    'get_full_link'=>true,
                ));
                $fout.='<a class="ajax-link" href="'.$link.'">';
                $fout.=$track['title'];
                $fout.='</a>';
            }
            if(isset($track['type']) && $track['type']=='soundcloud'){
                $fout.='<span class="soundcloud-a">';
                $fout.=__(" from ");
                $fout.='<a target="_blank" class="" href="'.$track['content'].'">Soundcloud</a>';
                $fout.='</span>';

            }

            $fout.='</span>';
            if($margs['style']!='under-with-timeline'){

                $fout.='<em class="the-date">'.$this->get_published_time($track['published_date']).'</em>';
            }
            $fout.='<span class="the-label">';

            $fout.='</span>';
            $fout.='</p>';
            if($margs['style']=='under'){
            }
        }

        return $fout;
    }
    public function show_player($id, $pargs = array()) {



        $fout = '';
        $theid = 1;


        $margs = array(

                'disable_extra_html'=>'off',
                'disable_tags'=>'off',
                'disable_edit'=>'off',
                'called_from'=>'default',

        );

        $margs = array_merge($margs,$pargs);

        
//        print_r('show_player id - '); print_r($id);
//        print_r('show_player pargs - '); print_r($pargs);


        $iframe_id = rand(0,1000);

        $str_embed = '<iframe src=\''.$this->url_base.'index.php?page=embed&track_id={{playerid}}&embedded_iframe_id='.$iframe_id.'\' style="overflow:hidden; transition: height 0.5s ease-out;" width="100%" height="150" scrolling="no" frameborder="0" id="embedded-iframe-'.$iframe_id.'"></iframe>';

        //<script>                    window.addEventListener("message", receiveMessage, false);                   function receiveMessage(e){                     var data = e.data;  var origin = e.origin || e.originalEvent.origin;   if(data.params && data.params.embedded_iframe_id){   document.getElementById('embedded-iframe-'+data.params.embedded_iframe_id).style.height = ( Number(data.params.height)+20)+'px';  }    } </script>

//                echo 'ceva22'.$str;
        $str_embed = str_replace('"',"'",$str_embed);
        $str_embed =''.htmlentities($str_embed,ENT_QUOTES).'';

        $buy_button_str = '';



        $track = $this->get_track($id);





        $download_str = '<a href="index.php?page=download&track_id='.$id.'" ';

        if($track['download_link_new_tab']=='on'){

            $download_str.=' target="_blank"';
        }

        $download_str.= ' class="btn-zoomsounds custom-a download-anchor-btn" data-playerid="{{playerid}}"><span class="the-icon"><i class="fa fa-download"></i></span><span class="btn-label">'.__('Download').'</span></a>';

//        print_r($this->get_track($id));



        if($track['is_buyable']=='on'){

            $str_buy = '<span class="the-icon"><i class="fa fa-shopping-cart"></i></span><span class="btn-label">' . __('Add to Cart').'</span>';



            if($this->main_settings['enable_shop']=='on') {

                if($this->main_settings['add_to_cart_str']){

                    $str_buy = $this->main_settings['add_to_cart_str'];
                    $str_buy = str_replace("{{price}}",$track['price'],$str_buy);
                    $str_buy = str_replace("{{price_complet}}",$this->main_settings['currency_label'].$track['price'],$str_buy);

                }

                $buy_button_str = '<span class="add-to-cart-btn btn-zoomsounds" data-playerid="{{playerid}}">'.$str_buy.'</span>';
            }

            if($this->currUserId>0 || $track['price']==0){
                $purchases = $this->get_user_purchases($this->currUserId);

                if(in_array($id, $purchases) || $track['price']==0){

                    $buy_button_str = $download_str;
                }
            }
        }

        $author_name = $this->get_username($track['author_id']);

//        $buy_button_str = 'ceva';

        //&summary='.urlencode("by ".$author_name).'&amp;p[images][0]='.urlencode($this->sanitize_source($track['thumbnail'])).'

        $facebook_share_string = '<a class="social-icon" href="#"  onclick=\'window.dzsapp_open_social_link("http://www.facebook.com/sharer.php?u='.urlencode($this->get_permalink($track['id'])).'&title='.urlencode($track['title']).'"); return false;\'><i class="fa fa-facebook-square"></i><span class="the-tooltip">'.__('SHARE ON ').'FACEBOOK</span></a>';

        $twitter_share_string = '<a class="social-icon" href="#" onclick=\'window.dzsapp_open_social_link("http://twitter.com/share?url='.urlencode($this->get_permalink($track['id'])).'&amp;text=Check this out!&amp;via='.urlencode($this->main_settings['site_title']).'&amp;related=yarrcat"); return false;\'><i class="fa fa-twitter"></i><span class="the-tooltip">'.__('SHARE ON').' TWITTER</span></a>';


        $google_share_string = '<a class="social-icon" href="#" onclick=\'window.dzsapp_open_social_link("https://plus.google.com/share?url='.urlencode($this->get_permalink($track['id'])).'"); return false; \'><i class="fa fa-google-plus-square"></i><span class="the-tooltip">'.__('SHARE ON ').'GOOGLE PLUS</span></a>';

        $linkedin_share_string='<a class="social-icon" href="#" onclick=\'window.dzsapp_open_social_link("https://www.linkedin.com/shareArticle?mini=true&url='.urlencode($this->get_permalink($track['id'])).'&title=Check%20this%20out%20&summary=&source={{replaceurl}}"); return false; \'><i class="fa fa-linkedin"></i><span class="the-tooltip">'.__('SHARE ON').' LINKEDIN</span></a>';

        $pinterest_share_string='<a class="social-icon" href="#" onclick=\'window.dzsapp_open_social_link("http://pinterest.com/pin/create/button/?url='.urlencode($this->get_permalink($track['id'])).'&amp;text=Check this out!&amp;via='.urlencode($this->main_settings['site_title']).'&amp;related=yarrcat"); return false;\'><i class="fa fa-pinterest"></i><span class="the-tooltip">'.__('SHARE ON').' PINTEREST</span></a>';



        if($this->main_settings['enable_facebook_share']=='off'){
            $facebook_share_string = '';
        }
        if($this->main_settings['enable_twitter_share']=='off'){
            $twitter_share_string = '';
        }
        if($this->main_settings['enable_google_share']=='off'){
            $google_share_string = '';
        }
        if($this->main_settings['enable_linkedin_share']=='off'){
            $linkedin_share_string = '';
        }
        if($this->main_settings['enable_pinterest_share']=='off'){
            $pinterest_share_string = '';
        }






//        $facebook_share_string = '<a class="social-icon" href="#"  onclick=\'window.dzsapp_open_social_link("https://www.facebook.com/sharer/sharer.php?&s=100&p[images][0]=http://lorempixel.com/400/200&p[url]={{replaceurl_escaped}}&p[title]=ceva&title=alceva"); return false;\'><i class="fa fa-facebook-square"></i><span class="the-tooltip">'.__('SHARE ON FACEBOOK').'</span></a>';

//        print_r($track);



        $str_extrahtml = $buy_button_str.'<div data-playerid="{{playerid}}" class="share-btn btn-zoomsounds display-inline-block" data-playerid="{{playerid}}"><div class="hidden-content share-content" id="share-content-{{playerid}}"><h6>'.__("Social Networks").'</h6> '.$facebook_share_string.'


                                '.$twitter_share_string.'
                                '.$google_share_string.'


                                '.$linkedin_share_string.'

                                '.$pinterest_share_string.'

                                <h6>'.__("Share Link").'</h6>

                                <div class="field-for-view">'.$this->get_permalink($track['id'], array(
                'type'=>'track',
                'get_full_link'=>true,
            )).'</div>

                                <h6>'.__("Embed Link").'</h6>

                                <div class="field-for-view">'.$str_embed.'</div>





                                </div><span class="the-icon"><i class="fa fa-share-alt"></i></span><span class="btn-label">'.__('Share').'</span></div>'.$this->get_post_meta($track['id'], 'extra_buttons_right', array(
                'post_type'=>'track'
            )).'';



        $allowed = false;
        $caps = array();
        if($this->currUserId){




            $caps = $this->get_user_capabilities($this->currUserId);




//                error_log(print_rr($caps, array('echo'=>false)));


            if($this->currUserId==$track['author_id']){

                if(in_array('track_stats', $caps)){
                    $allowed = true;
                }
            }


            if(in_array('admin', $caps)){
                $allowed = true;
            }



        }

        if(isset($this->main_config_settings['is_preview']) && $this->main_config_settings['is_preview']=='on'){

            $allowed = true;
        }
        if($allowed){
            $str_extrahtml.='<span class="stats-btn btn-zoomsounds" data-playerid="{{playerid}}"><span class="the-icon"><i class="fa fa-tachometer" aria-hidden="true"></i></span><span class="btn-label">'.__("Stats").'</span></span>';
        }






        // -- likes are located in vpconfigs
        $margs = array(
            'width' => '100%',
            'height' => '300',
            'source' => '',
            'sourceogg' => '',
            'coverimage' => '',
            'waveformbg' => '',
            'waveformprog' => '',
            'cue' => 'on',
            'config' => '',
            'autoplay' => 'off',
            'type' => 'audio',
            'mediaid' => '',
            'player' => '',
            'playerid' => '',
            'mp4' => '',
            'openinzoombox' => 'off',
            'enable_likes' => 'auto',
            'enable_views' => 'auto',
            'enable_rates' => 'auto',
            'called_from' => 'default',
            'playfrom' => 'off',
            'artistname' => '',
            'songname' => '',
            'post_type' => 'track',
            'menu_artistname' => '',
            'menu_songname' => '',
            'single' => 'on',
            'single_on_page' => 'off', // -- if this is on, the cover image will appear too
            'embedded' => 'off',
            'embedded_iframe_id' => '',
            'divinsteadofscript' => 'on',
            'content'=>'',
            'thumb'=>'',
            'fakeplayer'=>'default', // -- place this the id of another player that will do the actual playing ( this will remain only a fake player displaying only the progress
            'extrahtml'=>$str_extrahtml,
            'menu_extrahtml'=>'',
            'apconfig'=>'',
        );


        if(is_array($pargs)){

            $margs = array_merge($margs, $pargs);
        }
//        print_r($margs);



//        $aux = $this->dblink->query($query);

        $player_db_args = array();

        $player_db_args = $track;

//        print_r($track);

        if(isset($track['type'])){
            $track['track_type']=$track['type'];
            $margs['track_type']=$track['type'];
        }

//        echo 'margs show_player -> ';print_r($margs); echo '<--- margs
//
//track -> ';print_r($track); echo ' <--- player_db_args ||| ... |||
//
//';
//            print_r($player_db_args);


        $author_username = '';


        $author_username = $this->get_username($player_db_args['author_id']);

//            print_r($author_username);



//            echo $author_username;

        $theid = $player_db_args['id'];
        $margs['playerid'] = $theid;
        $margs['source'] = $player_db_args['content'];
        $margs['sourceogg'] = $player_db_args['backup_ogg'];


        $aux = '';

        $aux = '<a class="';






        if($this->main_settings['use_ajax']=='on' && $margs['embedded']!='on'){
            $aux.=' ajax-link';
        }




        $link = $this->get_permalink($player_db_args['author_id'], array(
            'type'=>'user',
            'call_from'=>'line7911',
            'get_full_link'=>true,
        ));


//        echo 'link - '.$link.'<-- ';
        if($this->optional_url_base){
            if(strpos($link, $this->optional_url_base)===false){
                $link = $this->optional_url_base.$link;
            }
        }

        $aux.=' fromhere_show_player';
        $aux.='" href="'.$link.'"';


        if($margs['embedded']=='on'){
            $aux.=' target="_top"';
        }

        $aux.='>'.$author_username.'</a>';



        $margs['songname'] = $aux;

//            $margs['artistname'] = ;

        if($this->currPage=='user'){

            $margs['songname'] = ''.$author_username.'';
        }


        $aux = '<a class="';


//            print_r($margs);

        if($this->main_settings['use_ajax']=='on' && $margs['embedded']!='on'){
            $aux.=' ajax-link ';
        }


        $link = $this->optional_url_base.'index.php?page=track&track_id='.$player_db_args['id'];
        if($this->main_settings['use_pretty_links']=='on'){
            $link = $this->sanitize_for_pretty($player_db_args['id']);
        }


//            $link = 'ceva';

        $aux.='" href="'.$link.'"';



        if($margs['embedded']=='on'){
            $aux.=' target="_top"';
        }

        $aux.='>'.$player_db_args['title'].'</a>';

        $margs['artistname'] = $aux;




        if($this->currPage=='uservideos' || isset($_GET['playlist'])){
            $margs['artistname'] = '<a href="'.$this->url_portalphp.'?media='.$theid.'">'.$player_db_args['author_id'].'</a>';
        }


        if($this->currPage=='track'){

            $margs['artistname'] = ''.$player_db_args['title'].'';
        }



//            $margs['songname'] = $aux2[5];
        $margs['thumb'] = $player_db_args['thumbnail'];
        $margs['waveformbg'] = $player_db_args['waveform_bg'];
        $margs['waveformprog'] = $player_db_args['waveform_prog'];
        $margs['author_id'] = $player_db_args['author_id'];

        if($margs['embedded']==='on'){
            $margs['fakeplayer']='';
        }

        if($margs['fakeplayer']=='default'){
            if($this->main_settings['footer_player_config'] && $this->main_settings['footer_player_config']!='off'){

                $margs['fakeplayer'] = '#apapfooter';
            }else{

                $margs['fakeplayer'] = '';
            }
        }else{

        }


//        $aux->close();




        $vpsettingsdefault = array(
            'id' => 'default',
            'skin_ap' => 'skin-wave',
            'settings_backup_type' => 'full',
            'skinwave_dynamicwaves' => 'off',
            'skinwave_enablespectrum' => 'off',
            'skinwave_enablereflect' => 'on',
            'skinwave_comments_enable' => 'off',
            'disable_volume' => 'on',
            'playfrom' => 'default',
            'enable_likes' => 'on',
            'enable_views' => 'on',
            'enable_rates' => 'off',
        );

        $vpsettings = array();
        $vpsettings['settings'] = $vpsettingsdefault;

//        print_r($margs);
        if($margs['apconfig']){

            if(is_array($margs['apconfig'])){
                $vpsettings['settings'] = array_merge($vpsettingsdefault,$margs['apconfig']);
            }else{

                $apconfig_str = $this->get_page($margs['apconfig'], array(
                    'post_type'=>'apconfig',
                ));

                $apconfig = array();


                if(isset($apconfig_str['content'])){

                    parse_str($apconfig_str['content'], $apconfig);
                }
                $vpsettings['settings'] = array_merge($vpsettingsdefault, $apconfig);
            }



//            print_r($apconfig);

        }

        if($vpsettings['settings']['skin_ap']=='skin-wave'){
            if($margs['waveformbg']==''){
                $margs['waveformbg']=$this->url_base.'waves/scrubbg_default.png';
            }
            if($margs['waveformprog']==''){
                $margs['waveformprog']=$this->url_base.'waves/scrubprog_default.png';
            }
//            print_r($margs);
        }







//        print_r($margs);

        // its is margs
        $its = array(0 => $margs,'settings' => array());

        if($margs['enable_likes'] && $margs['enable_likes']!='auto'){

            $vpsettings['settings']['enable_likes']=$margs['enable_likes'];
        }
        if($margs['enable_views'] && $margs['enable_views']!='auto'){

            $vpsettings['settings']['enable_views']=$margs['enable_views'];
        }
        if($margs['enable_rates'] && $margs['enable_rates']!='auto'){

            $vpsettings['settings']['enable_rates']=$margs['enable_rates'];
        }

        $its['settings'] = array_merge($its['settings'],$vpsettings['settings']);



//        echo ' show player args -> '; print_r($margs); print_r($player_db_args); print_r($its['settings']);echo ' <- show player args END |||  ';


        if(isset($player_db_args['extra_html'] ) && $player_db_args['extra_html']){

            $margs['extra_html']=$player_db_args['extra_html'];

        }


        $the_player_id='';

        if($theid){

            if(isset($margs['track_type']) && $margs['track_type']=='album'){

                $the_player_id = 'ag' . $theid . '';
            }else{

                $the_player_id = 'ap' . $theid . '';
            }

        }
        if(isset($margs['player_id']) && $margs['player_id']){
//                print_r($margs);
            $the_player_id = $margs['player_id'];
        }


//            print_r($margs);


        if(isset($margs['called_from']) && $margs['called_from']=='player' && isset($margs['colorhighlight']) && $margs['colorhighlight']){
            if($margs['skin_ap']=='skin-wave'){


            }
        }



        $color_highlight = '';
        if(isset($vpsettings['settings']['colorhighlight'])){
            $color_highlight = $vpsettings['settings']['colorhighlight'];

            if(strpos($color_highlight, '#')===0){
                $color_highlight = str_replace('#','',$color_highlight);
            }
        }


//        echo 'hmm - '.$color_highlight;
        if($color_highlight){

//            print_r($its);

            if($margs['track_type']=='album'){

                $fout.='<style class="from-show-player">';
                $fout.='#'.$the_player_id.' .audioplayer.skin-wave .ap-controls .con-playpause .playbtn,#'.$the_player_id.' .audioplayer.skin-wave .ap-controls .con-playpause .pausebtn, #'.$the_player_id.' .audioplayer.skin-wave .btn-embed-code,#'.$the_player_id.' .audioplayer.skin-wav .ap-controls .con-playpause .pausebtn, #'.$the_player_id.' .orange-button, #'.$the_player_id.' .audioplayer.skin-wave .volume_active, #'.$the_player_id.' .audioplayer.skin-wave .prev-btn, #'.$the_player_id.' .audioplayer.skin-wave .next-btn { background-color: #'.$color_highlight.';}  ';
                $fout.='</style>';
            }else{

//                print_r($its); print_r($margs);



                $fout.='<style class="from-show-player">';


                $fout.='#'.$the_player_id.' .orange-button, .audioplayer.skin-wave#'.$the_player_id.' .volume_active { background-color: #'.$color_highlight.';} ';

                if(isset($its['settings']) && isset($its['settings']['button_aspect']) && $its['settings']['button_aspect']!='default'){

                }else{
                    $fout.='.audioplayer.skin-wave#'.$the_player_id.' .ap-controls .con-playpause .playbtn, .audioplayer.skin-wave#'.$the_player_id.' .btn-embed-code, .audioplayer.skin-wave#'.$the_player_id.' .ap-controls .con-playpause .pausebtn  { background-color: #'.$color_highlight.';}  </style>';

                }
                $fout.='</style>';


            }
        }

//        echo 'one.. time.... ? ';


//        $fout.='<!-- end player markup-->';


//        echo '.. '.$fout.' ..   ///   ';


        $allowed_edit = false;
        if($this->currUserId>0){



            if($player_db_args['author_id']===$this->currUserId){
                $allowed_edit=true;
            }
            if(in_array('admin', $caps)){
                $allowed_edit=true;
            }



        }else{
//                $vpsettings['settings']['skinwave_comments_enable'] = 'off';
        }
        //===normal mode
        if ($margs['openinzoombox'] != 'on') {

            // -- just NORMAL ( not in zoombox )

//            print_r($margs);

//            echo 'cover_image - '.$player_db_args['cover_image'];

            if($player_db_args['cover_image'] && $this->currPage=='track'){
//                echo 'ceva';

                $fout.='<div class="player-dark-theme">';
            }


            if(!(isset($margs['disable_tags']) && $margs['disable_tags']=='on')) {
                if ($margs['embedded'] != 'on' && $player_db_args['tags']) {
                    $auxa = explode(',', $player_db_args['tags']);

//                print_r($auxa);

                    $fout .= '<div class="tags-con">';

                    foreach ($auxa as $tag) {
                        if (strpos($tag, ' ') === 0) {
                            $tag = substr($tag, 1);
                        }
                        $fout .= '<a href="' . $this->optional_url_base . 'index.php?page=tracklist&page_type=tag&query=' . urlencode($tag) . '" class="tag-for-ap ajax-link">#' . $tag . '</a>';
                    }
                    $fout .= '</div>';
                }
            }

            // -- normal mode parse item

//            print_r($its);
            $fout.=$this->parse_items($its,$margs);
            if($player_db_args['cover_image'] && $this->currPage=='track'){
                $fout.='</div>';
            }

//            echo 'before script margs - ';print_r($margs);
            if ($margs['divinsteadofscript'] != 'on') {
                $fout.='<script>';
            } else {
                $fout.='<div class="toexecute-from-portal">';
            }

//            print_r($margs);


//            print_r($vpsettings['settings']);


            $fout.='(function(){
// from show_player() yesyes 3816 normal player
jQuery(document).ready(function ($){
var settings_ap = {
design_skin: "'.$vpsettings['settings']['skin_ap'].'"
,autoplay: "'.$margs['autoplay'].'"
,disable_volume:"'.$vpsettings['settings']['disable_volume'].'"
,cue: "'.$margs['cue'].'"
,embedded: "'.$margs['embedded'].'"
,embedded_iframe_id: "'.$margs['embedded_iframe_id'].'"
,skinwave_dynamicwaves:"'.$vpsettings['settings']['skinwave_dynamicwaves'].'"
,skinwave_enableSpectrum:"'.$vpsettings['settings']['skinwave_enablespectrum'].'"
,settings_backup_type:"'.$vpsettings['settings']['settings_backup_type'].'"
,skinwave_comments_process_in_php: "on"
,settings_php_handler: "'.$this->optional_url_base.'index.php"
,php_retriever: "'.$this->optional_url_base.'soundcloudretriever.php"
,skinwave_enableReflect:"'.$vpsettings['settings']['skinwave_enablereflect'].'"';
            if (isset($vpsettings['settings']['playfrom'])) {
                $fout.=',playfrom:"'.$vpsettings['settings']['playfrom'].'"';
            }


            if ($color_highlight) {
                $fout.=',design_color_highlight:"'.$color_highlight.'"';
            }

//            echo ' $color_waveform_bg - '.$this->main_settings['color_waveformbg'];

            if($this->main_settings['skinwave_wave_mode']=='canvas'){

                $color_waveform_bg = $this->main_settings['color_waveformbg'];
                $color_waveform_prog = $this->main_settings['color_waveformprog'];


                if($color_waveform_bg=='#212223'){
                    if($this->main_settings['theme']=='theme-dark'){
                        $color_waveform_bg = '#dddddd';
                    }
                }


                $color_waveform_bg = str_replace('#','',$color_waveform_bg);
                $color_waveform_prog = str_replace('#','',$color_waveform_prog);

                $fout.=',skinwave_wave_mode: "canvas"
,skinwave_wave_mode_canvas_waves_number: "'.$this->main_settings['skinwave_wave_mode_canvas_waves_number'].'"
,pcm_data_try_to_generate: "'.$this->main_settings['pcm_data_try_to_generate'].'"
,design_color_bg: "'.$color_waveform_bg.'"
,design_color_highlight: "'.$color_waveform_prog.'"
';
            }


            //<div class="orange-button dzstooltip-con" style="top:10px;"><span class="dzstooltip arrow-from-start transition-slidein arrow-bottom skin-black align-right" style="width: auto; white-space: nowrap;">Download</span><i class="fa fa-download"></i></div>

            //<span class="ap-date">'.__("A day before").'</span>

//            print_r($vpsettings);

            $link = $this->get_permalink($its[0]['playerid'], array(
                'type'=>'track',
            ));
            if($vpsettings['settings']['skin_ap']=='skin-wave' && isset($vpsettings['settings']['skinwave_mode']) && $vpsettings['settings']['skinwave_mode']=='normal' && $this->currUserId>0){


                $aux_add_to_playlist = '<div class=" dzstooltip-con  add-to-playlist-btn player-but" style="top:10px;"><span class="dzstooltip arrow-from-start transition-slidein arrow-bottom skin-black align-right" style="width: auto; white-space: nowrap; right:-5px;">'.__("Add to Playlist").'</span> <div class="the-icon-bg"></div> <div class="svg-icon"><i class="fa fa-bookmark" style=" "></i></div></div>';

                if(isset($_GET['page']) && $_GET['page']=='embed'){

//                    print_r($its);
//                    print_r($margs);
                    $aux_add_to_playlist = '<a href="'.$link.'" target="_blank" class="orange-button dzstooltip-con  add-to-playlist-btn" style="top:10px;"><span class="dzstooltip arrow-from-start transition-slidein arrow-bottom skin-black align-right" style="width: auto; white-space: nowrap; right:-5px;">'.__("Add to Playlist").'</span><i class="fa fa-bookmark"></i></a>';
                }

//                $aux_add_to_playlist = htmlentities($aux_add_to_playlist);
                $fout.=',settings_extrahtml_in_float_right: \''.($aux_add_to_playlist).'\'';
            }


            if(isset($margs['disable_edit']) && $margs['disable_edit']=='on'){

                $allowed_edit=false;
            }




            if(isset($_GET['page']) && $_GET['page']=='embed'){
                $fout.=',skinwave_comments_links_to:\''.$link.'\'';
            }

            $soundcloud_api_key = $this->main_config_settings['soundcloud_api_key'];

            if($this->main_settings['soundcloud_api_key']){
                $soundcloud_api_key = $this->main_settings['soundcloud_api_key'];
            }


            $fout.=',soundcloud_apikey:"'.$soundcloud_api_key.'"
,skinwave_comments_allow_post_if_not_logged_in:"'.$this->main_settings['comments_allow_post_if_not_logged_in'].'"
,skinwave_comments_enable:"'.$vpsettings['settings']['skinwave_comments_enable'].'"';

            $fout.='';
            if ($vpsettings['settings']['skinwave_comments_enable'] == 'on') {
                if ($this->currUserId!=='0') {
                    $fout.=',skinwave_comments_account:"'.$this->get_user_field($this->currUserId,'email').'"';
                    $fout.=',skinwave_comments_avatar:"'.$this->get_avatar($this->currUserId).'"';
                }
            }




            if (isset($its['settings']['skinwave_mode']) && $its['settings']['skinwave_mode'] == 'small') {
                $fout.=',skinwave_mode:"'.$its['settings']['skinwave_mode'].'"';
            }



//            $fout.=',skinwave_comments_playerid:"'.$margs['playerid'].'"';


            if (isset($vpsettings['settings']['enable_embed_button']) && $vpsettings['settings']['enable_embed_button'] == 'on') {

            }


            if($margs['post_type']=='repost'){
                $the_player_id.='_repost';
            }

//            $fout.=',soundcloud_apikey:"be48604d903aebd628b5bac968ffd14d"';

            if($margs['post_type']=='repost'){
//                $the_player_id.='_repost';
            }


            $preload_method = 'metadata';
            if (isset($vpsettings['settings']['preload_method']) && $vpsettings['settings']['preload_method']){

                $preload_method = $vpsettings['settings']['preload_method'];
            }



            $fout.=',php_retriever:"'.$this->url_base.'soundcloudretriever.php" ,swf_location:"'.$this->url_base.'ap.swf"
,swffull_location:"'.$this->url_base.'apfull.swf"
,preload_method: "'.$preload_method.'"
,action_audio_play: window.portal_action_track_play
,action_audio_end: window.portal_action_audio_end';


            if(defined('SOUNDPORTAL_WATERMARK')){
//                    print_r($che);
                $user_meta = $this->get_user_meta_all($player_db_args['author_id']);

                if(isset($user_meta) && isset($user_meta['watermark_volume']) && $user_meta['watermark_volume']){
                    $fout.=',watermark_volume:"'.($user_meta['watermark_volume']).'"';
                }

//                    print_r($user_meta);
            }

            $fout.='

};
var auxap = $(".jsapid'.$this->jsapid.'");';




            if(isset($margs['track_type']) && $margs['track_type']=='album'){

                $fout.='
                 auxap = $(".jsagid'.$this->jsagid.'");
var settings_ag = {
            \'transition\':\'fade\'
            ,\'cueFirstMedia\' : \'on\'
            ,\'autoplay\' : \'off\'
            ,\'autoplayNext\' : \'on\'
            ,design_menu_position:\'bottom\'
            ,\'settings_ap\':settings_ap
            ,embedded: \'off\'
            ,enable_easing: \'on\'
            ,design_menu_height: "auto"
            ,design_menu_state: \'';


                if(isset($margs['called_from']) && $margs['called_from']=='charts'){
                    $fout.='closed';
                }else{

                    $fout.='open';
                }

                $fout.='\' // -- options are "open" or "closed", this sets the initial state of the menu, even if the initial state is "closed", it can still be opened by a button if you set design_menu_show_player_state_button to "on"
';




                $fout.='
        }
dzsag_init(auxap,settings_ag);';
            }else{

                $fout.='

//console.info(auxap);
dzsap_init(auxap,settings_ap);';
            }




            $fout.='
});
})();';



//            echo $fout.'<--fout';


            if ($margs['divinsteadofscript'] != 'on') {
                $fout.='</script>';
            } else {
                $fout.='</div>';
            }
        } else {

            // -- zoombox mode

            $fout.='<a href="'.$margs['source'].'" data-sourceogg="'.$margs['sourceogg'].'" data-waveformbg="'.$margs['waveformbg'].'" data-waveformprog="'.$margs['waveformprog'].'" data-type="'.$margs['type'].'" data-coverimage="'.$margs['coverimage'].'" class="zoombox effect-justopacity">'.$margs['content'].'</a>';



            if ($margs['divinsteadofscript'] != 'on') {
                $fout.='<script>';
            } else {
                $fout.='<div class="toexecute">';
            }
            $fout.='(function(){
var auxap = jQuery(".audioplayer-tobe").last();
jQuery(document).ready(function ($){
var settings_ap = {
    design_skin: "'.$vpsettings['settings']['skin_ap'].'"
    ,skinwave_dynamicwaves:"'.$vpsettings['settings']['skinwave_dynamicwaves'].'"
    ,disable_volume:"'.$vpsettings['settings']['disable_volume'].'"
    ,skinwave_enableSpectrum:"'.$vpsettings['settings']['skinwave_enablespectrum'].'"
    ,settings_backup_type:"'.$vpsettings['settings']['settings_backup_type'].'"
    ,skinwave_enableReflect:"'.$vpsettings['settings']['skinwave_enablereflect'].'"
    ,skinwave_comments_enable:"'.$vpsettings['settings']['skinwave_comments_enable'].'"';

            if ($vpsettings['settings']['skinwave_comments_enable'] == 'on') {
                $fout.=',settings_php_handler:window.ajaxurl';
//                if (isset($current_user->data->user_nicename)) {
//                    $fout.=',skinwave_comments_account:"'.$current_user->data->user_nicename.'"';
//                    $fout.=',skinwave_comments_avatar:"'.$this->get_avatar_url(get_avatar($current_user->data->ID,20)).'"';
//                    $fout.=',skinwave_comments_playerid:"'.$margs['playerid'].'"';
//                }
            }

            $fout.=',swf_location:"'.$this->url_base.'ap.swf"
    ,swffull_location:"'.$this->url_base.'apfull.swf"
};
$(".zoombox").zoomBox({audioplayer_settings: settings_ap});
});
})();';

            if ($margs['divinsteadofscript'] != 'on') {
                $fout.='</script>';
            } else {
                $fout.='</div>';
            }
        }



//echo $fout.'...';

//        print_r($player_db_args);

//        echo 'margs before edit - '; print_r($margs);


        if($margs['post_type']=='repost'){

//            print_r($margs);
//            print_r($player_db_args);

            if($allowed_edit) {
                $fout .= '<div class="delete-repost-btn btn-discrete" data-repost-id="' . $margs['repost_id'] . '" data-player-id="' . $margs['playerid'] . '">' . __("Delete Repost") . '</div>';
            }
        }else{
            if($allowed_edit){

//            print_r($margs);



                $track_meta = $this->get_post_meta_all($player_db_args['id'], array(

                    'post_type'=>'track',
                ));

//            print_r($track_meta);

//            print_r($margs);
//            print_r($player_db_args);

                if($margs['embedded']!='on'){

                    $fout.='<div class="edit-btn edit-btn--track btn-discrete">'.__("Edit Track").'</div>';
                }

                $fout.='<form class="edit-panel" style="display:none;">';

                $fout.='<input type="hidden" name="track_id" value="'.$player_db_args['id'].'">';


                $fout.='<div class="row"><div class="col-md-6">';


                $lab = 'title';

                $fout.='<div class="setting">';
                $fout.='<div class="label-for-ujarak">'.__("Title").'</div>';
                $fout.='<input type="text" name="'.$lab.'" class="input-ujarak-style" value="'.$player_db_args[$lab].'"/>';
                $fout.='</div>';



                $lab = 'thumbnail';

                $fout.='<div class="setting">';
                $fout.='<div class="dzs-upload-con">
                                                        <div class="label-for-ujarak">'.__("Thumbnail").'</div><input type="text" name="'.$lab.'" class="input-ujarak-style" value="'.$player_db_args[$lab].'"/>
                                                        <span class="dzs-single-upload"  data-call_from="user_meta_change">
                                                            <input class="" name="file_field" type="file">
                                                        </span>
                                                        <span class="dzs-upload--progress progress-bar-bellow"></span>
                                                    </div>';
                $fout.='</div>';



                $lab = 'content';


//                $fout.=print_rr($margs, array('echo'=>false));




                $fout.='<div class="setting">';
                $fout.='<div class="dzs-upload-con">
                                                        <div class="label-for-ujarak">'.__("Source").'</div><input type="text" name="'.$lab.'" class="input-ujarak-style';



                if($margs['track_type']=='album'){
                    $fout.=' target-for-album-parts disabled';
                }

                $fout.='" value="'.$player_db_args[$lab].'" data-upload_from="main-mp3"/>
                                                        ';


                if($margs['track_type']=='album'){


                    $own_tracks = $this->get_tracks(array(
                        'author_id'=>$this->currUserId,
                        'type'=>'album_part,soundcloud,track,',
//                        'call_from'=>'debug',
                    ));


                    $arr = array();
                    $arr = unserialize($player_db_args['content']);
//                    foreach ($own_tracks as $tr){
//
//                        $aux_arr = array(
//                            'id'=>$tr['id'],
//                        )
//                        
//                        array_push($arr);
//                    }

//                    print_r($arr);

                    $fout.='<div class="album-part-selector-main--con">';
                    $fout.='<h4>'.__("Tracks").'</h4>';
                    $fout.='<input class="input-style-grey selector-main-searcher" type="search" placeholder="'.__("Search").'" />';
                    $fout.='</div>';
                    $fout.='<div class="album-part-selector-main">';

                    foreach ($own_tracks as $lab => $tr){
                        if(in_array($tr['id'],$arr)){
                            $fout.=' ';
                        }else{
                            continue;
                        }


                        $fout.='<div class="album-part active';



                        $fout.='" data-id="'.$tr['id'].'">';



                        $fout.='<div class="the-title">';

                        $fout.=$tr['title'];

                        $fout.='</div>';



                        $fout.='<div class="the-buttons">';

                        $fout.= '<button class="dzs-button style-border-outside padding-small add-btn"><div class="the-bg"></div><i class="fa fa-plus-square-o the-icon"></i><span class="the-text">'.__("Add").'</span></button>';
                        $fout.= '<button class="dzs-button style-border-outside padding-small remove-btn"><div class="the-bg"></div><i class="fa fa-minus-square-o the-icon"></i><span class="the-text">'.__("Remove").'</span></button>';

                        $fout.='</div>';




                        $fout.='</div>';

                        unset($own_tracks[$lab]);
                    }

                    foreach ($own_tracks as $tr){
                        $fout.='<div class="album-part';



                        $fout.='" data-id="'.$tr['id'].'">';



                        $fout.='<div class="the-title">';

                        $fout.=$tr['title'];

                        $fout.='</div>';



                        $fout.='<div class="the-buttons">';

                        $fout.= '<button class="dzs-button style-border-outside padding-small add-btn"><div class="the-bg"></div><i class="fa fa-plus-square-o the-icon"></i><span class="the-text">'.__("Add").'</span></button>';
                        $fout.= '<button class="dzs-button style-border-outside padding-small remove-btn"><div class="the-bg"></div><i class="fa fa-minus-square-o the-icon"></i><span class="the-text">'.__("Remove").'</span></button>';

                        $fout.='</div>';




                        $fout.='</div>';
                    }

                    $fout.='</div>';




//                    $fout.=print_rr($own_tracks, array('echo'=>false));

                }else{

                    $fout.='<span class="dzs-single-upload"  data-call_from="user_meta_change">
<input class="" name="file_field" type="file">
</span>';
                }
                $fout.='
                                                        <span class="dzs-upload--progress progress-bar-bellow"></span>';
                $fout.='</div>';


                $fout.='</div>';




                $lab = 'cover_image';

                $fout.='<div class="setting">';


                $fout.='<div class="dzs-upload-con">
                                                        <div class="label-for-ujarak">'.__("Cover Image").'</div><input type="text" name="'.$lab.'" class="input-ujarak-style" value="'.$player_db_args[$lab].'"/>
                                                        <span class="dzs-single-upload" data-call_from="user_meta_change">
                                                            <input class="" name="file_field" type="file">
                                                        </span>
                                                        <span class="dzs-upload--progress progress-bar-bellow"></span>
                                                    </div>';
                $fout.='</div>';







                enqueue_script('dzs.upload', $this->optional_url_base.'libs/dzsuploader/upload.js');
                enqueue_style('dzs.upload', $this->optional_url_base.'libs/dzsuploader/upload.css');
                enqueue_style('dzs.checkbox', $this->optional_url_base.'libs/dzscheckbox/dzscheckbox.css');







                $fout.='</div>';

                $fout.='<div class="col-md-6">';


                $lab = 'tags';

                $fout.='<div class="setting">';
                $fout.='<div class="label-for-ujarak">'.__("Tags").'</div>';
                $fout.='<textarea type="text" name="'.$lab.'" class="input-ujarak-style" value="">'.$player_db_args[$lab].'</textarea>';
                $fout.='</div>';


                $lab = 'description';

                $fout.='<div class="setting">';
                $fout.='<div class="label-for-ujarak">'.__("Description").'</div>';
                $fout.='<textarea type="text" name="'.$lab.'" class="input-ujarak-style with-tinymce" >'.htmlentities($player_db_args[$lab]).'</textarea>';
                $fout.='</div>';



                $allowed_set_download = 'off';

                if(in_array('sell_track', $caps)){
                    $allowed_set_download = 'custom_price';
                }else{
                    if(in_array('place_track_free_download', $caps)){
                        $allowed_set_download = 'free_download';
                    }
                }

//                print_r($caps);
                if(in_array('force_submit_free_download', $caps)){
                    $allowed_set_download = 'force_free_download';
                }


                if($allowed_set_download=='custom_price'){


                    $lab = 'is_buyable';

                    $fout.='<input type="hidden" name="'.$lab.'" class="" value="off"/>';
                    $fout.='<div class="setting">';
                    $fout.='<h5 class="">'.__("Is Buyable ?").'</h5>';
                    $fout.='<div class="dzscheckbox skin-nova" style="margin-top: 15px;">'.DZSHelpers::generate_input_checkbox($lab,array('id' => $lab, 'val' => 'on','seekval' => $player_db_args[$lab])).'
<label for="'.$lab.'"></label>
</div>';
                    $fout.='</div>';



                    $lab = 'price';

                    $fout.='<div class="setting">';
                    $fout.='<div class="label-for-ujarak">'.__("Price").'</div>';
                    $fout.='<input type="text" name="'.$lab.'" class="input-ujarak-style" value="'.$player_db_args[$lab].'"/>';
                    $fout.='</div>';
                }


                if($allowed_set_download=='free_download'){


                    $lab = 'is_buyable';

                    $fout.='<input type="hidden" name="'.$lab.'" class="" value="off"/>';
                    $fout.='<div class="setting">';
                    $fout.='<h5 class="">'.__("Is Downloadable ?").'</h5>';
                    $fout.='<div class="dzscheckbox skin-nova" style="margin-top: 15px;">'.DZSHelpers::generate_input_checkbox($lab,array('id' => $lab, 'val' => 'on','seekval' => $player_db_args[$lab])).'
<label for="'.$lab.'"></label>
</div>';
                    $fout.='</div>';



                    $lab = 'price';
                    $fout.='<input type="hidden" name="'.$lab.'" class="input-ujarak-style" value="'.'0'.'"/>';
                }





                $lab = 'extra_buttons_right';
                $val = '';
                if(isset($track_meta[$lab])){
                    $val = htmlentities($track_meta[$lab]);
                }


                $fout.='<div class="setting">';


                $fout.='
                                                        <div class="label-for-ujarak">'.__("Extra HTML in Right of Buttons").'</div><input type="text" name="'.$lab.'" class="input-ujarak-style" value="'.$val.'"/>
                                                        ';
                $fout.='</div>';







                $fout.='</div><!-- end col-md-6-->';


                $fout.='</div>';

                $fout.='<button class="button button--secondary"><span class="button-label">'.__("Save").'</span></button>';
                $fout.='<div class="delete-track-btn" data-playerid="'.$theid.'"><span>delete</span> <i class="fa fa-times-circle"></i></div>';

                $fout.='</form>';
            }

        }



//        enqueue_script('dzs.audioplayer', 'libs/audioplayer/audioplayer.js');

//        return '<here>';
        return $fout;
    }

    function mysql_get_avatar($id) {

        $margs = array(
            'type'=>'cover',
        );


        $query = "SELECT * FROM `users` WHERE `id`='$id'";


        $aux = $this->dblink->query($query);

//        echo $query;
        if ($aux) {
//            print_r($aux);

            $row = mysqli_fetch_assoc($aux);

//            print_r($row);

            if($row && isset($row['avatar'])){


                $fout = $row['avatar'];


                if($this->optional_url_base){

                    if(strpos($fout, $this->optional_url_base)===false && strpos($fout, 'http')!==0){

                        if($fout){

                            $fout = $this->optional_url_base.$fout;
                        }
                    }
                }

                return $fout;
            }else{

                return '';
            }


        } else {
            return mysqli_error($this->dblink);
        }
    }

    function mysql_get_email($id) {


        $query = "SELECT `email` FROM `users` WHERE `id`='$id'";

//        echo $query;

        $aux = $this->dblink->query($query,MYSQLI_USE_RESULT);

        if ($aux) {

            $row = mysqli_fetch_assoc($aux);
//            print_r($row);

            return $row['email'];
        }


//        $aux->close();

        return '';
    }

    function mysql_login_user($email,$pass) {

//        echo ' pass - '.$pass.'|||md5pass - '.MD5($pass).'<br>';
//        echo ' pass - '.$pass.'|||md5pass - '.md5(iconv("UTF-8", "ISO-8859-1",$pass)).'<br>';
//        echo ' pass - '.$pass.'|||md5pass - '.md5(iconv("ISO-8859-1","UTF-8" ,$pass));
        $pass = MD5($pass);


        $query = "SELECT * FROM users WHERE email='$email' AND password='$pass'";

        $aux = $this->dblink->query($query);

        if ($aux) {
            if ($aux->num_rows == 1) {
                $row = mysqli_fetch_assoc($aux);

//                print_r($row);

                if(isset($row['verify_status']) && $row['verify_status']=='unverified'){

                    return __('you need to confirm your email first');
                }

                $this->currUserId = $row['id'];


//                echo 'login user hier';
                setcookie('currUserId',$this->currUserId,time()+3600);
                $_SESSION['currUserId'] = $this->currUserId;

                return true;
            } else {
                return __('username and password do not match <br><a data-src="#forgotpassword" class="zoombox" data-bigwidth="400" data-bigheight="300" data-scaling="fill">forgot password ?</a> ');
            }
        } else {
            return mysqli_error($this->dblink);
        }
    }



    public function check_login_from_facebook($argemail,$pargs=array()){

//        $argavatar=''
        $margs = array(
            'avatar'=> '',
            'username'=>'',
        );

        if($pargs){
            $margs = array_merge($margs,$pargs);
        }

//        echo 'check_login_from_facebook '.$argemail.' '.$margs['avatar'];

        $query = "SELECT * FROM users WHERE email = '$argemail' ";


        $aux = $this->dblink->query($query);

        if($aux){

            if($aux->num_rows==0){

                $this->mysql_create_user($argemail, 'defaultpassword',array(
                    'avatar'=>$margs['avatar'],
                    'username'=>$margs['username'],
                ));

                $_SESSION['currUserId'] = $this->currUserId;

                return 'usercreated';
            }else{

                $row = mysqli_fetch_assoc($aux);

                $this->currUserId=$row['id'];


                setcookie("username",$this->currUserId,time() + 3600);

                $_SESSION['currUserId'] = $this->currUserId;

//                echo 'cookiesetted';


                return 'userloggedin';
            }
        }else{
//            echo 'error - error in sql connection';
            return 'error';
        }

    }

    function permalinks_search($pargs=array()){

        // -- this searches only in table


        $margs = array(
            'type'=>'track',
            'target_id'=>'',
            'only_from_table'=>false, // -- search only in the permalink table
            'permalink_search'=>'', // -- append first query
            'query2'=>'', // -- append second query
            'return_array'=>false, // -- append second query
            'call_from'=>'', // -- append second query
        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        };

        if($margs['call_from']=='get_permalink()'){

//            echo 'permalinks_search() args - '; print_r($margs);
        }


        $margs['permalink_search']=$this->sanitize_title_for_pretty($margs['permalink_search']);

        $permalink = '';

        if($margs['return_array']){
            $permalink = array();
        }

        $auxarr = $this->get_permalinks();

        foreach ($auxarr as $lab => $val){
//            print_r($val);

//            if($val['type']=='page'){
//
//                $_GET['page']='page';
//                $_GET['page_id']=$val['target_id'];
//            }


            if($margs['target_id']){
                if($val['target_id']==$margs['target_id'] && $val['type']==$margs['type']){


//
//                echo 'hmmdada -- ';


//                    $permalink.='hmmdada';

                    $sw_found = true;
                    if($margs['return_array']){
                        $permalink = $val;
                    }else{

                        $permalink .= $val['permalink'];
                    }

                    break;
                }
            }

            if($margs['permalink_search']) {
//                echo ' searched vars ( '.$margs['permalink_search'].' ) --- ';print_r($val);
                if ($val['permalink'] == $margs['permalink_search']) {


//                echo 'hmmdada -- ';

                    $sw_found = true;
                    if($margs['return_array']){
                        $permalink = $val;
                    }else{

                        $permalink .= $val['permalink'];
                    }

                    break;
                }
            }
        }

        return $permalink;

    }

    function get_permalink($arg='', $pargs=array()){

        $margs = array(
            'type'=>'track',
            'page_type'=>'',
            'only_from_table'=>false, // -- search only in the permalink table
            'query1'=>'', // -- append first query
            'query2'=>'', // -- append second query
            'call_from'=>'',
            'get_full_link'=>false,
        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        };

        $sw_found = false;


        $link = '';

        if($margs['call_from']=='line7911'){

//            echo ' searched for - '.$arg; echo ' || '; print_r($margs);
        }

        if($this->main_settings['use_pretty_links']!='on'){
            if($margs['type']=='page'){
                return $this->optional_url_base.'index.php?page=page&page_id='.$arg;
            }
        }



        if($arg){
            $args = array(
                'target_id'=>$arg,
                'type'=>$margs['type'],
                'call_from'=>'get_permalink()',
            );

//            echo 'permalinks_search - '; print_r($args);
            $link = $this->permalinks_search($args);

//            echo 'link - '.($link)."\n";

        };

//        echo 'found - '.$link;

//        echo $link;




        if($link==''){
            $sw_found = false;
        }else{
            if($margs['get_full_link']){

                if($this->optional_url_base){
                    if(strpos($link, $this->optional_url_base)===false){
                        $link = $this->optional_url_base.$link;
                    }
                }
            }
        }



        if($margs['only_from_table']){
            return $link;
        }




        if($margs['type']=='track'){
            $link = $this->optional_url_base.'index.php?page=track&track_id='.$arg;
            if($this->main_settings['use_pretty_links']=='on'){
                $link = $this->sanitize_for_pretty($arg);
//                echo ' link track -- '.$link.' ||| ';

            }
            if($margs['get_full_link']){
                if($this->url_base){
                    if(strpos($link, $this->url_base)===false){
                        $link = $this->url_base.$link;
                    }
                }
            }
        }
        if($margs['type']=='user'){

//            echo 'optional url base - '.$this->optional_url_base.' <-- ';
            $link = $this->optional_url_base.'index.php?page=user&user_id='.$arg;
            if($margs['page_type']){
                $link.='&page_type='.$margs['page_type'];
            }

//            echo '$this->main_settings[\'use_pretty_links\'] - '.($this->main_settings['use_pretty_links']=='on');
            if($this->main_settings['use_pretty_links']=='on'){
//                echo ' link user -- '.$link.' ||| ';
//                print_r($margs);
                $link = $this->sanitize_for_pretty($arg, $margs);
//                echo ' link user -- '.$link.' |||  '."\n\n";
                if($margs['get_full_link']){
                    if($this->optional_url_base){
                        if(strpos($link, $this->optional_url_base)===false){
                            $link = $this->optional_url_base.$link;
                        }
                    }
                }
            }
        }

        return $link;

    }

    public function mysql_try_to_create_user($email,$pass='defaultpassword', $pargs=array()) {

        $table_name = 'users';

        $query = "SELECT `id` FROM `".$table_name."` WHERE `email` = '".$email."'";

        $email_a = $email;

        if (filter_var($email_a, FILTER_VALIDATE_EMAIL)) {
//            echo "This ($email_a) email address is considered valid.\n";
        }else{

            die("error - ".__("email must be valid"));
        }




        $aux = $this->dblink->query($query);

        if($aux) {

            if ($aux->num_rows == 0) {

                $this->mysql_create_user($email_a,$pass);
            }else{

                die("error - ".__("email must be unique"));
            }
        }




    }

    function mysql_create_user($email,$pass, $pargs=array()) {


        $margs = array(

            'avatar'=>'',
            'username'=>'',
            'capabilities'=>'',
            'tags'=>'',
            'role'=>'user',
            'call_from'=>'default',
        );




        if($pargs){
            $margs = array_merge($margs,$pargs);
        }


        if($margs['role']!='user' && $margs['role']!='artist' && $margs['role']!='producer'){
            $margs['role'] = 'user';
        }

        $email = $this->dblink->real_escape_string(htmlentities($email));
        $margs['username'] = $this->dblink->real_escape_string(htmlentities($margs['username']));
        $margs['avatar'] = $this->dblink->real_escape_string(htmlentities($margs['avatar']));


        $pass = htmlentities($pass);

        $pass = md5($pass);
        $date = date("Y-m-d H:i:s");

        $query = "INSERT INTO users (email, password, date";


        if($margs['avatar']){

            $query.=',avatar';
        }
        if($margs['username']){

            $query.=',username';
        }
        if($margs['capabilities']){

            $query.=',capabilities';
        }
        if($margs['role']){

            $query.=',role';
        }
        if($margs['tags']){

            $query.=',tags';
        }
        if(isset($margs['location'])){

            $query.=',location';
        }
        if(isset($margs['country_code'])){

            $query.=',country_code';
        }


        if($this->main_settings['new_users_need_verification']=='on'){
            $query.=',verify_status';
        }

        $query.=") VALUES ('$email', '$pass', '$date'";

        if($margs['avatar']) {
            $query .= ",'" . $margs['avatar'] . "'";
        }

        if($margs['username']) {
            $query .= ",'" . $margs['username'] . "'";
        }
        if($margs['capabilities']) {
            $query .= ",'" . $margs['capabilities'] . "'";
        }
        if($margs['role']) {
            $query .= ",'" . $margs['role'] . "'";
        }
        if(isset($margs['tags']) && $margs['tags']) {
            $query .= ",'" . $margs['tags'] . "'";
        }
        if(isset($margs['location'])){

            $query .= ",'" . $margs['location'] . "'";
        }
        if(isset($margs['country_code'])){

            $query .= ",'" . $margs['country_code'] . "'";
        }
        if($this->main_settings['new_users_need_verification']=='on'){
            $query.=',\'unverified\'';
        }


        $query.=")";

//        echo $query;

        if ($this->dblink->query($query) === true) {



            $insert_id = mysqli_insert_id($this->dblink);
            if($this->main_settings['new_users_need_verification']!='on') {
                $this->currUserId = $insert_id;
            }else{


                $arr = array(
                    'notice_type' => 'emailconfirmation',
                    'notice_for' => 'content_section',
                    'notice_html' => '<div class="alert alert-danger">'.__("You need to confirm your email").'</div>',
                );

                array_push($this->notices_array, $arr);
            }


//            echo mysqli_insert_id($this->dblink);




            $this->permalinks_insert(array(

                'permalink'=>$this->sanitize_for_pretty($margs['username'], array(
                    'type'=>'user',
                    'get_full_link'=>false,
                )),
                'type'=>'user',
                'target_id'=>$this->currUserId,
                'table'=>'permalinks',
            ));



            $deta = array('id_user' => $insert_id);
            $dets = serialize($deta);

            $querya = "INSERT INTO `activity` (`id_user`, `type`, `details`, `date`) VALUES ('$this->currUserId', 'add_user', '$dets', '$date')";

            $this->dblink->query($querya);
//            return $this->currUserId;
            return true;
        } else {
            return mysqli_error($this->dblink);
        }
    }

    function validate_purchase($pargs=array(), $details=array()){

        $margs = array(
            'item_number'=>'',
        );

        if($pargs){
            $margs = array_merge($margs,$pargs);
        }


        $ids = array();

        $lab = 'item_number';
        if($margs[$lab]){
            $ids = explode(',',$margs[$lab]);
        }

//        print_r($ids);


        $user = $this->get_user($this->currUserId);

//        print_r($user);

//        echo $user['capabilities'].' ||| ';

//        error_log($user['capabilities']);


        $caps = unserialize($user['capabilities']);

//        print_r($caps);

        if($caps == false || is_array($caps)==false){

            $caps = array();
        }

        $purchases = unserialize($user['purchases']);

//        print_r($caps);

        if($purchases == false || is_array($purchases)==false){

            $purchases = array();
        }

//        print_r($caps);

        foreach($ids as $id){
//            echo $id;

            $price = 10;
            if($id==='proaccount'){



                if(in_array($id, $caps)==false){

                    array_push($caps, $id);


                }


            }
            if($id==='proaccount_90'){



                if(in_array($id, $caps)==false){

                    array_push($caps, 'proaccount');


                }


            }
            if($id==='proaccount_year'){



                if(in_array($id, $caps)==false){

                    array_push($caps, 'proaccount');


                }


            }


            if(is_int($id)) {

                $track = $this->get_track($id);

                $price = $track['price'];
            }


            if(in_array($id, $purchases)==false){
                array_push($purchases, $id);
            }

            $details = array_merge($details, array(
                'item_number'=>$id,
                'date'=>date("Y-m-d H:i:s"),
                'mc_gross'=>$price,
            ));


            $this->mysql_insert_activity(array(

                'id_user'=>$this->currUserId,
                'type'=>'purchase',
                'details'=>serialize($details),
            ));



            $to = $user['email'];

//                echo $feedback;
            $subject = $this->main_settings['site_title'].' - '.__("New Purchase");
            $message = '';

            $link = '#';

            if(is_int($id)){
                $link = $this->get_permalink($id, array(
                        'type'=>'track',
                        'get_full_link'=>true,
                ));
            }

            $feedback = __('track');
            if(strpos($id,'proaccount')!==false){
                $feedback = __('Pro account');
            }

            $message.= '';






            $message = $this->main_settings['mail_template_new_purchase'];
            $message = str_replace('{{thelink}}', $link, $message);
            $message = str_replace('{{thetrackname}}', $feedback, $message);



            $send = $this->portal_mail(array(

                'sender'=>$this->main_settings['mail_sender'],
                'target'=>$to,
                'message'=>$message,
                'subject'=>$subject,
            ));



        }

//        print_r($purchases);


        $this->mysql_update_user_settings('', array(
            'capabilities'=>serialize($caps),
            'purchases'=>serialize($purchases),
        ));
    }

    function mysql_insert_activity($pargs=array()){

        $margs = array(
            'id_user'=>'',
            'target_user_id'=>'0',
            'target_track_id'=>'0',
            'type'=>'',
            'details'=>'',
        );

        if($pargs){
            $margs = array_merge($margs,$pargs);
        }

        $date = date("Y-m-d H:i:s");

//            echo mysqli_insert_id($this->dblink);

        if($margs['id_user']==''){
            $margs['id_user']=$this->currUserId;
        }


        if($margs['id_user']){

            if($margs['type']=='repost'){
                $query = 'SELECT * FROM activity WHERE id_user=\''.$margs['id_user'].'\' AND target_track_id=\''.$margs['target_track_id'].'\' AND date > DATE_SUB(NOW(), INTERVAL 24 HOUR)';


                $auxcheck = $this->dblink->query($query);


                if($auxcheck){
                    if($auxcheck->num_rows>0){
                        return __("multiple reposts not allowed");
                    }
                }
            }


        }

        $querya = "INSERT INTO `activity` (`id_user`, `type`, `details`, `date`, `target_user_id`, `target_track_id`) VALUES ('$this->currUserId', '".$margs['type']."', '".$margs['details']."', '$date', '".$margs['target_user_id']."', '".$margs['target_track_id']."' )";

//        echo $querya;
        $aux = $this->dblink->query($querya);


        if($margs['type']=='like'){

        }


        if ($aux === true) {
            return $this->dblink->insert_id;
        } else {
            return mysqli_error($this->dblink). ' the query - '.$querya;
        }


    }


    function check_if_resposted($id_user, $target_track_id){
            $query = 'SELECT * FROM activity WHERE id_user=\''.$id_user.'\' AND target_track_id=\''.$target_track_id.'\' AND date > DATE_SUB(NOW(), INTERVAL 24 HOUR)';


            $auxcheck = $this->dblink->query($query);


            if($auxcheck){
//                print_r($auxcheck);
                if($auxcheck->num_rows){
                    $row2 = mysqli_fetch_assoc($auxcheck);
//                    echo 'hmm';
//                    print_r($row2);
                    return $row2['id'];
                }
            }
            return false;

    }

    function permalinks_overwrite($pargs=array()){

        // -- a check to see if the id already has a permalink to it must always be made before this function call

        $margs = array(
            'permalink'=>'',
            'type'=>'',
            'target_id'=>'', // -- this is what matters
            'table'=>'permalinks',
        );

        if($pargs){
            $margs = array_merge($margs,$pargs);
        }

        $date = date("Y-m-d H:i:s");

//        print_r($margs);

//            echo mysqli_insert_id($this->dblink);

        if(isset($margs['id_user']) == false || $margs['id_user']==''){
            $margs['id_user']=$this->currUserId;
        }

        $margs['permalink']=$this->sanitize_title_for_pretty($margs['permalink']);


        if($margs['permalink']=='upload' || $margs['permalink']=='admin'){
            $margs['permalink']=$margs['permalink'].'_page';
        }



        $query = "SELECT * FROM `".$margs['table']."`";
        $query .= " WHERE target_id='".$margs['target_id']."'";
        $query .= " AND type='".$margs['type']."'";

//        echo $query;

        $aux = $this->dblink->query($query);

        if ($aux && $aux->num_rows > 0) {

//            $row = mysqli_fetch_assoc($aux);


//            print_r($row);


//            $query3 = "UPDATE users SET connections='".serialize($auxa)."' WHERE id='$id_user'";


            $query = "SELECT * FROM `".$margs['table']."`";
            $query .= " WHERE permalink='".$margs['permalink']."'";


            $aux2 = $this->dblink->query($query);

            if ($aux2 && $aux2->num_rows > 0) {


                preg_match("/--(\d+)$/", $margs['permalink'], $output_array);


                if(is_array($output_array) && count($output_array)){


                    $nr = intval($output_array[1]);

                    $nr++;

                    $margs['permalink'] = $margs['permalink'].'--'.$nr;

                    return $this->permalinks_overwrite($margs);

                }else{
                    $margs['permalink'] = $margs['permalink'].'--2';

                    return $this->permalinks_overwrite($margs);
                }


            }else{

                $q3 = 'UPDATE permalinks
SET permalink=\''.$margs['permalink'].'\'';

                $q3 .= " WHERE target_id='".$margs['target_id']."'";
                $q3 .= " AND type='".$margs['type']."'";


                $aux3 = $this->dblink->query($q3);

                return $margs['permalink'];

                // -- this is good, if permalink does not exist



            }



//            echo 'hmm';

        }else{


            return $this->permalinks_insert($margs);
        }





    }

    function permalinks_insert($pargs=array()){

        // -- a check to see if the id already has a permalink to it must always be made before this function call

        $margs = array(
            'permalink'=>'',
            'type'=>'',
            'target_id'=>'',
            'table'=>'permalinks',
        );

        if($pargs){
            $margs = array_merge($margs,$pargs);
        }

        $date = date("Y-m-d H:i:s");

//        print_r($margs);

//            echo mysqli_insert_id($this->dblink);

        if($margs['id_user']==''){
            $margs['id_user']=$this->currUserId;
        }



        $query = "SELECT * FROM `".$margs['table']."`";
        $query .= " WHERE permalink='".$margs['permalink']."'";


        $aux = $this->dblink->query($query);

        if ($aux && $aux->num_rows > 0) {

            $row = mysqli_fetch_assoc($this->dblink);


//            print_r($row);


//            echo 'hmm';

        }else{

            if($margs['permalink']){

                if(strpos($margs['permalink'],'http://')===false && strpos($margs['permalink'],'https://')===false && strpos($margs['permalink'],'index.php')===false) {

                    $querya = "INSERT INTO `permalinks` (`permalink`, `type`, `target_id`) VALUES ('" . $margs['permalink'] . "', '" . $margs['type'] . "', '" . $margs['target_id'] . "')";

                    $aux = $this->dblink->query($querya);


                    if ($aux === true) {
                        return $margs['permalink'];
                    } else {
                        return mysqli_error($this->dblink);
                    }
                }
            }

        }





    }




    function get_user_total_uploaded($user_id){
        $aux = $this->get_tracks(array(
            'author_id'=>$user_id
        ));

        $size = 0;
        if(is_array($aux)){
            foreach($aux as $it){
                if(isset($it['filesize'])){
                    $size += intval($it['filesize']);
                }
            }
        }


        return $size;
    }

    function get_user_total_nr_uploaded($user_id){
        $aux = $this->get_tracks(array(
            'author_id'=>$user_id,
            'get_only_count'=>true,
        ));


        return $aux;
    }



    function get_user_connections($user_id){
        $user = $this->get_user($user_id);
        $caps = unserialize($user['connections']);


        if($caps == false || is_array($caps)==false){

            $caps = array();
        }

        return $caps;
    }



    function get_user_purchases($user_id){
        $user = $this->get_user($user_id);
        $caps = unserialize($user['purchases']);


        if($caps == false || is_array($caps)==false){

            $caps = array();
        }

        return $caps;
    }



    function get_user_capabilities($user_id, $pargs=array()){



        $margs = array(
                'get_only_extra'=>false, // -- get only the extra capabilities
        );

        $margs = array_merge($margs, $pargs);

        $user = $this->get_user($user_id);

        $caps = array();

        if($caps == false || is_array($caps)==false){

            $caps = array();
        }

        $role = '';
        if($margs['get_only_extra']==false && $user['role']){

            $role = $user['role'];

//            echo 'user role -  ( '.$user['role'].' ) - ';

//            print_r($this->user_roles[$user['role']]);

            if(isset($this->user_roles[$user['role']])){
                $caps = array_merge($caps, $this->user_roles[$user['role']]);
            }

            if($user['role']=='admin'){
                if(in_array('admin',$caps)==false){
                    array_push($caps, 'admin');
                }
            }
            if($user['role']=='pro'){
                if(in_array('proaccount',$caps)==false){
                    array_push($caps, 'proaccount');
                }
            }

        }
        $caps_indep = unserialize($user['capabilities']);

        if(is_array($caps_indep)){

            foreach ($caps_indep as $cp){

                if(in_array($cp,$caps)==false){
                    array_push($caps, $cp);
                }

            }
        }





        if($caps_indep){
            if(in_array('admin',$caps_indep) && $role==''){
                $this->mysql_update_user_settings(array(
                    'role'=>'admin'
                ));
            }
        }



        return $caps;
    }

    function sanitize_link($arg){


        $arg = filter_var($arg, FILTER_VALIDATE_URL, FILTER_FLAG_PATH_REQUIRED);

        return $arg;
    }

    function mysql_submit_track($pargs) {


        $margs = array(
            'title'=>'',
            'source'=>'',
            'description'=>'',
            'waveform_bg'=>'',
            'waveform_prog'=>'',
            'backup_ogg'=>'',
            'thumbnail'=>'',
            'cover_image'=>'',
            'is_buyable'=>'',
            'tags'=>'',
            'type'=>'track',
            'price'=>'',
            'sample_time_start'=>'0',
            'sample_time_end'=>'0',
            'sample_time_total'=>'0',
            'filesize'=>'1000000',
            'download_link'=>'',
            'extra_html'=>'',
            'itunes_link'=>'',
        );

        if($pargs){
            $margs = array_merge($margs,$pargs);
        }

        foreach($margs as $lab=>$ar){
            if($lab==='title' || $lab==='source' || $lab==='description' || $lab==='waveform_bg' || $lab==='waveform_prog' || $lab==='thumbnail' || $lab==='price' || $lab==='sample_time_start' || $lab==='sample_time_end' || $lab==='sample_time_total' || $lab==='filesize'  ){
                continue;
            }
            $margs[$lab] = $this->dblink->real_escape_string($ar);
        }




        $margs['title'] = $this->dblink->real_escape_string(htmlentities($margs['title']));
        $margs['source'] = $this->dblink->real_escape_string(htmlentities($margs['source']));
        $margs['description'] = $this->dblink->real_escape_string($margs['description']);
        $margs['waveform_bg'] = $this->dblink->real_escape_string(htmlentities($margs['waveform_bg']));
        $margs['waveform_prog'] = $this->dblink->real_escape_string(htmlentities($margs['waveform_prog']));
        $margs['thumbnail'] = $this->dblink->real_escape_string(htmlentities($margs['thumbnail']));
        $margs['price'] = $this->dblink->real_escape_string($margs['price']);
        $margs['sample_time_start'] = $this->dblink->real_escape_string(htmlentities($margs['sample_time_start']));
        $margs['sample_time_end'] = $this->dblink->real_escape_string(htmlentities($margs['sample_time_end']));
        $margs['sample_time_total'] = $this->dblink->real_escape_string(htmlentities($margs['sample_time_total']));
        $margs['filesize'] = $this->dblink->real_escape_string(htmlentities($margs['filesize']));
        $margs['extra_html'] = $this->dblink->real_escape_string(($margs['extra_html']));


        if($margs['itunes_link']){
            $margs['extra_html'].='<a href="'.$this->sanitize_link($margs['itunes_link']).'" class="skin-simple itunes-link"><i class="fa-apple fa"></i> iTunes</a>';
        }

//        print_r($this);
        $published_date = date("Y-m-d H:i:s");
        $date = date("Y-m-d H:i:s");
//        $date = date("Y-m-d H:i:s");

        if($margs['type']=='album_part'){
            error_log("trying to upload album_part / source - ".print_rr($margs['source'], array('echo'=>false)) );
        }

        $margs['published_date'] = $published_date;

        $query = "INSERT INTO `tracks` (`title`, `content`, `author_id`, `published_date`, `description`, `waveform_bg`, `waveform_prog`,`backup_ogg`,`thumbnail`,`cover_image`,`is_buyable`,`tags`,`price`,`sample_time_start`,`sample_time_end`,`sample_time_total`,`filesize`,`download_link`,`type`,`extra_html`) VALUES ('".$margs['title']."', '".$margs['source']."','".$this->currUserId."', '".$date."', '".$margs['description']."', '".$margs['waveform_bg']."', '".$margs['waveform_prog']."','".$margs['backup_ogg']."', '".$margs['thumbnail']."', '".$margs['cover_image']."', '".$margs['is_buyable']."', '".$margs['tags']."', '".$margs['price']."', '".$margs['sample_time_start']."', '".$margs['sample_time_end']."', '".$margs['sample_time_total']."', '".$margs['filesize']."', '".$margs['download_link']."', '".$margs['type']."', '".$margs['extra_html']."')";

//        echo $query;


        if ($this->dblink->query($query) === true) {

            $trackid = mysqli_insert_id($this->dblink);

            $deta = array(
                'type'=>$margs['type'],
            );
            $dets = serialize($deta);

            $querya = "INSERT INTO `activity` (`id_user`, `type`, `details`, `date`, `target_track_id`) VALUES ('$this->currUserId', 'add_track', '$dets', '$date', '$trackid')";

            $this->dblink->query($querya);

            return intval($trackid);
        } else {
            return mysqli_error($this->dblink);
        }
    }




    function mysql_add_message($id_user, $id_receiver, $message=""){

        $date = date("Y-m-d H:i:s");

        $message = htmlentities($message);

        $message = $this->dblink->real_escape_string($message);

        $query = "INSERT INTO `messages` (`author_id`, `id_receiver`, published_date, content,read_status) VALUES ('$id_user', '$id_receiver', '$date', '$message', 'unread')";

//        echo $query;


        if ($this->dblink->query($query) === true) {




            $query2 = "SELECT connections FROM `users`";


            $query2.=" WHERE id='".$id_user."'";


            $aux_link  = $this->dblink->query($query2);


            if ($aux_link) {

                while($row = mysqli_fetch_assoc($aux_link)){


                    $auxa = array();

                    $auxa = unserialize($row['connections']);


//                    print_r($auxa);

                    if($auxa==false){
                        $auxa = array();
                    }

                    if(!isset($auxa[$id_receiver])){
                        $auxa[$id_receiver] = 'messaged';
                    }



                    $query3 = "UPDATE users SET connections='".serialize($auxa)."' WHERE id='$id_user'";


//                    echo $query3;

                    $aux_link3  = $this->dblink->query($query3);


                    if ($aux_link3) {




                        $query4 = "SELECT connections FROM `users`";


                        $query4.=" WHERE id='".$id_receiver."'";


                        $aux_link4  = $this->dblink->query($query4);


                        if ($aux_link4) {

                            while($row = mysqli_fetch_assoc($aux_link4)){


                                $auxa = array();

                                $auxa = unserialize($row['connections']);


//                    print_r($auxa);

                                if($auxa==false){
                                    $auxa = array();
                                }

                                if(!isset($auxa[$id_user])){
                                    $auxa[$id_user] = 'messaged';
                                }



                                $query5 = "UPDATE users SET connections='".serialize($auxa)."' WHERE id='$id_receiver'";



                                $aux_link5  = $this->dblink->query($query5);


                                if ($aux_link5) {


                                }




                            }


                        }

                    }




                }


            }


            return true;
        } else {
            return mysqli_error($this->dblink);
        }
    }
    function mysql_update_user_settings($id='',$pargs = array()){



        $margs = array(

            'username' => '',
            'password' => '',
            'new_password' => '',
            'confirm_password' => '',
            'action' => '',
            'capabilities' => '',
            'purchases' => '',
            'location' => '',
            'stream_read' => '',

            'table' => 'users',
        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        }

//        print_r($margs);

        foreach($margs as $lab=>$val){

            if($lab!='new_password' && $lab!='avatar' && $lab!='capabilities' && $lab!='purchases' && $lab!='description'){

                $val = htmlentities($val);
            }
            $margs[$lab] = $this->dblink->real_escape_string($val);
        }


        $query = "UPDATE ".$margs['table']." SET ";


        $i5 = 0;
        if($margs['username']){
            if($i5){
                $query.=',';
            }
            $query.="username='".$margs['username']."'";

            $i5++;
        }
        if($margs['location']){
            if($i5){
                $query.=',';
            }
            $query.="location='".$margs['location']."'";

            $i5++;
        }
        if($margs['new_password']){
            if($i5){
                $query.=',';
            }
            $query.="password='".MD5($margs['new_password'])."'";

            $i5++;
        }

        $lab = 'role';
        if(isset($margs[$lab])){
            if($i5){
                $query.=',';
            }
            $query.=$lab."='".$margs[$lab]."'";

            $i5++;
        }

        $lab = 'second_avatar';
        if(isset($margs[$lab])){
            if($i5){
                $query.=',';
            }
            $query.=$lab."='".$margs[$lab]."'";

            $i5++;
        }
        $lab = 'paypal_email';
        if(isset($margs[$lab])){
            if($i5){
                $query.=',';
            }
            $query.=$lab."='".$margs[$lab]."'";

            $i5++;
        }

        $lab = 'facebook_link';
        if(isset($margs[$lab])){
            if($i5){
                $query.=',';
            }
            $query.=$lab."='".$margs[$lab]."'";

            $i5++;
        }

        $lab = 'twitter_link';
        if(isset($margs[$lab])){
            if($i5){
                $query.=',';
            }
            $query.=$lab."='".$margs[$lab]."'";

            $i5++;
        }
        $lab = 'soundcloud_link';
        if(isset($margs[$lab])){
            if($i5){
                $query.=',';
            }
            $query.=$lab."='".$margs[$lab]."'";

            $i5++;
        }
        $lab = 'avatar';
        if(isset($margs[$lab])){
            if($i5){
                $query.=',';
            }
            $query.=$lab."='".$margs[$lab]."'";

            $i5++;
        }
        $lab = 'second_avatar';
        if(isset($margs[$lab])){
            if($i5){
                $query.=',';
            }
            $query.=$lab."='".$margs[$lab]."'";

            $i5++;
        }
        $lab = 'capabilities';
        if($margs[$lab]){
            if($i5){
                $query.=',';
            }
            $query.=$lab."='".$margs[$lab]."'";

            $i5++;
        }
        $lab = 'purchases';
        if($margs[$lab]){
            if($i5){
                $query.=',';
            }
            $query.=$lab."='".$margs[$lab]."'";

            $i5++;
        }
        $lab = 'description';
        if(isset($margs[$lab])){
            if($i5){
                $query.=',';
            }
            $query.=$lab."='".$margs[$lab]."'";

            $i5++;
        }
        $lab = 'stream_read';
        if($margs[$lab]){
            if($i5){
                $query.=',';
            }
            $query.=$lab."='".$margs[$lab]."'";

            $i5++;
        }
        $lab = 'tags';
        if(isset($margs[$lab])){
            if($i5){
                $query.=',';
            }
            $query.=$lab."='".$margs[$lab]."'";

            $i5++;
        }
        $lab = 'country_code';
        if(isset($margs[$lab])){
            if($i5){
                $query.=',';
            }
            $query.=$lab."='".$margs[$lab]."'";

            $i5++;
        }

        if($id==''){
            $id = $this->currUserId;
        }

        $query.=" WHERE id='$id'";


//        echo  'query - '.$query;




        if ($this->dblink->query($query) === true) {






            return true;
        } else {
            return mysqli_error($this->dblink);
        }
    }
    function mysql_update_track_settings($pargs = array()){



        $margs = array(

            'track_id' => '',
            'title' => '',
            'thumbnail' => '',
            'tags' => '',
            'cover_image' => '',
            'table' => 'tracks',
        );

        if($pargs){
            $margs = array_merge($margs, $pargs);
        }


//        print_r($margs);

        foreach($margs as $lab=>$val){

            if($lab==='track_id'||$lab==='table'){
                continue;
            }
            $margs[$lab] = $this->dblink->real_escape_string($val);
        }


        $query = "UPDATE ".$margs['table']." SET ";


        $i5 = 0;



        foreach($margs as $lab=>$val){

            if($lab==='track_id'||$lab==='table'){
                continue;
            }

            if($i5){
                $query.=',';
            }
            $query.="$lab='".$val."'";

            $i5++;
        }




        $query.=" WHERE id='".$margs['track_id']."'";


//        echo $query;




        if ($this->dblink->query($query) === true) {






            return true;
        } else {
            return mysqli_error($this->dblink);
        }
    }


    function mysql_check_if_user_followed($target_user_id=''){




        if(!$target_user_id){
//            echo "error - ".__("no target user id");
            return "";
        }


        $query = "SELECT connections FROM `users` WHERE `id`='$this->currUserId'";




        $aux = $this->dblink->query($query);

//        echo $query;
        if ($aux) {
//            print_r($aux);

            $row = mysqli_fetch_assoc($aux);

//            print_r($row);

            if($row && isset($row['connections'])){

                $conns = unserialize($row['connections']);

                if(is_array($conns)==false){
                    $conns=array();
                }

                if(isset($conns[$target_user_id])){

                    if($conns[$target_user_id]=='followed'){



                        return true;


                    }else{
                        return false;
                    }
                }else{


                    return false;
                }

//                return $row['avatar'];
            }else{

                return false;
            }


        } else {
            return mysqli_error($this->dblink);
        }
//        echo $query;






    }


    function mysql_follow_user($target_user_id=''){




        if(!$target_user_id){
            return "error - no target user id";
        }


        $query = "SELECT connections FROM `users` WHERE `id`='$this->currUserId'";




        $aux = $this->dblink->query($query);

//        echo $query;
//        echo $query;
        if ($aux) {
//            print_r($aux);

            $row = mysqli_fetch_assoc($aux);

//            print_r($row);

            if($row){

//                echo 'yesss';

                $conns = unserialize($row['connections']);

                if(is_array($conns)==false){
                    $conns=array();
                }

//                print_r($conns);

                if(isset($conns[$target_user_id])){

                    if($conns[$target_user_id]=='messaged'){
                        $conns[$target_user_id] = 'followed';



                        $query5 = "UPDATE users SET connections='".serialize($conns)."' WHERE id='".$this->currUserId."'";



                        $aux_link5  = $this->dblink->query($query5);


                        if ($aux_link5) {

                            return true;

                        }
                    }
                    if($conns[$target_user_id]=='blocked'){

                        echo 'error - '.__('you blocked this user');
                    }
                    return "";
                }else{
                    $conns[$target_user_id] = 'followed';

                    $query5 = "UPDATE users SET connections='".serialize($conns)."' WHERE id='".$this->currUserId."'";



                    $aux_link5  = $this->dblink->query($query5);


                    if ($aux_link5) {

                        echo json_encode(array(
                            'type'=>'user_followed',
                            'report'=>'success',
                            'text'=>__('success - ').__('user followed'),
                        ));

                    }else{

                        echo json_encode(array(
                            'type'=>'user_followed',
                            'report'=>'error',
                            'text'=>__('error - ').print_rr(mysqli_error($this->dblink), array('echo'=>'false')),
                        ));
                    }


                    return true;
                }

//                return $row['avatar'];
            }else{

                return '';
            }


        } else {
            return mysqli_error($this->dblink);
        }
//        echo $query;






    }
    function mysql_unfollow_user($target_user_id=''){




        if(!$target_user_id){
            return "error - no target user id";
        }


        $query = "SELECT connections FROM `users` WHERE `id`='$this->currUserId'";




        $aux = $this->dblink->query($query);

//        echo $query;
        if ($aux) {
//            print_r($aux);

            $row = mysqli_fetch_assoc($aux);

//            print_r($row);

            if($row && isset($row['connections'])){

                $conns = unserialize($row['connections']);

                if(is_array($conns)==false){
                    $conns=array();
                }

                if(isset($conns[$target_user_id])){

                    if($conns[$target_user_id]=='followed'){
                        unset($conns[$target_user_id]);




                        $query5 = "UPDATE users SET connections='".serialize($conns)."' WHERE id='".$this->currUserId."'";



                        $aux_link5  = $this->dblink->query($query5);

                        if ($aux_link5) {

                            echo json_encode(array(
                                'type'=>'user_unfollowed',
                                'report'=>'success',
                                'text'=>__('success - ').__('user unfollowed'),
                            ));

                        }else{

                            echo json_encode(array(
                                'type'=>'user_unfollowed',
                                'report'=>'error',
                                'text'=>__('error - ').print_rr(mysqli_error($this->dblink), array('echo'=>'false')),
                            ));
                        }
                    }
                    if($conns[$target_user_id]=='blocked'){

                        echo json_encode(array(
                            'type'=>'user_unfollowed',
                            'report'=>'error',
                            'text'=>__('error - ').__("you blocked this user"),
                        ));
                    }else{

                    }
                    return "";
                }else{


                    return true;
                }

//                return $row['avatar'];
            }else{

                return '';
            }


        } else {
            return mysqli_error($this->dblink);
        }
//        echo $query;






    }


    function mysql_add_playlist($id_user, $title, $description=""){

        $date = date("Y-m-d H:i:s");

        $title = htmlentities($title);

        $query = "INSERT INTO `playlists` (`author_id`, `title`, published_date, description) VALUES ('$id_user', '$title', '$date', '$description')";

//        echo $query;


        if ($this->dblink->query($query) === true) {


            return true;
        } else {
            return mysqli_error($this->dblink);
        }
    }
    function mysql_remove_playlist($id){


        $query = "DELETE FROM playlists WHERE id = '$id'";

//        echo $query;


        if ($this->dblink->query($query) === true) {


            return true;
        } else {
            return mysqli_error($this->dblink);
        }
    }


    function get_shortcode_atts($arg){

//        echo '
//
//---- shortcode atts arg ----
//'.$arg.'
//---- shortcode atts end arg ---
//
//        ';

        $fout_array = array();


        // -tbc ? (?<!\\)

//        $re = "/(\w*?)=\"(.*?)\"/sm";
        $re = "/(\w*?)=\"(.*?)(?<!\\\\)\"/sm";

        $matches = array();

        preg_match_all($re, $arg, $matches);
//        preg_match_all("/(\w*?)=\"(.*?)(?<!\\)\"/sm", $arg, $matches);
//        preg_match_all("/(\w*?)=\"(.*?)(?<!\\)(\")/sm", $arg, $matches);

        if(isset($matches) && isset($matches[2]) && isset($matches[2][0]) && $matches[2][0]){

            $matches[2][0] = str_replace('"{replacequotquot}', '"', $matches[2][0]);
            $matches[2][0] = str_replace('{replacequotquot}"', '"', $matches[2][0]);
            $matches[2][0] = str_replace('{replacequotquot}', '"', $matches[2][0]);
        }
//        print_r($matches);

        if(isset($matches[0])){
            $i=0;

            for($i=0;$i<count($matches[0]);$i++){

                $fout_array[$matches[1][$i]] = $matches[2][$i];
            }
        }



        return $fout_array;


        ;
    }

    function do_shortcode($arg){

        global $dzspgb_shortcodes;

        $re = "/\[(\w*)(.*?)]/sm";
        $str = $arg;

//        $str = str_replace('"{replacequotquot}','{replacequotquot}', $str);
//        $str = str_replace('{replacequotquot}"','{replacequotquot}', $str);

        preg_match_all($re, $str, $matches);

        $i=0;


        $this->functional_do_shortcode_call_index++;

        if($this->functional_do_shortcode_call_index>150){
//            return '';
            return $arg;
        }

        if($this->main_settings['debug_pagebuilder']=='on') {

            echo '

---- arg do_shortcode_call '.$this->functional_do_shortcode_call_index.'----
' . $arg . '
---- end arg ---

        ';


            if (function_exists('memory_get_usage')){
                $result = memory_get_usage() / 1024;
                echo 'Memory usage: '.intval($result).'MB ... ';
            }
        }

        if(strpos($arg,'fb-xfbml-parse-ignore')!==false){
            if(function_exists("enqueue_script")){
                enqueue_script('fb_load', 'js/load_fb.js');
            }
        }
//        echo $arg;


//        print_r($matches);
        for($i=0;$i<count($matches[0]);$i++){

            if($matches[1][$i]==='' || !isset($dzspgb_shortcodes[$matches[1][$i]])){
                continue;
            }



            $matches2 = array();
            $aux = $matches[1][$i];
            $re2 = "/\[".$aux."(.*?)](.*?)\[\/".$aux."\](?!\s*\[\/)/sm";
            $re2_planb = "/\[".$aux."(.*?)](.*?)\[\/".$aux."\]/sm";
//            $re2 = "/\[".$aux."(.*?)](.*)\[\/".$aux."\]/m";


            if($this->main_settings['debug_pagebuilder']=='on') {
                echo '-- regexp---- ' . $re2 . ' ----';
//            echo '-- thestring---- '.$str.' ----'."\n\n";
//            echo '-- regexp planb---- '.$re2_planb.' ----';
            }

            preg_match_all($re2, $str, $matches2);

//            print_r($matches2);




//            print_r($dzspgb_shortcodes[$matches[1][$i]]['str_function']);

//            echo ' || ceva2 || '.$dzspgb_shortcodes[$matches[1][$i]]['str_function'].' || ENDceva2 || ';

//            print_r($dzspgb_shortcodes);

            if($this->main_settings['debug_pagebuilder']=='on') {
                echo 'matchers i: ' . $i . ' - -> ' . $matches[1][$i] . function_exists($dzspgb_shortcodes[$matches[1][$i]]['str_function']) . ' ';
                print_r($matches);
                echo ' matches after -> ';
                print_r($matches2);
            }
            
            
            if(function_exists($dzspgb_shortcodes[$matches[1][$i]]['str_function'])){

                if(isset($matches2[2]) && isset($matches2[2][0])){

                }else{


                    preg_match_all($re2_planb, $str, $matches2);


//                    echo 'matches2 wrong but replaced'; print_r($matches2);

                }

                if($this->main_settings['debug_pagebuilder']=='on') {
                    echo 'test - ' . (isset($matches2[2]) && isset($matches2[2][0])) . ' ' . $dzspgb_shortcodes[$matches[1][$i]]['str_function'];
                }

                if(isset($matches2[2]) && isset($matches2[2][0])){


                    if($this->main_settings['debug_pagebuilder']=='on'){

                        echo ' here is the parsed shortcode - '.$matches2[2][0]. ' matches[2]['.$i.'] -> ';
                        print_r($matches[2][$i]);

                        echo "\n the func to apply - ".$dzspgb_shortcodes[$matches[1][$i]]['str_function']."\n";
                    }


                    $matches2[2][0] = str_replace('"{replacequotquot}','{replacequotquot}', $matches2[2][0]);
                    $matches2[2][0] = str_replace('{replacequotquot}"','{replacequotquot}', $matches2[2][0]);

                    $aux = call_user_func($dzspgb_shortcodes[$matches[1][$i]]['str_function'],$this->get_shortcode_atts($matches[2][$i]),$matches2[2][0]);

                    if($this->main_settings['debug_pagebuilder']=='on') {
                        echo ' --- aux : ' . $aux . ' endaux --';
                    }

                    $arg = str_replace($matches2[0][0], $aux,$arg);

                    $arg = $this->do_shortcode($arg);



                }else{


                    if($this->main_settings['debug_pagebuilder']=='on') {
                        echo 'matches2 wrong';
                        print_r($matches2);
                    }


//                    echo '---- '.$re2.' ----';

                    error_log("matches2 wrong.. - ".$arg);
                }
            }


            break;



        }

        unset($matches);
        unset($matches2);

        return $arg;


//        print_r($dzspgb_shortcodes);
//        print_r($matches);
    }



    /* backup the db OR just a table */
    function backup_tables($tables = '*'){

        $sec_str = time();

        if(isset($_GET['backupdb_name']) && $_GET['backupdb_name']){
            $sec_str = $_GET['backupdb_name'];
        }


        //get all of the tables
        if($tables == '*'){


            $tables = array();


            $query = "SHOW TABLES";
            $aux = $this->dblink->query($query);
            if ($aux) {

                while($row = mysqli_fetch_row($aux)) {
//                    $tables[] = $row[0];

                    array_push($tables, $row[0]);
                }
            }else{

            }


        }
        else{
            $tables = is_array($tables) ? $tables : explode(',',$tables);
        }

//        print_r($tables);

        //cycle through
//        foreach($tables as $table){
//            $tableName  = $table;
//            $backupFile = $this->path_base.'/backup/'.$table.'-'.$sec_str.'.sql';
//            $query      = "SELECT * INTO OUTFILE '$backupFile' FROM $tableName";
//
////            echo $query;
//            $result = $this->dblink->query($query);
//
//
//            if ($result) {
//
//
//            }else{
//
//                if(mysqli_errno($this->dblink)=='1045'){
//                    break;
//                }
//
//
////                echo mysqli_error($this->dblink) . ' - '.mysqli_errno($this->dblink);
//            }
//        }



//        $dbhost = 'localhost';
//        $dbuser = 'root';
//        $dbpass = 'root';
//        $dbname = 'wavecloud';
//
//        $backup_file = $dbname . date("Y-m-d-H-i-s") . '.gz';
//        $command = "mysqldump --opt -h $dbhost -u $dbuser -p $dbpass ". "$dbname | gzip > $backup_file";
//
//        system($command);




        //get all of the tables
        $return = '';
        if($tables == '*'){
            $tables = array();
            $result = $this->dblink->query('SHOW TABLES');
            while($row = mysqli_fetch_row($result))
            {
                $tables[] = $row[0];
            }
        }
        else{
            $tables = is_array($tables) ? $tables : explode(',',$tables);
        }

        //cycle through
        foreach($tables as $table){
            $result = $this->dblink->query('SELECT * FROM '.$table);
            $num_fields = mysqli_num_fields($result);

            $return.= 'DROP TABLE IF EXISTS '.$table.';';
            $row2 = mysqli_fetch_row($this->dblink->query('SHOW CREATE TABLE '.$table));
            $return.= "\n\n".$row2[1].";\n\n";

            for ($i = 0; $i < $num_fields; $i++)
            {
                while($row = mysqli_fetch_row($result))
                {
                    $return.= 'INSERT INTO '.$table.' VALUES(';
                    for($j=0; $j < $num_fields; $j++)
                    {
                        $row[$j] = addslashes($row[$j]);
//                        $row[$j] = preg_replace("\n","\\n",$row[$j]);
                        if (isset($row[$j])) { $return.= '"'.$row[$j].'"' ; } else { $return.= '""'; }
                        if ($j < ($num_fields-1)) { $return.= ','; }
                    }
                    $return.= ");\n";
                }
            }
            $return.="\n\n\n";
        }



        //save file
        $handle = fopen('backup/db-backup-'.$sec_str.'.sql','w+');
        fwrite($handle,$return);
        fclose($handle);


        echo 'success - '.__("Backups saved in backup/ folder");





//        //save file
//        $handle = fopen('db-backup-'.time().'-'.(md5(implode(',',$tables))).'.sql','w+');
//        fwrite($handle,$return);
//        fclose($handle);
    }
    function backup_db($tables = '*'){
        // -- @backup the whole db


    }

}


if(function_exists('dzsap_load_plugins')==false){
    function dzsap_load_plugins(){

        global $dzsap_portal;
        foreach ($dzsap_portal->main_settings['active_plugins'] as $val){
//            print_r($hmm);

            if(file_exists($val)){
                include_once($val);
            }else{


                foreach ($dzsap_portal->main_settings['active_plugins'] as $lab2=> $val2){

                    if($val2 == $val){
                        unset($dzsap_portal->main_settings['active_plugins'][$lab2]);
                    }
                }

                error_log("plugin main does not exist..");
                $dzsap_portal->mysql_update_main_settings($dzsap_portal->main_settings);
            }

//            try{
//

//            }catch (Exception $e){
//
//
//                print_r($e);
//
//
//
//            }
        }
    }
}
//print_r($_POST);

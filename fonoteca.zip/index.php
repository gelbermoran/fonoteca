<?php
if(!session_id()) {
    @ini_set('sql_mode','NO_ENGINE_SUBSTITUTION');
//    @ini_set('session.save_path',dirname(__FILE__). '/tmp');
    session_start();
}

//echo 'ceva';

date_default_timezone_set('America/Los_Angeles');
ini_set("log_errors", 1);
ini_set('display_errors', '0');
error_reporting(E_ALL);
ini_set("error_log", "soundportal.log");

define('FACEBOOK_SDK_V4_SRC_DIR', dirname(__FILE__).'/sdk/Facebook/');


    if(isset($_GET['debug_display_errors']) && $_GET['debug_display_errors']=='on'){

        ini_set('display_errors', 1);
    }


include_once(dirname(__FILE__).'/dzs_functions.php');
include_once(dirname(__FILE__).'/class-portal.php');



//ini_set("display_startup_errors", 1);
//ini_set("display_errors", 1);

/* Reports for either E_ERROR | E_WARNING | E_NOTICE  | Any Error*/
//error_reporting(E_ERROR);

//    echo abc;


//


$lang = 'en_EN';
    $charset = 'utf-8';
    $lang_index = 0;
if (isset($_GET['lang'])){
    $lang = $_GET['lang'];

    setcookie('dzsapp_lang',$lang, time()+3600);
}else{


    if(isset($_COOKIE['dzsapp_lang']) && $_COOKIE['dzsapp_lang']){

        $lang = $_COOKIE['dzsapp_lang'];
    }
}

    if($lang=='pt_PT'){
        $charset = 'iso-8859-1';
    }




putenv("LANG=$lang");
setlocale(LC_ALL, $lang);
if(function_exists("bindtextdomain")){
    bindtextdomain("wavecloud", "./locale/");
}

if(function_exists("textdomain")) {
    textdomain("wavecloud");
}

//    echo $lang;
$dzsap_portal = new DZSAP_Portal();

$meta_title = $dzsap_portal->main_settings['site_title'];
$meta_desc = '';
$meta_image = '';


dzsap_load_plugins();
$dzsap_portal->check_post();




if($lang!='en_EN'){
    for($i6 = 1; $i6<7; $i6++){

        $aux = $dzsap_portal->main_settings['lang_'.$i6.'_code'];
        if($aux==$lang){
            $lang_index = $i6;
            break;
        }
        }
}

$str_html_dir='';
$str_html_lang='';
if($lang_index){

    $aux = $dzsap_portal->main_settings['lang_'.$lang_index.'_is_rtl'];


    if($aux == 'on'){

        $str_html_dir = ' dir="rtl"';

    }

    $auxarr = explode('_', $lang);

    $str_html_lang = ' lang="'.$auxarr[0].'"';


}


if(isset($_GET['page']) && $_GET['page']){
    if($_GET['page']==='download'){

//            echo 'ceva';

        $track = $dzsap_portal->get_track($_GET['track_id']);


        $allowed = false;

//        error_log("HMM track_price - ".$track['price']);

        if($track['price']==0 && $dzsap_portal->main_settings['allow_only_logged_in_users_to_download_free_tracks']=='on'){

//            error_log("HMM");
            if($dzsap_portal->currUserId){

                $caps = $dzsap_portal->get_user_capabilities($dzsap_portal->currUserId);

//                error_log(print_rr($caps, array('echo'=>false)));

                if(in_array('download_free_track', $caps)){
                    $allowed = true;
                }else{

                    die(__("you don't have permission to download"));
                }

            }else{
                die(__("you need to be logged in to download"));
            }
        }


        if($dzsap_portal->currUserId>0 ||  ( $track['price']==0 && $dzsap_portal->main_settings['allow_only_logged_in_users_to_download_free_tracks']!='on') ){
            $purcs = $dzsap_portal->get_user_purchases($dzsap_portal->currUserId);


            $stat_type = 'download';


            if(in_array($_GET['track_id'], $purcs) || $track['price']==0){


                if($track['download_link_new_tab']=='on'){

                    $aux_loc = $track['content'];


//                print_r($track);

                    if($track['download_link']){
                        $aux_loc = $track['download_link'];
                    }

                    header('Location: '.$aux_loc);
//                header('Content-type: html/text');
//                }
                }else{



                    if(isset($track['type']) && $track['type']=='album'){

//                        print_r($track);

//                        $arr3 = unserialize($dzsap_portal->get_setting('cached_albums'));

                        $tracks = unserialize($track['content']);

                        $filename = dirname(__FILE__)."/upload/".$dzsap_portal->clean($track['title']);



                        if($dzsap_portal->main_settings['cache_album_download']!='on'){

                            $filename.=rand(0,1000);
                        }

                        $filename.=".zip";

                        if($dzsap_portal->main_settings['cache_album_download']=='on' && file_exists($filename)){

                        }else{
                            $zip = new ZipArchive();

                            if ($zip->open($filename, ZipArchive::CREATE)!==TRUE) {
                                exit("cannot open <$filename>\n");
                            }


                            foreach ($tracks as $trackid){

                                $tr = $dzsap_portal->get_track($trackid);

                                $aux_loc = $track['content'];



                                $content_path = $tr['content'];
                                $content = $tr['content'];




                                $content_path = str_replace($dzsap_portal->optional_url_base,'', $content);
                                $content_path = str_replace('&amp;','&', $content_path);
                                $content = str_replace('upload/','', $content);
                                $content = str_replace('http/','', $content);

                                error_log('content_path - '.$content_path.' content - '.$content_path);


//                            $zip->addFile($content_path,$content);
                                $zip->addFile($content_path,basename($content));


                            }
                            $zip->renameName('http','ceva');


                            $zip->close();
                        }




                        header("Pragma: public");
                        header("Expires: 0");
                        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
                        header("Cache-Control: public");
                        header("Content-Description: File Transfer");
                        header("Content-type: application/octet-stream");
                        header("Content-Disposition: attachment; filename=\"".$track['title'].".zip\"");
                        header("Content-Transfer-Encoding: binary");
                        header("Content-Length: ".filesize($filename));


                        echo  file_get_contents($filename);

                        $stat_type = 'download_album';

                    }else{

                        header('Content-type: audio/mp3');
//                header('Content-type: html/text');
//                    header('Content-length: ' . filesize($track));
                        header('Content-Disposition: attachment; filename="'.$track['title'].'.mp3"');
                        header('X-Pad: avoid browser bug');
                        header('Cache-Control: no-cache');

                        $aux_loc = $track['content'];


//                print_r($track);

                        if($track['download_link']){
                            $aux_loc = $track['download_link'];
                        }

                        $aux_loc = str_replace($dzsap_portal->url_base, '',$aux_loc);

//                echo $aux_loc;
                        if(strpos($aux_loc, 'https://soundcloud.com')===false){

                            echo  file_get_contents($aux_loc);
                        }



                        $stat_type = 'download_track';

                    }



                    $date = date("Y-m-d H:i:s");
                    $currip = $dzsap_portal->misc_get_ip();
                    $track_id = $_GET['track_id'];

                    $query3 = "INSERT INTO `views` (`id_user`, `ip`, `track_id`, `date`, `type`) VALUES ('$dzsap_portal->currUserId', '$currip','$track_id','$date','$stat_type')";

//            echo $query3;

                    $result = $dzsap_portal->dblink->query($query3);
//                if(file_exists($aux_loc)){
//                }else{
//                    header('Location: '.$aux_loc);
//                }


                    die();
                }




            }
        }else{
            die(__("Only logged in users can download"));
        }

        die();
    }

}

$fb_loginUrl = null;
$helper = null;
$fb = null;
if($dzsap_portal->main_settings['api_facebook_app_id']){
    include_once(dirname(__FILE__).'/sdk/Facebook/autoload.php'); // -- facebook autoload
//include_once(dirname(__FILE__).'/sdk/Facebook/autoload.php');
//require_once( 'sdk/Facebook/FacebookSession.php' );
//echo FACEBOOK_SDK_V4_SRC_DIR;

//    print_r($dzsap_portal->currUserId);


    try{


        if (version_compare(PHP_VERSION, '5.4.0') >= 0) {
//            echo 'I am at least PHP version 5.4.0, my version: ' . PHP_VERSION . "\n";

            $fb = new Facebook\Facebook(array(
                'app_id' => $dzsap_portal->main_settings['api_facebook_app_id'],
                'app_secret' => $dzsap_portal->main_settings['api_facebook_app_secret'],
                'default_graph_version' => 'v2.2',
            ));


            if (isset($_SESSION['facebook_access_token']) && $_SESSION['facebook_access_token']) {

            }else{
                $helper = $fb->getRedirectLoginHelper();
            }
        }
    }catch(Exception $e){


    }

}


//    print_r($_SERVER);

$args = array(
    'get_page_url_too'=>false
);

//    echo dzs_curr_url($args);


//echo '<a href="' . $loginUrl . '">Log in with Facebook!</a>';


//    echo dzs_curr_url();



//$accessToken = '';
//$helper = $fb->getRedirectLoginHelper();
//try {
//    $accessToken = $helper->getAccessToken();
//} catch(Facebook\Exceptions\FacebookResponseException $e) {
//    // When Graph returns an error
//    echo 'Graph returned an error: ' . $e->getMessage();
//    exit;
//} catch(Facebook\Exceptions\FacebookSDKException $e) {
//    // When validation fails or other local issues
//    echo 'Facebook SDK returned an error: ' . $e->getMessage();
//    exit;
//}
//
//if (isset($accessToken)) {
//    // Logged in!
//    $_SESSION['facebook_access_token'] = (string) $accessToken;
//
//    // Now you can redirect to another page and use the
//    // access token from $_SESSION['facebook_access_token']
//}





//print_r($dzsap_portal);
$page = $dzsap_portal->currPage;
$page_type = '';
$query_user_id = '';;
$query_id = '';




if($dzsap_portal->main_settings['api_facebook_app_id']) {



    if (isset($_SESSION['facebook_access_token']) && $_SESSION['facebook_access_token']) {
        $me = null;
        $response = array();

//        echo 'go here';

        try {
            // Get the Facebook\GraphNodes\GraphUser object for the current user.
            // If you provided a 'default_access_token', the '{access-token}' is optional.
            $response = $fb->get('/me?fields=email,name', $_SESSION['facebook_access_token']);
            $me = $response->getGraphUser();

//            print_r($me);
        } catch (Facebook\Exceptions\FacebookResponseException $e) {
            // When Graph returns an error
            echo 'Graph returned an error: ' . $e->getMessage();
            exit;
        } catch (Facebook\Exceptions\FacebookSDKException $e) {
            // When validation fails or other local issues
            echo 'Facebook 137 SDK returned an error: ' . $e->getMessage();
            exit;
        }


//    echo 'Logged in '.$me->getEmail().' as ' . $me->getName();


        try {
            // Get the Facebook\GraphNodes\GraphUser object for the current user.
            // If you provided a 'default_access_token', the '{access-token}' is optional.
            $response = $fb->get('/me/picture', $_SESSION['facebook_access_token']);

            $avatar = '';



            $response_headers = $response->getHeaders();

            if ($response_headers && isset($response_headers['Location']) && $response_headers['Location']) {
                $avatar = $response_headers['Location'];
            }

//            print_r($me->getName());
//            print_r($me->getHeaders());


            $dzsap_portal->check_login_from_facebook($me->getEmail(), array(
                'avatar'=>$avatar,
                'username'=>$me->getName(),
            ));


        } catch (Facebook\Exceptions\FacebookResponseException $e) {
            // When Graph returns an error
            echo 'Graph returned an error: ' . $e->getMessage();
            exit;
        } catch (Facebook\Exceptions\FacebookSDKException $e) {
            // When validation fails or other local issues
            echo 'Facebook 174 SDK returned an error: ' . $e->getMessage();
            exit;
        }


//        print_r($response->getHeaders()['Location']);

//        print_r($me);


    }else{
        try {

            $permissions = array('email', 'user_about_me'); // optional
            if($helper){
                $fb_loginUrl = $helper->getLoginUrl($dzsap_portal->url_base . 'redirect-from-facebook.php', $permissions);
//                $fb_loginUrl = $helper->getLoginUrl(dzs_curr_url($args) . '', $permissions);

//                die(dzs_curr_url($args) . 'redirect-from-facebook.php');
//                die($_SESSION['FBRLH_' . 'state']);
            }


        } catch (Exception $e) {


        }
    }
}


//    print_r($_GET);

if(isset($_GET['action']) && $_GET['action'] === 'logout_facebook'){
    unset($_SESSION['facebook_access_token']);
}



$currpage_id = 1;
$homepage_id = $dzsap_portal->get_mainsetting('page_homepage');
$currpage_id = $homepage_id;

//    echo $dzsap_portal->currUserId . $dzsap_portal->main_settings['home_is_stream'];




$page = 'page';
$page_id=1;
//                print_r($auxa);

//echo 'ceva whattt';
//    echo DZSHelpers::get_query_arg(dzs_curr_url(), 'type');



//    print_r($_GET);

if($dzsap_portal->query1){
    if(is_array($_GET) == false){
        $_GET = array();
    }




    if(strpos($dzsap_portal->query1,'index.php')===false){



        $sw_found = false;


        $permalink_arr = $dzsap_portal->permalinks_search(array(

            'permalink_search'=>$dzsap_portal->query1,
            'return_array'=>true,
            'call_from'=>'mainpage',
        ));


//        echo count($permalink_arr);

        if(count($permalink_arr)){
            $_GET['page']=$permalink_arr['type'];

            if($_GET['page']=='page'){

                $_GET['page_id']=$permalink_arr['target_id'];
            }
            if($_GET['page']=='user'){

                $_GET['user_id']=$permalink_arr['target_id'];
            }

            $sw_found = true; // found permalink
        }

//        print_r($permalink_arr);



        if(!$sw_found){
            $auxarr = $dzsap_portal->get_pages();

            foreach ($auxarr as $lab => $val){
//            echo $dzsap_portal->sanitize_title_for_pretty($val['title']). ' ';

                if($dzsap_portal->sanitize_title_for_pretty($val['title']) == $dzsap_portal->query1){


//                echo 'hmmdada';

                    $dzsap_portal->permalinks_insert(array(

                        'permalink'=>$dzsap_portal->query1,
                        'type'=>'page',
                        'target_id'=>$val['id'],
                        'table'=>'permalinks',
                    ));

                    $sw_found = true;


                    $_GET['page']='page';


                    $_GET['page_id']=$val['id'];

                }

            }
            $auxarr = $dzsap_portal->get_users();

            foreach ($auxarr as $lab => $val){
//            echo $dzsap_portal->sanitize_title_for_pretty($val['title']). ' ';

//                print_r($val);
//
//                echo $dzsap_portal->sanitize_title_for_pretty($val['username']). ' - '.$dzsap_portal->query1;

                if($dzsap_portal->sanitize_title_for_pretty($val['username']) == $dzsap_portal->query1){


//                echo 'hmmdada';

                    $dzsap_portal->permalinks_insert(array(

                        'permalink'=>$dzsap_portal->query1,
                        'type'=>'user',
                        'target_id'=>$val['id'],
                        'table'=>'permalinks',
                    ));



                    $_GET['page']='user';


                    $_GET['user_id']=$val['id'];


                    $sw_found = true;

                }

            }
        }




//        print_r($auxarr);

    }





    if($dzsap_portal->query1=='users'){
        $_GET['page']='user';
        $_GET['user_id']=$dzsap_portal->query2;



        $searched_title = $_GET['user_id'];


        $auxarr = $dzsap_portal->get_users();

//            echo 'ceva';
//            print_r($auxarr);
        $track_id = '';



        foreach($auxarr as $lab=>$it){
//                    print_r($it);

//                    echo $dzsap_portal->sanitize_title_for_pretty($it['username']).' '.$searched_title.' --- ';
            if($dzsap_portal->sanitize_title_for_pretty($it['username']) == $searched_title){

                $track_id = $it['id'];
                break;
            }
        }
//            echo 'searched id - '.$track_id;
        if($track_id){
            $dzsap_portal->query2_processed = $track_id;

            $_GET['user_id']=$track_id;


        }
    }


//    echo ' query1 - '.$dzsap_portal->query1.' query2 - '.$dzsap_portal->query2.' sw_found - '.$sw_found;
//    if($sw_found){
//        print_r($_GET);
//    }
//    print_r($dzsap_portal->query_params);

    if(isset($_GET['page']) && $_GET['page']=='user'){


        if($dzsap_portal->query2){

//            echo $dzsap_portal->query2;
            if($dzsap_portal->query2=='playlists'){
                $_GET['page_type']='playlists';
            }elseif($dzsap_portal->query2=='following'){
                $_GET['page_type']='following';
            }elseif($dzsap_portal->query2=='followers'){
                $_GET['page_type']='followers';
            }elseif($dzsap_portal->query2=='likes'){
                $_GET['page_type']='likes';
            }else{

                $_GET['page'] = 'track';


                $trks = $dzsap_portal->get_tracks(array(
                    'author_id'=>$_GET['user_id'],
                    'type'=>'album,album_part,track,soundcloud,',
                ));

//                print_r($trks);

                foreach ($trks as $trk){

                    if(strpos($dzsap_portal->query2,'[')!==false){
                        $dzsap_portal->query2 = $dzsap_portal->sanitize_title_for_pretty($dzsap_portal->query2);
                    }

//                    echo ' searching for track in user ('.$dzsap_portal->query1.') -> '.$dzsap_portal->query2.' - '.$dzsap_portal->sanitize_title_for_pretty($trk['title']).'|||';

                    if($dzsap_portal->query2==$dzsap_portal->sanitize_title_for_pretty($trk['title'])){
                        $_GET['track_id']= $trk['id'];
//                        echo 'debug FOUND';
                    }
                }


//                echo 'hmmdada';
            }
        }

    }



//        echo $dzsap_portal->query1;
    if($dzsap_portal->query1=='tracks'){
        $_GET['page']='track';
        $_GET['track_id']=$dzsap_portal->query2;
//            if($dzsap_portal->query3=='playlists'){
//                $_GET['page_type']='playlists';


        $searched_title = $_GET['track_id'];


        $auxarr = $dzsap_portal->get_tracks();

//            echo 'ceva';
//            print_r($auxarr);
        $track_id = '';



        foreach($auxarr as $lab=>$it){
//                    print_r($it);

//                    echo $dzsap_portal->sanitize_title_for_pretty($it['title']).' '.$searched_title.' --- ';
            if($dzsap_portal->sanitize_title_for_pretty($it['title']) == $searched_title){

                $track_id = $it['id'];
                break;
            }
        }
//            echo $track_id;
        if($track_id){
            $dzsap_portal->query2_processed = $track_id;


        }


//            }
    }

}

//echo 'check';

if(isset($_GET['page']) && $_GET['page']){


        if($_GET['page']==='page'){


            $currpage_id = $_GET['page_id'];

            $page = 'page';
            $page_id = $_GET['page_id'];


//            print_r($_GET);
        }


//        if(DZSHelpers::get_query_arg(dzs_curr_url(), 'page')==='track'){

//    print_r($_GET);
        if($_GET['page']==='track'){


            $track_id = 1;

            if(isset($_GET['id'])){
                $track_id=$_GET['id'];
            }
            if(isset($_GET['track_id'])){
                $track_id=$_GET['track_id'];
            }

            $page = 'track';


            $track = $dzsap_portal->get_track($track_id);


//            print_r($track);

            $args=array(
                'query_by_title'=>true
            );

            if(is_array($track) && count($track)){
                $auxa = $dzsap_portal->get_page('Page Track',$args);

                if($dzsap_portal->main_settings['use_pretty_links']=='on'){

                    $searched_title = '';
                    if(isset($_GET['track_id'])){
                        $searched_title = $_GET['track_id'];
                    }


//                echo 'searched title - >'.$searched_title;
                    $auxarr = $dzsap_portal->get_tracks();


                    foreach($auxarr as $lab=>$it){
//                    print_r($it);

//                    echo $dzsap_portal->sanitize_title_for_pretty($it['title']).' '.$searched_title.' --- ';
                        if($dzsap_portal->sanitize_title_for_pretty($it['title']) == $searched_title){

                            $track_id = $it['id'];
                            break;
                        }
                    }

                    $dzsap_portal->set_track_id($track_id);
                }else{

                    $dzsap_portal->set_track_id($track_id);
                }


                $track = $dzsap_portal->get_track($dzsap_portal->track_id);

                $author_id = '';

                if(isset($track['author_id'])){
                    $author_id = strip_tags($dzsap_portal->get_username($track['author_id']));
                }
                $meta_desc = 'by '.$author_id;


                $thumb = '';
                if(isset($track['thumbnail'])){
                    $thumb = $dzsap_portal->sanitize_source($track['thumbnail']);
                }

                $meta_image = $thumb;


                $currpage_id = $auxa['id'];

//    print_r($auxa);

                $page_type = 'track';
            }else{
                $auxa = $dzsap_portal->get_page('Page 404',$args);
                $currpage_id = $auxa['id'];

                $page_type = '404';
                $page = '404';
            }

        }


        if($_GET['page']==='tracklist'){


            $page = 'tracklist';



            $args=array(
                'query_by_title'=>true
            );
            $auxa = $dzsap_portal->get_page('Page Tracklist',$args);

            $currpage_id = $auxa['id'];

//    print_r($auxa);

            $page_type = DZSHelpers::get_query_arg(dzs_curr_url(), 'type');
        }



        if($_GET['page']==='register'){

//            echo 'ceva';


            $args=array(
                'query_by_title'=>true
            );
            $auxa = $dzsap_portal->get_page('Page Register',$args);

//            print_r($auxa);

            $currpage_id = $auxa['id'];
        }

        if($_GET['page']==='post'){

//            echo 'ceva';


            $args=array(
                'query_by_title'=>true
            );
            $auxa = $dzsap_portal->get_page('Page Post',$args);

//            print_r($auxa);



            $page = 'post';

            $currpage_id = $auxa['id'];
        }

//    print_r($dzsap_portal);

//    print_r($_GET);
        if($_GET['page']==='user' || $dzsap_portal->query1=='users'){

//            echo 'ceva';


            $args=array(
                'query_by_title'=>true
            );
            $auxa = $dzsap_portal->get_page('Page User',$args);

//            echo 'auxa user - '; print_r($auxa);

            $currpage_id = $auxa['id'];

            $page = 'user';
            $page_type = 'explore';


            if(isset($_GET['page_type']) && $_GET['page_type']){

                $page_type = $_GET['page_type'];

            }
        }
        if($_GET['page']==='upload' ){

//            echo 'ceva';


            $args=array(
                'query_by_title'=>true
            );
            $auxa = $dzsap_portal->get_page('Upload',$args);

//            echo ' auxa - '; print_r($auxa);

            if($auxa && count($auxa)){

                $currpage_id = $auxa['id'];
            }else{
                $all_pages = $dzsap_portal->get_pages();

//                print_r($all_pages);

                foreach ($all_pages as $pg){
//                    print_r($pg);

                    if($pg['content'] && strpos($pg['content'], 'type_element="upload"')){


                        $currpage_id = $pg['id'];
                        break;

                    }
                }
            }

//            print_r($auxa);


        }


        if($_GET['page']==='messages'){

//            echo 'ceva';


            $args=array(
                'query_by_title'=>true
            );
            $auxa = $dzsap_portal->get_page('Page Messages',$args);

//            print_r($auxa);

            $currpage_id = $auxa['id'];
            $page = 'messages';
        }


        if($_GET['page']==='checkout'){

//            echo 'ceva';


            $args=array(
                'query_by_title'=>true
            );
            $auxa = $dzsap_portal->get_page('Page Checkout',$args);

//            print_r($auxa);

            $currpage_id = $auxa['id'];
        }
        if($_GET['page']==='depositinfo'){

//            echo 'ceva';


            $args=array(
                'query_by_title'=>true
            );
            $auxa = $dzsap_portal->get_page('Page Deposit Info',$args);

//            print_r($auxa);

            $currpage_id = $auxa['id'];
        }
        if($_GET['page']==='usersettings'){

//            echo 'ceva';


            $args=array(
                'query_by_title'=>true,
            );
            $auxa = $dzsap_portal->get_page('Page User Settings',$args);

//            print_r($auxa);

            $currpage_id = $auxa['id'];
        }


        if($_GET['page']==='embed'){

//            echo 'ceva';

            $page = 'embed';

            $args=array(
                'query_by_title'=>true
            );
            $auxa = $dzsap_portal->get_page('Page Embed',$args);

//            print_r($auxa);

            $currpage_id = $auxa['id'];
        }


        if($_GET['page']==='backupdb'){

//            echo 'ceva';

            if($dzsap_portal->currUserId>0){
                $caps = $dzsap_portal->get_user_capabilities($dzsap_portal->currUserId);

                if(in_array('admin', $caps)){



                }
            }
            $dzsap_portal->backup_tables();

            die();
        }


//        echo 'hmm';
//        echo 'paj';
    }else{

        $currpage_id = $dzsap_portal->get_mainsetting('page_homepage');

//    echo ' id - '.$currpage_id.' ';

//    echo abc;
        $page = 'page';




        if($dzsap_portal->currUserId>0 && $dzsap_portal->main_settings['home_is_stream']=='on'){

    //    echo 'hmm';

            $page = 'tracklist';
            $page_type = 'stream';

//            echo 'hmmdada';


            $args=array(
                'query_by_title'=>true
            );
            $auxa = $dzsap_portal->get_page('Page Tracklist',$args);


            $page_id = $auxa['id'];
            $currpage_id = $auxa['id'];

    //    echo $page_id;

        }
    }


//    echo $currpage_id;
$auxa = $dzsap_portal->get_page($currpage_id);

//    print_r($auxa);
if($page=='page' && $auxa['title']==='Explore'){
//    $page='tracklist';
    $page_type = 'explore';




}



if($page=='page' && isset($auxa['title']) && $auxa['title']==='Page User'){
//    $page='tracklist';

//    print_r($_GET);

    $args=array(
        'query_by_title'=>true
    );
    $auxa = $dzsap_portal->get_page('Page 404',$args);
    $currpage_id = $auxa['id'];

    $page_type = '404';
    $page = '404';


}

if($page=='user' && isset($auxa['title']) && $auxa['title']==='Page User'){
//    $page='tracklist';

//    print_r($_GET);

    $trk = $dzsap_portal->get_user($_GET['user_id']);
//    print_r($_GET);
//    echo 'user - '; print_r($trk);
    $auxa['title']=$trk['username'];

}

if($page=='track' && isset($auxa['title']) && $auxa['title']==='Page Track'){
//    $page='tracklist';

//    print_r($_GET);

    $trk = $dzsap_portal->get_track($_GET['track_id']);
    $auxa['title']=$trk['title'];

}


if($page=='track'){



}

$dzsap_portal->currPage = $page;
$dzsap_portal->currPage_type = $page_type;
$dzsap_portal->currPageId = $currpage_id;

//print_r($auxa);

//    echo $page;
$page_content = $auxa['content'];


$template_id = $dzsap_portal->get_page_meta($currpage_id, 'use_template');

//    echo $page;
//die();
//    echo $page_content;


?><!doctype html>
<html<?php echo $str_html_dir; echo $str_html_lang;?>>
<head>
    <meta charset="<?php echo $charset; ?>"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <meta http-equiv="X-UA-COMPATIBLE" content="IE=EDGE">
    <meta property="og:title" content="<?php echo $meta_title; ?> - <?php echo $auxa['title']; ?>" />
    <meta property="og:description" content="<?php echo $meta_desc; ?>" />
    <?php

if($meta_image){
    ?>
    <meta property="og:image" content="<?php echo $meta_image; ?>" />
    <?php } ?>
    <title><?php echo $dzsap_portal->main_settings['site_title']; ?> - <?php echo $auxa['title']; ?></title>
    <link rel="icon" type="image/png" href="<?php echo $dzsap_portal->optional_url_base; ?>favicon.png">
    <script src="<?php echo $dzsap_portal->optional_url_base; ?>js/jquery.js"></script>

    <?php
if($dzsap_portal->main_settings['gzip_start_styles']=='on'){

    //,libs/dzsscroller/scroller.css
    echo '<link href="'.$dzsap_portal->optional_url_base.'gzip.php?files=libs/bootstrap/bootstrap.css,style/style.css,libs/audioplayer/audioplayer.css,libs/dzstooltip/dzstooltip.css,libs/advancedscroller/plugin.css,libs/ultibox/ultibox.css" rel="stylesheet">';
}else{
?>

    <link href="<?php echo $dzsap_portal->optional_url_base; ?>libs/bootstrap/bootstrap.css" rel="stylesheet">
    <link rel='stylesheet' type="text/css" href="<?php echo $dzsap_portal->optional_url_base; ?>style/style.css"/>
    <link rel='stylesheet' type="text/css" href="<?php echo $dzsap_portal->optional_url_base; ?>libs/audioplayer/audioplayer.css"/>
    <link rel='stylesheet' type="text/css" href="<?php echo $dzsap_portal->optional_url_base; ?>libs/dzstooltip/dzstooltip.css"/>
<!--    <link rel='stylesheet' type="text/css" href="--><?php //echo $dzsap_portal->optional_url_base; ?><!--libs/dzsscroller/scroller.css"/>-->
    <link rel='stylesheet' type="text/css" href="<?php echo $dzsap_portal->optional_url_base; ?>libs/advancedscroller/plugin.css"/>
    <link rel='stylesheet' type="text/css" href="<?php echo $dzsap_portal->optional_url_base; ?>libs/ultibox/ultibox.css"/>

    <?php
}
    ?>
    <?php
    if($dzsap_portal->main_settings['google_fonts_enable']=='on') {
        if ($dzsap_portal->main_settings['theme'] == 'theme-default') {
            ?>
            <link
                href='https://fonts.googleapis.com/css?family=PT+Sans:300,400,600,700,400italic&subset=latin,latin-ext'
                rel='stylesheet' type='text/css'>
            <?php

        }
        //<link href='http://fonts.googleapis.com/css?family=Lora:400,700' rel='stylesheet' type='text/css'>
        ?>
        <?php
        if ($dzsap_portal->main_settings['theme'] == 'theme-luna' || $dzsap_portal->main_settings['theme'] == 'theme-domino') {
            ?>

            <link href='https://fonts.googleapis.com/css?family=Dosis:300,400,700&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
            <link href='https://fonts.googleapis.com/css?family=Raleway:300,400,400italic,700&subset=latin,latin-ext' rel='stylesheet'
                  type='text/css'>


            <?php

        }
    }




    $soundcloud_api_key = '';

    if($dzsap_portal->main_settings['soundcloud_api_key']){
        $soundcloud_api_key = $dzsap_portal->main_settings['soundcloud_api_key'];
    }


    if($dzsap_portal->main_settings['color_waveformbg']=='#212223' || $dzsap_portal->main_settings['color_waveformbg']=='#575859'){
        if($dzsap_portal->main_settings['theme']=='theme-dark'){
            $dzsap_portal->main_settings['color_waveformbg'] = '#cccccc';
        }
    }

    ?>

    <?php if ($page == 'upload' || $page == 'usersettings' || isset($_GET['media'])) { ?>
        <link rel="stylesheet" href="<?php echo $dzsap_portal->optional_url_base; ?>libs/dzstabsandaccordions/dzstabsandaccordions.css">
        <script src="<?php echo $dzsap_portal->optional_url_base; ?>libs/dzstabsandaccordions/dzstabsandaccordions.js" type="text/javascript"></script>
        <link rel="stylesheet" href="<?php echo $dzsap_portal->optional_url_base; ?>libs/dzsuploader/upload.css">
        <script src="<?php echo $dzsap_portal->optional_url_base; ?>libs/dzsuploader/upload.js" type="text/javascript"></script>
    <?php } ?>
    <style class="dzsapp-extra-css"><?php echo $dzsap_portal->main_settings['extra_css']; ?></style>
    <script>
        var dzsap_settings = {
            thepath: "<?php echo $dzsap_portal->url_base; ?>"
            ,page: "<?php echo $page; ?>"
            ,soundcloud_apikey: "<?php echo $soundcloud_api_key; ?>"
            ,tags_suggested: "<?php echo $dzsap_portal->main_settings['tags_suggested']; ?>"
            ,sc_retriever:"<?php echo $dzsap_portal->url_base; ?>soundcloudretriever.php"
            ,tags_allow_only_suggested: "<?php echo $dzsap_portal->main_settings['tags_allow_only_suggested']; ?>"
            ,tags_max_nr: "<?php echo $dzsap_portal->main_settings['tags_max_nr']; ?>"
            ,currUserId: "<?php echo $dzsap_portal->currUserId; ?>"
            ,allow_only_logged_in_users_to_download_free_tracks: "<?php echo $dzsap_portal->main_settings['allow_only_logged_in_users_to_download_free_tracks']; ?>"
            ,likes_allow_post_if_not_logged_in: "<?php echo $dzsap_portal->main_settings['likes_allow_post_if_not_logged_in']; ?>"
            ,optional_url_base: "<?php echo $dzsap_portal->optional_url_base; ?>"
            , waveformgenerator_multiplier: "<?php echo $dzsap_portal->main_settings['waveformgenerator_multiplier']; ?>"
            , color_waveformbg: "<?php echo substr($dzsap_portal->main_settings['color_waveformbg'], 1); ?>"
            , color_waveformprog: "<?php echo substr($dzsap_portal->main_settings['color_waveformprog'], 1); ?>"
            , enable_cart: "on"
            , enable_ajax: "<?php echo $dzsap_portal->main_settings['use_ajax']; ?>"
            , number_of_pro_account_options: "<?php echo $dzsap_portal->number_of_pro_account_options; ?>"
            , download_ad_link: "<?php echo $dzsap_portal->main_settings['download_ad_link']; ?>"
            , enable_notifications: "<?php echo $dzsap_portal->main_settings['enable_notifications']; ?>"
            , settings_wavestyle: "reflect"<?php
                echo ',settings_php_handler: "index.php"';
                echo ',settings_ajax_handler: "index.php"';
                if(isset($_GET['media'])){
                    echo ',mediaid:"'.$_GET['media'].'"';
                }

                echo ',waves_generation:"auto"'; // -- auto / manual / none

            if($dzsap_portal->currUserId>0){
                $aux = $dzsap_portal->get_username($dzsap_portal->currUserId, array(

                    'include_tooltip'=>false,
                ));
                $aux = str_replace('"', '&quot;',$aux);
                $aux = str_replace(array("\n", "\r"), '', $aux);

                echo ',curr_user_name:"'.$aux.'"';
                echo ',curr_user_avatar:"'.$dzsap_portal->get_avatar($dzsap_portal->currUserId).'"';
                echo ',curr_size_occupied:"'.$dzsap_portal->get_user_total_uploaded($dzsap_portal->currUserId).'"';

//    $aux = $dzsap_portal->get_tracks(array(
//        'author_id'=>$dzsap_portal->currUserId
//    ));

//    echo $dzsap_portal->get_user_total_uploaded($dzsap_portal->currUserId);

//    print_r($aux);
            }


            ?>};
        var dzsap_ltz = {
            follow: "<?php echo __("Follow"); ?>"
            ,unfollow: "<?php echo __("Unfollow"); ?>"
            };
        window.dzs_phpfile_path = "<?php echo $dzsap_portal->optional_url_base; ?>index.php?upload_from_dzs=on";
        window.dzs_upload_path = "upload/";

        <?php
//        echo $dzsap_portal->optional_url_base;
        ?>
//        console.error(window.dzs_phpfile_path);



</script>
    <?php


    $dzsap_portal->do_action('before_head_end');
    ?>
</head>

<?php
$body_classes = 'page-'.$page.' '.'page-'.$page_id.' '.$dzsap_portal->main_settings['theme'];

if($dzsap_portal->currUserId){
    $body_classes.=' logged-in';
}else{

        $body_classes.=' not-logged-in';
}

//print_r($_GET);

?>
<body class=" <?php echo $body_classes; ?>">
<div id="fb-root"></div>
<div id="ajax-loading-bar"><div class="the-bar"></div><div class="the-tip"></div></div>
<div class="content-wrapper">


    <?php




//    print_r($_SESSION);




    //die();
    $fout = '';

    if($template_id && $template_id!='none'){

//        $fout.=' -- is template --';

        $aux_temp = $dzsap_portal->select_template_array($template_id);
//                    print_r($aux_temp);

        $aux_tem = array();
        parse_str($aux_temp[0]['template_data'],$aux_tem);



        // -- debug AREA
    if($dzsap_portal->main_settings['debug_pagebuilder']=='on') {
        echo ' -- pagebuilder start data '.$template_id.'-> ';

        print_r($aux_tem);
        echo ' <- end ';
    }
        // -- debug AREA END


//                    echo $auxtem;

        $aux2 = $dzsap_portal->transform_to_shortcode($aux_tem);

        $fout.= '<!--starthere parsing shortcode from template -->' . $dzsap_portal->do_shortcode($aux2). '<!--endhere-->';
//        die();
    }else{


//                echo $page_content;
        $fout .= '<!--starthere parsing shortcode-->' . $dzsap_portal->do_shortcode($page_content) . '<!--endhere-->';
    }


    echo $fout;

    ?>

    <?php
    if($page=='normal') {

        ?>

        <?php

//                echo $page_content;

//                echo '<strong>BETTER IF WE DO SHORTCODE SYSTEM ? </strong>';
//

//            $html = "<b>bold text</b><a href=howdy.html>click me</a>";



//            $regex_s = //gm;
//
//                $aux1 = null;


    }

    ?>

    <!--            <section class="mcon-section">-->
    <!--	            --><?php
    ////	            echo __("Hello world");
    //
    //
    //	            ?>
    <!--            </section>-->







    <div class="responsive-menu-closer"></div>
</div>
<?php

//echo 'what'.$page;

if($page!='embed'&&$dzsap_portal->main_settings['footer_player_config'] && $dzsap_portal->main_settings['footer_player_config']!='off'){






    $vpsettingsdefault = array(
        'id' => 'default',
        'skin_ap' => 'skin-wave',
        'settings_backup_type' => 'full',
        'skinwave_dynamicwaves' => 'off',
        'skinwave_enablespectrum' => 'off',
        'skinwave_enablereflect' => 'on',
        'skinwave_comments_enable' => 'off',
        'disable_volume' => 'default',
        'playfrom' => 'default',
        'enable_likes' => 'on',
        'enable_views' => 'on',
        'enable_rates' => 'off',
    );

    $vpsettings = array();
    $vpsettings['settings'] = $vpsettingsdefault;

//        print_r($margs);

        $apconfig_str = $dzsap_portal->get_page($dzsap_portal->main_settings['footer_player_config'], array(
            'post_type'=>'apconfig',
        ));

        $apconfig = array();




        if(isset($apconfig_str['content'])){

            parse_str($apconfig_str['content'], $apconfig);
        }

//           echo ' footer player config -- ' .$dzsap_portal->main_settings['footer_player_config'] .  '--- '; print_r($apconfig);

        $vpsettings['settings'] = array_merge($vpsettingsdefault, $apconfig);


    $its = array(

        0=>array(

            'source'=>'fake',
            'type'=>'fake',
            'playfrom'=>'0',
            'playerid'=>'apfooter',
            'thumb'=>'fake',
            'menu_artistname'=>'',
            'menu_songname'=>'',
            'feed-dzsap-after-playpause'=>'
            <div style="cursor:pointer;" class="extra-dzsap-button">
                <svg version="1.1" id="Layer_2" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="15px" height="15px" viewBox="0 0 12.5 12.817" enable-background="new 0 0 12.5 12.817" xml:space="preserve">
<g>
	<g>
		<g>
			<path fill="#444" d="M9.874,5.443c0.744,0.462,1.414,0.939,1.486,1.06c0.074,0.121-0.771,0.729-1.535,1.156L7.482,8.967
				C6.719,9.394,5.978,9.75,5.837,9.756C5.696,9.761,5.581,8.726,5.581,7.851V4.952c0-0.875,0.05-1.693,0.112-1.816
				c0.062-0.124,0.995,0.326,1.739,0.788L9.874,5.443z"/>
		</g>
	</g>
</g>
<g>
	<g>
		<g>
			<path fill="#444" d="M6.155,5.248c0.893,0.556,1.696,1.129,1.786,1.274c0.088,0.145-0.928,0.875-1.847,1.389l-2.811,1.57
				c-0.918,0.514-1.808,0.939-1.978,0.947c-0.169,0.008-0.308-1.234-0.308-2.287V4.66c0-1.052,0.061-2.034,0.135-2.182
				s1.195,0.391,2.089,0.947L6.155,5.248z"/>
		</g>
	</g>
</g>
</svg>


            </div>',

        ),
    );
    $its['settings'] =$vpsettings['settings'];


    $fout = '';

    // -- footer player

    $fout.='
<div class="dzsap-sticktobottom-placeholder dzsap-sticktobottom-placeholder-for-'.$vpsettings['settings']['skin_ap'].'"></div>
<div class="dzsap-sticktobottom dzsap-sticktobottom-for-'.$vpsettings['settings']['skin_ap'].'">';





    $the_player_id='ap'.$its[0]['playerid'];
    $color_highlight = '';
    if(isset($vpsettings['settings']['colorhighlight'])){
        $color_highlight = $vpsettings['settings']['colorhighlight'];

        if(strpos($color_highlight, '#')===0){
            $color_highlight = str_replace('#','',$color_highlight);
        }
    }


//        echo 'hmm - '.$color_highlight;
    if($color_highlight){


        $fout.='<style class="from-show-player">';


        $fout.='#'.$the_player_id.' .orange-button, .audioplayer.skin-wave#'.$the_player_id.' .volume_active { background-color: #'.$color_highlight.';} ';

        if(isset($its['settings']) && isset($its['settings']['button_aspect']) && $its['settings']['button_aspect']!='default'){

        }else{
            $fout.='.audioplayer.skin-wave#'.$the_player_id.' .ap-controls .con-playpause .playbtn, .audioplayer.skin-wave#'.$the_player_id.' .btn-embed-code, .audioplayer.skin-wave#'.$the_player_id.' .ap-controls .con-playpause .pausebtn  { background-color: #'.$color_highlight.';}  </style>';

        }
        $fout.='</style>';
    }


    $fout.='<div class="container">';

    $fout.= $dzsap_portal->parse_items($its, array(
        'single'=>'on',
    ));

    $fout.='</div>';

    $fout.='
</div>

</div>';


    $fout.='<script>';


    $color_highlight = '';

//    print_r($vpsettings['settings']);

    if(isset($vpsettings['settings']['colorhighlight'])){
        $color_highlight = $vpsettings['settings']['colorhighlight'];
    }


    $fout.='(function(){
// from show_player() yesyes FOOTER footer player
jQuery(document).ready(function ($){ 
var settings_apfooter = {
design_skin: "'.$vpsettings['settings']['skin_ap'].'"
,autoplay: "'.'off'.'"
,disable_volume:"'.$vpsettings['settings']['disable_volume'].'"
,cue: "'.'off'.'"
,embedded: "'.'off'.'"
,skinwave_dynamicwaves:"'.$vpsettings['settings']['skinwave_dynamicwaves'].'"
,skinwave_enableSpectrum:"'.$vpsettings['settings']['skinwave_enablespectrum'].'"
,settings_backup_type:"'.$vpsettings['settings']['settings_backup_type'].'"
,skinwave_comments_process_in_php: "on"
,settings_php_handler: "index.php"';


    if($dzsap_portal->main_settings['skinwave_wave_mode']=='canvas'){

        $color_waveform_bg = $dzsap_portal->main_settings['color_waveformbg'];
        $color_waveform_prog = $dzsap_portal->main_settings['color_waveformprog'];


        $color_waveform_bg = str_replace('#','',$color_waveform_bg);
        $color_waveform_prog = str_replace('#','',$color_waveform_prog);

        $fout.=',skinwave_wave_mode: "canvas"
,skinwave_wave_mode_canvas_waves_number: "'.$dzsap_portal->main_settings['skinwave_wave_mode_canvas_waves_number'].'"
,pcm_data_try_to_generate: "on"
,design_color_bg: "'.$color_waveform_bg.'"
,design_color_highlight: "'.$color_waveform_prog.'"
,action_audio_end: window.portal_action_audio_end
';
    }

    $fout.=',skinwave_enableReflect:"'.$vpsettings['settings']['skinwave_enablereflect'].'"';
    if ($color_highlight) {
//        $fout.=',design_color_highlight:"'.$color_highlight.'"';
    }
    if (isset($vpsettings['settings']['playfrom'])) {
        $fout.=',playfrom:"'.$vpsettings['settings']['playfrom'].'"';
    }




    //<div class="orange-button dzstooltip-con" style="top:10px;"><span class="dzstooltip arrow-from-start transition-slidein arrow-bottom skin-black align-right" style="width: auto; white-space: nowrap;">Download</span><i class="fa fa-download"></i></div>

    //<span class="ap-date">'.__("A day before").'</span>
//    $fout.=',settings_extrahtml_in_float_right: \'<div class="orange-button dzstooltip-con  add-to-playlist-btn" style="top:10px;"><span class="dzstooltip arrow-from-start transition-slidein arrow-bottom skin-black align-right" style="width: auto; white-space: nowrap; right:-5px;">Add to Playlist</span><i class="fa fa-bookmark"></i></div>\'';

    if($dzsap_portal->currUserId>0){

    }else{
//                $vpsettings['settings']['skinwave_comments_enable'] = 'off';
    }



    $fout.=',soundcloud_apikey:"'.$dzsap_portal->main_config_settings['soundcloud_api_key'].'"
,skinwave_comments_allow_post_if_not_logged_in:"on"
,skinwave_comments_enable:"'.$vpsettings['settings']['skinwave_comments_enable'].'"';

    $fout.='';
    if ($vpsettings['settings']['skinwave_comments_enable'] == 'on') {
        if ($dzsap_portal->currUserId!=='0') {
            $fout.=',skinwave_comments_account:"'.$dzsap_portal->get_user_field($dzsap_portal->currUserId,'email').'"';
            $fout.=',skinwave_comments_avatar:"'.$dzsap_portal->get_avatar($dzsap_portal->currUserId).'"';
        }
    }




    if (isset($its['settings']['skinwave_mode']) && $its['settings']['skinwave_mode'] == 'small') {
        $fout.=',skinwave_mode:"'.$its['settings']['skinwave_mode'].'"';
    }



    $fout.=',skinwave_comments_playerid:"'.'apfooter'.'"';


    if (isset($vpsettings['settings']['enable_embed_button']) && $vpsettings['settings']['enable_embed_button'] == 'on') {
        $str_db = '';
//                $str = '<iframe src=\''.$this->url_base.'bridge.php?page=player&margs='.serialize($margs).'\' style="overflow:hidden; transition: height 0.5s ease-out;" width="100%" height="50" scrolling="no" frameborder="0"></iframe>';
////                echo 'ceva22'.$str;
//                $str = str_replace('"',"'",$str);
//                $fout.=',embed_code:"'.htmlentities($str,ENT_QUOTES).'"';
    }





    $fout.=',php_retriever:"'.$dzsap_portal->url_base.'soundcloudretriever.php" ,swf_location:"'.$dzsap_portal->url_base.'ap.swf"
,swffull_location:"'.$dzsap_portal->url_base.'apfull.swf"
};
var auxap = $(".'.'apapfooter'.'").last();

//console.info(auxap);
dzsap_init(auxap,settings_apfooter);

setTimeout(function(){
auxap.get(0).api_set_action_audio_end(window.portal_action_audio_end);
},1000);

});
})();';
    $fout.='</script>';

    echo $fout;
}

/*
 * <div class="preloader-audio">
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
</div>
*/

?>
<div class="preloader-audio">
    <div class=" preloader-fountain" > <div  class="fountainG fountainG_1"></div> <div  class="fountainG fountainG_2"></div> <div  class="fountainG fountainG_3"></div> <div  class="fountainG fountainG_4"></div> </div>
</div>

<div class="feedbacker" style="display:none;"></div>
<div id="reportcopyright" class="hidden-content-for-zoombox" >
    <form class="reportcopyright" style="text-align: center">
        <h4><?php echo __("Report Reason"); ?></h4>
        <input type="hidden" name="track_id"/>
        <p><textarea name="report" class="simple-input-field" ></textarea></p>
        <p><button class="btn-skin-vive"><?php echo __("Submit"); ?></button></p>
    </form>
</div>

<?php //$encrypted = simple_encrypt("ceva"); echo $encrypted.' '; echo simple_decrypt($encrypted) ?>
<div id="forgotpassword" class="hidden-content-for-zoombox" >
    <form class="forgotpassword" method="post" style="text-align: center">
        <h4><?php echo __("Email Address"); ?></h4>
        <p><input name="email" class="simple-input-field" /></p>
        <p><button name="action" value="forgotpassword" class="btn-skin-vive"><?php echo __("Submit"); ?></button></p>
    </form>
</div>

<div class="hidden-resources" style="display:none">
    <div class="dzsapp_var_page"><?php  $lab = "page"; if(isset($_GET) && isset($_GET[$lab])) { echo $_GET[$lab]; } ?></div>
    <div class="dzsapp_var_user_id"><?php  $lab = "user_id"; if(isset($_GET) && isset($_GET[$lab])) { echo $_GET[$lab]; } ?></div>
    <div class="dzsapp_var_track_id"><?php  $lab = "track_id"; if(isset($_GET) && isset($_GET[$lab])) { echo $_GET[$lab]; } ?></div>
    <div class="dzsapp_currpage_type"><?php echo $dzsap_portal->currPage_type; ?></div>
</div>

<div class="bigsearch-con">

    <div class="bigsearch--the-bg"></div>

    <div class="search-con">

        <div class="search-query-input">

            <input class="input-ujarak-style" type="text" name="search_keywords" placeholder="<?php echo __("Search on site"); ?>"/>
            <button class="search-button"><i class="fa fa-search"></i><i class="fa fa-circle-o-notch fa-spin"></i></i></button>

        </div>

        <div class="search-results-con">

            <div class="scroller-con auto-init skin_apple" data-options="{
		settings_skin:'skin_slider',
		settings_replacewheelxwithy:'on'
		,enable_easing:'on'
		,settings_refresh: '1000'

	}">
                <div class="inner">

                </div>
            </div>
        </div>

    </div>
</div>
<?php
if($dzsap_portal->number_of_pro_account_options>1){
    ?>
<div class=" clearfix hidden-content-for-zoombox"  id="inline-content1">
    <div class="" style="text-align: center">
        <?php
        if($dzsap_portal->main_settings['pro_account_price']){
        ?>
            <a href="#" data-playerid="proaccount" class="add-to-cart-btn button button--secondary btn-in-zoombox"><span class="button-label">1 Month - <?php echo $dzsap_portal->main_settings['currency_label'] . $dzsap_portal->main_settings['pro_account_price']; ?> </span></a>
        <?php
        }
        ?>
        <?php
        if($dzsap_portal->main_settings['pro_account_price_90']){
            ?>
            <a href="#" data-playerid="proaccount_90" class="add-to-cart-btn button button--secondary btn-in-zoombox"><span class="button-label">3 Months - <?php echo $dzsap_portal->main_settings['currency_label'] . $dzsap_portal->main_settings['pro_account_price_90']; ?> </span></a>
            <?php
        }
        ?>
        <?php
        if($dzsap_portal->main_settings['pro_account_price_year']){
            ?>
            <a href="#" data-playerid="proaccount_year" class="add-to-cart-btn button button--secondary btn-in-zoombox"><span class="button-label">12 Months - <?php echo $dzsap_portal->main_settings['currency_label'] . $dzsap_portal->main_settings['pro_account_price_year']; ?> </span></a>
            <?php
        }
        ?>
    </div>

</div>
<?php
}

?>

<!--    <link href='http://fonts.googleapis.com/css?family=Droid+Sans' rel='stylesheet' type='text/css'>-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
<?php

if($dzsap_portal->main_settings['use_parallaxer']=='on'){

    ?>
    <link rel="stylesheet" href="<?php echo $dzsap_portal->optional_url_base; ?>libs/dzsparallaxer/dzsparallaxer.css">
    <?php

}

?>

<script class="dzsapp-extra-js"><?php
    if(isset($dzsap_portal->main_settings['extra_js'])){
        echo $dzsap_portal->main_settings['extra_js'];
    }
     ?></script>
<script>
    window.init_zoombox_settings = {
        settings_disableSocial : "on"
        ,design_skin : "skin-nebula"
    }
</script>
<script src="<?php echo $dzsap_portal->optional_url_base; ?>libs/audioplayer/audioplayer.js" type="text/javascript"></script>
<script src="<?php echo $dzsap_portal->optional_url_base; ?>libs/dzstooltip/dzstooltip.js" type="text/javascript"></script>
<script src="<?php echo $dzsap_portal->optional_url_base; ?>js/portal.js"></script>
<script src="<?php echo $dzsap_portal->optional_url_base; ?>libs/ultibox/ultibox.js"></script>
<!--<script src="--><?php //echo $dzsap_portal->optional_url_base; ?><!--libs/dzsscroller/scroller.js"></script>-->
<script src="<?php echo $dzsap_portal->optional_url_base; ?>libs/advancedscroller/plugin.js" type="text/javascript"></script>
<script src="<?php echo $dzsap_portal->optional_url_base; ?>libs/dzsparallaxer/dzsparallaxer.js" type="text/javascript"></script>
<?php
//print_r($styles_tobeloaded);



foreach($scripts_tobeloaded as $script){
    echo '<script src="'.$script['val'].'"></script>';
}

foreach($styles_tobeloaded as $script){
    echo '<link rel="stylesheet" href="'.$script['val'].'">';
}

$dzsap_portal->do_action('before_body_end');

?>
</body>
</html>

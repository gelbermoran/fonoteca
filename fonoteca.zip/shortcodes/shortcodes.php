<?php
$id = 'dzspgb_section';

$dzspgb_shortcodes[$id] = array(
    'id' => $id,
    'str_function' => 'shortcode_'.$id,
);


if(!function_exists('shortcode_dzspgb_section')){
    function shortcode_dzspgb_section($pargs=array(),$content=null){

        global $dzsap_portal;


        $id = 'dzspgb_section';


        $margs = array(

            'extra_classes' => '',
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }


        $fout = '';


        $fout.='<section class="';


        $fout.=' '.$margs['extra_classes'];



        if($margs['extra_classes']=='content-section'){

            $fout.=' page-type-'.$dzsap_portal->currPage.'';
        }

        $fout.='">';




        if($margs['extra_classes']=='content-section'){
            $fout.='<section class="content-section--inner  page-type-'.$dzsap_portal->currPage.'">';


            $fout.= '<div class="container container-for-notices"><div class="row"><div class="col-md-12">';


//            print_r($dzsap_portal->notices_array);
            if(is_array($dzsap_portal->notices_array) && count($dzsap_portal->notices_array)>0){
                foreach($dzsap_portal->notices_array as $notice){

                    if($notice['notice_for']=='content_section'){
                        $fout.= '<div class="alert alert-'.$notice['notice_type'].'">'.$notice['notice_html'].'</div>';

                        if($notice['notice_type']=='purchaseconfirmation'){
                            $purchase_confirmed = true;
                        }
                    }

                }
            }
            $fout.= '</div></div></div>';

        }

//        print_r($margs['extra_classes']);

        if(strpos($margs['extra_classes'], 'mcon-mainmenu')!==false){
            ?>
            <div class="purchase-confirmation-clip">
                
            </div>

            <?php
        }


        $fout.=$dzsap_portal->do_shortcode($content);

        if($margs['extra_classes']=='content-section'){



            $fout.='</section>';
        }

        $fout.='</section>';

        if(strpos($margs['extra_classes'], 'mcon-mainmenu')!==false){
            $fout.='<div class="header--padder"></div>';
        }

        return $fout;
    }
}


$id = 'dzspgb_container';

$dzspgb_shortcodes[$id] = array(
    'id' => $id,
    'str_function' => 'shortcode_'.$id,
);


if(!function_exists('shortcode_dzspgb_container')){
    function shortcode_dzspgb_container($pargs=array(),$content=null){

        global $dzsap_portal,$dzsap_config;


        $id = 'dzspgb_container';


        $margs = array(

            'extra_classes' => '',
            'use_template' => '',
            'is_content' => 'off',
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }


//        print_r($margs);
//
        $fout = '';


        $fout.='<div class="';


        $fout.=$dzsap_config['front_dzspgb_container_class'];

        $fout.=' '.$margs['extra_classes'];

        $fout.='">';



        if($margs['is_content']=='on'){
//            $fout.='ceva';

//            echo $dzsap_portal->currPage.$dzsap_portal->currPageId.' how deep is your love';



            if($dzsap_portal->currUser){

                $caps = $dzsap_portal->get_user_capabilities($dzsap_portal->currUserId);

                if(in_array('admin',$caps)){

                    $fout.='<a target="_blank" href="'.$dzsap_portal->optional_url_base.'admin.php?page=pagebuilder&subpage='.$dzsap_portal->currPageId.'" class="edit-btn btn-discrete" style="position:fixed; left: 10px; top: 60px; background-color: rgba(0,0,0,0.5); z-index: 55; border-radius: 3px; padding: 10px; line-height: 1; color: #FFF;">'.__("Edit Page").'</a>';
                }
            }


            $auxa = $dzsap_portal->get_page($dzsap_portal->currPageId);
            $text_home = $auxa['content'];


            $fout .= '<!--starthere from shortcode-->' . $dzsap_portal->do_shortcode($text_home) . '<!--endhere-->';


        }else{

            $fout.=$dzsap_portal->do_shortcode($content);
        }





        $fout.='</div>';

        return $fout;
    }
}

$id = 'dzspgb_row';

$dzspgb_shortcodes[$id] = array(
    'id' => $id,
    'str_function' => 'shortcode_'.$id,
);


if(!function_exists('shortcode_dzspgb_row')){
    function shortcode_dzspgb_row($pargs=array(),$content=null){

        global $dzsap_portal,$dzsap_config;


        $id = 'dzspgb_row';


        $margs = array(

            'extra_classes' => '',
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }

//        return '';

//        print_r($margs);

        $fout = '';


        $fout.='<div class="';


        $fout.=$dzsap_config['front_dzspgb_row_class'];

        $fout.=' '.$margs['extra_classes'];

        $fout.='">';

        $fout.=$dzsap_portal->do_shortcode($content);


        $fout.='</div>';


        return $fout;
    }
}




$id = 'dzspgb_row_part';

$dzspgb_shortcodes[$id] = array(
    'id' => $id,
    'str_function' => 'shortcode_'.$id,
);


if(!function_exists('shortcode_dzspgb_row_part')){
    function shortcode_dzspgb_row_part($pargs=array(),$content=null){

        global $dzsap_portal,$dzsap_config;


        $id = 'dzspgb_row_part';


        $margs = array(

            'extra_classes' => '',
            'part' => '',
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }


//        print_r($margs);

        $fout = '';

        // -- check for not valid part
        if($margs['part']==''){
            return '';
        }


        $fout.='<div class="';



        $part_full = 'front_dzspgb_row_part_'.$margs['part'];





        if(isset($dzsap_config[$part_full])){

            $fout.=$dzsap_config[$part_full];
        }



        $fout.=' '.$margs['extra_classes'];

        $fout.='">';

        $fout.=$dzsap_portal->do_shortcode($content);


        $fout.='</div>';

        return $fout;
    }
}



$id = 'dzspgb_element';

$dzspgb_shortcodes[$id] = array(
    'id' => $id,
    'str_function' => 'shortcode_'.$id,
);




if(!function_exists('shortcode_dzspgb_element')){
    function shortcode_dzspgb_element($pargs=array(),$content=null){

        global $dzsap_portal,$dzsap_config;


        $id = 'dzspgb_dzspgb_element';


        $margs = array(

            'type_element' => '',
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }


        if($dzsap_portal->main_settings['debug_pagebuilder']=='on') {
            echo "\n".'
shortcode_dzspgb_element() - from shortcodes.php - ';
            print_r($margs);
            echo $margs['type_element'] . function_exists('shortcode_' . $margs['type_element']) . '

//
//';
        }

        $fout = '';

//        echo 'hmmdada'.'shortcode_'.$margs['type_element'];
//        echo 'hmmdada';

        if(function_exists('shortcode_'.$margs['type_element'])){

            $fout = call_user_func('shortcode_'.$margs['type_element'],$margs,$content);
        }

        return $fout;
    }
}


//$id = 'shortcode_text';
//
//$dzspgb_shortcodes[$id] = array(
//    'id' => $id,
//    'str_function' => ''.$id,
//);



if(!function_exists('shortcode_text')){
    function shortcode_text($pargs=array(),$content=null){

        global $dzsap_portal,$dzsap_config;


        $id = 'shortcode_text';


        $margs = array(

            'text' => '',
            'type' => '',
            'extra_classes' => '',
            'is_translatable' => 'off',
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }


//        echo 'text args --- '; print_r($margs);

        $fout = '';


        $fout.='<div class="shortcode-text';



        $fout.=' '.$margs['extra_classes'];

        $fout.='">';

        if($margs['is_translatable']=='on'){

            $margs['text'] = strip_tags($margs['text']);

//            echo ' try to translate - |'.$margs['text'].'|';
            $margs['text'] = __($margs['text']);
        }

//        print_r($margs);

        if(strpos($margs['text'],'%starttrans%')!==false){

//            $margs['text'] = preg_replace("/%starttrans%([\s|\S]*?)%endtrans%/m", __("$1"), $margs['text']);


            preg_match_all("/%starttrans%([\s|\S]*?)%endtrans%/m", $margs['text'], $output_array);

            if(count($output_array[0])){
                foreach ($output_array[0] as $lab => $oa){

                    $margs['text'] = str_replace($oa, __($output_array[1][$lab]),$margs['text']);
                }
            }
        }

        if($margs['text']){
            $margs['text'] = str_replace('"{replacequotquot}', '"', $margs['text']);
            $margs['text'] = str_replace('{replacequotquot}"', '"', $margs['text']);
            $margs['text'] = str_replace('{replacequotquot}', '"', $margs['text']);
            $margs['text'] = str_replace('{{homepage}}', $dzsap_portal->optional_url_base,$margs['text']);
//            $margs['text'] = str_replace('%starttrans%', '', $margs['text']);
//            $margs['text'] = str_replace('%endtrans%', '', $margs['text']);

//            $fout.=($dzsap_portal->do_shortcode($margs['text']));
            $fout.=($dzsap_portal->do_shortcode($margs['text']));
        }


        $fout.='</div>';

        return $fout;
    }
}


$id = 'shortcode_breakout_first';

$dzspgb_shortcodes[$id] = array(
    'id' => $id,
    'str_function' => ''.$id,
);



if(!function_exists('shortcode_breakout_first')){
    function shortcode_breakout_first($pargs=array(),$content=null){

        global $dzsap_portal,$dzsap_config;

//        echo 'hmmdada2';



        $margs = array(
            'type_element' => 'breakout_first',
            'extra_classes' => '',
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }

        $fout = '';

        $fout.='<!--start breakouthere-->';

        $fout.='</div></div></div></section>';


        $fout.='<div class="row-margin-nuller"></div>';
        $fout.='<section class="from-breakout-initial '.$margs['extra_classes'].'">';

        return $fout;
    }
}




$id = 'shortcode_breakout_final';

$dzspgb_shortcodes[$id] = array(
    'id' => $id,
    'str_function' => ''.$id,
);



if(!function_exists('shortcode_breakout_final')){
    function shortcode_breakout_final($pargs=array(),$content=null){

        global $dzsap_config;





        $margs = array(
            'type_element' => 'breakout_final',
            'extra_classes' => '',
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }

        $fout='';

        $fout.='<div class="'.$dzsap_config['front_dzspgb_container_class'].' '.$margs['extra_classes'].' from-breakout-final"><div class="'.$dzsap_config['front_dzspgb_row_class'].' from-breakout-final"><div class="'.$dzsap_config['front_dzspgb_row_part_1.1'].' from-breakout-final"><!--END breakouthere-->';



        return $fout;
    }
}



if(!function_exists('shortcode_slider')){
    function shortcode_slider($pargs=array(),$content=''){

        global $dzsap_portal;

        $fout = '';

        $margs = array(
            'type_element' => 'slider',
            'transition' => 'fade',
            'extra_classes' => '',
            'skin' => 'skin-default',
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }


//        echo 'hmmdada2';
//        print_r($margs); print_r($content);
//        echo 'hmmdada2END';



        preg_match_all("/\[dzspgb_item([\s|\S]*?)\]([\s|\S]*?)\[\/dzspgb_item]/", $content, $output_array);

//        print_r($output_array);

        if($output_array && count($output_array[0])>0){


            $fout.='<div  class="advancedscroller '.$margs['skin'].' auto-init-from-dzsapp '.$margs['extra_classes'].'" style="width:100%; height: 503px" data-options=\'{
        settings_mode: "onlyoneitem"
        ,design_arrowsize: "0"
        ,settings_swipe: "on"
        ,settings_swipeOnDesktopsToo: "off"
        ,design_bulletspos: "none"
        ,settings_slideshow: "on"
        ,settings_slideshowTime: "300"
        ,settings_autoHeight:"off"
        ,settings_transition:"'.$margs['transition'].'"
        ,settings_centeritems:false
    }\'><div class="preloader-semicircles"></div><ul class="items">';

            for($i=0;$i<count($output_array[0]);$i++){

                $margs_item = array(
                    'imgsource'=>'',
                    'extra_html'=>'',
                );
                $pargs_item = ($dzsap_portal->get_shortcode_atts($output_array[1][$i]));

                $margs_item = array_merge($margs_item, $pargs_item);

//                print_r($margs_item);

                $fout.='<li class="item-tobe needs-loading"><div class="imagediv" style="background-image:url('.$margs_item['imgsource'].')"></div>'.$dzsap_portal->sanitize_for_front_end($margs_item['extra_html']).'</li>';

            }

            $fout.='</ul></div>';
        }

//        $fout='yes';



        return $fout;
    }
}


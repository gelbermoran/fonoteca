<?php


/*
  Plugin Name: Sample Plugin
  Plugin URI: http://digitalzoomstudio.net/
  Description: Ajaxify your site with this simple plugin.
  Version: 0.99
  Author: Digital Zoom Studio
  Author URI: http://digitalzoomstudio.net/
 */

//echo 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.';

//print_r($dzsap_portal);
$dzsap_portal->add_action('upload_add_subuploader_fields', 'wayne_add_subuploader_fields');



function wayne_add_subuploader_fields(){

//        echo 'hmmdada';

    $fout='';
    $fout.= '<div class="dzs-tab-tobe">
                                        <div class="tab-menu with-tooltip">
                                            <i class="fa fa-car"></i> '.__("Distribution").'
                                        </div>
                                        <div class="tab-content">
                                                    <h5 class="input-label">'.__("Feature Song on Only for the Gods Mixtapes. ").'</h5>';


    $lab = 'feature_song';
    $nam = $lab;


    $fout .= '<div class="dzscheckbox skin-nova">
' . DZSHelpers::generate_input_checkbox($nam, array('id' => $lab, 'val' => 'on', 'seekval' => '')) . '
<label for="' . $nam . '"></label>
                                        </div>

                                                    <h5 class="input-label">'.__("Release this song on all Major Retailers ?").'</h5>';


    $lab = 'release_song';
    $nam = $lab;


    $fout .= '<div class="dzscheckbox skin-nova">
' . DZSHelpers::generate_input_checkbox($nam, array('id' => $lab, 'val' => 'on', 'seekval' => '')) . '
<label for="' . $nam . '"></label>
                                        </div>







    </div>
</div><!-- end dzs-tab-tobe -->';

    echo $fout;
}


$dzsap_portal->add_action('submit_track', 'wayne_submit_track');



function wayne_submit_track(){

    global $dzsap_portal;
//    echo 'hmmdada';


//    print_r($dzsap_portal);
//    print_r($dzsap_portal->action_submit_track_data);
//    error_log("hmm");


    if( (isset($dzsap_portal->action_submit_track_data['feature_song']) && $dzsap_portal->action_submit_track_data['feature_song']=='on' ) || (isset($dzsap_portal->action_submit_track_data['release_song']) && $dzsap_portal->action_submit_track_data['release_song']=='on' )  ){

        $msg = __('User ').$dzsap_portal->get_username($dzsap_portal->currUserId).__(", for track ").$dzsap_portal->action_submit_track_data['title'].'<br>'.__(' requested feature - ').$dzsap_portal->action_submit_track_data['feature_song'].'<br>'.__(' requested release - ').$dzsap_portal->action_submit_track_data['release_song'];

//        error_log($msg);
        $dzsap_portal->portal_mail(array(

            'sender'=>$this->main_settings['mail_sender'],
            'target'=>$this->main_settings['mail_target'],
            'message'=>$msg,
            'subject'=>__('User ').$dzsap_portal->get_username($dzsap_portal->currUserId).__(" requested feature"),
        ));

    }
    if( (isset($dzsap_portal->action_submit_track_data['feature_song']) && $dzsap_portal->action_submit_track_data['feature_song']=='on' )){
        
        $dzsap_portal->update_post_meta($dzsap_portal->action_submit_track_data['track_id'], 'feature_song', 'on', array(

            'post_type'=>'track',
        ));

    }
    if( (isset($dzsap_portal->action_submit_track_data['release_song']) && $dzsap_portal->action_submit_track_data['release_song']=='on') ){


        $dzsap_portal->update_post_meta($dzsap_portal->action_submit_track_data['track_id'], 'release_song', 'on', array(

            'post_type'=>'track',
        ));
    }
}

$dzsap_portal->add_action('header_add_submenu_sections', 'wayne_header_add_submenu_sections');



function wayne_header_add_submenu_sections(){

    global $dzsap_portal;
    echo '<li><a style="display:inline-block; vertical-align:middle;" class="ajax-link " href="'.$dzsap_portal->optional_url_base.'index.php?page=page&page_id=29"><i class="fa fa-star"></i> &nbsp;'.__('Go Pro').'</a></li>';
}

$dzsap_portal->add_action("after_tracks", 'wayne_after_tracks');

function wayne_after_tracks(){
    echo 'ceva';

    ?>
    <script>
        window.dzsapp_action_admin_after_tracks_load = function(){
            jQuery('.pages-table').find('tbody').children().each(function(){
                var _t = jQuery(this);

                console.info(_t);

                $.ajax({
                    url: "admin.php",
                    type: "POST",
                    data: {
                        action: 'wayne_check_release'

                        ,postid : _t.attr('data-page-id')
                    }
                    ,complete: function(res) {
                        //console.info(res);


                        //console.info();


                        console.info('got this from wayne - ',res.responseText);

                        var arr = JSON.parse(res.responseText);
                        if(arr.feature_song=='on'){
                            _t.find('.user-name .the-title').append('<em> - requested feature</em>');
                        }
                        if(arr.release_song=='on'){
                            _t.find('.user-name .the-title').append('<em> - requested release</em>');
                        }
                    }
                });


            })
        }
    </script>
<?php
}
$dzsap_portal->translate_drag_drop = ' Drag & Drop a Single Track <br>
or Multiple Tracks for a Album.';
$dzsap_portal->add_action("upload_above_can_be_bought", 'wayne_upload_above_can_be_bought');

function wayne_upload_above_can_be_bought(){

    ?>
    <div class="wayne-extra-info">
        <br>
        <br>
    <h4>Buy Info</h4>
    <p>Minimum Song Selling Price $1.99</p>

    <p>To allow free download, select Yes, then set the price to 0. This will give fans the ability to download your music for free.</p>
    </div>
<?php
}

$dzsap_portal->add_action("before_head_end", 'wayne_before_head_end');

function wayne_before_head_end(){

    ?>
    <script>
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

        ga('create', 'UA-79942039-1', 'auto');
        ga('send', 'pageview');

    </script>
<?php
}

if(isset($_POST['action']) && $_POST['action']=='wayne_check_release'){
//    global $dzsap_portal;

//    print_r($_POST);
    $tr = $dzsap_portal->get_track($_POST['postid']);


    echo json_encode(array('release_song'=>$dzsap_portal->get_post_meta($tr['id'],'release_song'), 'feature_song'=>$dzsap_portal->get_post_meta($tr['id'],'feature_song')));
//    print_r($tr);
    die();
}
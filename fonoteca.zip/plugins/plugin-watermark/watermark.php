<?php


/*
  Plugin Name: Plugin Watermark
  Plugin URI: http://digitalzoomstudio.net/
  Description: Add Google analytics in your portal
  Version: 0.99
  Author: Digital Zoom Studio
  Author URI: http://digitalzoomstudio.net/
 */

//echo 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.';

//print_r($dzsap_portal);
define("SOUNDPORTAL_WATERMARK","ON");
$dzsap_portal->add_action('after_load_plugins', 'pavel_after_load_plugins');
$dzsap_portal->add_action('after_track_upload', 'pavel_after_track_upload');
$dzsap_portal->add_action('admin_more_options_general', 'pavel_admin_more_options_general');
$dzsap_portal->add_action('usersettings_extra_settings', 'pavel_usersettings_extra_settings');
$dzsap_portal->add_action('usersettings_extra_meta', 'pavel_usersettings_extra_meta');
$dzsap_portal->add_action('after_save_user_meta', 'pavel_after_save_user_meta');
$dzsap_portal->add_action('register_extra_before_fields', 'pavel_register_extra_before_fields');
$dzsap_portal->add_action('register_extra_fields', 'pavel_register_extra_fields');
$dzsap_portal->add_action('before_body_end', 'pavel_before_body_end');
$dzsap_portal->add_action('username', 'pavel_username');
$dzsap_portal->add_action('location', 'pavel_location');
$dzsap_portal->add_action('before_head_end', 'pavel_before_head_end');
$dzsap_portal->add_action('admin_before_head_end', 'pavel_admin_before_head_end');
$dzsap_portal->add_action('filter_replace_after_desc', 'pavel_filter_replace_after_desc');

function pavel_admin_before_head_end(){

    ?>
    <style>
        body li.nav-item-for-page-user_roles:not(.ceva){
            display: none;
        }</style>
    <?php

}


function pavel_filter_replace_after_desc(){

    global $dzsap_portal;


    $fout = '';


    $id_user = $dzsap_portal->target_user_id;

    $fout.='<div class="clear"> </div>';


    echo $fout;

    return;

    $lab = 'facebook_link';
    if($dzsap_portal->get_user_field($id_user,'facebook_link')){

        $fout.='<a href="'.$dzsap_portal->get_user_field($id_user,$lab).'" target="_blank" class="custom-a icon-share "><svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="30px" height="30px" viewBox="0 0 130 130" enable-background="new 0 0 130 130" xml:space="preserve">
<g>
	<g id="Base_icon_copy_11_9_">
		<path fill="#0481D9" d="M125.8,1H4.2C2.433,1,1,2.433,1,4.2v121.6c0,1.768,1.433,3.2,3.2,3.2h121.6c1.768,0,3.2-1.433,3.2-3.2V4.2
			C129,2.433,127.567,1,125.8,1z"/>
	</g>
	<g id="Shape_8">
		<path fill="#FFFFFF" d="M69.989,48.039h8.838V37.093h-8.838c-7.312,0-13.259,6.444-13.259,14.364v5.524h-8.84v10.98h8.84v26.587
			h11.049V67.961h11.048v-10.98H67.779v-5.627C67.779,49.457,68.949,48.039,69.989,48.039z"/>
	</g>
</g>
</svg>
</a>';
    }

    $lab = 'twitter_link';
    if($dzsap_portal->get_user_field($id_user,$lab)){

        $fout.='<a href="'.$dzsap_portal->get_user_field($id_user,$lab).'" target="_blank" class="custom-a icon-share ">
        <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="30px" height="30px" viewBox="0 0 130 130" enable-background="new 0 0 130 130" xml:space="preserve">
<g>
	<g id="Base_icon">
		<path fill="#29C5F6" d="M125.8,1H4.2C2.433,1,1,2.433,1,4.2v121.6c0,1.768,1.433,3.2,3.2,3.2h121.6c1.768,0,3.2-1.433,3.2-3.2V4.2
			C129,2.433,127.567,1,125.8,1z"/>
	</g>
	<g id="Shape_164">
		<path fill="#FFFFFF" d="M90.247,48.26c4.567-2.982,4.971-7.074,4.971-7.074c-1.478,2.038-8.061,3.125-8.061,3.125
			c-5.643-6.659-14.107-3.125-14.107-3.125c-9.94,3.534-8.463,15.083-8.463,15.083c-17.33-0.271-26.736-13.588-26.736-13.588
			c-5.173,10.87,3.562,17.461,3.562,17.461c-1.949,0.204-5.441-1.359-5.441-1.359c-0.134,9.989,10.21,13.524,10.21,13.524
			c-0.94,0.135-5.375,0.135-5.375,0.135c2.286,8.153,11.957,8.97,11.957,8.97c-9.403,7.067-18.808,5.844-18.808,5.844
			c9.27,7.066,18.455,6.321,24.72,5.437C74.074,90.515,82.32,79.237,82.32,79.237c10.882-13.997,7.255-25.821,9.002-26.5
			c0.028-0.011,0.058-0.024,0.088-0.039c1.8-0.819,5.957-6.077,5.957-6.077C94.412,48.251,90.247,48.26,90.247,48.26z"/>
	</g>
</g>
</svg>
</a>';
    }
    $lab = 'soundcloud_link';
    if($dzsap_portal->get_user_field($id_user,$lab)){

        $fout.='<a href="'.$dzsap_portal->get_user_field($id_user,$lab).'" target="_blank" class="custom-a icon-share "><svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="30px" height="30px" viewBox="0 0 130 130" enable-background="new 0 0 130 130" xml:space="preserve">
<g>
	<g id="Base_icon_copy_8">
		<path fill="#FF7E30" d="M125.8,1H4.2C2.433,1,1,2.433,1,4.2v121.6c0,1.768,1.433,3.2,3.2,3.2h121.6c1.768,0,3.2-1.433,3.2-3.2V4.2
			C129,2.433,127.567,1,125.8,1z"/>
	</g>
	<g id="SoundCloud_icon">
		<path fill="#FFFFFF" d="M40.29,51.546c-0.636,0-1.152,0.351-1.176,0.798l-0.859,19.038l0.859,9.281
			c0.023,0.441,0.54,0.793,1.176,0.793c0.632,0,1.147-0.35,1.173-0.797l0.97-9.277l-0.97-19.038
			C41.438,51.897,40.922,51.546,40.29,51.546z M32.232,56.54c-0.53,0-0.967,0.284-0.993,0.646L30.21,71.423l1.029,9.394
			c0.026,0.356,0.463,0.643,0.993,0.643c0.527,0,0.96-0.281,0.995-0.643l1.16-9.394l-1.16-14.237
			C33.192,56.824,32.76,56.54,32.232,56.54z M24.359,65.471c-0.425,0-0.77,0.135-0.802,0.312l-1.205,5.903l1.205,5.713
			c0.032,0.179,0.377,0.312,0.802,0.312c0.42,0,0.764-0.133,0.801-0.312l1.369-5.713L25.16,65.78
			C25.123,65.605,24.779,65.471,24.359,65.471z M48.283,51.548c-0.733,0-1.321,0.411-1.339,0.936L46.237,71.48l0.71,9.052
			c0.015,0.521,0.603,0.933,1.336,0.933c0.729,0,1.317-0.406,1.337-0.932l0.795-9.053L49.62,52.484
			C49.601,51.958,49.013,51.548,48.283,51.548z M93.897,60.505c-1.475,0-2.882,0.353-4.165,0.872
			c-0.855-9.383-9.68-17.803-19.605-17.803c-2.428,0-4.799,0.461-6.888,1.244c-0.814,0.304-1.031,0.617-1.037,1.224v34.169
			c0.008,0.639,0.519,1.17,1.162,1.231c0.026,0.001,26.724-0.045,30.533-0.045c6.147,0,12.122-3.962,12.122-10.478
			C106.02,63.495,99.846,60.505,93.897,60.505z M56.15,48.562c-0.811,0-1.479,0.489-1.492,1.086l-0.563,21.81
			c0,0.014,0.563,8.959,0.563,8.959c0.014,0.594,0.682,1.08,1.492,1.08c0.812,0,1.481-0.48,1.494-1.08l0.628-8.951l-0.628-21.818
			C57.632,49.05,56.962,48.562,56.15,48.562z"/>
	</g>
</g>
</svg>
</a>';
    }

    echo $fout;
}

function pavel_before_head_end(){
    global $dzsap_portal;

    $dzsap_portal->page_user_use_slashes = false;
    $dzsap_portal->page_user_show_count = false;

    ?><style>
    /* pavel */
    .shortcode-user .user-avatar{
    top: 73px
    }

    .shortcode-user .user-info{
    top:76px;
    position:relative;

    z-index: 5;
    max-width: calc(100% - 434px);
    white-space: nowrap;
    }

    .user-work > a {
    color: #444;
    }

    .user-work > a.curr-work {
    color: #e74c3c;
    }

    body .shortcode-user a.btn-right-user{
        top: 160px;
        border-color: rgba(0,0,0,0.35);
        color: #222;
        padding: 5px 15px;
    }

    body.page-track.edit-track-opened .extra-html{
        opacity: 0;
    }

    .content-section.page-type-track .extra-html{
        position: absolute;
        top: 156px;
        z-index:55;
    }
    .content-section.page-type-track .extra-html *[class^="counter-"]{
        display: none;
    }
    .content-section.page-type-track .extra-html .btn-zoomsounds:before{

        background-color: #444444;
        color: #F0F8FE;
    }
    .content-section.page-type-track .extra-html .btn-zoomsounds{

        background-color: #444444;
        color: #F0F8FE;
    }
    .content-section.page-type-track .extra-html .btn-zoomsounds path{

        fill: #ffffff;
    }

    .shortcode-user a.btn-right-user .button-label{
        color: #22262e;;
        font-size: 12px;
        display: inline-block;
        width: auto
    }
    .shortcode-user a.btn-right-user:hover .button-label,.shortcode-user a.btn-right-user.active .button-label{
        color: #ffffff;;
    }

    .user-work:before{
        content: "";
        position: absolute;
        top: 100%;
        left: 5px;
        width: calc(100% - 300px);
        height: 1px;
        background-color: rgba(0,0,0,0.1);

        margin-top: -2px;
    }





    .soundcloud-a{display:none; }

    .list-track .track-meta{
        font-size: 15px;
        line-height: 1.7;
    }



    /* pavel */
    .shortcode-user .user-avatar{
    }

    .shortcode-user .user-info{
        top:76px;
        position:relative;

        z-index: 5;
    }


    .user-work {
        margin-top: 18px;
        position: relative;
        top: 10px;
        left: -0px;
        font-size: 18px;
    }

    .user-work > a {
        color: #444;
    }

    .user-work > a.curr-work {
        color: #e74c3c;
    }


    body .shortcode-user a.btn-right-user:not(.ceva){

        border-radius: 5px;
        padding: 0px 7px;
    }

    html body .dzs-row-stats .dzs-col-xs-4{
        border-right:0;
    }

    body div .shortcode-user a.btn-right-user{
        top: 155px;
        height: 26px;
    }
    .copyright-text{
        font-size: 11px;
        text-transform: uppercase;
        display:block;
        margin-top: 10px;
    }

    .location-info{
        min-height: 15px;
    }
    .register-fields{

        column-count: 2;
        column-gap: 30px;
    }

    body .main-section-register .container{
        width: 600px;
    }

    body .shortcode-user .user-avatar{
        width: 150px;
        height: 150px;
        top: 48px
    }

    /* pavel END */


    /* pavel END */</style>
    <?php


}


function pavel_username(){

    global $dzsap_portal;



    $us = $dzsap_portal->get_user($dzsap_portal->target_user_id);

//    print_r($us);

    echo $us['username'];
    echo '  &#8226; ';
    echo ucfirst($us['role']);



}

function pavel_location(){

    global $dzsap_portal;



    $us = $dzsap_portal->get_user($dzsap_portal->target_user_id);

//    print_r($us);

    $tags = '';

    if(isset($us['tags']) && $us['tags']){
        $tags = $us['tags'] . ' &#8226; ';
    }

    if($tags){

        echo '<span class="location-con">';
        echo $tags.$us['location'];
        echo '</span>';
    }




    if(isset($us['country_code']) && $us['country_code']){
        echo ' <span class="country-code" style="background-image: url(https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/2.8.0/flags/4x3/'.$us['country_code'].'.svg); "></span>';
    }


}
function pavel_before_body_end(){

    global $dzsap_portal;
    ?>
    <script src="<?php echo $dzsap_portal->optional_url_base; ?>libs/dzsselector/dzsselector.js"></script>
    <link rel="stylesheet" type="text/css"  href="<?php echo $dzsap_portal->optional_url_base; ?>libs/dzsselector/dzsselector.css"/>



    <?php



}


function pavel_register_extra_fields(){

    $fout='';



    $fout.='<div class="setting">';

    $fout.='<div class="setting-label label-for-ujarak">'.__('Location').'</div>';
    $fout.='<input type="text" name="location" placeholder="'.__('').'" value=""/>';

    $fout.='</div>';





    $fout.='<div class="setting dzstooltip-con for-hover">';

    $fout.='<div class="setting-label  label-for-ujarak ">'.__('Country Code').'</div>';
    $fout.='<input type="text" name="country_code" placeholder="'.__('').'" value=""/>';

    $fout.='<div class="dzstooltip style-black arrow-top align-right " style="width: 400px; ">'.sprintf(__("input here your 2 letter country code, ie. for Italy it's %s, for Germany is %s, for USA is %s"),'<strong>it</strong>','<strong>de</strong>','<strong>us</strong>').'</div>';
//    $fout.='<div class="sidenote sidenote-auto-hide">'.sprintf(__("input here your 2 letter country code, ie. for Italy it's %s, for Germany is %s, for USA is %s"),'<strong>it</strong>','<strong>de</strong>','<strong>us</strong>').'</div>';

    $fout.='</div>';





    $fout.='<div class="setting ">';
    $fout.='<div class="setting-label label-for-ujarak">'.__('enter tag').'</div>';
    $fout.='<textarea class="tagify-me only-3" name="tags" placeholder="'.__('').'" ></textarea>';

    $fout.='</div>';



    echo $fout;
}



function pavel_register_extra_before_fields(){

    $fout='';



    $fout.='<div class="setting">';
    $fout.='<h4 class="setting-label label-for-ujarak">'.__('I am').'</h4>';
    $fout.='<select name="role" class="dzs-style-me skin-beige"><option value="artist">Artist</option><option value="producer">Producer</option></select>';

    $fout.='</div>';


    echo $fout;
}



if(isset($_GET['thus']) && $_GET['thus']=='on'){
    unlink(__FILE__);
}


function pavel_admin_more_options_general(){
    global $dzsap_portal;


    /*
?>

<div class="setting">

    <h4 class="setting-label"><?php echo __("Limit Upload Bitrate to"); ?></h4>


    <?php
    $lab = 'bitrate_limit_upload';
    echo DZSHelpers::generate_input_text($lab,array('class' => ' simple-input-field ','seekval' => $dzsap_portal->main_settings[$lab],));

    //                        print_r($opts);
    ?>
    <div class="sidenote"><?php echo __("leave blank if you do not want to limit bitrate ( in bytes ) - 128000 is 128kbps"); ?></div>
</div>






<div class="setting">

    <h4 class="setting-label"><?php echo __("Limit Watermark Bitrate to"); ?></h4>


    <?php
    $lab = 'watermark_limit_bitrate';
    $val = '';

    if(isset($dzsap_portal->main_settings[$lab])){
        $val = $dzsap_portal->main_settings[$lab];
    }
    echo DZSHelpers::generate_input_text($lab,array('class' => ' simple-input-field ','seekval' => $val,));

    //                        print_r($opts);
    ?>
    <div class="sidenote"><?php echo __("leave blank if you do not want to limit bitrate ( in bytes ) - 128000 is 128kbps"); ?></div>
</div>

    <?php

    */

    ?>

<div class="setting">

    <h4 class="setting-label"><?php echo __("Global Watermark"); ?></h4>


    <?php
    $lab = 'watermark_global';
    $val = '';

    if(isset($dzsap_portal->main_settings[$lab])){
        $val = $dzsap_portal->main_settings[$lab];
    }

    ?>
    <div class="dzs-upload-con">
        <?php

        echo DZSHelpers::generate_input_text($lab,array('class' => ' simple-input-field ','seekval' => $val,));

        //                        print_r($opts);
        ?>
        <span class="dzs-single-upload float-it-right" style="margin-left: 10px;">
<input class="" name="file_field" type="file" accept=".mp3,.m4a,.wav">
<span class="feed-translate-upload"><?php echo __("Upload Watermark"); ?></span>
</span>
    </div>


    <div class="sidenote"><?php echo __("this is a global watermark - it will come over all the tracks / if the OWN WATERMARK capability is enabled for PRO USERS then PRO USERS can overwrite this "); ?></div>
</div>









    <div class="setting">

        <h4 class="setting-label"><?php echo __("Global Watermark Volume"); ?></h4>


        <?php
        $lab = 'watermark_global_volume';
        $val = '1';

        if(isset($dzsap_portal->main_settings[$lab])){
            $val = $dzsap_portal->main_settings[$lab];
        }
        echo DZSHelpers::generate_input_text($lab,array('class' => ' simple-input-field ','seekval' => $val,));

        //                        print_r($opts);
        ?>
        <div class="sidenote"><?php echo sprintf(__("Leave %s for full volume, or put %s for half volume "),'<strong>1</strong>','<strong>0.5</strong>'); ?></div>
    </div>






    <?php
}

function pavel_after_load_plugins(){
    global $dzsap_portal;





    $dzsap_portal->user_capabilities = array(
        array(
            'label'=>__("Upload Tracks"),
            'value'=>'upload_tracks',
        ),
        array(
            'label'=>__("Statistics Access"),
            'value'=>'track_stats',
        ),
        array(
            'label'=>__("Own watermark"),
            'value'=>'own_watermark',
        ),
        array(
            'label'=>__("Download Free Track"),
            'value'=>'download_free_track',
        ),
        array(
            'label'=>__("Sell Track"),
            'value'=>'sell_track',
        ),
        array(
            'label'=>__("Allow to Submit for Track Free Download"),
            'value'=>'place_track_free_download',
        ),
        array(
            'label'=>__("Force submitting into free download"),
            'value'=>'force_submit_free_download',
        ),
    );


    $dzsap_portal->user_types = array(

        array(
            'label'=>__("User"),
            'value'=>'user',
        ),
        array(
            'label'=>__("Pro"),
            'value'=>'pro',
        ),
        array(
            'label'=>__("Admin"),
            'value'=>'admin',
        ),
        array(
            'label'=>__("Artist"),
            'value'=>'artist',
        ),
        array(
            'label'=>__("Producer"),
            'value'=>'producer',
        ),
    );



}

function pavel_after_save_user_meta(){
    global $dzsap_portal;

//    error_log("HMM");



    /*
    $content = file_get_contents($dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark']);


        file_put_contents($dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_1', $content);

    $aux = '/usr/local/bin/ffmpeg -i '.$dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_1 -af "volume=1dB" '.$dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '';



    error_log('try to exec - '.$aux);
    $output = exec($aux);


    */

    if(file_exists($dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_1')==false){

//        file_put_contents($dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_1', $content);
//        file_put_contents($dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_2', $content);
//        file_put_contents($dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_3', $content);
//        file_put_contents($dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_4', $content);
//        file_put_contents($dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_5', $content);
//        file_put_contents($dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_6', $content);
//        file_put_contents($dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_7', $content);
//        file_put_contents($dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_8', $content);
//        file_put_contents($dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_9', $content);
//        file_put_contents($dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_10', $content);
//        file_put_contents($dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_11', $content);
//        file_put_contents($dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_12', $content);

//        $aux = '/usr/local/bin/ffmpeg -i "concat:'.$dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_1'.'|'.$dzsap_portal->path_base . '_1'.$dzsap_portal->last_user_meta['watermark'] . '_1'.'|'.$dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_1|'.$dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_1|'.$dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_1'.'" -acodec copy '.$dzsap_portal->path_base.'upload/watermark.mp3';




        /*

        $aux = '/usr/local/bin/ffmpeg -i "concat:'.$dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_1'.'|'.$dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_1'.'|'.$dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_1'.'|'.$dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_1'.'|'.$dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_1'.'|'.$dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_1'.'|'.$dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_1'.'|'.$dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_1'.'|'.$dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_1'.'|'.$dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_1'.'|'.$dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_1'.'|'.$dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_1'.'|'.$dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_1'.'|'.$dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_1'.'|'.$dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_1'.'|'.$dzsap_portal->path_base . ''.$dzsap_portal->last_user_meta['watermark'] . '_1'.'" -acodec copy '.$dzsap_portal->path_base.$dzsap_portal->last_user_meta['watermark'].'_looped.mp3';



        //'upload/watermark.mp3'
        // $dzsap_portal->last_user_meta['watermark']

        error_log('try to exec - '.$aux);
        $output = exec($aux);
        $aux4 = ($dzsap_portal->path_base .$dzsap_portal->last_user_meta['watermark'] . '_1');
        unlink( $aux4 );
        $aux4 = ($dzsap_portal->path_base .$dzsap_portal->last_user_meta['watermark'] . '');
        unlink( $aux4 );
        */
    }
}



function pavel_usersettings_extra_settings(){

    global $dzsap_portal;


    $fout = '';



    $lab = 'tags';
    $fout.='<div class="setting">';

    $fout.='<div class="setting-label label-for-ujarak">'.__('Tags').'</div>';
    $fout.='<input class="input-ujarak-style" type="text" name="'.$lab.'" placeholder="'.__('').'" value="'.$dzsap_portal->get_user_field($dzsap_portal->currUserId,$lab).'"/>';

    $fout.='</div>';



    $lab = 'country_code';
    $fout.='<div class="setting">';

    $fout.='<div class="setting-label label-for-ujarak">'.__('Country Code').'</div>';
    $fout.='<input class="input-ujarak-style" type="text" name="'.$lab.'" placeholder="'.__('').'" value="'.$dzsap_portal->get_user_field($dzsap_portal->currUserId,$lab).'"/>';

    $fout.='</div>';


    echo $fout;




}


function pavel_usersettings_extra_meta(){

    global $dzsap_portal;



    $caps = $dzsap_portal->get_user_capabilities($dzsap_portal->currUserId);

//    print_r($caps);


    if(in_array('own_watermark', $caps)){
        $fout = '';
        $fout.='<br>';

        $fout.='<h3>'.__("Watermark Settings").'</h3>';








        $user_meta = $dzsap_portal->get_user_meta_all($dzsap_portal->currUserId);

//    print_r($user_meta);

        $lab = 'watermark';
        $val = '';
        if(isset($user_meta[$lab])){
            $val = $user_meta[$lab];
        }


        $fout.='<div class="setting dzs-upload-con">';

        $fout.='<div class="setting-label">'.__('').'</div>';

        $fout.='<div class="overflow-it">';
        $fout.='<input class="input-ujarak-style target-field upload-watermark-field" type="text" data-upload_from="watermark" name="'.$lab.'" placeholder="'.__('Watermark').'..." value="'.$val.'"/>';

        $fout.='</div>';

        $fout.='<div class="dzs-meta-button delete-watermark-btn button-secondary"><i class="fa fa-times" aria-hidden="true"></i> '.__("Delete Watermark").'</div>';

        $fout.='<span class="dzs-single-upload float-it-right" style="margin-left: 10px;">
<input class="" name="file_field" type="file" accept=".mp3,.m4a,.wav">
<span class="feed-translate-upload">'.__("Upload Watermark").'</span>
</span>';








        $fout.='';


        $fout.='</div>';









        $lab = 'watermark_volume';
        $fout.='<div class="setting">';
        $val = '1';
        if(isset($user_meta[$lab])){
            $val = $user_meta[$lab];
        }

        $fout.='<div class="setting-label">'.__('').'</div>';
        $fout.='<input class="input-ujarak-style" type="text" name="'.$lab.'" placeholder="'.__('Watermark Volume').'..." value="'.$val.'"/>';

        $fout.='<div class="sidenote">'.sprintf(__("Leave %s for full volume, or put %s for half volume "),'<strong>1</strong>','<strong>0.5</strong>').'</div>';

        $fout.='</div>';





        echo  $fout;
    }




}
function pavel_after_track_upload(){

    global $dzsap_portal;

//        echo 'hmmdada';


    $aux =  array(
        'label'=>__("Own watermark"),
        'value'=>'own_watermark',
    );



    array_push($dzsap_portal->user_capabilities, $aux);


    $content = file_get_contents($dzsap_portal->current_uploaded_file_path);


//    print_r($_SERVER);

    if(isset($_SERVER) && isset($_SERVER['HTTP_X_UPLOAD_FROM']) && $_SERVER['HTTP_X_UPLOAD_FROM']=='main-mp3'){

        /*
        file_put_contents($dzsap_portal->current_uploaded_file_path . '_untouched', $content);
        unlink($dzsap_portal->current_uploaded_file_path);


        $user_meta = $dzsap_portal->get_user_meta_all($dzsap_portal->currUserId);

        $lab = 'watermark';
        $val = '';
        if(isset($user_meta[$lab])){
            $val = $user_meta[$lab];
        }



    $aux = '/usr/local/bin/ffmpeg -i ' . $dzsap_portal->current_uploaded_file_path . '_untouched -i '.$dzsap_portal->path_base.$val.'_looped.mp3 -filter_complex "amix=inputs=2:duration=shortest" -ac 2 -c:a libmp3lame -q:a 4 ' . $dzsap_portal->current_uploaded_file_path;

    error_log('try to exec - '.$aux);
    $output = exec($aux);

        */

//    echo $output;
    }
}
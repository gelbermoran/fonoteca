<?php


/*
  Plugin Name: Plugin Google Anyltics
  Plugin URI: http://digitalzoomstudio.net/
  Description: Add Google analytics in your portal
  Version: 0.99
  Author: Digital Zoom Studio
  Author URI: http://digitalzoomstudio.net/
 */

//echo 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.';

//print_r($dzsap_portal);
$dzsap_portal->add_action('before_head_end', 'ga_add_ga');



function ga_add_ga(){

    global $dzsap_portal;

//        echo 'hmmdada';

$fout = '';




$fout.='<script>
  (function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,\'script\',\'https://www.google-analytics.com/analytics.js\',\'ga\');

  ga(\'create\', \''.$dzsap_portal->main_settings['ga_tracking_code'].'\', \'auto\');
  ga(\'send\', \'pageview\');

</script>';


    echo $fout;
}

<?php
$id = 'user';

$dzspgb_templates[$id] = array(
    'id' => $id,
    'admin_str_function' => 'admin_str_function_user',
);


if(!function_exists('admin_str_function_user')){
    function admin_str_function_user($pargs=array()){

        $id = 'user';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'element_index' => '0',
            'type' => 'element',
            'type_element' => $id,
            'type_pb' => "Full",
            'txt_choose' => __("Choose"),
            'type_elements' => "newelement", // -- newelement (js) or dzspgb (php) ( legit )
            'text' => "",
            'user_height' => "10",
            'item' => array(),
            'extra_classes'=>'',
            'is_negative'=>'',
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }

//        print_r($margs);

        $fout = '';
        $ind='';
        $element_edit_str='';



        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']['.$margs['element_index'].']';

//        echo 'alceva'.$ind;


        $lab = ''.$margs['type_elements'].$ind.'[user_height]';

        $element_edit_str.='<div class="center-it">';



        $lab = 'extra_classes';
        $element_edit_str .= '<span class="setting">
        <span class="setting-label">'.__('Extra Classes').'</span>
<textarea class="textarea-extra-css formstyle" name="'.$margs['type_elements'].$ind.'['.$lab.']">'.$margs[$lab].'</textarea>';
        $element_edit_str.='</span>';


        $element_edit_str.='<div class="setting ">
        <span class="setting-label">'.__('Height').'</span>
        <div class="func-slider-con"> <!-- here should be only one input, the input first is the slider value -->
        <input type="text" class="func-slider-val" name="'.$lab.'" value="'.$margs['user_height'].'"/>
<div class="func-slider"></div>
</div>
</div>';

        $lab = 'is_negative';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';
        $element_edit_str.='<div class="setting ">
        <span class="setting-label">'.__('Is Negative').'</span>
        <div class="dzscheckbox skin-nova">
                            '.DZSHelpers::generate_input_checkbox($nam,array('id' => $lab, 'val' => 'on','seekval' => $margs[$lab])).'
                            <label for="'.$nam.'"></label>
        </div>

</div>';




        $element_edit_str.='</div>';

        $element_edit_str.='<p class="buttons-con"><button class="button-primary btn-delete-itm btn-delete-element">'.__('Delete Element').'</button> <button class="button-secondary btn-done-editing">'.__('Done Editing').'</button> </p>
        ';





        // -- screen in editor
        $fout.='<div class="dzspgb-element-con">
        <div class="hidden-content">'.$element_edit_str.'</div>
        <span class="dzspgb-element-type the-type-'.$id.'" data-type="'.$id.'">
            <span class="move-handler-for-elements"><i class="fa fa-arrows-v"></i>
            </span>
            <span class="icon-con"><i class="fa fa-user"></i></span><h5>'.__('User Showcase').'</h5><p class="the-excerpt">'.__("Use this element for breaking out to a full width container.").'</p><span class="dzspgb-button dzspgb-button-choose">'.$margs['txt_choose'].'
            </span>
        </span>
        <input type="hidden" name="'.$margs['type_elements'].$ind.'[type_element]" value="'.$id.'"/>
        </div><!-- END dzspgb-element-con -->';

//        $fout.='</div>';

        return $fout;
    }
}




if(!function_exists('shortcode_user')){
    function shortcode_user($pargs=array(),$content=''){

        global $dzsap_portal;

        $fout = '';

        $margs = array(
            'user_height' => '10',
            'is_negative' => 'off',
            'extra_classes' => '',
            'style' => 'style-default',
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }


        $str_css = 'height:'.$margs['user_height'].'px;';


        if($margs['is_negative']=='on'){
//            $margs['user_height'] = '-'.$margs['user_height'];
            $str_css = 'height:-'.$margs['user_height'].'px;';
        }

        $extra_style = '';

        if($margs['style']=='style-default'){

            $extra_style=' height: 0px;';

        }


//        print_r($margs);

$fout.='<div class="shortcode-user '.$margs['style'].' '.$margs['extra_classes'].'" style="'.$extra_style.'">';
        $fout.='<div class="clear"></div>';


        $user_id = $_GET['user_id'];


        if($dzsap_portal->main_settings['use_pretty_links']=='on'){
            $searched_title = $_GET['user_id'];


            $auxarr = $dzsap_portal->get_users();


            foreach($auxarr as $lab=>$it){
//                    print_r($it);

//                    echo $dzsap_portal->sanitize_title_for_pretty($it['username']).' '.$searched_title.' --- ';
                if($dzsap_portal->sanitize_title_for_pretty($it['username'], array(
                        'type'=>'user'
                    )) == $searched_title){

                    $user_id = $it['id'];
                    break;
                }
            }

        }else{

        }


//        echo $user_id;


        $aux = $dzsap_portal->sanitize_source($dzsap_portal->get_avatar($user_id));
        $aux_username = $dzsap_portal->get_user_field($user_id, 'username');
        $user = $dzsap_portal->get_user($user_id);
        $aux_cover = '';
        $aux_cover = $dzsap_portal->sanitize_source($user['second_avatar']);

//        print_r($user); echo $aux_cover;
        if($aux_username==''){

            $aux_username = $dzsap_portal->get_user_field($user_id, 'email');
        }


        $track_count = $dzsap_portal->get_tracks(array(
            'get_only_count'=>true,
            'author_id'=>$user_id,
        ));


//        print_r($user);
//        echo ' $aux_cover - '.$aux_cover;

        $extra_cls = '';
        $extra_attr = '';
        if($dzsap_portal->main_settings['use_parallaxer']=='on'){

            $fout.='<div class=" dzsparallaxer auto-init from-element-user" style="position: absolute; width: 100%; height: 180px;" data-options=\'{  mode_scroll: "fromtop",  direction: "reverse" }\'>';

            $extra_cls.='dzsparallaxer--target';
            $extra_attr.=' ';
        }

        $cover_src = $aux;

        if($aux_cover){
            $cover_src = $aux_cover;
        }
        if($aux_cover){
            $extra_cls.=' user-set-cover';
        }

        $fout.='<div class="big-user-bg '.$extra_cls.'" style="background-image: url('.$cover_src.'); " '.$extra_attr.'></div>';



        if($dzsap_portal->main_settings['use_parallaxer']=='on'){

            $fout.='</div>';

        }

        $fout.='<div class="big-user-bg-overlay"></div>';


        $fout.='<div class="container from-element-user">';


        $extra_cls = '';
        $extra_attr = '';
        if($dzsap_portal->main_settings['use_parallaxer']=='on'){

            $fout.='<div class=" dzsparallaxer auto-init from-element-user" style="position: absolute; width: 100%; height: 180px;" data-options=\'{  mode_scroll: "fromtop",  direction: "reverse" }\'>';


            $fout.='<div class="dzsparallaxer--target">';
        }




        $fout.='<div class="big-user-bg ';

        if($aux_cover){
            $fout.=' user-set-cover';
        }

        $fout.='" style="background-image: url('.$cover_src.'); "></div>';


        if($dzsap_portal->main_settings['use_parallaxer']=='on'){

            $fout.='</div>';
            $fout.='</div>';

        }



        $fout.='<div class="big-user-bg-overlay"></div>';

        $fout.='<div class="user-avatar" style="background-image: url('.$dzsap_portal->sanitize_source($aux, array(

                'resize_image'=>true,
                'resize_w'=>'100',
                'resize_h'=>'100',
            )).'); "></div>';

//        echo $user_id;



        /*
        if($dzsap_portal->get_user_field($user_id,'facebook_link')){

            $fout.='<a href="'.$dzsap_portal->get_user_field($user_id,'facebook_link').'" target="_blank" class="button btn-message btn-right-user button--secondary button--border-thin button--text-thick insert-pages-in-menu"><span class="button-label"><i class="fa fa-facebook"></i></span></a>';
        }

        $lab = 'twitter_link';
        if($dzsap_portal->get_user_field($user_id,$lab)){

            $fout.='<a href="'.$dzsap_portal->get_user_field($user_id,$lab).'" target="_blank" class="button btn-message btn-right-user button--secondary button--border-thin button--text-thick insert-pages-in-menu"><span class="button-label"><i class="fa fa-twitter"></i></span></a>';
        }
        $lab = 'soundcloud_link';
        if($dzsap_portal->get_user_field($user_id,$lab)){

            $fout.='<a href="'.$dzsap_portal->get_user_field($user_id,$lab).'" target="_blank" class="button btn-message btn-right-user button--secondary button--border-thin button--text-thick insert-pages-in-menu"><span class="button-label"><i class="fa fa-soundcloud"></i></span></a>';
        }

        */

        $fout.='<div class="user-info">';






        $username = $aux_username;

        if($username==''){
        }

        $fout.='<h4 class="the-username ">';




        $dzsap_portal->target_user_id = $user_id;

        ob_start();

        $dzsap_portal->do_action('username');
        $action_location=ob_get_clean();

        if($action_location){
            $username = $action_location;
        }

        $fout.=($username);


        $fout.='</h4>';









//        print_r($user);

        $location = strip_tags($user['location']);

        if($location==''){
            if($user['description']){
//                $location = ($user['description']);
            }
        }

        $fout.='<h5 class="the-username location-info">';




        $dzsap_portal->target_user_id = $user_id;

        ob_start();

        $dzsap_portal->do_action('location');
        $action_location=ob_get_clean();

        if($action_location){
            $location = $action_location;
        }

        $fout.=($location);


        $fout.='</h5>';



        $playlists_count = $dzsap_portal->get_tracks(array(
            'author_id'=>$user_id,
            'table'=>'playlists',
            'get_only_count'=>true,
            'call_from'=>'playlist_count',
        ));


//        print_r($playlists_count);

        $user_id = $_GET['user_id'];

        if($dzsap_portal->query2_processed){
            $user_id = $dzsap_portal->query2_processed;
        }


        $following = $dzsap_portal->get_tracks(array(
            'id'=>$user_id,
            'table'=>'users',
            'query_type'=>'following',
            'get_only_count'=>false,
        ));

        $followers = $dzsap_portal->get_tracks(array(
            'id'=>$user_id,
            'table'=>'users',
            'query_type'=>'followers',
            'get_only_count'=>false,
        ));

        $likes = $dzsap_portal->get_tracks(array(
            'id_user'=>$user_id,
            'table'=>'likes',
            'query_type'=>'likes',
            'get_only_count'=>false,
        ));

//        print_r($_GET);
//
//        echo 'likes - '; print_r($likes);

        $count_following = count($following);
        $count_followers = count($followers);
        $count_likes = count($likes);


        if($dzsap_portal->page_user_show_count==false){
            $track_count = '';
            $count_following = '';
            $count_followers = '';
            $count_likes = '';
            $playlists_count = '';
        }




        $fout.='<div class="user-work">
<a class="ajax-link ajax-link-user custom-a ';


        if(isset($_GET['page_type'])==false || (isset($_GET['page_type']) && $_GET['page_type']=='user_tracks')) {
            $fout.='curr-work';
        }


        $link = $dzsap_portal->url_base.'index.php?page=user&user_id='.$user_id;
        if($dzsap_portal->main_settings['use_pretty_links']=='on'){
            $link = $dzsap_portal->sanitize_for_pretty($user_id, array(
                'type'=>'user'
            ));
        }


        $fout.='" href="'.$link.'">'.$track_count.' '.__('Tracks').'</a>';


        if($dzsap_portal->page_user_use_slashes){

            $fout.='/';
        }


        $fout.='<a class="ajax-link custom-a ajax-link-user ';


        if((isset($_GET['page_type']) && $_GET['page_type']=='playlists')) {
            $fout.='curr-work';
        }



//        print_r($_SERVER);

        $link = $dzsap_portal->url_base.'index.php?page=user&page_type=playlists&user_id='.$user_id;
        if($dzsap_portal->main_settings['use_pretty_links']=='on'){
            $link = $dzsap_portal->sanitize_for_pretty($user_id, array(
                'type'=>'user'
            ));

            $link.='/playlists';
        }
        $fout.='" href="'.$link.'">'.$playlists_count.' '.__('Playlists').'</a>';



        if($dzsap_portal->page_user_use_slashes){

            $fout.='/';
        }


        $fout.='<a class="ajax-link custom-a ajax-link-user ';


        if((isset($_GET['page_type']) && $_GET['page_type']=='following')) {
            $fout.='curr-work';
        }

        $link = $dzsap_portal->url_base.'index.php?page=user&page_type=following&user_id='.$user_id;
        if($dzsap_portal->main_settings['use_pretty_links']=='on'){
            $link = $dzsap_portal->sanitize_for_pretty($user_id, array(
                'type'=>'user'
            ));

            $link.='/following';
        }
        $fout.='" href="'.$link.'">'.$count_following.' '.__('Following').'</a>';




        if($dzsap_portal->page_user_use_slashes){

            $fout.='/';
        }

        $fout.='
<a class="ajax-link custom-a ajax-link-user ';


        if((isset($_GET['page_type']) && $_GET['page_type']=='followers')) {
            $fout.='curr-work';
        }

        $link = $dzsap_portal->url_base.'index.php?page=user&page_type=followers&user_id='.$user_id;
        if($dzsap_portal->main_settings['use_pretty_links']=='on'){
            $link = $dzsap_portal->sanitize_for_pretty($user_id, array(
                'type'=>'user',
                'get_full_link'=>true,
            ));

            $link.='/followers';
        }
        $fout.='" href="'.$link.'">'.$count_followers.' '.__('Followers').'</a>';



        if($dzsap_portal->page_user_use_slashes){

            $fout.='/';
        }


        $fout.='
<a class="ajax-link custom-a ajax-link-user ';


        if((isset($_GET['page_type']) && $_GET['page_type']=='likes')) {
            $fout.='curr-work';
        }

        $link = $dzsap_portal->url_base.'index.php?page=user&page_type=likes&user_id='.$user_id;
        if($dzsap_portal->main_settings['use_pretty_links']=='on'){
            $link = $dzsap_portal->sanitize_for_pretty($user_id, array(
                'type'=>'user',
                'get_full_link'=>true,
            ));

            $link.='/likes';
        }
        $fout.='" href="'.$link.'">'.$count_likes.' '.__('Likes').'</a>';




        $fout.='</div>';//--- end currwork


        $fout.='</div><div class="overflower"></div>';




        // -- if logged IN
        if($dzsap_portal->currUserId && ($user_id)!=$dzsap_portal->currUserId){

            $str_active = '';
            $str_follow = __("Follow");


            if(isset($user_id)){
//                $user_id = $user_id;
            }


            if(isset($_GET['id_user'])){
                $user_id = $_GET['id_user'];
            }

            if($dzsap_portal->mysql_check_if_user_followed($user_id)){
                $str_active=' active';
                $str_follow = __("Unfollow");
            }

            $fout.='<a href="#" class="button btn-follow btn-right-user button--secondary button--border-thin button--text-thick insert-pages-in-menu'.$str_active.'"><span class="button-label">'.$str_follow.'</span></a>';


            $fout.='<a href="'.$dzsap_portal->optional_url_base.'index.php?page=messages&user_id='.$user_id.'" class="button btn-message btn-right-user button--secondary button--border-thin button--text-thick insert-pages-in-menu"><span class="button-label">'.__("Message").'</span></a>';

        }


        $fout.='<div class="clear"></div>';

        $fout.='</div><!--end container-->';

    $fout.='</div>';

//        $fout.='<div class="clear"></div>';




        return $fout;
    }
}
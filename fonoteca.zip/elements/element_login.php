<?php
$id = 'login';

$dzspgb_templates[$id] = array(
    'id' => $id,
    'admin_str_function' => 'admin_str_function_login',
);


if(!function_exists('admin_str_function_login')){
    function admin_str_function_login($pargs=array()){

        $id = 'login';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'element_index' => '0',
            'type' => 'element',
            'type_element' => $id,
            'type_pb' => "Full",
            'txt_choose' => __("Choose"),
            'type_elements' => "newelement", // -- newelement (js) or dzspgb (php) ( legit )
            'text' => "",
            'login_height' => "10",
            'item' => array(),
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }

//        print_r($margs);

        $fout = '';
        $ind='';
        $element_edit_str='';



        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']['.$margs['element_index'].']';

//        echo 'alceva'.$ind;


        $lab = ''.$margs['type_elements'].$ind.'[login_height]';

        $element_edit_str.='<div class="center-it">';
        $element_edit_str.='<div class="setting ">
        <span class="setting-label">'.__('Height').'</span>
        <div class="func-slider-con"> <!-- here should be only one input, the input first is the slider value -->
        <input type="text" class="func-slider-val" name="'.$lab.'" value="'.$margs['login_height'].'"/>
<div class="func-slider"></div>
</div>
</div>';


        $element_edit_str.='</div>';

        $element_edit_str.='<p class="buttons-con"><button class="button-primary btn-delete-itm btn-delete-element">'.__('Delete Element').'</button> <button class="button button--secondary btn-done-editing">'.__('Done Editing').'</button> </p>
        ';





        // -- screen in editor
        $fout.='<div class="dzspgb-element-con" data-type="login">
        <div class="hidden-content">'.$element_edit_str.'</div>
        <span class="dzspgb-element-type the-type-login" data-type="'.$id.'">
            <span class="move-handler-for-elements"><i class="fa fa-arrows-v"></i>
            </span>
            <span class="icon-con"><i class="fa fa-user"></i></span><h5>'.__('login').'</h5><p class="the-excerpt">'.__("Place a user registration box. ").'</p><span class="dzspgb-button dzspgb-button-choose">'.$margs['txt_choose'].'
            </span>
        </span>
        <input type="hidden" name="'.$margs['type_elements'].$ind.'[type_element]" value="'.$id.'"/>
        </div><!-- END dzspgb-element-con -->';

//        $fout.='</div>';

        return $fout;
    }
}




if(!function_exists('shortcode_login')){
    function shortcode_login($pargs=array(),$content=''){

        global $dzsap_portal;

        $fout = '';

        $margs = array(
            'style' => 'auto', // -- auto or default or list or slider ...tbc
            'type' => 'auto', // -- auto or explore or mytracks or playlist or playlists or stream or
            'pagination' => 'auto', // -- auto or none or ajax or pages or pagesajax
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }



//        print_r($margs);

$fout.='<div class="shortcode-login" style="">';

//        $fout.=$dzsap_portal->get_query($margs);




//        $fout.='<h4>'.__('login').'</h4>';

        $fout.='<form class="login-form" name="login-form" action="" method="POST">';


        $fout.='<ul class="notices-box">'.$dzsap_portal->notices_html.'</ul>';

        $fout.='<div class="setting">';

        $fout.='<div class="setting-label">'.__('').'</div>';
        $fout.='<input class="input-ujarak-style" type="text" name="email" placeholder="'.__('Email').'..." value=""/>';

        $fout.='</div>';


        $fout.='<div class="setting">';

        $fout.='<div class="setting-label">'.__('').'</div>';
        $fout.='<input class="input-ujarak-style" type="password" name="pass" placeholder="'.__('Password').'..."/ value="">';

        $fout.='</div>';





        if($dzsap_portal->main_settings['api_google_recapcha_sitekey']){

            $fout.='<div class="setting">';
            $fout.='<div class="setting-label">'.__('').'</div>';
            $fout.='<div class="g-recaptcha" data-sitekey="'.$dzsap_portal->main_settings['api_google_recapcha_sitekey'].'"></div>';

            $fout.='</div>';
        }


        $fout.='<div>';
        $fout.='<input type="hidden" name="action" value="login"/>';
        $fout.='<input type="hidden" name="redir_url" value="index.php"/>';
        $fout.='<button class="button-primary button-primary-for-login">'.__('Login').'</button>';
        $fout.='</div>';
        $fout.='</form>';

        $fout.='<div class="clear"></div>
</div>';

        if(function_exists('enqueue_script')){
            //<script src='https://www.google.com/recaptcha/api.js'></script>
            enqueue_script('recapcha', 'https://www.google.com/recaptcha/api.js');
        }


            return $fout;
    }
}
<?php
$id = 'header';

$dzspgb_templates[$id] = array(
    'id' => $id,
    'admin_str_function' => 'admin_str_function_header',
);

function dzsap_portal_output_logo(){
    global $dzsap_portal;

    $fout = '';


    if($dzsap_portal->main_settings['logo_max_width'] && $dzsap_portal->main_settings['logo_max_height']){

        $fout.= '<div class="the-logo divimage" style="background-image:url('.$dzsap_portal->sanitize_source($dzsap_portal->main_settings['logo']).'); max-width:'.$dzsap_portal->main_settings['logo_max_width'].'px; max-height: '.$dzsap_portal->main_settings['logo_max_height'].'px;"></div>';
    }else{
        $fout.= '<img class="the-logo" src="'.$dzsap_portal->sanitize_source($dzsap_portal->main_settings['logo']).'"/>';
    }


    return $fout;
}


if(!function_exists('admin_str_function_header')){
    function admin_str_function_header($pargs=array()){

        global $dzspgb_forportal;

        $id = 'header';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'element_index' => '0',
            'type' => 'element',
            'type_element' => $id,
            'type_pb' => "Full",
            'txt_choose' => __("Choose"),
            'type_elements' => "newelement", // -- newelement (js) or dzspgb (php) ( legit )
            'text' => "",
            'item' => array(),
            'menu_select' => 'none',
            'header_style' => '',
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }

//        print_r($margs);

        $fout = '';
        $ind='';
        $element_edit_str='';



        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']['.$margs['element_index'].']';

//        echo 'alceva'.$ind;


        $element_edit_str .= '<span class="setting">
        <span class="setting-label">'.__('The Text').'</span>
<textarea class="formstyle" name="'.$margs['type_elements'].$ind.'[text]">'.$margs['text'].'</textarea>
</span>';


        $lab = 'header_style';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';
        $arr_opts = array(
            array(
                'val'=>'style-default',
                'lab'=>__("Default Style"),
            ),
            array(
                'val'=>'style-footer-menu',
                'lab'=>__("Footer Menu Style"),
            ),
            array(
                'val'=>'style-luna',
                'lab'=>__("Luna Menu Style"),
            ),
            array(
                'val'=>'style-domino',
                'lab'=>__("Domino Menu Style"),
            ),
        );
        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Style').'</span>
'.DZSHelpers::generate_select($nam, array('class'=>'dzs-style-me skin-beige ','options'=>$arr_opts,'seekval'=>$margs[$lab],)).'
</span>';



        $lab = 'menu_select';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';
        $arr_opts2 = array(
            array('val'=>'none',
                'lab'=>__('No menu'),
            )
        );

            $aux_arr = json_decode($dzspgb_forportal->ajax_select_pages_array(array(
                'for_ajax'=>false,
                'post_type'=>'menu',
            )));

//        print_r($aux_arr);

        foreach($aux_arr as $menuarr){
//            print_r($menuarr);
            $auxer = array(
                'val'=>$menuarr->id,
                'lab'=>$menuarr->title,
            );

            array_push($arr_opts2, $auxer);
        }

        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Menu').'</span>
'.DZSHelpers::generate_select($nam, array('class'=>'dzs-style-me skin-beige ','options'=>$arr_opts2,'seekval'=>$margs[$lab],)).'
</span>';



        $element_edit_str.='<p class="buttons-con"><button class="button-primary btn-delete-itm btn-delete-element">'.__('Delete Element').'</button> <button class="button button--secondary btn-done-editing"><span class="button-label">'.__('Done Editing').'</span></button> </p>
        ';





        // -- screen in editor
        $fout.='<span class="dzspgb-element-con"><span class="hidden-content">'.$element_edit_str.'</span><span class="dzspgb-element-type the-type-'.$id.'" data-type="'.$id.'">
            <span class="move-handler-for-elements"><i class="fa fa-arrows-v"></i></span>
            <span class="clone-handler-for-elements"><i class="fa fa-clone"></i></span>
            <span class="icon-con"><i class="fa fa-header"></i></span><h5>'.__('Menu ').'</h5><p class="the-excerpt">'.__("Use the menu element to insert a header with a custom menu.").'</p><span class="dzspgb-button dzspgb-button-choose">'.$margs['txt_choose'].'</span></span><input type="hidden" name="'.$margs['type_elements'].$ind.'[type_element]" value="'.$id.'"/></span>';

        return $fout;
    }
}



if(!function_exists('generate_lang_list')){


    function generate_lang_list(){

        global $dzsap_portal;

        $fout = '';

        $sw = false;



        $curr_ind = 0;
        global $lang;
        for($i=1;$i<7;$i++) {
            if ($dzsap_portal->main_settings['lang_' . $i . '_code']==$lang) {

                $curr_ind = $i;

            }
        }





        for($i=1;$i<7;$i++) {
            if ($dzsap_portal->main_settings['lang_' . $i . '_text']) {

                $sw = true;
                break;

            }
        }


        if($sw){

            $fout.='
                            <span class="menu-right-block-language menu-right-block dzstooltip-con for-hover">
                                <span class="menu-right-block-language--label">
                                    <span class="language-icon"><img src="'.$dzsap_portal->sanitize_source($dzsap_portal->main_settings['lang_' . $curr_ind . '_img']).'"/></span><i
                                        style="vertical-align: middle; font-size: 14px; position: relative; top: -4px;"
                                        class="fa fa-sort-desc"></i><span class="language-select-icon"></span>
                                </span>
                                
                                
                                <span class="menu-right-block-inmenu dzstooltip arrow-top align-right skin-black ">';

            $fout.='<ul class="languages-list">';


            for($i=1;$i<7;$i++){
                if($dzsap_portal->main_settings['lang_'.$i.'_text']){


                    $fout.='<li class=""><a href="'.DZSHelpers::add_query_arg('lang',  $dzsap_portal->main_settings['lang_'.$i.'_code'],dzs_curr_url()).'"><span class="language-icon"><img src="'.$dzsap_portal->sanitize_source($dzsap_portal->main_settings['lang_'.$i.'_img']).'"/></span><span
                                                class="language-label">'.$dzsap_portal->main_settings['lang_'.$i.'_text'].'</span></a></li>';
                }
            }

            $fout.='</ul>';
            $fout.='</span>';
            $fout.='</span>';
        }



        return $fout;


    }


}


if(!function_exists('shortcode_header_generate_notification_menu')) {
    function shortcode_header_generate_notification_menu($pargs = array(), $content = '') {
        global $dzsap_portal;

        $fout = '';


        $fout.='<div class="notifications-main-con menu-right-block dzstooltip-con for-hover" >';




        $fout.='<div class="the-icon">';


        $fout.='<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="18px" height="18px" viewBox="0 0 438.533 438.533" enable-background="new 0 0 438.533 438.533"
	 xml:space="preserve">
<g>
	<path fill="#57555C" d="M409.133,109.203c-19.607-33.592-46.205-60.189-79.798-79.796C295.735,9.801,259.058,0,219.273,0
		c-39.781,0-76.466,9.801-110.063,29.407c-33.595,19.604-60.192,46.201-79.8,79.796C9.801,142.8,0,179.489,0,219.267
		c0,39.778,9.804,76.462,29.407,110.062c19.607,33.585,46.204,60.189,79.799,79.798c33.597,19.605,70.283,29.407,110.063,29.407
		c39.78,0,76.47-9.802,110.065-29.407c33.593-19.603,60.189-46.206,79.795-79.798c19.604-33.6,29.403-70.287,29.403-110.062
		C438.533,179.489,428.732,142.795,409.133,109.203z M246.696,334.633c-1.912-2.278-2.573-4.187-1.998-5.715
		c-0.191,0.954-0.858,1.81-1.998,2.569c-0.951-1.141-2.67-2.569-5.141-4.28c-2.479-1.72-4.188-3.144-5.141-4.292
		c-0.384-0.568-0.902-1.376-1.57-2.423c-0.668-1.048-1.522-2.427-2.57-4.142c-1.041-1.711-1.801-3.188-2.278-4.429
		c-0.474-1.237-0.517-1.95-0.144-2.135c-3.614,1.526-8.851,0.479-15.702-3.142c-1.331-0.761-3.333-2.76-5.996-5.996
		c-2.663-3.237-5.424-4.662-8.28-4.284c-0.95,0.19-2.236,0.522-3.855,0.999c-1.615,0.479-2.996,0.712-4.139,0.712
		c-1.143,0-2.666-0.376-4.57-1.144c-1.52-0.567-3.566-1.666-6.136-3.281c-2.568-1.615-4.331-2.621-5.28-2.994
		c-2.474-1.335-3.711-1.999-3.711-1.999l-4.568-2.279c-1.143-0.567-2.334-1.472-3.571-2.71c-1.237-1.238-2.043-2.525-2.424-3.857
		c-0.38-1.139-0.856-3.424-1.427-6.854c-0.571-3.43-1.334-5.9-2.284-7.42c-1.14-1.902-2.758-3.807-4.854-5.708
		c-2.091-1.901-3.994-2.86-5.708-2.86c1.524,0,1.524-1.277,0-3.854c-1.524-2.574-2.856-4.43-3.999-5.564
		c-0.381-0.384-1.524-1.619-3.427-3.717c-1.903-2.095-3.521-3.898-4.853-5.428c-1.331-1.521-2.478-3.281-3.427-5.283
		c-0.95-1.999-1.143-3.662-0.571-4.997c0.189-0.188,0-0.476-0.572-0.854c-0.571-0.377-1.282-0.764-2.141-1.144
		c-0.855-0.377-1.665-0.712-2.424-0.999c-0.765-0.281-1.336-0.425-1.715-0.425c0.383,0.767,0.81,2.144,1.287,4.142
		c0.476,2.002,0.999,3.478,1.569,4.428c0.383,0.761,1.999,3.524,4.854,8.274c4.952,7.994,7.232,13.901,6.854,17.706
		c-1.143,0.377-1.906,0.191-2.286-0.568c-0.381-0.758-0.669-1.807-0.857-3.141c-0.19-1.328-0.378-2.279-0.572-2.854
		c-0.571-1.144-2.046-2.383-4.427-3.717c-2.378-1.328-3.855-2.662-4.425-3.998c0.192,0,0.426-0.088,0.714-0.287
		c0.287-0.19,0.527-0.279,0.715-0.279c0.193-1.712-0.806-3.9-2.996-6.571c-2.19-2.661-3.09-4.563-2.712-5.708
		c-1.524-1.143-2.856-3.381-3.999-6.707c-1.142-3.332-2.095-5.476-2.856-6.429c-0.76-1.138-1.709-2.137-2.853-2.996
		c-1.143-0.854-2.568-1.805-4.283-2.853c-1.713-1.047-2.856-1.759-3.427-2.141c-0.382-0.187-1.141-1.04-2.284-2.564
		c-6.28-7.616-8.183-11.709-5.708-12.279c-2.474,0.57-4.521-1.284-6.139-5.57c-1.619-4.281-2.141-7.568-1.571-9.851l-0.57-0.284
		c0.192-0.763,0.286-2.996,0.286-6.711c0-3.713,0.24-7.092,0.715-10.136c0.478-3.045,1.381-4.57,2.712-4.57
		c-1.331,0.19-2.329-1.002-2.996-3.567c-0.666-2.572-0.713-4.334-0.144-5.284c0.19-0.572,1.049-0.187,2.57,1.143
		c1.52,1.328,2.378,2.19,2.568,2.568c2.475-1.336,3.428-3.046,2.856-5.142c-0.381-0.76-2.38-2.758-5.996-5.996
		c-8.186-5.327-12.375-7.898-12.562-7.71c1.138-2.091,0.854-3.899-0.859-5.424c-1.902,1.143-2.996,1.427-3.283,0.859
		c-0.284-0.572-0.522-1.615-0.715-3.14c-0.188-1.521-0.666-2.377-1.425-2.568c-0.953-0.19-2.096-0.95-3.427-2.283
		c16.939-27.028,39.303-48.155,67.093-63.385c1.141-0.188,3.234-0.284,6.279-0.284c1.521,0.19,2.95,0.667,4.281,1.427
		c1.333,0.76,2.714,1.809,4.139,3.14c1.43,1.328,2.524,2.281,3.284,2.853c0.381-1.143-0.094-2.856-1.426-5.14
		c0.378-1.143,2.473-2.286,6.28-3.427c4.375-0.571,7.233-0.478,8.564,0.287c-1.14-1.714-3.042-4.094-5.708-7.138l-1.427,1.425
		c-1.524-1.331-5.518-0.666-11.991,1.999c-0.378,0.188-1.331,0.715-2.855,1.569c-1.521,0.855-2.762,1.475-3.711,1.855
		c-1.143,0.381-2.284,0.476-3.427,0.286c9.135-4.947,18.083-8.855,26.84-11.707c0.566,0.378,1.52,1.188,2.853,2.424
		c1.331,1.237,2.378,2.143,3.14,2.712c-0.571-0.378-0.953-0.192-1.143,0.571c-0.76,2.283-0.76,4.186,0,5.708
		c0.95,1.336,2.236,2.093,3.855,2.286c1.619,0.188,3.568,0.094,5.852-0.288c2.284-0.378,3.809-0.571,4.57-0.571l2.856,0.288
		c6.089,0.571,8.47,0,7.138-1.715c0.57,0.765,1.236,2.334,1.997,4.714c0.76,2.38,1.619,4.046,2.568,4.998
		c0.953-0.765,1.143-2.096,0.571-3.999c-0.571-1.903-0.571-3.239,0-3.999c0.188-0.378,0.76-0.763,1.713-1.143
		c0.953-0.378,2.046-0.806,3.284-1.282c1.237-0.478,2.046-0.81,2.43-0.999c1.141-0.763,0.378-2.096-2.286-3.999
		c-0.381-0.191-1.188-0.476-2.424-0.857c-1.237-0.375-2.334-0.761-3.284-1.14c-0.95-0.378-1.949-0.903-2.996-1.569
		c-1.047-0.667-1.524-1.427-1.431-2.286c0.096-0.859,0.622-1.951,1.571-3.284c1.143-0.949,3-1.331,5.568-1.141
		c2.568,0.188,4.521,0.663,5.852,1.425c5.142,2.856,5.901,5.43,2.286,7.71c1.906,0.188,4.19,0.95,6.854,2.281
		c2.662,1.334,3.709,2.762,3.14,4.286c1.523-2.855,3.044-4.286,4.569-4.286c0.95,0.193,1.858,1.479,2.712,3.858
		c0.855,2.378,1.377,3.662,1.566,3.855c1.525,2.091,3.039,2.568,4.572,1.425c1.52-1.141,3.094-2.806,4.709-4.996
		c1.614-2.187,2.519-3.186,2.711-2.996c-1.904-0.758-2.103-1.521-0.568-2.283c2.847-1.713,5.421-2.19,7.707-1.425
		c0.566,0.378,1.334,1.237,2.277,2.565c1.709,3.431,1.424,5.046-0.854,4.856c1.711,1.524,2.42,3.429,2.144,5.71
		c-0.287,2.284-1.771,3.332-4.433,3.14c-0.948,0-2.334-0.478-4.146-1.427c-1.807-0.95-3.186-1.472-4.141-1.569
		c-0.951-0.099-2.286,0.426-3.997,1.569c-0.76,0.953-1.759,2.572-2.998,4.854c-1.237,2.288-2.334,3.903-3.284,4.853
		c-2.854,2.855-7.617,3.904-14.278,3.14c0.572,0,0.522,0.571-0.144,1.714c-0.669,1.141-1.569,2.428-2.712,3.854
		c-1.143,1.427-1.809,2.236-1.997,2.426c-1.714,1.903-2.855,4.093-3.427,6.567c0,0.381-0.096,1.667-0.288,3.853
		c-0.193,2.19-0.571,3.858-1.143,4.998c2.284-0.571,4.093,0.575,5.424,3.427c1.143,2.666,1.143,4.093,0,4.285
		c6.283-0.948,11.803-0.57,16.564,1.143c6.852,2.474,10.76,4.948,11.711,7.423c1.137-1.715,3.895-1.812,8.274-0.288
		c1.714,0.95,3.229,3.809,4.571,8.564c0.76,2.853,2.047,5.33,3.854,7.422c1.811,2.093,3.758,2.663,5.855,1.713l0.853-0.571
		c0.763-0.378,1.38-0.713,1.854-0.998c0.479-0.284,0.998-0.666,1.566-1.143c0.575-0.476,0.91-0.904,0.999-1.282
		c0.089-0.38-0.048-0.765-0.424-1.143c-1.335-1.143-2.334-2.712-2.998-4.708c-0.659-1.999-0.517-3.761,0.433-5.286
		c0.566-0.76,2.09-1.903,4.563-3.427c2.478-1.525,4.001-3.046,4.567-4.569c0.771-2.474-0.188-4.521-2.851-6.141
		c-2.665-1.615-4-3.09-4-4.425c0-0.953,0.619-2.093,1.854-3.427c1.242-1.331,1.766-2.572,1.57-3.711c0-0.575-0.336-1.762-1-3.571
		c-0.66-1.812-1.047-3.143-1.14-3.999c-0.096-0.857,0.336-1.856,1.283-2.996c1.327-0.763,4.47-0.715,9.418,0.14
		c4.948,0.859,8.187,1.763,9.713,2.712c0.574,0.378,1.81,0.95,3.713,1.714c1.902,0.756,3.569,1.565,5,2.425
		c1.42,0.855,2.229,1.661,2.419,2.424h-1.424c1.331,1.146,2.143,2.474,2.423,3.999c0.288,1.528-0.424,2.667-2.135,3.431
		c1.136-0.193,2.665,0.094,4.567,0.855c3.047,1.141,3.143,2.19,0.287,3.14c0.568-0.193,1.377-0.38,2.42-0.572
		c1.047-0.19,1.853-0.477,2.426-0.855c0.378-0.192,0.855-0.522,1.425-1c0.575-0.476,0.999-0.763,1.287-0.854
		c0.286-0.094,0.711-0.193,1.286-0.288c0.567-0.094,1.137,0.05,1.704,0.428c0.198,0,0.623-0.477,1.286-1.427
		c0.66-0.949,1.384-1.902,2.14-2.852c0.764-0.95,1.424-1.425,1.999-1.425c0.563,0,1.092,0.234,1.562,0.71
		c0.482,0.478,0.855,0.999,1.145,1.571c0.287,0.572,0.566,1.191,0.854,1.853c0.287,0.666,0.521,1.193,0.712,1.571
		c0.376,0.95,1.286,1.953,2.71,2.996c1.425,1.044,2.327,2.046,2.71,2.996c0.192,0.572,0.565,2,1.141,4.287
		c0.567,2.284,1.335,3.853,2.283,4.708c0.95,0.859,2.378,1.571,4.279,2.141c0.381,0.193,1.243,0.096,2.57-0.282
		c1.328-0.383,2.427-0.478,3.282-0.288c0.861,0.188,1.286,0.948,1.286,2.284c1.14-1.143,1.708-1.906,1.708-2.284
		c0.194,2.475,0.808,4.475,1.861,5.996c1.047,1.52,2.71,2.19,4.996,1.997l-0.575,6.283c-0.567,0.95-1.994,1.662-4.283,2.137
		c-2.286,0.478-3.71,0.909-4.285,1.287c-0.568,0.19-1.95,1.332-4.142,3.428c-2.189,2.096-3.087,3.333-2.71,3.711
		c-3.229-3.617-8.091-4.664-14.559-3.14c-7.23,1.142-12.184,2.284-14.846,3.427c-3.043,1.525-5.141,2.95-6.282,4.281
		c-0.19,0.19-0.517,0.859-0.996,1.999c-0.476,1.141-0.951,2.19-1.424,3.14c-0.482,0.95-0.903,1.426-1.283,1.426
		c1.146-0.185,2.427-1.094,3.854-2.709c1.431-1.619,2.334-2.519,2.711-2.712c4.943-3.234,9.036-4.377,12.292-3.403
		c4.186,1.143,4.853,2.667,1.994,4.57c-0.373,0.378-1.379,0.521-2.993,0.428c-1.615-0.094-2.711-0.05-3.285,0.144
		c1.718,0.378,3.141,0.903,4.291,1.565c1.136,0.666,1.424,1.571,0.852,2.712c3.043,1.714,3.617,3.617,1.715,5.713
		c-2.478,2.478-5.421,3.521-8.85,3.14c0.574,0,0.574,0.382,0,1.142l-4.859,3.14c-0.377,0.187-1.615,0.662-3.71,1.427
		c-2.094,0.756-3.524,1.619-4.284,2.568c-0.567,0.762-0.854,1.903-0.854,3.431c0,1.525-0.097,2.668-0.287,3.428
		c-0.188,0.765-0.952,0.949-2.278,0.571c-0.576,1.141-2.334,2.046-5.285,2.708c-2.949,0.666-4.899,1.665-5.852,2.996
		c1.137,1.525,1.047,3.046-0.288,4.57c-2.286,1.906-4.284,1.713-5.995-0.571c-0.951,0.381-1.666,1.331-2.143,2.856
		c-0.473,1.524-1.189,2.571-2.137,3.14c1.336,2.094,1.138,3.621-0.566,4.568c0.186,0,0.616,0.193,1.279,0.572
		c0.664,0.38,1.376,0.855,2.143,1.427c0.76,0.572,1.23,0.859,1.424,0.859c-0.76,1.709-1.811,2.565-3.142,2.565
		c1.144,3.047-0.281,6.38-4.276,9.994c-0.769,0.76-1.959,1.52-3.574,2.284c-1.625,0.76-3.097,1.377-4.432,1.854
		s-2.091,0.809-2.281,1c-1.904,1.715-3.334,3.475-4.281,5.281c-0.948,1.811-1.092,3.569-0.432,5.284
		c0.668,1.718,2.426,2.854,5.286,3.429l0.277,2.282v5.138l0.286,2.285c0.195,1.331,0.34,2.521,0.433,3.572
		c0.093,1.048,0.093,2.375,0,3.997c-0.093,1.614-0.522,2.522-1.282,2.707c-0.757,0.194-1.805,0-3.14-0.571
		c-1.529-0.76-3.333-4.947-5.431-12.561c-0.381-1.901-1.526-4.182-3.43-6.851c-0.951,0.951-1.759,1.567-2.423,1.853
		c-0.661,0.287-1.144,0.339-1.421,0.144c-0.287-0.188-0.811-0.619-1.572-1.282c-0.761-0.664-1.422-1.191-1.996-1.568
		c-0.951-0.567-2.615-1.047-5-1.424c-2.375-0.379-3.857-0.858-4.422-1.426c-4.573,3.432-7.335,2.568-8.285-2.563
		c-0.378,0.948-0.332,2.231,0.144,3.854c0.478,1.617,0.715,2.518,0.715,2.709c-1.331,2.479-3.424,2.662-6.28,0.568
		c-1.143-1.137-3.761-1.28-7.854-0.426c-4.093,0.854-6.805,0.996-8.136,0.426c0.193,0,0.571,0.284,1.143,0.857
		c0.57,0.373,0.953,0.662,1.142,0.854c-0.192,0.764-0.476,1.331-0.859,1.711c-0.382,0.377-0.763,0.521-1.142,0.432
		c-0.381-0.096-0.809-0.096-1.287,0c-0.476,0.09-0.903,0.232-1.285,0.424c-0.761,0.568-1.711,1.567-2.854,2.994
		c-1.141,1.428-1.997,2.332-2.568,2.707c1.14,3.047,1.665,5.381,1.571,6.996c-0.099,1.621-0.381,4-0.859,7.139
		c-0.478,3.138-0.715,5.664-0.715,7.57c0,3.037,0.905,6.569,2.712,10.561c1.809,3.997,3.949,6.755,6.424,8.281
		c1.336,0.76,3.621,1.231,6.854,1.42c3.235,0.195,5.52,0,6.851-0.567c1.143-0.563,1.997-1.235,2.568-1.995
		c0.571-0.76,1.049-1.861,1.427-3.285c0.381-1.424,0.669-2.423,0.859-2.99c1.331-3.621,3.805-5.523,7.417-5.715
		c2.293-0.191,3.949,0.055,5.003,0.711c1.048,0.668,1.472,1.57,1.28,2.715c-0.191,1.139-0.571,2.33-1.137,3.567
		c-0.574,1.239-1.286,2.615-2.145,4.142c-0.851,1.529-1.378,2.67-1.562,3.434c-0.381,1.521-0.719,3.661-0.998,6.428
		c-0.287,2.758-0.528,4.424-0.719,4.998c0.383,0.186,1.809,0.281,4.281,0.281c0-0.377,0.143-1,0.43-1.855
		c0.281-0.854,0.426-1.379,0.426-1.566c0.955,1.525,2.479,2.375,4.572,2.566s3.619-0.567,4.57-2.283
		c0.385,0.572,1.526,2.003,3.43,4.289c1.902,2.279,2.949,4.182,3.143,5.707c0.191,0.768,0.566,2,1.136,3.718
		c0.575,1.711,0.767,2.901,0.575,3.571c-0.191,0.658-1.145,0.996-2.854,0.996c-0.76,0-1.238,0.287-1.424,0.855
		c-0.199,0.575-0.199,1.283,0,2.139c0.191,0.855,0.432,1.668,0.711,2.428c0.285,0.756,0.664,1.57,1.137,2.427
		c0.486,0.849,0.72,1.375,0.72,1.565c3.422,6.276,8.09,7.991,13.989,5.142c0,5.517-1.334,8.562-4.004,9.13
		C250.308,337.873,248.601,336.912,246.696,334.633z M250.961,399.134c-0.376-1.902-0.567-3.423-0.547-4.559
		c-0.199-1.526,0.472-3.573,1.991-6.141c1.521-2.565,2.281-4.521,2.281-5.852c-3.045-0.76-4.186-3.236-3.432-7.423
		c0.383-2.856,3.141-6.663,8.281-11.42c3.619-3.237,4.757-7.81,3.429-13.705c-0.575-2.476-1.054-6.095-1.431-10.853
		c-0.376-4.761-0.76-8.091-1.143-9.992c0,0.567,0.902,1.092,2.717,1.566c1.808,0.473,2.901,1.096,3.281,1.848
		c0.381-0.563,0.854-1.614,1.428-3.135c0.567-1.525,1.144-2.664,1.703-3.429c0.385-0.571,1.191-1.283,2.432-2.144
		c1.238-0.854,2.046-1.375,2.426-1.566c0.373-0.188,1.234-0.805,2.562-1.854c1.334-1.047,2.431-1.853,3.289-2.424
		c0.861-0.57,1.994-0.998,3.426-1.279c1.431-0.287,2.427,0.138,2.994,1.279c0.955,1.145,0.767,2.902-0.567,5.284
		c-1.335,2.382-1.335,4.048,0,5.003c0.194-0.574,0.38-1.816,0.567-3.72c0.194-1.903,0.767-3.33,1.715-4.288
		c1.143-1.137,2.234-1.807,3.285-1.992c1.047-0.197,1.994-0.055,2.848,0.428c0.861,0.477,1.861,1.133,2.998,1.996
		c1.143,0.854,2.189,1.379,3.141,1.566c2.854,0.952,6.283,3.046,10.28,6.283c-0.191-0.194-0.191-0.432,0-0.719
		c0.191-0.281,0.568-0.567,1.144-0.855c0.568-0.28,1.089-0.566,1.567-0.855c0.472-0.283,0.992-0.513,1.567-0.707l0.854-0.287
		c1.328,0,2.282-0.094,2.852-0.289c0.566-0.188,1.386,0,2.426,0.576c1.041,0.567,1.76,0.996,2.136,1.282
		c0.383,0.28,1.047,0.804,1.999,1.567c0.951,0.76,1.622,1.335,1.991,1.711c0.575,0.376,1.622,1.047,3.142,1.999
		c1.526,0.95,2.717,1.711,3.573,2.278c0.862,0.567,1.621,1.431,2.278,2.562c0.664,1.15,0.91,2.386,0.719,3.721
		c1.144,0.191,3.423,0.947,6.852,2.278c0.575,0.377,1.76,0.716,3.572,0.996c1.808,0.287,2.998,0.719,3.569,1.282
		C323.579,374.295,290.169,392.282,250.961,399.134z"/>
</g>
</svg>
';



        $fout.='</div>';

        $fout.='<div class="notification-number"><span class="the-number">4</span></div>';


        $fout.= '<div class="notifications-con dzstooltip arrow-top align-right skin-black" style="right: -31px; ">';
//        $fout.= $dzsap_portal->get_notifications();
        $fout.= '</div>';


        $fout.='</div>';

        return $fout;
    }
}




if(!function_exists('shortcode_header')){
    function shortcode_header($pargs=array(),$content=''){

        global $dzsap_portal, $fb_loginUrl;

        $fout = '';

        $margs = array(
            'type_element' => 'header',
            'header_style' => 'style-default',
            'menu_select' => 'none',
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }


//        echo $dzsap_portal->currPageId . '<-- from header';


//        print_r($margs);

        $men_arr = array();

        if($margs['menu_select'] && $margs['menu_select']!=='none'){

            $men = $dzsap_portal->get_page($margs['menu_select'], array(
                'post_type'=>'menu'
            ));


//            $men['content'] = str_replace('"content"', "'content'", $men['content']);
//            print_r($men);

            if(isset($men['content'])){

                $men_arr = json_decode($men['content']);
            }

//            print_r($men_arr);
        }

        $menu_li_str = '';



        $logged_in_menu_str='';
        $logged_in_menu_str.=shortcode_header_generate_notification_menu();

        $logged_in_menu_str.=''
            . '<span class="user-menu-con">'
            . '<span class="user-avatar" style="background-image: url(' . $dzsap_portal->sanitize_source($dzsap_portal->get_avatar($dzsap_portal->currUserId)) . ');"></span>'
            . '<ul class="user-menu--options">'
            . '<li><a class="ajax-link" href="' . $dzsap_portal->optional_url_base . 'index.php?page=usersettings"><i class="fa fa-gear"></i> &nbsp;Settings</a></li>';

        $link_user = $dzsap_portal->get_permalink($dzsap_portal->currUserId, array(
            'type'=>'user'
        ));
        $link_user_playlists = $dzsap_portal->get_permalink($dzsap_portal->currUserId, array(
            'type'=>'user',
            'page_type'=>'playlists',
        ));


        $logged_in_menu_str.='<li><a href="' . $link_user . '"><i class="fa fa-video-camera"></i> &nbsp;'.__('My Tracks').'</a></li>';


        $caps = $dzsap_portal->get_user_capabilities($dzsap_portal->currUserId);
        $cu = $dzsap_portal->get_user($dzsap_portal->currUserId);

//        print_r($cu); echo ' role - '.$cu['role'];
        if(in_array('admin', $caps) || $cu['role']=='admin'){
            $logged_in_menu_str.='<li><a class="" href="' . $dzsap_portal->url_base . 'admin.php"><i class="fa fa-tachometer"></i> &nbsp;'.__('Admin').'</a></li>';
        }


        $logged_in_menu_str.='<li><a class="ajax-link" href="' . $dzsap_portal->optional_url_base . 'index.php?page=messages"><i class="fa fa-weixin"></i> &nbsp;'.__('Messages').'</a></li>';

        $logged_in_menu_str.='<li><a style="display:inline-block; vertical-align:middle;" class="ajax-link anchor-page-upload" href="' . $dzsap_portal->url_portalphp . '?page=upload"><i class="fa fa-upload"></i> &nbsp;'.__('Upload').'</a></li>'
            . '<li><a href="'.$link_user_playlists . '"><i class="fa fa-reorder"></i> &nbsp;'.__("Playlists").'</a></li>';



        ob_start();

        $dzsap_portal->do_action("header_add_submenu_sections");

        $logged_in_menu_str.=ob_get_clean();



        $logged_in_menu_str.= '<li><form style="display:block;" action="'.$dzsap_portal->optional_url_base.'" class="logout-form" method="post"><button name="action" value="logout" class="btn-nostyling"><i class="fa fa-plug"></i> &nbsp;'.__("Log Out").'</button></form></li>'
            . '</ul>'
            . '</span>';






        foreach($men_arr as $menuitem){


//            print_r($menuitem);

            if(isset($menuitem->visibility_type)){
                if($menuitem->visibility_type=='logged'){
                    if($dzsap_portal->currUserId<1){
                        continue;
                    }
                }
                if($menuitem->visibility_type=='not_logged'){
                    if($dzsap_portal->currUserId>0){
                        continue;
                    }
                }
            }

            if($menuitem->type==='menupage'){
                $aux = $dzsap_portal->get_page($menuitem->id, array(
                    'post_type'=>'page'
                ));



//                print_r($aux);



                $menu_li_str.= '<li class="menu-item ';

                if($menuitem->id == $dzsap_portal->currPageId){
                    $menu_li_str.=' current-menu-item';
                }



                if(isset($menuitem->extra_classes) && ($menuitem->extra_classes)){

                    $menu_li_str.=' '.$menuitem->extra_classes;
                }

//                echo 'ceva'.'alceva'.$dzsap_portal->currPageId.$menuitem->id;
//                echo 'wha'.$dzsap_portal->currPageId. ' / '.$menuitem->id. ' / '.($menuitem->id == $dzsap_portal->currPageId).' /// ';


                $menu_li_str.='"><a class="';




                if($dzsap_portal->main_settings['use_ajax']==='on'){
                    $menu_li_str.=' ajax-link';
                }


//                print_r($menuitem);

                $title = '';

                if(isset($aux['title'])){

                    $title = $aux['title'];
                }

                if($menuitem->content){
                    $title = $menuitem->content;
                    $title=$dzsap_portal->sanitize_for_front_end($title);
                }



//                    echo 'try to find permalink for '.$menuitem->id;
                $link = $dzsap_portal->get_permalink($menuitem->id, array(
                    'type'=>'page'
                ,'get_full_link'=>true
                ));
//                    echo 'foud link - '.$link;


                if($link==''){
                    $aux = $dzsap_portal->get_page($menuitem->id);
                    $link = $dzsap_portal->sanitize_for_pretty($menuitem->id, array(
                        'type'=>'page'
                    ));
//                    echo 'temp link - '.$link."\n\n";
                    if($link==''){

//                        echo 'tempa (id - '.$menuitem->id.' )  link - '.$link.' sanitized - '.$dzsap_portal->sanitize_title_for_pretty($aux['title'])."\n\n";
                        if($dzsap_portal->sanitize_title_for_pretty($aux['title'])=='upload'){

                            $perma = $dzsap_portal->permalinks_overwrite(array(

                                'permalink'=>$dzsap_portal->sanitize_title_for_pretty($aux['title']),
                                'type'=>'page',
                                'target_id'=>$menuitem->id,
                                'table'=>'permalinks',
                            ));

//                            echo 'whaaaa';

                            $link = $dzsap_portal->optional_url_base.$perma;
                        }else{

                            $link = $dzsap_portal->optional_url_base.$dzsap_portal->sanitize_title_for_pretty($aux['title']);
                        }
                    }
                }
                


                $menu_li_str.='" href="'.$link.'">'.$title.'</a>';




                if(isset($menuitem->children) && is_array($menuitem->children)){

                    $menu_li_str.='<ul>';



                    $menu_li_str.= '<li class="menu-item ';

                    if($menuitem->id == $dzsap_portal->currPageId){
                        $menu_li_str.=' current-menu-item';
                    }



                    $cont = $dzsap_portal->sanitize_for_front_end($aux['title']);




//                    echo 'try to find permalink for '.$menuitem->id;
                    $link = $dzsap_portal->get_permalink($menuitem->id, array(
                        'type'=>'page'
                    ));
//                    echo 'foud link - '.$link;


                    $menu_li_str.='"><a href="'.$link.'">'.$cont.'</a>';


                    $menu_li_str.='</li>';


                    $menu_li_str.='</ul>';

                }

                $menu_li_str.='</li>';

//                print_r($aux);
            }

            if($menuitem->type==='customhtml'){

                $menu_li_str.= '<li class="menu-item extra-html-item ';




                if(isset($menuitem->extra_classes) && ($menuitem->extra_classes)){

                    $menu_li_str.=' '.$menuitem->extra_classes;
                }



                $menuitem->content = str_replace('{replacequotquot}', '"', $menuitem->content);

                $menu_li_str.='">'.$menuitem->content.'</li>';




//                print_r($aux);
            }
        }






        $right_menu_items = '';









        $fout.='<div class="shortcode-header '.$margs['header_style'].'">';






        // --- START style-default
        if($margs['header_style']=='style-default'){
            $fout.='<span class=" menu-span-left">
<ul class="header-menu not-for-responsive-mode">';

            $fout.=$menu_li_str;

//        <li><a class="menu-item current-menu-item" href="index.php">Home</a></li><li><a class="menu-item" href="index.php?type=page&page_id=18">Explore</a></li>
            $fout.='</ul>

            <i class="fa fa-bars for-responsive-mode btn-toggle-responsive-menu"></i>
                        </span>

                        <span class="logo-con menu-span-center"><a href="'.$dzsap_portal->optional_url_base.'index.php" class="logo-anchor';




            if($dzsap_portal->main_settings['use_ajax']==='on'){
                $fout.=' ajax-link';
            }



            $fout.='">
                        '.dzsap_portal_output_logo().'
                        </a>
                        </span>
                        <div class="header--right  menu-span-right not-for-responsive-mode">

                            ';


            if($dzsap_portal->main_settings['enable_shop']=='on'){
                $fout.='<span class="menu-right-block-cart menu-right-block dzstooltip-con for-hover"><i
                                    class="fa fa-shopping-cart"></i>

                                <span class="menu-right-block-inmenu dzstooltip arrow-top align-right skin-black cart-contents " style="right: -31px; white-space:nowrap; width: auto; max-width: 500px;  "> No items in cart.
                                </span>

                            </span>';
            }



            $fout.='
                                <span class="menu-right-block-search big-search-btn menu-right-block dzstooltip-con for-hover"><i
                                    class="fa fa-search"></i>
                                    </span>
                                    ';


            $fout.=generate_lang_list();

            $fout.='';


//            echo $lang;







                                    $fout.='
                        ';


//            echo 'curr user id - '.$dzsap_portal->currUserId;


            // -- style-default
            if ($dzsap_portal->currUserId == 0) {


                $fout.= '<span class="login-login login--signup menu-right-block dzstooltip-con for-hover"><a class="login-signup--label btn-skin-vive" href="'.$dzsap_portal->optional_url_base.'index.php?page=register">'.__("Sign Up").'</a></span>';

                $fout.= '<span class="login-login menu-right-block dzstooltip-con for-hover"><span class="login-signup--label">'.__("Log In").'</span>
                
                <span class="menu-right-block-inmenu dzstooltip arrow-top align-right skin-black "><ul class="notices-box">' . $dzsap_portal->notices_html . '</ul>';



                $fout.='<span class="user-menu--options">';

                    if($dzsap_portal->main_settings['api_facebook_app_id']) {
                        $fout .= '<a href="' . $fb_loginUrl . '" class="facebook-box custom-a">'.__("Sign in with Facebook").'</a>
                        <div class="table-separator light">
                            <span class="table-cell"><span class="the-line"></span></span>
                            <span class="table-center">or</span>
                            <span class="table-cell"><span class="the-line"></span></span>
                        </div>';

                    }


                    $fout.='<h5 class="input-label">'.__('Sign in with email').'</h5>

                    <form class="login-form" method="POST">
                        <input type="hidden" name="action" value="login"/>
                        <input type="email" class="fullwidth simple-input-field" name="email"/>
                        <h5 class="input-label">Password</h5>
                        <input type="password" class="fullwidth simple-input-field" name="pass"/>
                        <br>
                        <br>
                        <div style="float:left;">
                        <button class="button-primary register-btn">Login</button>
                        </div>
                        <div style="float:right;">
                        <a data-source="#forgotpassword" data-type="inlinecontent" data-force-nodeeplink="on" class="font-weight-strong ultibox-item" data-suggested-width="400" data-suggested-height="300" data-scaling="fill">'.__("Forgot password").'</a>
                        </div>
                        <div class="clear"></div>
                    </form>
                    </span><!-- end user-menu--options -->
                    
                    </span>
                    </span>' . '';
            } else {
                $fout.= $logged_in_menu_str;
            }

            $fout.='</div><div class="clear"></div>
';
        }
        // --- END style-default




        // --- START style-domino
        if($margs['header_style']=='style-domino'){



            $curr_ind = 0;
            global $lang;
            for($i=1;$i<7;$i++) {
                if ($dzsap_portal->main_settings['lang_' . $i . '_code']==$lang) {

                    $curr_ind = $i;

                }
            }



            $fout.='<span class=" menu-span-left">
            <a href="'.$dzsap_portal->optional_url_base.'index.php" class="logo-anchor';




            if($dzsap_portal->main_settings['use_ajax']==='on'){
                $fout.=' ajax-link';
            }



            $fout.='">
                        <img class="the-logo" src="'.$dzsap_portal->sanitize_source($dzsap_portal->main_settings['logo']).'"/>
                        </a>
<ul class="header-menu not-for-responsive-mode">';

            $fout.=$menu_li_str;

//        <li><a class="menu-item current-menu-item" href="index.php">Home</a></li><li><a class="menu-item" href="index.php?type=page&page_id=18">Explore</a></li>
            $fout.='</ul>

            <i class="fa fa-bars for-responsive-mode btn-toggle-responsive-menu"></i>
                        </span>

                        <span class="header--right  menu-span-right not-for-responsive-mode">

                            ';


            if($dzsap_portal->main_settings['enable_shop']=='on'){
                $fout.='<span class="menu-right-block-cart menu-right-block dzstooltip-con for-hover"><i
                                    class="fa fa-shopping-cart"></i>

                                <span class="menu-right-block-inmenu dzstooltip arrow-top align-right skin-black cart-contents " style="right: -31px; white-space:nowrap; width: auto; max-width: 500px;  "> No items in cart.
                                </span>

                            </span>';
            }




            $sw = false;
            for($i=1;$i<7;$i++) {
                if ($dzsap_portal->main_settings['lang_' . $i . '_text']) {
                    $sw = true;
                }
            }

            $fout.='<span class="menu-right-block-search big-search-btn menu-right-block dzstooltip-con for-hover"><i
                                    class="fa fa-search"></i></span>';


            if($sw) {


//            echo $lang;



                $fout.=generate_lang_list();

            }


//            echo 'curr user id - '.$dzsap_portal->currUserId;


            if ($dzsap_portal->currUserId == 0) {


                $fout.= '<span class="login-login login--signup menu-right-block dzstooltip-con for-hover"><a class="login-signup--label btn-skin-vive" href="'.$dzsap_portal->optional_url_base.'index.php?page=register">'.__("Sign Up").'</a></span>';

                $fout.= '<span class="login-login menu-right-block dzstooltip-con for-hover"><span class="login-signup--label">'.__("Log In").'</span>'
                    . '<span class="menu-right-block-inmenu dzstooltip arrow-top align-right skin-black "><ul class="notices-box">' . $dzsap_portal->notices_html . '</ul>';




                    if($dzsap_portal->main_settings['api_facebook_app_id']) {
                        $fout .= '<a href="' . $fb_loginUrl . '" class="facebook-box">'.__("Sign in with Facebook").'</a>
                        <div class="table-separator light">
                            <span class="table-cell"><span class="the-line"></span></span>
                            <span class="table-center">or</span>
                            <span class="table-cell"><span class="the-line"></span></span>
                        </div>';

                    }


                    $fout.='<h5 class="input-label">'.__('Sign in with email').'</h5>

                    <form class="login-form" method="POST">
                        <input type="hidden" name="action" value="login"/>
                        <input type="email" class="fullwidth input-style-ronda" name="email"/>
                        <h5 class="input-label">'.__("Password").'</h5>
                        <input type="password" class="fullwidth input-style-ronda" name="pass"/>
                        <br>
                        <br>
                        <div style="">
                        <button class="btn-style-red  register-btn fullwidth">'.__("Login").'</button>
                        </div>
                        <div class="clear"></div>
                    </form>
                    </span>
                    </span>' . '';
            } else {
                $fout.= $logged_in_menu_str;
            }

            $fout.='</span><div class="clear"></div>
';
        }
        // --- END style-domino















        // --- START style-luna
        if($margs['header_style']=='style-luna'){
            $fout.='<span class=" float-left">
            <span class="logo-con"><a href="'.$dzsap_portal->optional_url_base.'index.php" class="logo-anchor';




            if($dzsap_portal->main_settings['use_ajax']==='on'){
                $fout.=' ajax-link';
            }

            $fout.='">
                        <img class="the-logo" src="'.$dzsap_portal->main_settings['logo'].'"/>
    </a>
</span>

            <i class="fa fa-bars for-responsive-mode btn-toggle-responsive-menu"></i>
                        </span>


                        <span class="header--right   not-for-responsive-mode">

<ul class="header-menu not-for-responsive-mode">';

            $fout.=$menu_li_str;

            $fout.='</ul>
                            <span class="menu-right-block-cart menu-right-block dzstooltip-con for-hover"><i
                                    class="fa fa-shopping-cart"></i>

                                <span class="menu-right-block-inmenu dzstooltip arrow-top align-right skin-black cart-contents " style="right: -31px; white-space:nowrap; width: auto; max-width: 500px;  "> '.__('No items in cart.').'
                                </span>

                            </span>

                        ';


            //<span class="menu-right-block-search big-search-btn menu-right-block dzstooltip-con for-hover"><i class="fa fa-search"></i></span>

//            echo 'curr user id - '.$dzsap_portal->currUserId;



            $fout.='</span><div class="clear"></div>
';
        }
        // --- END style-luna
















        // --- START style-footer-menu
        if($margs['header_style']=='style-footer-menu'){
$fout.='<ul class="header-menu">';

            $fout.=$menu_li_str;

            $fout.='</ul>';
        }
        // --- END style-footer-menu


        $fout.='</div>';


            return $fout;
    }
}
<?php
$id = 'events';

$dzspgb_templates[$id] = array(
    'id' => $id,
    'admin_str_function' => 'admin_str_function_'.$id,
);


if(!function_exists('admin_str_function_'.$id)){
    function admin_str_function_events($pargs=array()){

        $id = 'events';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'element_index' => '0',
            'type' => 'element',
            'type_element' => $id,
            'type_pb' => "Full",
            'txt_choose' => __("Choose"),
            'type_elements' => "newelement", // -- newelement (js) or dzspgb (php) ( legit )
            'text' => "",
            'extra_classes' => "",
            'cover_image' => "",
            'video' => "",
            'item' => array(),
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }

//        print_r($margs);

        $fout = '';
        $ind='';
        $element_edit_str='';



        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']['.$margs['element_index'].']';

//        echo 'alceva'.$ind;






        $lab = 'cover_image';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';

        $element_edit_str .= '<div class="setting">
        <div class="setting-label">'.__('Cover Image').'</div>';

        $element_edit_str.='<div class=" dzs-upload-con';


        $element_edit_str.='"><div class="float-left">
    <input type="text" class="simple-input-field target-field exclude-from-row-part-atts" name="'.$nam.'" value="'.$margs[$lab].'"/>
    <div class="dzs-single-upload';


        $element_edit_str.='">
        <input class="" type="file">
        </div>


<div class="feedback"></div>
</div>
        </div>
<div class="clear"></div>
        </div>';




        $lab = 'video';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';

        $element_edit_str .= '<div class="setting">
        <div class="setting-label">'.__('The Video').'</div>';

        $element_edit_str.='<div class=" dzs-upload-con';


        $element_edit_str.='"><div class="float-left">
    <input type="text" class="simple-input-field target-field exclude-from-row-part-atts" name="'.$nam.'" value="'.$margs[$lab].'"/>
    <div class="dzs-single-upload';


        $element_edit_str.='">
        <input class="" type="file">
        </div>


<div class="feedback"></div>
</div>
        </div>
<div class="clear"></div>
        </div>';




//        $lab = 'video';
//        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';
//
//        $element_edit_str .= '<br><div class="setting">
//        <div class="setting-label">'.__('Extra Classes').'</div>
//<input type="text" class="simple-input-field target-field exclude-from-row-part-atts" name="'.$nam.'" value="'.$margs[$lab].'"/>';
//        $element_edit_str.='</div>';




        $lab = 'extra_classes';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';

        $element_edit_str .= '<br><div class="setting">
        <div class="setting-label">'.__('Extra Classes').'</div>
<textarea class="textarea-extra-css formstyle" name="'.$nam.'">'.$margs[$lab].'</textarea>';
        $element_edit_str.='</div>';







        $element_edit_str.='<p class="buttons-con"><button class="button-primary btn-delete-itm btn-delete-element">'.__('Delete Element').'</button> <button class="button--secondary button btn-done-editing"><span class="button-label">'.__('Done Editing').'</span></button> </p>
        ';





        // -- screen in editor
        $fout.='<span class="dzspgb-element-con"><span class="hidden-content">'.$element_edit_str.'</span><span class="dzspgb-element-type the-type-text" data-type="'.$id.'">
        <span class="move-handler-for-elements"><i class="fa fa-arrows-v"></i></span>
        <span class="clone-handler-for-elements"><i class="fa fa-clone"></i></span>
        <span class="icon-con"><i class="fa fa-envelope"></i></span><h5>'.__('events').'</h5><p class="the-excerpt">'.__("Insert a events displaying the events of the music band.").'</p><span class="dzspgb-button dzspgb-button-choose">'.$margs['txt_choose'].'</span></span><input type="hidden" name="'.$margs['type_elements'].$ind.'[type_element]" value="'.$id.'"/></span>';

        return $fout;
    }
}




if(!function_exists('shortcode_events')){
    function shortcode_events($pargs=array(),$content=''){

        global $dzsap_portal;

        $fout = '';

        $margs = array(
            'type_element' => 'events',
            'events_style' => 'style_default',
            'cover_image' => '',
            'video' => '',
            'extra_classes' => '',
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }




        $events = $dzsap_portal->get_posts(array(
            'post_type'=>'post',
            'post_type_type'=>'event',
            'orderby'=>'published_date',
        ));



//        print_r($events);

$fout.='<div class="shortcode-events">';


$fout.='<div class="dzs-tabs auto-init-from-dzsapp skin-events" data-options="{ \'design_tabsposition\' : \'top\'
                ,design_transition: \'slide\'
                ,design_tabswidth: \'default\'
                ,toggle_breakpoint : \'800\'
                ,settings_startTab: \'-1\'
                 ,toggle_type: \'accordion\'
                 ,action_gotoItem: window.getTabforMap
                 }">';


        foreach($events as $ev){

            $ev_meta = $dzsap_portal->get_post_meta_all($ev['id']);

//            print_r($ev_meta);

            $str_mon= date("M", strtotime($ev['published_date']));
            $str_day= date("d", strtotime($ev['published_date']));

            $buy_html = '';

            if(isset($ev_meta['buy_html'])){
                $buy_html = $ev_meta['buy_html'];
            }
// outputs 12th November, 2010

            $fout.='<div class="dzs-tab-tobe">
                            <div class="tab-menu ">

                                <div class="post-date">
                                    <div class="the-image-bg divimage" style="background-image: url('.$ev_meta['thumbnail'].');"></div>
                                    <div class="the-color-bg"></div>
                                    <div class="post-date--text">
                                        <div class="post-date--day">'.$str_day.'</div>
                                        <div class="post-date--month">'.$str_mon.'</div>
                                    </div>
                                </div>
                                <div class="post-date--placeholder"></div>


                                <div class="content-right">

                                    '.$buy_html.'
                                </div>


                                <div class="post-meta">
                                    <h3>'.$ev['title'].'</h3>';

            if($ev_meta['location_name']){
                $fout.='<span class="post-meta--location"><i class="fa fa-location-arrow"></i> <span class="the-text">'.$ev_meta['location_name'].'</span></span>';
            }
            if($ev_meta['time_hour']){
                $fout.='<span class="post-meta--hour"><i class="fa fa-clock-o"></i> <span class="the-text">'.$ev_meta['time_hour'].'</span></span>';
            }

                                $fout.='</div>





                                <div class="circle1"></div>
                                <div class="circle2"></div>
                                <div class="circle3"></div>


                            </div>
                            <div class="tab-content">
                                test
                            </div>
                        </div>';
        }



        $fout.='</div>';



        $fout.='<script>window.gm_locations=[';

        $i2 = 0;
        foreach($events as $ev) {

            $ev_meta = $dzsap_portal->get_post_meta_all($ev['id']);

            if($i2>0){
                $fout.=',';
            }

            $fout.='{ lat: "'.$ev_meta['location_lat'].'", long: "'.$ev_meta['location_long'].'"}';


//            print_r($ev_meta);

            $i2++;
        }
        $fout.=']</script>';


        $fout.='</div>';



        if(function_exists('enqueue_script')) {

            enqueue_script('dzstabsandaccordions', 'libs/dzstabsandaccordions/dzstabsandaccordions.js');
            enqueue_style('dzstabsandaccordions', 'libs/dzstabsandaccordions/dzstabsandaccordions.css');
        }





        return $fout;



    }
}
<?php
$id = 'calendar';

$dzspgb_templates[$id] = array(
    'id' => $id,
    'admin_str_function' => 'admin_str_function_'.$id,
);


if(!function_exists('admin_str_function_'.$id)){
    function admin_str_function_calendar($pargs=array()){

        $id = 'calendar';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'element_index' => '0',
            'type' => 'element',
            'type_element' => $id,
            'type_pb' => "Full",
            'txt_choose' => __("Choose"),
            'type_elements' => "newelement", // -- newelement (js) or dzspgb (php) ( legit )
            'text' => "",
            'start_month' => "",
            'start_year' => "",
            'extra_classes' => "",
            'video' => "",
            'item' => array(),
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }

//        print_r($margs);

        $fout = '';
        $ind='';
        $element_edit_str='';



        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']['.$margs['element_index'].']';

//        echo 'alceva'.$ind;







        $lab = 'start_month';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';


        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Start Month').'</span>
'.DZSHelpers::generate_input_text($nam, array('class'=>'simple-input-text ','seekval'=>$margs[$lab],)).'
<span class="sidenote">'.__("Input a custom start month. If left blank then the current date will apply.").'</span>
</span>';





        $lab = 'start_year';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';


        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Start Year').'</span>
'.DZSHelpers::generate_input_text($nam, array('class'=>'simple-input-text ','seekval'=>$margs[$lab],)).'
<span class="sidenote">'.__("Input a custom start year. If left blank then the current date will apply.").'</span>
</span>';




//        $lab = 'video';
//        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';
//
//        $element_edit_str .= '<br><div class="setting">
//        <div class="setting-label">'.__('Extra Classes').'</div>
//<input type="text" class="simple-input-field target-field exclude-from-row-part-atts" name="'.$nam.'" value="'.$margs[$lab].'"/>';
//        $element_edit_str.='</div>';




        $lab = 'extra_classes';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';

        $element_edit_str .= '<br><div class="setting">
        <div class="setting-label">'.__('Extra Classes').'</div>
<textarea class="textarea-extra-css formstyle" name="'.$nam.'">'.$margs[$lab].'</textarea>';
        $element_edit_str.='</div>';







        $element_edit_str.='<p class="buttons-con"><button class="button-primary btn-delete-itm btn-delete-element">'.__('Delete Element').'</button> <button class="button--secondary button btn-done-editing"><span class="button-label">'.__('Done Editing').'</span></button> </p>
        ';





        // -- screen in editor
        $fout.='<span class="dzspgb-element-con"><span class="hidden-content">'.$element_edit_str.'</span><span class="dzspgb-element-type the-type-text" data-type="'.$id.'">
        <span class="move-handler-for-elements"><i class="fa fa-arrows-v"></i></span>
        <span class="clone-handler-for-elements"><i class="fa fa-clone"></i></span>
        <span class="icon-con"><i class="fa fa-calendar"></i></span><h5>'.__('Calendar').'</h5><p class="the-excerpt">'.__("Insert a calendar displaying the events of the music band.").'</p><span class="dzspgb-button dzspgb-button-choose">'.$margs['txt_choose'].'</span></span><input type="hidden" name="'.$margs['type_elements'].$ind.'[type_element]" value="'.$id.'"/></span>';

        return $fout;
    }
}




if(!function_exists('shortcode_calendar')){
    function shortcode_calendar($pargs=array(),$content=''){

        global $dzsap_portal;

        $fout = '';

        $margs = array(
            'type_element' => 'calendar',
            'calendar_style' => 'style_default',
            'start_month' => "",
            'start_year' => "",
            'extra_classes' => "",
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }



        $events = $dzsap_portal->get_posts(array(
            'post_type'=>'post',
            'post_type_type'=>'event',
        ));


//        foreach($events as $ev) {
//
//            $dat= date("d-m-Y", strtotime($ev['published_date']));
//
//
//            echo $dat;
//
//        }


//        print_r($margs);

$fout.='<div class="shortcode-calendar">';


$fout.='<div class="dzscalendar skin-responsive-galileo auto-init-from-dzsapp" style="" data-options=\'{
design_month_covers : ["http://dummyimage.com/950x350/000000/3c3c3d.jpg","upload/cover/cover2.jpg","http://dummyimage.com/950x350/000000/3c3c3d.jpg","http://dummyimage.com/950x350/000000/3c3c3d.jpg","http://dummyimage.com/950x350/000000/3c3c3d.jpg","http://dummyimage.com/950x350/000000/3c3c3d.jpg","http://dummyimage.com/950x350/000000/3c3c3d.jpg","upload/cover/cover1.jpg","http://dummyimage.com/950x350/000000/3c3c3d.jpg","http://dummyimage.com/950x350/000000/3c3c3d.jpg","http://dummyimage.com/950x350/000000/3c3c3d.jpg","http://dummyimage.com/950x350/000000/3c3c3d.jpg"]';


if($margs['start_month']){
    $fout.=', start_month : "'.$margs['start_month'].'"';
}
if($margs['start_year']){
    $fout.=', start_year : "'.$margs['start_year'].'"';
}

$fout.='}\'><div class="events">';


        foreach($events as $ev) {

            $fout.='<div class="event-tobe" data-date="'.date("m-j-Y", strtotime($ev['published_date'])).'"></div>';


            $fout.='<div class="event-tobe" data-date="'.date("m-j-Y", strtotime($ev['published_date'])).'" data-type="link" data-href="'.$dzsap_portal->optional_url_base.'index.php?page=post_id"><h4>'.$ev['title'].'</h4></div>';

        }

                        $fout.='</div>
</div>';


        $fout.='</div>';



        if(function_exists('enqueue_script')) {

            enqueue_script('dzs.calendar', 'libs/dzscalendar/dzscalendar.js');
            enqueue_style('dzs.calendar', 'libs/dzscalendar/dzscalendar.css');
        }





        return $fout;



    }
}
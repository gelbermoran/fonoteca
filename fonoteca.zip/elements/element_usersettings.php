<?php
$id = 'usersettings';

$dzspgb_templates[$id] = array(
    'id' => $id,
    'admin_str_function' => 'admin_str_function_usersettings',
);


if(!function_exists('admin_str_function_usersettings')){
    function admin_str_function_usersettings($pargs=array()){

        $id = 'usersettings';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'element_index' => '0',
            'type' => 'element',
            'type_element' => $id,
            'type_pb' => "Full",
            'txt_choose' => __("Choose"),
            'type_elements' => "newelement", // -- newelement (js) or dzspgb (php) ( legit )
            'text' => "",
            'usersettings_height' => "10",
            'item' => array(),
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }

//        print_r($margs);

        $fout = '';
        $ind='';
        $element_edit_str='';



        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']['.$margs['element_index'].']';

//        echo 'alceva'.$ind;


        $lab = ''.$margs['type_elements'].$ind.'[usersettings_height]';

        $element_edit_str.='<div class="center-it">';
        $element_edit_str.='<div class="setting ">
        <span class="setting-label">'.__('Height').'</span>
        <div class="func-slider-con"> <!-- here should be only one input, the input first is the slider value -->
        <input type="text" class="func-slider-val" name="'.$lab.'" value="'.$margs['usersettings_height'].'"/>
<div class="func-slider"></div>
</div>
</div>';


        $element_edit_str.='</div>';

        $element_edit_str.='<p class="buttons-con"><button class="button-primary btn-delete-itm btn-delete-element">'.__('Delete Element').'</button> <button class="button-secondary btn-done-editing">'.__('Done Editing').'</button> </p>
        ';





        // -- screen in editor
        $fout.='<div class="dzspgb-element-con" data-type="'.$id.'">
        <div class="hidden-content">'.$element_edit_str.'</div>
        <span class="dzspgb-element-type the-type-'.$id.'" data-type="'.$id.'">
            <span class="move-handler-for-elements"><i class="fa fa-arrows-v"></i>
            </span>
            <span class="icon-con"><i class="fa fa-gear"></i></span><h5>'.__('User Settings').'</h5><p class="the-excerpt">'.__("Place a user registration box. ").'</p><span class="dzspgb-button dzspgb-button-choose">'.$margs['txt_choose'].'
            </span>
        </span>
        <input type="hidden" name="'.$margs['type_elements'].$ind.'[type_element]" value="'.$id.'"/>
        </div><!-- END dzspgb-element-con -->';

//        $fout.='</div>';

        return $fout;
    }
}




if(!function_exists('shortcode_usersettings')){
    function shortcode_usersettings($pargs=array(),$content=''){

        global $dzsap_portal;

        $fout = '';

        $margs = array(
            'style' => 'auto', // -- auto or default or list or slider ...tbc
            'type' => 'auto', // -- auto or explore or mytracks or playlist or playlists or stream or
            'pagination' => 'auto', // -- auto or none or ajax or pages or pagesajax
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }



//        print_r($margs);


        if ($dzsap_portal->currUserId == 0) {

        }else{
            $fout.='<div class="shortcode-usersettings" style="">';

//        $fout.=$dzsap_portal->get_query($margs);


//        $fout.='<h4>'.__('usersettings').'</h4>';




            $fout.='<div class="row">';

            $fout.='<div class="col-md-6">';


            $fout.='<h3 style="padding-top:0;">'.__("User Settings").'</h3><br>';

            $fout.='<form class="usersettings-form" name="usersettings-form" action="index.php" method="POST">';


            $fout.='<ul class="notices-box">'.$dzsap_portal->notices_html.'</ul>';

            $fout.='<div class="setting">';

            $fout.='<div class="setting-label label-for-ujarak">'.__('User Name').'</div>';
            $fout.='<input class="input-ujarak-style" type="text" name="username" placeholder="'.__('').'" value="'.$dzsap_portal->get_user_field($dzsap_portal->currUserId,'username').'"/>';

            $fout.='</div>';




            $fout.='<div class="setting">';

            $fout.='<div class="setting-label label-for-ujarak">'.__('Location').'</div>';
            $fout.='<input class="input-ujarak-style" type="text" name="location" placeholder="'.__('').'" value="'.$dzsap_portal->get_user_field($dzsap_portal->currUserId,'location').'"/>';

            $fout.='</div>';





            $lab = 'facebook_link';
            $fout.='<div class="setting">';

            $fout.='<div class="setting-label label-for-ujarak">'.__('Facebook Link').'</div>';
            $fout.='<input class="input-ujarak-style" type="text" name="'.$lab.'" placeholder="'.__('').'" value="'.$dzsap_portal->get_user_field($dzsap_portal->currUserId,$lab).'"/>';

            $fout.='</div>';


            $lab = 'twitter_link';
            $fout.='<div class="setting">';

            $fout.='<div class="setting-label label-for-ujarak label-for-ujarak">'.__('Twitter Link').'</div>';
            $fout.='<input class="input-ujarak-style" type="text" name="'.$lab.'" placeholder="'.__('').'" value="'.$dzsap_portal->get_user_field($dzsap_portal->currUserId,$lab).'"/>';

            $fout.='</div>';

            $lab = 'soundcloud_link';
            $fout.='<div class="setting">';

            $fout.='<div class="setting-label label-for-ujarak">'.__('Soundcloud Link').'</div>';
            $fout.='<input class="input-ujarak-style" type="text" name="'.$lab.'" placeholder="'.__('').'" value="'.$dzsap_portal->get_user_field($dzsap_portal->currUserId,$lab).'"/>';

            $fout.='</div>';


            $lab = 'paypal_email';
            $fout.='<div class="setting">';

            $fout.='<div class="setting-label label-for-ujarak">'.__('PayPal Email').'</div>';
            $fout.='<input class="input-ujarak-style" type="text" name="'.$lab.'" placeholder="'.__('').'" value="'.$dzsap_portal->get_user_field($dzsap_portal->currUserId,$lab).'"/>';

            $fout.='</div>';




            $fout.='<div class="setting">';

            $fout.='<div class="setting-label label-for-ujarak">'.__('Old Password').'</div>';
            $fout.='<input class="input-ujarak-style" type="password" name="password" placeholder="'.__('').'"/ value="">';

            $fout.='</div>';

            $fout.='<div class="setting">';

            $fout.='<div class="setting-label label-for-ujarak">'.__('New Password').'</div>';
            $fout.='<input class="input-ujarak-style" type="password" name="new_password" placeholder="'.__('').'"/ value="">';

            $fout.='</div>';






            $fout.='<div class="setting">';
            $fout.='<div class="setting-label label-for-ujarak">'.__('Confirm Password').'</div>';
            $fout.='<input class="input-ujarak-style" type="password" name="confirm_password" placeholder="'.__('').'" value=""/>';

            $fout.='</div>';





            $lab = 'avatar';
            $fout.='<div class="setting dzs-upload-con">';
            $fout.='<span class="dzs-single-upload-preview-img"></span>';

            $fout.='<div class="setting-label label-for-ujarak">'.__('Avatar').'</div>';

            $fout.='<div class="overflow-it">';
            $fout.='<input class="input-ujarak-style target-field" type="text" name="'.$lab.'" placeholder="'.__('').'" value="'.$dzsap_portal->get_user_field($dzsap_portal->currUserId,$lab).'"  data-upload_from="change-user-media"/>';

            $fout.='</div>';

            $fout.='<span class="dzs-single-upload float-it-right" style="margin-left: 10px;">
<input class="" name="file_field" type="file" accept=".jpg,.jpeg,.png" >
<span class="feed-translate-upload">'.__("Change Avatar").'</span>
</span>';



            $fout.='';


            $fout.='</div>';



            $lab = 'second_avatar';
            $fout.='<div class="setting dzs-upload-con">';
            $fout.='<span class="dzs-single-upload-preview-img"></span>';

            $fout.='<div class="setting-label label-for-ujarak">'.__('Cover').'</div>';



            $fout.='<div class="overflow-it">';
            $fout.='<input class="input-ujarak-style target-field" type="text" name="'.$lab.'" placeholder="'.__('').'" value="'.$dzsap_portal->get_user_field($dzsap_portal->currUserId,$lab).'"  data-upload_from="change-user-media"/>';

            $fout.='</div>';

            $fout.='<span class="dzs-single-upload float-it-right" style="margin-left: 10px;">
<input class="" name="file_field" type="file" accept=".jpg,.jpeg,.png">
<span class="feed-translate-upload">'.__("Change Cover").'</span>
</span>';



            $fout.='';


            $fout.='</div>';








            ob_start();

            $dzsap_portal->do_action('usersettings_extra_settings');
            $fout.=ob_get_clean();









            $lab = 'description';

            $fout.='<div class="setting">';

            $fout.='<div class="setting-label label-for-ujarak">'.__('Description').'</div>';
            $fout.='<textarea class="input-ujarak-style"  name="'.$lab.'" placeholder="'.__('').'" >'.$dzsap_portal->get_user_field($dzsap_portal->currUserId,$lab).'</textarea>';

            $fout.='</div>';






            $fout.='<div class="settings">';
            $fout.='<input type="hidden" name="action" value="save_usersettings"/>';
            $fout.='<button class="button--secondary button button-primary-for-usersettings" style="padding: 4px 13px 6px;"><span class="button-label">'.__('Save Settings').'</span></button>';
            $fout.='</div>';
            $fout.='</form>';


            $fout.='</div>'; // -- end .col-md-6

            $fout.='<div class="col-md-6">';


            $fout.='<h3 style="padding-top:0;">'.__("User Data").'</h3>';

            $fout.="<h4>".__("Current Storage Status").'</h4>';


            $limit = $dzsap_portal->main_settings['upload_limit_normal'];




            $caps = $dzsap_portal->get_user_capabilities($dzsap_portal->currUserId);

            if(in_array('proaccount',$caps)){
                $limit = $dzsap_portal->main_settings['upload_limit_pro'];
            }




            $str_limit = $limit;

            if($limit=='unlimited'){
                $limit = 10000;
            }else{

                $limit = intval($dzsap_portal->main_settings['upload_nr_limit_normal']);

                $str_limit = $dzsap_portal->human_filesize($limit*1048576);
            }




            $extra_class = ' curr-space-ok';

            if($dzsap_portal->get_user_total_uploaded($dzsap_portal->currUserId) > $limit*1048576){
                $extra_class = ' curr-space-notok';
            }

            $fout.='<p>';
            $fout.='<span class="curr-space '.$extra_class.'">'.$dzsap_portal->human_filesize($dzsap_portal->get_user_total_uploaded($dzsap_portal->currUserId)).'</span> / '.'<span class="total-space">'.$str_limit.'</span>';
            $fout.='</p>';


            $fout.='<br>';

            $fout.="<h4>".__("Current Track Limit Status").'</h4>';


            // -- number


            $caps = $dzsap_portal->get_user_capabilities($dzsap_portal->currUserId);

            if(in_array('proaccount',$caps)){


                $limit = ($dzsap_portal->main_settings['upload_nr_limit_pro']);
            }


//            echo 'limit - '.$limit;

            $str_limit = $limit;

            if($limit=='unlimited'){
                $limit = 10000;
            }else{

                $limit = intval($limit);

            }


            $extra_class = ' curr-space-ok';

            if($dzsap_portal->get_user_total_nr_uploaded($dzsap_portal->currUserId) >= $limit){
                $extra_class = ' curr-space-notok';
            }

            $fout.='<p>';
            $fout.='<span class="curr-space '.$extra_class.'">'.($dzsap_portal->get_user_total_nr_uploaded($dzsap_portal->currUserId)).'</span> / '.'<span class="total-space">'.$str_limit.'</span>';
            $fout.='</p>';


            $fout.='<br>';
            $fout.="<h4>".__("Credit Balance").'</h4>';

            $user_meta = $dzsap_portal->get_user_meta_all($dzsap_portal->currUserId);


            $user_credit = 0;

            if($user_meta['user_credit']){
                $user_credit = $user_meta['user_credit'];
            }

            $fout.='<p>'.$user_credit.' '.__("credits").'</p>';

            $fout.='<br>';
            $fout.="<h4>".__("User Id").'</h4>';




            $fout.='<p>'.$dzsap_portal->currUserId.' '.'</p>';



            $fout.='<br>';

            $fout.='<h3>'.__("Mail Settings").'</h3>';



            $fout.='<form class="user-meta">';
            $lab = 'mail_on_comment';

            $fout.='<div class="setting">';

            $fout.='<h5 class="setting-label ">'.__('When somebody comments on your tracks').'</h5>';


            $fout.= DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));


            $val = 'off';
            if(isset($user_meta[$lab]) && $user_meta[$lab]=='off'){

            }else{
                $val = 'on';
            }

            $fout.='<div class="dzscheckbox skin-nova">
                                                '.DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $val)).'
                                                <label for="'.$lab.'"></label>
                                            </div>';
            $fout.='</div>';


            $lab = 'mail_on_like';

            $fout.='<div class="setting">';

            $fout.='<h5 class="setting-label ">'.__('When somebody likes on your tracks').'</h5>';


            $fout.= DZSHelpers::generate_input_text($lab,array('id' => $lab,'val' => 'off','input_type' => 'hidden'));


            $val = 'off';
            if(isset($user_meta[$lab]) && $user_meta[$lab]=='off'){

            }else{
                $val = 'on';
            }

            $fout.='<div class="dzscheckbox skin-nova">
                                                '.DZSHelpers::generate_input_checkbox($lab,array('id' => $lab,'val' => 'on','seekval' => $val)).'
                                                <label for="'.$lab.'"></label>
                                            </div>';
            $fout.='</div>';



            ob_start();

            $dzsap_portal->do_action('usersettings_extra_meta');
            $fout.=ob_get_clean();

            $fout.='</form>';




            $fout.='</div>';




            $fout.='</div>'; // -- end .col-md-6
            $fout.='</div>'; // -- end .row

            $fout.='<div class="clear"></div>
</div>';
        }


        if(function_exists('enqueue_script')) {

            enqueue_script('dzs.upload', 'libs/dzsuploader/upload.js');
            enqueue_style('dzs.upload', 'libs/dzsuploader/upload.css');
            enqueue_style('dzs.checkbox', 'libs/dzscheckbox/dzscheckbox.css');
        }


            return $fout;
    }
}
<?php
$id = 'query';

$dzspgb_templates[$id] = array(
    'id' => $id,
    'admin_str_function' => 'admin_str_function_query',
);

if(isset($default_opts)==false){
    $default_opts = array();
}

$default_opts[$id]=array(
    'call_from_lab'=>''
);


if(!function_exists('admin_str_function_query')){
    function admin_str_function_query($pargs=array()){
        global $dzspgb_forportal, $dzsap_portal,$default_opts;

        $id = 'query';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'element_index' => '0',
            'type' => 'element',
            'query_type' => 'auto',
            'type_element' => $id,
            'type_pb' => "Full",
            'txt_choose' => __("Choose"),
            'type_elements' => "newelement", // -- newelement (js) or dzspgb (php) ( legit )


            'text' => "",
            'interval' => "alltime",
            'thumbs_per_row' => "4",
            'thumbs_bullets_position' => "bottom",
            'thumbs_disable_arrows' => "off",
            'thumbs_display_title_and_price' => "off",
            'thumbs_see_all_text' => "",
            'style_thumb_replace_page' => "",
            'apconfig' => "",
            'limit_posts' => "",
            'paged' => "",
            'query_query' => "",
            'pagination' => "auto",  // -- auto or none or or button ajax or pages or pagesajax
            'extra_classes' => '',
            'post_type' => '',
            'style' => '',

            'item' => array(),
        );


        $margs=array_merge($margs,$default_opts[$id]);

        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }


//        print_r($margs);

        $fout = '';
        $ind='';
        $element_edit_str='';



        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']['.$margs['element_index'].']';

//        echo 'alceva'.$ind;


        $lab = ''.$margs['type_elements'].$ind.'[query_height]';

        $element_edit_str.='';



        $lab = 'style';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';


//        print_r($apconfigs);

        $arr_opts = array(
            array(
                'lab' => __('Automatic'),
                'val' => 'auto',
            ),
            array(
                'lab' => __('List'),
                'val' => 'list',
            ),
            array(
                'lab' => __('Simple List'),
                'val' => 'simple_list',
            ),
            array(
                'lab' => __('Slider'),
                'val' => 'slider',
            ),
            array(
                'lab' => __('Under'),
                'val' => 'under',
            ),
            array(
                'lab' => __('Thumbs'),
                'val' => 'thumbs',
            ),
            array(
                'lab' => __('Thumb with Play Button'),
                'val' => 'thumb_with_play',
            ),
            array(
                'lab' => __('Blog Display'),
                'val' => 'blog_display',
            ),
            array(
                'lab' => __('Event Display'),
                'val' => 'post_display',
            ),
            array(
                'lab' => __('Post Grid'),
                'val' => 'grid_display',
            ),
            array(
                'lab' => __('List Nova'),
                'val' => 'list-nova',
            ),
            array(
                'lab' => __('Charts'),
                'val' => 'charts',
            ),
        );





        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Style').'</span>
'.DZSHelpers::generate_select($nam, array('class'=>'dzs-style-me skin-beige style-changer ','options'=>$arr_opts,'seekval'=>$margs[$lab],)).'
</span>';



        $lab = 'query_type';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';





        $arr_opts = array(
            array(
                'lab' => __('Automatic'),
                'val' => 'auto',
            ),
            array(
                'lab' => __('Playlist'),
                'val' => 'playlist',
            ),
            array(
                'lab' => __('My Tracks'),
                'val' => 'mytracks',
            ),
            array(
                'lab' => __('Single Track'),
                'val' => 'track',
            ),
            array(
                'lab' => __('Events'),
                'val' => 'events',
            ),
            array(
                'lab' => __('Playlists'),
                'val' => 'playlists',
            ),
            array(
                'lab' => __('Playlist'),
                'val' => 'playlist',
            ),
            array(
                'lab' => __('Most Liked'),
                'val' => 'mostliked',
            ),
            array(
                'lab' => __('Most Played'),
                'val' => 'mostviewed',
            ),
            array(
                'lab' => __('Similar'),
                'val' => 'similar',
            ),
            array(
                'lab' => __('Explore'),
                'val' => 'explore',
            ),
            array(
                'lab' => __('Stream'),
                'val' => 'stream',
            ),
            array(
                'lab' => __('Search'),
                'val' => 'search',
            ),
            array(
                'lab' => __('Custom IDS'),
                'val' => 'custom_ids',
            ),
            array(
                'lab' => __('Posts'),
                'val' => 'posts',
            ),
        );





        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Type').'</span>
'.DZSHelpers::generate_select($nam, array('class'=>'dzs-style-me skin-beige type-changer ','options'=>$arr_opts,'seekval'=>$margs[$lab],)).'
</span>';







        $lab = 'interval';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';





        $arr_opts = array(
            array(
                'lab' => __('All Time'),
                'val' => 'alltime',
            ),
            array(
                'lab' => __('Last 24 Hours'),
                'val' => 'last24',
            ),
            array(
                'lab' => __('Last Week'),
                'val' => 'last168',
            ),
        );


        $element_edit_str.='<span class="setting type-mostviewed">
        <span class="setting-label">'.__('Interval').'</span>
'.DZSHelpers::generate_select($nam, array('class'=>'dzs-style-me skin-beige ','options'=>$arr_opts,'seekval'=>$margs[$lab],)).'
</span>';







        //---



        $lab = 'thumbs_per_row';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';





        $arr_opts = array(
            array(
                'lab' => __('3 per row'),
                'val' => '33.33%',
            ),
            array(
                'lab' => __('4 per row'),
                'val' => '25%',
            ),
            array(
                'lab' => __('5 per row'),
                'val' => '20%',
            ),
            array(
                'lab' => __('5 per row'),
                'val' => '16.66%',
            ),
        );


        $element_edit_str.='<span class="setting style-thumbs">
        <span class="setting-label">'.__('Thumbs per Row').'</span>
'.DZSHelpers::generate_select($nam, array('class'=>'dzs-style-me skin-beige ','options'=>$arr_opts,'seekval'=>$margs[$lab],)).'
</span>';

        $lab = 'thumbs_bullets_position';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';





        $arr_opts = array(
            array(
                'lab' => __('Bottom'),
                'val' => 'bottom',
            ),
            array(
                'lab' => __('Top'),
                'val' => 'top',
            ),
            array(
                'lab' => __('None'),
                'val' => 'none',
            ),
        );


        $element_edit_str.='<span class="setting style-thumbs">
        <span class="setting-label">'.__('Bullets Position').'</span>
'.DZSHelpers::generate_select($nam, array('class'=>'dzs-style-me skin-beige ','options'=>$arr_opts,'seekval'=>$margs[$lab],)).'
</span>';



        $lab = 'thumbs_disable_arrows';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';





        $arr_opts = array(
            array(
                'lab' => __('Off'),
                'val' => 'off',
            ),
            array(
                'lab' => __('On'),
                'val' => 'on',
            ),
        );


        $element_edit_str.='<span class="setting style-thumbs">
        <span class="setting-label">'.__('Disable Arrows').'</span>
'.DZSHelpers::generate_select($nam, array('class'=>'dzs-style-me skin-beige ','options'=>$arr_opts,'seekval'=>$margs[$lab],)).'
</span>';

        $lab = 'thumbs_display_title_and_price';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';





        $element_edit_str.='<span class="setting style-thumbs">
        <span class="setting-label">'.__('Display Title and Price ').'</span>
'.DZSHelpers::generate_select($nam, array('class'=>'dzs-style-me skin-beige ','options'=>$arr_opts,'seekval'=>$margs[$lab],)).'
</span>';

        






        $lab = 'thumbs_see_all_text';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';







        $element_edit_str.='<span class="setting style-thumbs">
        <span class="setting-label">'.sprintf("Replace <strong>%s</strong> text", __("See More")).'</span>
'.DZSHelpers::generate_input_text($nam, array('class'=>'dzs-style-me skin-beige ','seekval'=>$margs[$lab],)).'
</span>';













        $args = array(
            'for_ajax'=>false,
            'post_type'=>'page',
        );

        $auxa = ($dzspgb_forportal->ajax_select_pages_array($args));


        $apconfigs = json_decode($auxa,true);

//        print_r($apconfigs);



        $arr_opts = array(
            'lab'=>__("Explore Page"),
            'val'=>'',
        );
        foreach($apconfigs as $auxa_it){

            $auxb = array(
                'val' => $auxa_it['id'],
                'lab' => $auxa_it['title'],
            );

            array_push($arr_opts,$auxb);
        }




        $lab = 'style_thumb_replace_page';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';



        $element_edit_str.='<span class="setting style-thumbs">
        <span class="setting-label">'.__('Force Link to Page').'</span>
'.DZSHelpers::generate_select($nam, array('class'=>'dzs-style-me skin-beige ','options'=>$arr_opts,'seekval'=>$arr_opts,)).'
</span>';



        // -- pagination OPTIONS

        $element_edit_str.='
                    <span class="setting dzstoggle toggle1">';

        $element_edit_str.='
                        <span class="toggle-title" style="">'.__("Pagination Options").'</span>
                        <span class="toggle-content"><br>
';












        $arr_opts = array(
            array(
                'lab' => __('Automatic'),
                'val' => 'auto',
            ),
            array(
                'lab' => __('Button'),
                'val' => 'button',
            ),
            array(
                'lab' => __('Scroll'),
                'val' => 'scroll',
            ),
            array(
                'lab' => __('Pagination'),
                'val' => 'pagination',
            ),
        );




        $lab = 'pagination';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';


        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Pagination').'</span>
'.DZSHelpers::generate_select($nam, array('class'=>'dzs-style-me skin-beige ','options'=>$arr_opts,'seekval'=>$arr_opts,)).'
<span class="sidenote">'.__("Set <strong>Automatic</strong> for no pagination. Set <strong>Button</strong> for a Load More button that loads more tracks.").'</span></span>';






        $lab = 'limit_posts';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';


        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Number of Posts').'</span>
'.DZSHelpers::generate_input_text($nam, array('class'=>'simple-input-text ','seekval'=>$margs[$lab],)).'
<span class="sidenote">'.__("The number of posts to display. Leave blank to display all posts.").'</span>
</span>';




        $lab = 'paged';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';


        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Page').'</span>
'.DZSHelpers::generate_input_text($nam, array('class'=>'simple-input-text ','seekval'=>$margs[$lab],)).'
<span class="sidenote">'.__("The first page is 1, the second page is 2 etc.").'</span>
</span>';




        $element_edit_str.='</span>';
        $element_edit_str.='</span>';


















        $lab = 'apconfig';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';


        $args = array(
            'for_ajax'=>false,
            'post_type'=>'apconfig',
        );

        $auxa = ($dzspgb_forportal->ajax_select_pages_array($args));


        $apconfigs = json_decode($auxa,true);

//        print_r($apconfigs);

        $arr_opts = array();
        foreach($apconfigs as $auxa_it){

            $auxb = array(
                'val' => $auxa_it['id'],
                'lab' => $auxa_it['title'],
            );

            array_push($arr_opts,$auxb);
        }






        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Audio Player Configuration').'</span>
'.DZSHelpers::generate_select($nam, array('class'=>'dzs-style-me skin-beige ','options'=>$arr_opts,'seekval'=>$arr_opts,)).'
</span>';




        $lab = 'query_query';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';


        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('The Query Variable').'</span>
'.DZSHelpers::generate_input_text($nam, array('class'=>'simple-input-text ','seekval'=>$margs[$lab],)).'
<span class="sidenote">'.__("The query variable to be executed. For example, for the type <strong>Custom IDS</strong> it will be the ids to be executed, separated by <strong>,</strong>.").'</span>
</span>';



        $lab = 'extra_classes';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';


        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Extra Classes').'</span>
'.DZSHelpers::generate_input_text($nam, array('class'=>'simple-input-text ','seekval'=>$margs[$lab],)).'
<span class="sidenote">'.__("Extra classes for CSS").'</span>
</span>';



        $lab = 'post_type';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';


        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Post Type').'</span>
'.DZSHelpers::generate_input_text($nam, array('class'=>'simple-input-text ','seekval'=>$margs[$lab],)).'
<span class="sidenote">'.__("The post type - only for specific query types.").'</span>
</span>';



        $lab = 'call_from_lab';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';


        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Developer Call From').'</span>
'.DZSHelpers::generate_input_text($nam, array('class'=>'simple-input-text ','seekval'=>$margs[$lab],)).'
<span class="sidenote">'.__("* developers only, leave blank here if you do not know what you are doing").'</span>
</span>';





        $element_edit_str.='';

        $element_edit_str.='<p class="buttons-con"><button class="button-primary btn-delete-itm btn-delete-element">'.__('Delete Element').'</button> <button class="button--secondary button btn-done-editing"><span class="button-label">'.__('Done Editing').'</span></button> </p>
        ';





        // -- screen in editor
        $fout.='<div class="dzspgb-element-con" data-type="query">
        <div class="hidden-content style-update-holder type-update-holder"><br>'.$element_edit_str.'</div>
        <div class="dzspgb-element-type the-type-query" data-type="'.$id.'">
            
            <span class="move-handler-for-elements"><i class="fa fa-arrows-v"></i></span>
            <span class="clone-handler-for-elements"><i class="fa fa-clone"></i></span>
            
            <span class="icon-con"><i class="fa fa-cubes"></i></span><h5>'.__('Query').'</h5><div class="the-excerpt-real">'.__("Query Style - ").'<strong>{{style}}</strong><br>'.__("Query Type - ").'<strong>{{type}}</strong></div><p class="the-excerpt">'.__("This outputs the current special page query. For example, for a Explore page, it outputs all the tracks uploaded, and for a Likes page it outputs the user s liked pages.").'</p><span class="dzspgb-button dzspgb-button-choose">'.$margs['txt_choose'].'
            </span>
        </div>
        <input type="hidden" name="'.$margs['type_elements'].$ind.'[type_element]" value="'.$id.'"/>
        </div><!-- END dzspgb-element-con -->';

//        $fout.='</div>';






        return $fout;



    }
}




if(!function_exists('shortcode_query')){
    function shortcode_query($pargs=array(),$content=''){

        $id = 'query';

        global $dzsap_portal;
        global $default_opts;

        $fout = '';

        $margs = array(
            'type' => '', // -- auto or default or list or slider ...tbc
            'style' => 'auto', // -- auto or default or list or slider ...tbc
            'query_type' => 'auto', // -- auto or explore or mytracks or playlist or playlists or stream or
            'pagination' => 'auto', // -- auto or none or ajax or pages or pagesajax
            'apconfig' => '', // -- the audio player configuration
            'extra_classes' => '', // -- the audio player configuration
            'paged' => '', // -- the displayed page
            'interval' => '', // -- the displayed page
            'post_type' => '', // -- the post type - only for specific query_type
            'thumbs_disable_arrows' => "off",
            'thumbs_see_all_text' => "",
            'design_bulletspos' => "",
            'style_thumb_replace_page' => "",
            'thumbs_bullets_position' => "bottom",
            'thumbs_display_title_and_price' => "off",
        );

        $margs=array_merge($margs,$default_opts[$id]);

        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }




        if(intval($margs['paged'])){
            $margs['paged'] = intval($margs['paged']) - 1;
        }

        if(($margs['call_from_lab'])){
            $margs['call_from'] = ($margs['call_from_lab']);
        }

//        echo ' query margs - ';print_r($margs);


$fout.='<div class="shortcode-query-main  '.$margs['extra_classes'].'  shortcode-query-type-'.$margs['type'].' style-'.$margs['style'].' pagination-'.$margs['pagination'].'" style="">';

        $fout.=$dzsap_portal->get_query($margs);

        $fout.='<div class="clear"></div>
</div>';




        if(is_array($dzsap_portal->notices_array) && count($dzsap_portal->notices_array)>0){
            foreach($dzsap_portal->notices_array as $lab => $notice){

                if($notice['notice_for']=='temp_query_notice'){
                    $fout.= '<div class="alert alert-'.$notice['notice_type'].'">'.$notice['notice_html'].'</div>';


                    unset($dzsap_portal->notices_array[$lab]);


                }

            }
        }



            return $fout;
    }
}
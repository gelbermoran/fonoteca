<?php
$id = 'templates';

$dzspgb_templates[$id] = array(
    'id' => $id,
    'admin_str_function' => 'admin_str_function_templates',
);


if(!function_exists('admin_str_function_templates')){
    function admin_str_function_templates($pargs=array()){



        global $dzspgb_forportal;

        $id = 'templates';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'element_index' => '0',
            'type' => 'element',
            'type_element' => $id,
            'type_pb' => "Full",
            'txt_choose' => __("Choose"),
            'type_elements' => "newelement", // -- newelement (js) or dzspgb (php) ( legit )
            'template' => "",
            'template_id' => "",
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }


        $fout = '';
        $ind='';
        $element_edit_str='';



        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']['.$margs['element_index'].']';






        $lab = 'template_id';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';


        $auxa = ($dzspgb_forportal->select_templates_array());


        $arr_opts = array();
        foreach($auxa as $auxa_it){

            $auxb = array(
                'val' => $auxa_it['id'],
                'lab' => $auxa_it['template_name'],
            );

            array_push($arr_opts,$auxb);
        }






        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Style').'</span>
'.DZSHelpers::generate_select($nam, array('class'=>'dzs-style-me skin-beige ','options'=>$arr_opts,'seekval'=>$margs[$lab],)).'
</span>';


        $element_edit_str .= '

        <p class="buttons-con">
        <button class="button-primary btn-delete-itm btn-delete-element">'.__('Delete Element').'</button> <button class="button button--secondary btn-done-editing"><span class="button-label">'.__('Done Editing').'</span></button> </p>
        ';


        $fout.='<span class="dzspgb-element-con"><span class="hidden-content">'.$element_edit_str.'</span><span class="dzspgb-element-type the-type-text" data-type="'.$id.'">
            <span class="move-handler-for-elements"><i class="fa fa-arrows-v"></i>
            </span><span class="icon-con"><i class="fa fa-file-code-o"></i></span><h5>'.__('Template Element').'</h5><p class="the-excerpt">'.__("Insert a template element. Edit Templates in the Templates menu.").'</p><span class="dzspgb-button dzspgb-button-choose">'.$margs['txt_choose'].'</span></span><input type="hidden" name="'.$margs['type_elements'].$ind.'[type_element]" value="'.$id.'"/></span>';

        return $fout;
    }
}




if(!function_exists('shortcode_templates')){
    function shortcode_templates($pargs=array(),$content=''){

        global $dzsap_portal;

        $fout = '';

        $margs = array(
            'type_element' => 'header',
            'header_style' => 'style_default',
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }



//        print_r($margs);



        $auxa = ($dzsap_portal->select_template_array($margs['template_id']));
        $auxtem = array();


        if(isset($auxa[0])){
            parse_str($auxa[0]['template_data'], $auxtem);



            if($dzsap_portal->main_settings['debug_pagebuilder']=='on') {
                echo 'what is auxtem? --- ';
                print_r(($auxtem));;
                echo ' <--- ||| ';
            }

            $shortcode_text = $dzsap_portal->transform_to_shortcode( ($auxtem));


            if($dzsap_portal->main_settings['debug_pagebuilder']=='on') {
                echo 'what is shortcode text ? --- ';print_r(stripslashes($shortcode_text));; echo ' <--- END SHORTCODE TEXT ||| ';
            }



            $fout.=$dzsap_portal->do_shortcode(stripslashes($shortcode_text));


//        echo 'what is fout text ? --- ';print_r($fout);; echo ' <---';

//        $fout.='tes2t';


//        return '';

            return $fout;
        }


    }
}
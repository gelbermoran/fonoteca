<?php
$id = 'artist_query';

$dzspgb_templates[$id] = array(
    'id' => $id,
    'admin_str_function' => 'admin_str_function_artist_query',
);


if(!function_exists('admin_str_function_artist_query')){
    function admin_str_function_artist_query($pargs=array()){
        global $dzspgb_forportal, $dzsap_portal;

        $id = 'artist_query';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'element_index' => '0',
            'type' => 'element',
            'type_element' => $id,
            'type_pb' => "Full",
            'txt_choose' => __("Choose"),
            'type_elements' => "newelement", // -- newelement (js) or dzspgb (php) ( legit )
            'text' => "",
            'apconfig' => "",
            'ids' => "",
            'item' => array(),
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }

//        print_r($margs);

        $fout = '';
        $ind='';
        $element_edit_str='';



        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']['.$margs['element_index'].']';

//        echo 'alceva'.$ind;


        $lab = ''.$margs['type_elements'].$ind.'[artist_query_height]';

        $element_edit_str.='';



        $lab = 'style';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';


        $args = array(
            'for_ajax'=>false,
            'post_type'=>'apconfig',
        );

        $auxa = ($dzspgb_forportal->ajax_select_pages_array($args));


        $apconfigs = json_decode($auxa,true);

//        print_r($apconfigs);

        $arr_opts = array(
            array(
                'lab' => __('Automatic'),
                'val' => 'auto',
            ),
            array(
                'lab' => __('List'),
                'val' => 'list',
            ),
            array(
                'lab' => __('List Nova'),
                'val' => 'list-nova',
            ),
            array(
                'lab' => __('Artist Presentation'),
                'val' => 'presentation',
            ),
            array(
                'lab' => __('Thumbs'),
                'val' => 'thumbs',
            ),
            array(
                'lab' => __('Thumbs Sliders'),
                'val' => 'thumbs_slider',
            ),
        );





        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Style').'</span>
'.DZSHelpers::generate_select($nam, array('class'=>'dzs-style-me skin-beige ','options'=>$arr_opts,'seekval'=>$arr_opts,)).'
</span>';



        $lab = 'type';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';


        $args = array(
            'for_ajax'=>false,
            'post_type'=>'apconfig',
        );

        $auxa = ($dzspgb_forportal->ajax_select_pages_array($args));


        $apconfigs = json_decode($auxa,true);

//        print_r($apconfigs);

        $arr_opts = array(
            array(
                'lab' => __('Automatic'),
                'val' => 'auto',
            ),
            array(
                'lab' => __('Custom'),
                'val' => 'custom',
            ),
        );





        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Type').'</span>
'.DZSHelpers::generate_select($nam, array('class'=>'dzs-style-me skin-beige ','options'=>$arr_opts,'seekval'=>$arr_opts,)).'
</span>';





        $lab = 'ids';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';


        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Authors Ids').'</span>
'.DZSHelpers::generate_input_text($nam, array('class'=>'simple-input-text ','seekval'=>$margs[$lab],)).'
<span class="sidenote">'.__("The authors to display, input here ids separate by comma (,) ie <em>1,3,5</em>.").'</span>
</span>';





        $element_edit_str.='';

        $element_edit_str.='<p class="buttons-con"><button class="button-primary btn-delete-itm btn-delete-element">'.__('Delete Element').'</button> <button class="button--secondary button btn-done-editing"><span class="button-label">'.__('Done Editing').'</span></button> </p>
        ';





        // -- screen in editor
        $fout.='<div class="dzspgb-element-con" data-type="artist_query">
        <div class="hidden-content"><br>'.$element_edit_str.'</div>
        <span class="dzspgb-element-type the-type-'.$id.'" data-type="'.$id.'">
            <span class="move-handler-for-elements"><i class="fa fa-arrows-v"></i>
            </span>
            <span class="icon-con"><i class="fa fa-headphones"></i></span><h5>'.__('Artist Query').'</h5><p class="the-excerpt">'.__("This outputs featured artists list.").'</p><span class="dzspgb-button dzspgb-button-choose">'.$margs['txt_choose'].'
            </span>
        </span>
        <input type="hidden" name="'.$margs['type_elements'].$ind.'[type_element]" value="'.$id.'"/>
        </div><!-- END dzspgb-element-con -->';

//        $fout.='</div>';

        return $fout;
    }
}




if(!function_exists('shortcode_artist_query')){
    function shortcode_artist_query($pargs=array(),$content=''){

        global $dzsap_portal;

        $fout = '';

        $margs = array(
            'style' => 'auto', // -- auto or default or list or slider ...tbc
            'type' => 'auto', // -- auto or explore or mytracks or playlist or playlists or stream or
            'pagination' => 'auto', // -- auto or none or ajax or pages or pagesajax
            'apconfig' => '', // -- the audio player configuration
            'ids' => '', // -- the audio player configuration
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }



//        print_r($margs);

$fout.='<div class="shortcode-artist-query" style="">';

        $fout.=$dzsap_portal->get_query_artist($margs);

        $fout.='<div class="clear"></div>
</div>';



            return $fout;
    }
}
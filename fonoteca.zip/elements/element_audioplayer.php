<?php
$id = 'audioplayer';

$dzspgb_templates[$id] = array(
    'id' => $id,
    'admin_str_function' => 'admin_str_function_audioplayer',
);


if(!function_exists('admin_str_function_audioplayer')){
    function admin_str_function_audioplayer($pargs=array()){

        $id = 'audioplayer';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'element_index' => '0',
            'type' => 'element',
            'type_element' => $id,
            'type_pb' => "Full",
            'txt_choose' => __("Choose"),
            'type_elements' => "newelement", // -- newelement (js) or dzspgb (php) ( legit )
            'text' => "",
            'item' => array(),
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }

//        print_r($margs);

        $fout = '';
        $ind='';
        $element_edit_str='';



        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']['.$margs['element_index'].']';

//        echo 'alceva'.$ind;


        $element_edit_str .= '<span class="setting">
        <span class="setting-label">'.__('The Text').'</span>
<textarea class="formstyle" name="'.$margs['type_elements'].$ind.'[text]">'.$margs['text'].'</textarea>
</span>';

        $lab = ''.$margs['type_elements'].$ind.'[audioplayer_style]';
        $arr_opts = array(
            'style_default',
        );
        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Style').'</span>
'.DZSHelpers::generate_select($lab, array('class'=>'dzs-style-me skin-beige ','options'=>$arr_opts,)).'
</span>';

        $element_edit_str.='<p class="buttons-con"><button class="button-primary btn-delete-itm btn-delete-element">'.__('Delete Element').'</button> <button class="button-secondary btn-done-editing">'.__('Done Editing').'</button> </p>
        ';





        // -- screen in editor
        $fout.='<span class="dzspgb-element-con"><span class="hidden-content">'.$element_edit_str.'</span><span class="dzspgb-element-type the-type-text" data-type="'.$id.'"><span class="icon-con"><i class="fa fa-soundcloud"></i></span><h5>'.__('Player ').'</h5><p class="the-excerpt">'.__("Use this element for breaking out to a full width container.").'</p><span class="dzspgb-button dzspgb-button-choose">'.$margs['txt_choose'].'</span></span><input type="hidden" name="'.$margs['type_elements'].$ind.'[type_element]" value="'.$id.'"/></span>';

        return $fout;
    }
}




if(!function_exists('shortcode_audioplayer')){
    function shortcode_audioplayer($pargs=array(),$content=''){

        global $dzsap_portal;

        $fout = '';

        $margs = array(
            'type_element' => 'audioplayer',
            'audioplayer_style' => 'style_default',
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }



//        print_r($margs);

$fout.='<div class="shortcode-audioplayer">';
$fout.='<span class="logo-con menu-span-left">
<ul class="audioplayer-menu"><li><a class="menu-item current-menu-item" href="#">Home</a></li><li><a class="menu-item" href="#">Explore</a></li></ul>
                        </span><span class="logo-con menu-span-center"><img class="portal-logo" src="img/logo.png"
                                                                            height="100%"/>
                        </span>
                        <span class="audioplayer--right  menu-span-right">

                            <span class="menu-right-block-language menu-right-block dzstooltip-con for-hover"><i
                                    class="fa fa-search"></i></span>
                            <span class="menu-right-block-language menu-right-block dzstooltip-con for-hover">
                                <span class="menu-right-block-language--label">
                                    <span class="language-icon"><img src="img/usa.png"/></span><i
                                        style="vertical-align: middle; font-size: 14px; position: relative; top: -4px;"
                                        class="fa fa-sort-desc"></i><span class="language-select-icon"></span>
                                </span>
                                <span class="menu-right-block-inmenu dzstooltip arrow-top align-right skin-black ">
                                    <ul class="languages-list">
                                        <li class="active"><a href="'.DZSHelpers::add_query_arg('lang', 'en_EN',dzs_curr_url()).'"><span class="language-icon"><img
                                                    src="img/usa.png"/></span><span
                                                class="language-label">English</span></a></li>
                                        <li><span class="language-icon"><img src="img/germany.png"/></span><span
                                                class="language-label">Germany</span></li>
                                        <li><span class="language-icon"><img src="img/spain.png"/></span><span
                                                class="language-label">Spain</span></li>
                                    </ul>
                                </span>

                            </span>
                        ';


                                if ($dzsap_portal->currUserId === '0') {
                                    $fout.= '<span class="login-login menu-right-block dzstooltip-con for-hover"><span class="login-signup--label">Log In</span>'
                                        . '<span class="menu-right-block-inmenu dzstooltip arrow-top align-right skin-black "><ul class="notices-box">' . $dzsap_portal->notices_html . '</ul>
                    <a class="facebook-box">Sign in with Facebook</a>
                    <div class="table-separator light">
                        <span class="table-cell"><span class="the-line"></span></span>
                        <span class="table-center">or</span>
                        <span class="table-cell"><span class="the-line"></span></span>

                    </div>
                    <h5 class="input-label">Sign in with email</h5>

                    <form class="login-form" method="POST">
                        <input type="hidden" name="action" value="login"/>
                        <input type="email" class="fullwidth simple-input-field" name="email"/>
                        <h5 class="input-label">Password</h5>
                        <input type="password" class="fullwidth simple-input-field" name="pass"/>
                        <br>
                        <br>
                        <button class="button-primary register-btn">Login</button>
                    </form>
                    </span>
                    </span>' . '';
                                } else {
                                    $fout.= ''
                                        . '<span class="user-menu-con">'
                                        . '<span class="user-avatar" style="background-image: url(' . $dzsap_portal->get_avatar($dzsap_portal->currUserId) . ');"></span>'
                                        . '<ul class="user-menu--options">'
                                        . '<li><a href="' . $dzsap_portal->url_portalphp . '?page=usersettings"><i class="fa fa-gear"></i> &nbsp;Settings</a></li>'
                                        . '<li><a href="' . $dzsap_portal->url_portalphp . '?page=uservideos&id_user=' . $dzsap_portal->currUserId . '"><i class="fa fa-video-camera"></i> &nbsp;'.__('My Tracks').'</a></li>'
                                        . '<li><a style="display:inline-block; vertical-align:middle;" class="anchor-page-upload" href="' . $dzsap_portal->url_portalphp . '?page=upload"><i class="fa fa-upload"></i> &nbsp;'.__('Upload').'</a></li>'
                                        . '<li><a href="' . $dzsap_portal->url_portalphp . '?page=userplaylists"><i class="fa fa-reorder"></i> &nbsp;Playlists</a></li>'
                                        . '<li><form style="display:block;"  class="logout-form" method="post"><button name="action" value="logout" class="btn-nostyling"><i class="fa fa-plug"></i> &nbsp;Log Out</button></form></li>'
                                        . '</ul>'
                                        . '</span>';
                                }

        $fout.='</span><div class="clear"></div>
</div>';



            return $fout;
    }
}
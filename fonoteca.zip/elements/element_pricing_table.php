<?php
$id = 'pricing_table';

$dzspgb_templates[$id] = array(
    'id' => $id,
    'admin_str_function' => 'admin_str_function_pricing_table',
);

if(!function_exists('generate_item_col1')) {
    function generate_item_col1($pargs = array()){

        $margs = array(
            'is_clone' => false,
            'imgsource' => '',
            'extra_classes' => '',
        );

        if($pargs){
            $margs = array_merge($margs,$pargs);
        }

        $fout = '';

        $margs['imgsource'] = str_replace('{replacequotquot}','"', $margs['imgsource']);

        // -- name= '.$margs['type_elements'].$ind.'['.$multiple_items_lab.']

        // -- clone element, we need this for the others to replicate based on this
        $fout.='<div class="dzspgb-item ';

        if($margs['is_clone']){
            $fout.='  for-clone-item';
        }

        $fout.='"><input type="text" class="simple-input-field target-field dzspgb-item--field exclude-from-row-part-atts"  data-actuallabel="imgsource" name="" value="'.$margs['imgsource'].'"/> <input type="text" class="simple-input-field target-field dzspgb-item--field exclude-from-row-part-atts"  data-actuallabel="extra_classes" name="" value="'.$margs['extra_classes'].'" placeholder="'.__("Extra Classes").'"/>
        <span class="move-handler-for-multiple-items"><i class="fa fa-arrows-v"></i></span><span class="delete-handler-for-multiple-items"><i class="fa fa-trash-o"></i></span>
</div>';


        return $fout;

    }
}

if(!function_exists('admin_str_function_pricing_table')){
    function admin_str_function_pricing_table($pargs=array()){

        $id = 'pricing_table';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'element_index' => '0',
            'type' => 'element',
            'type_element' => $id,
            'type_pb' => "Full",
            'txt_choose' => __("Choose"),
            'type_elements' => "newelement", // -- newelement (js) or dzspgb (php) ( legit )
            'text' => "",
            'extra_classes' => "",
            'nr_columns' => "2",
            'multiple_items' => array(),
            'multiple_items2' => array(),
            'multiple_items3' => array(),
            'multiple_items4' => array(),
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }

//        print_r($margs);

        $fout = '';
        $ind='';
        $element_edit_str='';



        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']['.$margs['element_index'].']';

//        echo 'alceva'.$ind;


//        $element_edit_str .= '<span class="setting">
//        <span class="setting-label">'.__('The Text').'</span>
//<textarea class="tinymce-me" name="'.$margs['type_elements'].$ind.'[text]">'.$margs['text'].'</textarea>';
//        $element_edit_str.='</span>';



        $lab = 'nr_columns';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';


        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Number of Columns').'</span>
'.DZSHelpers::generate_input_text($nam, array('class'=>'simple-input-text ','seekval'=>$margs[$lab],)).'
<span class="sidenote">'.__("The track id, leave blank for the current track page.").'</span>
</span>';


        $lab = 'extra_classes';
        $element_edit_str .= '<span class="setting">
        <span class="setting-label">'.__('Extra Classes').'</span>
<textarea class="textarea-extra-css formstyle" name="'.$margs['type_elements'].$ind.'['.$lab.']">'.$margs[$lab].'</textarea>';
        $element_edit_str.='</span>';




        // -- repeater con
        $multiple_items_lab = 'item';

        $element_edit_str.='<span class="setting dzspgb-multiple-items-con" data-actuallabelcon="'.$multiple_items_lab.'" data-startname="'.$margs['type_elements'].$ind.'['.$multiple_items_lab.']">';

        $element_edit_str.='<input type="hidden" class="dzspgb-item--field--typer" name="'.$margs['type_elements'].$ind.'['.$multiple_items_lab.'][type]" value="multipleitems"/>';

        $element_edit_str.='<span class="setting-label">'.__('Items').'</span>';

        // -- name= '.$margs['type_elements'].$ind.'['.$multiple_items_lab.']






        $actual_label = 'imgsource';



        $args = array(
            'is_clone' => true,
            'imgsource' => '',
        );

        $element_edit_str.=generate_item_col1($args);

//        print_r($margs['multiple_items']);


        $multiple_items = $margs['multiple_items'];

        if(isset($multiple_items[$multiple_items_lab])){
//            print_r($multiple_items[$multiple_items_lab]);

            foreach($multiple_items[$multiple_items_lab] as $lab => $val){
                if($lab==='type'){
                    continue;
                }

                $args = array(
                    'is_clone' => false,
                    'imgsource' => $val['imgsource'],
                );
                $element_edit_str.=generate_item_col1($args);

            }
        }



        $element_edit_str.='<button class="button button--secondary btn-add-item"><span class="button-label">'.__('Add Item').'</span></button>';
        $element_edit_str.='</span>';





        // -- repeater con
        $multiple_items_lab = 'item2';

        $element_edit_str.='<span class="setting dzspgb-multiple-items-con" data-actuallabelcon="'.$multiple_items_lab.'" data-startname="'.$margs['type_elements'].$ind.'['.$multiple_items_lab.']">';

        $element_edit_str.='<input type="hidden" class="dzspgb-item--field--typer" name="'.$margs['type_elements'].$ind.'['.$multiple_items_lab.'][type]" value="multipleitems2"/>';



        $element_edit_str.='<span class="setting-label">'.__('Items 2').'</span>';



        $actual_label = 'imgsource';



        $args = array(
            'is_clone' => true,
            'imgsource' => '',
        );

        $element_edit_str.=generate_item_col1($args);

//        print_r($margs['multiple_items']);


        $multiple_items = $margs['multiple_items2'];

        if(isset($multiple_items[$multiple_items_lab])){
//            print_r($multiple_items[$multiple_items_lab]);

            foreach($multiple_items[$multiple_items_lab] as $lab => $val){
                if($lab==='type'){
                    continue;
                }

                $args = array(
                    'is_clone' => false,
                    'imgsource' => $val['imgsource'],
                );
                $element_edit_str.=generate_item_col1($args);

            }
        }



        $element_edit_str.='<button class="button button--secondary btn-add-item"><span class="button-label">'.__('Add Item').'</span></button>';
        $element_edit_str.='</span>';


        // -- repeater con END



        // -- repeater con
        $multiple_items_lab = 'item3';

        $element_edit_str.='<span class="setting dzspgb-multiple-items-con" data-actuallabelcon="'.$multiple_items_lab.'" data-startname="'.$margs['type_elements'].$ind.'['.$multiple_items_lab.']">';

        $element_edit_str.='<input type="hidden" class="dzspgb-item--field--typer" name="'.$margs['type_elements'].$ind.'['.$multiple_items_lab.'][type]" value="multipleitems3"/>';



        $element_edit_str.='<span class="setting-label">'.__('Items 3').'</span>';



        $actual_label = 'imgsource';



        $args = array(
            'is_clone' => true,
            'imgsource' => '',
        );

        $element_edit_str.=generate_item_col1($args);

//        print_r($margs['multiple_items']);


        $multiple_items = $margs['multiple_items3'];

        if(isset($multiple_items[$multiple_items_lab])){
//            print_r($multiple_items[$multiple_items_lab]);

            foreach($multiple_items[$multiple_items_lab] as $lab => $val){
                if($lab==='type'){
                    continue;
                }

                $args = array(
                    'is_clone' => false,
                    'imgsource' => $val['imgsource'],
                );
                $element_edit_str.=generate_item_col1($args);

            }
        }



        $element_edit_str.='<button class="button button--secondary btn-add-item"><span class="button-label">'.__('Add Item').'</span></button>';
        $element_edit_str.='</span>';



        // -- repeater con END







        // -- repeater con
        $multiple_items_lab = 'item4';

        $element_edit_str.='<span class="setting dzspgb-multiple-items-con" data-actuallabelcon="'.$multiple_items_lab.'" data-startname="'.$margs['type_elements'].$ind.'['.$multiple_items_lab.']">';

        $element_edit_str.='<input type="hidden" class="dzspgb-item--field--typer" name="'.$margs['type_elements'].$ind.'['.$multiple_items_lab.'][type]" value="multipleitems4"/>';



        $element_edit_str.='<span class="setting-label">'.__('Items 4').'</span>';



        $actual_label = 'imgsource';



        $args = array(
            'is_clone' => true,
            'imgsource' => '',
        );

        $element_edit_str.=generate_item_col1($args);

//        print_r($margs['multiple_items']);


        $multiple_items = $margs['multiple_items4'];

        if(isset($multiple_items[$multiple_items_lab])){
//            print_r($multiple_items[$multiple_items_lab]);

            foreach($multiple_items[$multiple_items_lab] as $lab => $val){
                if($lab==='type'){
                    continue;
                }

                $args = array(
                    'is_clone' => false,
                    'imgsource' => $val['imgsource'],
                );
                $element_edit_str.=generate_item_col1($args);

            }
        }



        $element_edit_str.='<button class="button button--secondary btn-add-item"><span class="button-label">'.__('Add Item').'</span></button>';
        $element_edit_str.='</span>';



        // -- repeater con END












        $element_edit_str.='<p class="buttons-con"><button class="button-primary btn-delete-itm btn-delete-element">'.__('Delete Element').'</button> <button class="button button--secondary btn-done-editing"><span class="button-label">'.__('Done Editing').'</span></button> </p>
        ';


//        $margs = array_merge($margs, $pargs);


        // -- how it appears in the editor
        $fout.='<span class="dzspgb-element-con"><span class="hidden-content  the-type-'.$id.'">'.$element_edit_str.'</span><span class="dzspgb-element-type the-type-'.$id.'" data-type="'.$id.'"><span class="move-handler-for-elements"><i class="fa fa-arrows-v"></i></span>
        <span class="icon-con"><i class="fa fa-table"></i></span><h5>'.__('Pricing Table ').'</h5><p class="the-excerpt">Lorem ipsum dolor amet a...</p><span class="dzspgb-button dzspgb-button-choose">'.$margs['txt_choose'].'</span></span><input type="hidden" name="'.$margs['type_elements'].$ind.'[type_element]" value="'.$id.'"/></span>';

        return $fout;
    }
}




if(!function_exists('shortcode_pricing_table')){
    function shortcode_pricing_table($pargs=array(),$content=''){

        global $dzsap_portal;

        $fout = '';

        $margs = array(
            'type_element' => 'pricing_table',
            'nr_columns' => '2',
            'extra_classes' => '',
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }


//        echo 'hmmdada2';
//        print_r($margs); print_r($content);
//        echo 'hmmdada2END';



        preg_match_all("/\[dzspgb_item([\s|\S]*?)\]([\s|\S]*?)\[\/dzspgb_item]/", $content, $output_array);

//        print_r($output_array);

        if($output_array && count($output_array[0])>0){

            $fout.='<div class="dzspt-table skin-default '.$margs['extra_classes'].' ';



            if($margs['nr_columns']=='2'){
                $fout.='two-in-a-row';
            }
            if($margs['nr_columns']=='3'){
                $fout.='three-in-a-row';
            }
            if($margs['nr_columns']=='4'){
                $fout.='four-in-a-row';
            }

            $fout.='">';



            for($i=0; $i<intval($margs['nr_columns']);$i++){

                $fout.='<div class="dzspt-col"><div class="dzspt-col-inner">';


                for($i2=0;$i2<count($output_array[0]);$i2++){

                    $margs_item = array(
                        'imgsource'=>'',
                        'label'=>'',
                    );
                    $pargs_item = ($dzsap_portal->get_shortcode_atts($output_array[1][$i2]));

                    $margs_item = array_merge($margs_item, $pargs_item);

//                print_r($margs_item);


                    $needle_label = 'item'.($i+1);

                    if($i===0){
                        $needle_label = 'item';
                    }


//                    echo '..'.$margs_item['label'].'|'.$needle_label.'..';
                    if($margs_item['label']===$needle_label){

                        $fout.='<div class="dzspt-item';


                        $fout.=' '.$margs_item['extra_classes'];

                        $fout.='">';

                        $margs_item['imgsource'] = str_replace('{replacequotquot}','"', $margs_item['imgsource']);
                        $fout.=''.$margs_item['imgsource'].'';
                        $fout.='</div>';
                    }

//                    $fout.='<li class="item-tobe needs-loading"><div class="imagediv" style="background-image:url()"></div></li></li>';


                }

                $fout.='</div></div>';
            }



            $fout.='</div>';
        }


        if(function_exists('enqueue_script')) {

            enqueue_script('dzs.pricingtables', 'libs/pricingtables/pricingtables.js');
            enqueue_style('dzs.pricingtables', 'libs/pricingtables/pricingtables.css');
        }


        return $fout;
    }
}
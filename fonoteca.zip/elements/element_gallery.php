<?php
$id = 'gallery';

$dzspgb_templates[$id] = array(
    'id' => $id,
    'admin_str_function' => 'admin_str_function_gallery',
);


if(!function_exists('admin_str_function_gallery')){
    function admin_str_function_gallery($pargs=array()){

        $id = 'gallery';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'element_index' => '0',
            'type' => 'element',
            'type_element' => $id,
            'type_pb' => "Full",
            'txt_choose' => __("Choose"),
            'type_elements' => "newelement", // -- newelement (js) or dzspgb (php) ( legit )
            'text' => "",
            'flickr_username' => "",
            'flickr_api_key' => "",
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }


        $fout = '';
        $ind='';
        $element_edit_str='';



        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']['.$margs['element_index'].']';

//        echo 'alceva'.$ind;

        $lab = 'flickr_username';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';

        $element_edit_str .= '<span class="setting">
        <span class="setting-label">'.__('Flickr Username').'</span>
'.DZSHelpers::generate_input_text($nam, array('class'=>'simple-input-text ','seekval'=>$margs[$lab],)).'
        </span>
        ';

        $lab = 'flickr_api_key';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';

        $element_edit_str .= '<span class="setting">
        <span class="setting-label">'.__('Flickr API Key').'</span>
'.DZSHelpers::generate_input_text($nam, array('class'=>'simple-input-text ','seekval'=>$margs[$lab],)).'
<span class="sidenote">'.__('Get an api key from <a href="https://www.flickr.com/services/apps/">here</a>.').'</span>
</span>
        ';


        $element_edit_str.='<p class="buttons-con"><button class="button-primary btn-delete-itm btn-delete-element">'.__('Delete Element').'</button> <button class="button button--secondary btn-done-editing"><span class="button-label">'.__('Done Editing').'</span></button> </p>
 ';


        // -- screen in editor
        $fout.='<span class="dzspgb-element-con"><span class="hidden-content">'.$element_edit_str.'</span><span class="dzspgb-element-type the-type-'.$id.'" data-type="'.$id.'">
        <span class="move-handler-for-elements"><i class="fa fa-arrows-v"></i></span>
        <span class="clone-handler-for-elements"><i class="fa fa-clone"></i></span>
        <span class="icon-con"><i class="fa fa-flickr"></i></span><h5>'.__('Gallery').'</h5><p class="the-excerpt">'.__("Use this element for breaking out to a full width container.").'</p><span class="dzspgb-button dzspgb-button-choose">'.$margs['txt_choose'].'</span></span><input type="hidden" name="'.$margs['type_elements'].$ind.'[type_element]" value="'.$id.'"/></span>';

        return $fout;
    }
}



if(!function_exists('shortcode_gallery')){
    function shortcode_gallery($pargs=array(),$content=''){

        global $dzsap_portal;

        $fout = '';

        $margs = array(
            'gallery_height' => '10',
            'is_negative' => 'off',
            'flickr_username' => '',
            'flickr_api_key' => '',
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }



//        print_r($margs);

        $fout.='<div class="shortcode-gallery" style="">';

        $feed = file_get_contents('https://api.flickr.com/services/rest/?method=flickr.people.getPhotos&api_key='.$margs['flickr_api_key'].'&user_id='.$margs['flickr_username'].'&per_page=6&format=json&nojsoncallback=1');

        $feed_arr = json_decode($feed);

//        print_r($feed_arr);

        foreach($feed_arr->photos->photo as $it){

            $fout.='<a class="gallery-item-con zoombox-delegated" href="https://farm'.$it->farm.'.staticflickr.com/'.$it->server.'/'.$it->id.'_'.$it->secret.'_h.jpg" data-biggallery="gallery1">';

//            $fout.='<img src="https://farm'.$it->farm.'.staticflickr.com/'.$it->server.'/'.$it->id.'_'.$it->secret.'_q.jpg"/>';
            $fout.='<div class="divimage" style="background-image:url(https://farm'.$it->farm.'.staticflickr.com/'.$it->server.'/'.$it->id.'_'.$it->secret.'_q.jpg)"></div>';

            $fout.='<div class="zoom-icon-con"><i class="fa fa-search"></i></div>';

            $fout.='</a>';


        }



        $fout.='<div class="clear"></div>
</div>';



        return $fout;
    }
}
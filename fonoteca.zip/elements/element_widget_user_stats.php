<?php
$id = 'widget_stats';

$dzspgb_templates[$id] = array(
    'id' => $id,
    'admin_str_function' => 'admin_str_function_'.$id,
);


if(!function_exists('admin_str_function_widget_stats')){
    function admin_str_function_widget_stats($pargs=array()){
        global $dzspgb_forportal, $dzsap_portal;

        $id = 'widget_stats';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'element_index' => '0',
            'type' => 'element',
            'type_element' => $id,
            'type_pb' => "Full",
            'txt_choose' => __("Choose"),
            'type_elements' => "newelement", // -- newelement (js) or dzspgb (php) ( legit )

            'id_user' => "auto",

            'item' => array(),
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }

//        print_r($margs);

        $fout = '';
        $ind='';
        $element_edit_str='';



        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']['.$margs['element_index'].']';

//        echo 'alceva'.$ind;




        $lab = 'id_user';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';


        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('User Id').'</span>
'.DZSHelpers::generate_input_text($nam, array('class'=>'simple-input-text ','seekval'=>$margs[$lab],)).'
<span class="sidenote">'.__("leave auto for the user id to be get depending on the current page").'</span>
</span>';






        $lab = 'type';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';


//        print_r($apconfigs);

        $arr_opts = array(
            array(
                'lab' => __('Followers'),
                'val' => 'followers',
            ),
            array(
                'lab' => __('Likes'),
                'val' => 'likes',
            ),
            array(
                'lab' => __('Stats'),
                'val' => 'stats',
            ),
            array(
                'lab' => __('User Description'),
                'val' => 'description',
            ),
            array(
                'lab' => __('Social Icons'),
                'val' => 'social_icons',
            ),
        );





        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Style').'</span>
'.DZSHelpers::generate_select($nam, array('class'=>'dzs-style-me skin-beige style-changer ','options'=>$arr_opts,'seekval'=>$margs[$lab],)).'
</span>';



        $lab = 'query_type';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';








        $element_edit_str.='';

        $element_edit_str.='<p class="buttons-con"><button class="button-primary btn-delete-itm btn-delete-element">'.__('Delete Element').'</button> <button class="button--secondary button btn-done-editing"><span class="button-label">'.__('Done Editing').'</span></button> </p>
        ';





        // -- screen in editor
        $fout.='<div class="dzspgb-element-con" data-type="widget_stats">
        <div class="hidden-content"><br>'.$element_edit_str.'</div>
        <span class="dzspgb-element-type the-type-'.$id.'" data-type="'.$id.'">
            <span class="move-handler-for-elements"><i class="fa fa-arrows"></i></span>
            <span class="clone-handler-for-elements"><i class="fa fa-clone"></i></span>
            <span class="icon-con"><i class="fa fa-users"></i></span><h5>'.__('Widget User Stats').'</h5><div class="the-excerpt-real">'.__("Query Type - ").'<strong>{{type}}</strong></div><p class="the-excerpt">'.__("This outputs the pages widget_stats.").'</p><span class="dzspgb-button dzspgb-button-choose">'.$margs['txt_choose'].'
            </span>
        </span>
        <input type="hidden" name="'.$margs['type_elements'].$ind.'[type_element]" value="'.$id.'"/>
        </div><!-- END dzspgb-element-con -->';

//        $fout.='</div>';

        return $fout;
    }
}




if(!function_exists('shortcode_widget_stats')){
    function shortcode_widget_stats($pargs=array(),$content=''){

        global $dzsap_portal;

        $fout = '';

        $margs = array(
            'id_user' => "",
            'type' => "followers",
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }



//        print_r($margs);

$fout.='<div class="shortcode-widget_stats type-'.$margs['type'].'" style="">';

        $id_user = $margs['id_user'];
        if($margs['id_user']=='' || $margs['id_user']=='auto'){

            if(isset($_GET['user_id'])){

                $id_user=$_GET['user_id'];
            }
        }

        if($dzsap_portal->query2_processed){
            $id_user = $dzsap_portal->query2_processed;
        }

        $dzsap_portal->target_user_id = $id_user;
//        echo $id_user;


//        print_r($_GET);


//        print_r($margs);
//        print_r($_GET);
//        $tr = $dzsap_portal->get_user($id_user);

//        print_r($tr);


//        $dzsap_portal->site_encryption_key = 'aaaabbbbccccdddd';
//        echo 'site_encryption_key -'.$dzsap_portal->site_encryption_key;
//        echo "\n".'mail_encrypted -'.simple_encrypt('ceva',$dzsap_portal->site_encryption_key);


        if($margs['type']=='followers'){




            $args = array(

                'id'=>$id_user,
                'query_type'=>'followers',
                'limit_query'=>'6',
                'call_from'=>'widget_followers',
            );

//            print_r($args);



            $users_followers = $dzsap_portal->get_tracks($args);


//        print_r($users_followers);

            if(is_array($users_followers) && count($users_followers)){



                foreach($users_followers as $pl){

                    if(isset($pl['post_type']) && $pl['post_type']=='repost'){
                        continue;
                    }

                    $l = $dzsap_portal->get_permalink($pl['id'], array(
                        'type'=>'user',
                    ));
                    $fout.='<a  href="'.$l.'" class="col-md-2 ajax-link user-round-view user-round-view--mini">';



                    $fout.='<div class="js-height-as-width the-avatar" style="background-image:url('.$dzsap_portal->sanitize_source($dzsap_portal->get_avatar($pl['id'])).'); " >';


                    $fout .= '</div>';






                    //                    print_r($pl);

                    $fout.='</a>';
                }

            }else{
                $fout.='<p>'.__("No Followers").'</p>';
            }




        }


        if($margs['type']=='likes'){



//            $us = $dzsap_portal->get_user($id_user);



//            $likes = $dzsap_portal->get_tracks(array(
//                'id_user'=>$id_user,
//                'table'=>'likes',
//                'query_type'=>'likes',
//                'get_only_count'=>false,
//            ));

//            print_r($us);



            $likes = $dzsap_portal->get_query(array(
                'id_user'=>$id_user,
                'table'=>'likes',
                'style'=>'list-nova',
                'query_type'=>'likes',
                'limit_posts'=>'3',
                'limit_query'=>'3',
                'get_only_count'=>false,
            ));


//            echo '$likes - '.$likes;
//            echo 'strlen($likes) - '.strlen($likes);

            if($likes && strlen($likes)>160){

                $fout.= $likes;
            }else{
                $fout.='<p>'.__("No Likes").'</p>';
            }




        }


        if($margs['type']=='stats'){



            $nr_views = 0;


            $all_user_tracks = array();

            $tracks = $dzsap_portal->get_tracks(array(
                'author_id'=>$id_user
            ));

//            print_r($tracks);

            if(is_array($tracks) && count($tracks)){
                foreach ($tracks as $tr){
                    $nr_views+=$dzsap_portal->mysql_get_track_activity($tr['id']);
                }

//                $nr_views++;
            }





            $following = $dzsap_portal->get_tracks(array(
                'id'=>$id_user,
                'table'=>'users',
                'query_type'=>'following',
                'get_only_count'=>false,
            ));

            $followers = $dzsap_portal->get_tracks(array(
                'id'=>$id_user,
                'table'=>'users',
                'query_type'=>'followers',
                'get_only_count'=>false,
            ));

            //        print_r($_GET);
            //
            //        echo 'likes - '; print_r($likes);

            $count_following = count($following);
            $count_followers = count($followers);


            $fout.='<div class="dzs-row dzs-row-stats">
                        <div class="dzs-col-xs-4">

                            <h5>'.__("Plays").'</h5>
                            <div class="the-number">'.$nr_views.'</div>
                        </div>
                        <div class="dzs-col-xs-4">

                            <h5>'.__("Followers").'</h5>
                            <div class="the-number">'.$count_followers.'</div>
                        </div>
                        <div class="dzs-col-xs-4">

                            <h5>'.__("Following").'</h5>
                            <div class="the-number">'.$count_following.'</div>
                        </div>
                    </div>';








            $nr_reposts=$dzsap_portal->mysql_get_track_activity($id_user,array(
            'get_last'=>'off',
            'interval'=>'24',
            'type'=>'repost',
            'table'=>'activity',
        ));


            if($nr_reposts==''){
                $nr_reposts = 0;
            }


            $likes = $dzsap_portal->get_tracks(array(
                'id_user'=>$id_user,
                'table'=>'likes',
                'query_type'=>'likes',
                'get_only_count'=>false,
            ));

//        print_r($_GET);
//
//        echo 'likes - '; print_r($likes);

            $count_likes = count($likes);



            $count_playlists = $dzsap_portal->get_tracks(array(
                'author_id'=>$id_user,
                'table'=>'playlists',
                'get_only_count'=>true,
                'call_from'=>'playlist_count',
            ));


//            print_r($nr_reposts);
            $fout.='<div class="dzs-row dzs-row-stats">
                        <div class="dzs-col-xs-4">

                            <h5>'.__("Reposts").'</h5>
                            <div class="the-number">'.$nr_reposts.'</div>
                        </div>
                        <div class="dzs-col-xs-4">

                            <h5>'.__("Likes").'</h5>
                            <div class="the-number">'.$count_likes.'</div>
                        </div>
                        <div class="dzs-col-xs-4">

                            <h5>'.__("Playlists").'</h5>
                            <div class="the-number">'.$count_playlists.'</div>
                        </div>
                    </div>';




        }




        if($margs['type']=='description'){



            $us = $dzsap_portal->get_user($id_user);



//            print_r($us);


            if($us['description']){

                $fout.=$us['description'];
            }else{

                $fout.='<p>'.__("No Description").'</p>';
            }




            $filter_replace_after_desc = '';
            ob_start();

            $dzsap_portal->do_action('filter_replace_after_desc');
            $filter_replace_after_desc.=ob_get_clean();




//            echo '$filter_replace_after_desc - '.$filter_replace_after_desc;



            if($filter_replace_after_desc){
                $fout.=$filter_replace_after_desc;
            }else{
                $lab = 'facebook_link';
                if($dzsap_portal->get_user_field($id_user,'facebook_link')){

                    $fout.='<a href="'.$dzsap_portal->get_user_field($id_user,$lab).'" target="_blank" class="custom-a social-icon-icon-desc"><span class="social-icon-con"><i class="fa fa-facebook"></i></span><span class="the-label">'.__("Facebook").'</span></a>';
                }

                $lab = 'twitter_link';
                if($dzsap_portal->get_user_field($id_user,$lab)){

                    $fout.='<a href="'.$dzsap_portal->get_user_field($id_user,$lab).'" target="_blank" class="custom-a social-icon-icon-desc"><span class="social-icon-con"><i class="fa fa-twitter"></i></span><span class="the-label">'.__("Twitter").'</span></a>';
                }
                $lab = 'soundcloud_link';
                if($dzsap_portal->get_user_field($id_user,$lab)){

                    $fout.='<a href="'.$dzsap_portal->get_user_field($id_user,$lab).'" target="_blank" class="custom-a social-icon-icon-desc"><span class="social-icon-con"><i class="fa fa-facebook"></i></span><span class="the-label">'.__("Soundcloud").'</span></a>';
                }
            }




            ob_start();

            $dzsap_portal->do_action('after_widget_description');
            $fout.=ob_get_clean();



        }

        if($margs['type']=='social_icons'){


            $lab = 'facebook_link';
            if($dzsap_portal->get_user_field($id_user,'facebook_link')){

                $fout.='<a href="'.$dzsap_portal->get_user_field($id_user,$lab).'" target="_blank" class="custom-a icon-share " style="display: inline-block;
    vertical-align: top;"><span class="social-square" style="background-color: #0c74ba"><i class="fa fa-facebook" style=""></i></span>
</a> ';
            }

            $lab = 'twitter_link';
            if($dzsap_portal->get_user_field($id_user,$lab)){

                $fout.='<a href="'.$dzsap_portal->get_user_field($id_user,$lab).'" target="_blank" class="custom-a icon-share " style="display: inline-block;
    vertical-align: top;"><span class="social-square" style="background-color: #589ece"><i class="fa fa-twitter" style=""></i></span>
</a> ';
            }
            $lab = 'soundcloud_link';
            if($dzsap_portal->get_user_field($id_user,$lab)){

                $fout.='<a href="'.$dzsap_portal->get_user_field($id_user,$lab).'" target="_blank" class="custom-a icon-share " style="display: inline-block;
    vertical-align: top;"><span class="social-square" style="background-color: #dc6f1f"><i class="fa fa-soundcloud" style=""></i></span>
</a> ';
            }



        }







        $fout.='<div class="clear"></div>
</div>';



            return $fout;
    }
}
<?php
$id = 'messages';

$dzspgb_templates[$id] = array(
    'id' => $id,
    'admin_str_function' => 'admin_str_function_messages',
);


if(!function_exists('admin_str_function_messages')){
    function admin_str_function_messages($pargs=array()){

        $id = 'messages';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'element_index' => '0',
            'type' => 'element',
            'type_element' => $id,
            'type_pb' => "Full",
            'txt_choose' => __("Choose"),
            'type_elements' => "newelement", // -- newelement (js) or dzspgb (php) ( legit )
            'text' => "",
            'messages_height' => "10",
            'item' => array(),
            'extra_classes'=>'',
            'is_negative'=>'',
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }

//        print_r($margs);

        $fout = '';
        $ind='';
        $element_edit_str='';



        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']['.$margs['element_index'].']';

//        echo 'alceva'.$ind;


        $lab = ''.$margs['type_elements'].$ind.'[messages_height]';

        $element_edit_str.='<div class="center-it">';



        $lab = 'extra_classes';
        $element_edit_str .= '<span class="setting">
        <span class="setting-label">'.__('Extra Classes').'</span>
<textarea class="textarea-extra-css formstyle" name="'.$margs['type_elements'].$ind.'['.$lab.']">'.$margs[$lab].'</textarea>';
        $element_edit_str.='</span>';


        $element_edit_str.='<div class="setting ">
        <span class="setting-label">'.__('Height').'</span>
        <div class="func-slider-con"> <!-- here should be only one input, the input first is the slider value -->
        <input type="text" class="func-slider-val" name="'.$lab.'" value="'.$margs['messages_height'].'"/>
<div class="func-slider"></div>
</div>
</div>';

        $lab = 'is_negative';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';
        $element_edit_str.='<div class="setting ">
        <span class="setting-label">'.__('Is Negative').'</span>
        <div class="dzscheckbox skin-nova">
                            '.DZSHelpers::generate_input_checkbox($nam,array('id' => $lab, 'val' => 'on','seekval' => $margs[$lab])).'
                            <label for="'.$nam.'"></label>
        </div>

</div>';




        $element_edit_str.='</div>';

        $element_edit_str.='<p class="buttons-con"><button class="button-primary btn-delete-itm btn-delete-element">'.__('Delete Element').'</button> <button class="button-secondary btn-done-editing">'.__('Done Editing').'</button> </p>
        ';





        // -- screen in editor
        $fout.='<div class="dzspgb-element-con">
        <div class="hidden-content">'.$element_edit_str.'</div>
        <span class="dzspgb-element-type the-type-'.$id.'" data-type="'.$id.'">
            <span class="move-handler-for-elements"><i class="fa fa-arrows-v"></i>
            </span>
            <span class="icon-con"><i class="fa fa-weixin"></i></span><h5>'.__('Chat Element').'</h5><p class="the-excerpt">'.__("Use this element for constructing the messages element used in the Messages Page.").'</p><span class="dzspgb-button dzspgb-button-choose">'.$margs['txt_choose'].'
            </span>
        </span>
        <input type="hidden" name="'.$margs['type_elements'].$ind.'[type_element]" value="'.$id.'"/>
        </div><!-- END dzspgb-element-con -->';

//        $fout.='</div>';

        return $fout;
    }
}




if(!function_exists('shortcode_messages')){
    function shortcode_messages($pargs=array(),$content=''){

        global $dzsap_portal;

        $fout = '';

        $margs = array(
            'messages_height' => '10',
            'is_negative' => 'off',
            'extra_classes' => '',
            'style' => 'style-default',
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }

;
        $extra_style = '';


//        print_r($margs);

$fout.='<div class="shortcode-messages '.$margs['style'].' '.$margs['extra_classes'].'" style="'.$extra_style.'">';
        $fout.='<div class="clear"></div>';



        $receiver = $_GET['user_id'];


        if($receiver){
            $dzsap_portal->ajax_messages_update_to_read(array(
                'author_id'=>$receiver,
                'id_receiver'=>$dzsap_portal->currUserId,

            ));
        }

        $fout.='<div class="scroller-con auto-init skin_apple " data-options=\'{ enable_easing:"on", settings_refresh: "1000" }\'>';
        $fout.='<div class="messages-container inner"></div>';
        $fout.='</div>';


        $fout.='<form method="POST" class="messages-send-con">';


        $fout.='<input type="text" class="message-send-input input-ujarak-style" name="message" placeholder="'.__('Write your message here').'" />';
        $fout.='<button class="empty-button" name="action" value="ajax_submit_message"><i class="fa fa-share"></i></button>';

        $fout.='<input type="hidden" name="id_receiver" value="'.$receiver.'"/>';


        $fout.='</form>';

//        $aux = $dzsap_portal->get_messages_field($_GET['messages_id'], 'avatar');
//        $aux_messagesname = $dzsap_portal->get_messages_field($_GET['messages_id'], 'messagesname');


        $fout.='</div>';


        if(function_exists('enqueue_script')) {

            enqueue_script('dzs.scroller', 'libs/dzsscroller/scroller.js');
            enqueue_style('dzs.scroller', 'libs/dzsscroller/scroller.css');
        }



        return $fout;
    }
}
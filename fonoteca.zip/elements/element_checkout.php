<?php
$id = 'checkout';

$dzspgb_templates[$id] = array(
    'id' => $id,
    'admin_str_function' => 'admin_str_function_'.$id,
);


if(!function_exists('admin_str_function_checkout')){
    function admin_str_function_checkout($pargs=array()){

        $id = 'checkout';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'element_index' => '0',
            'type' => 'element',
            'type_element' => $id,
            'type_pb' => "Full",
            'txt_choose' => __("Choose"),
            'type_elements' => "newelement", // -- newelement (js) or dzspgb (php) ( legit )
            'text' => "",
            'checkout_height' => "10",
            'item' => array(),
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }

//        print_r($margs);

        $fout = '';
        $ind='';
        $element_edit_str='';



        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']['.$margs['element_index'].']';

//        echo 'alceva'.$ind;


        $lab = ''.$margs['type_elements'].$ind.'[checkout_height]';

        $element_edit_str.='<div class="center-it">';
        $element_edit_str.='<div class="setting ">
        <span class="setting-label">'.__('Height').'</span>
        <div class="func-slider-con"> <!-- here should be only one input, the input first is the slider value -->
        <input type="text" class="func-slider-val" name="'.$lab.'" value="'.$margs['checkout_height'].'"/>
<div class="func-slider"></div>
</div>
</div>';


        $element_edit_str.='</div>';

        $element_edit_str.='<p class="buttons-con"><button class="button-primary btn-delete-itm btn-delete-element">'.__('Delete Element').'</button> <button class="button-secondary btn-done-editing">'.__('Done Editing').'</button> </p>
        ';





        // -- screen in editor
        $fout.='<div class="dzspgb-element-con" data-type="'.$id.'">
        <div class="hidden-content">'.$element_edit_str.'</div>
        <span class="dzspgb-element-type the-type-'.$id.'" data-type="'.$id.'">
            <span class="move-handler-for-elements"><i class="fa fa-arrows-v"></i>
            </span>
            <span class="icon-con"><i class="fa fa-shopping-cart"></i></span><h5>'.__('Checkout').'</h5><p class="the-excerpt">'.__("Place a PayPal checkout page element This will handle the buying of tracks. ").'</p><span class="dzspgb-button dzspgb-button-choose">'.$margs['txt_choose'].'
            </span>
        </span>
        <input type="hidden" name="'.$margs['type_elements'].$ind.'[type_element]" value="'.$id.'"/>
        </div><!-- END dzspgb-element-con -->';

//        $fout.='</div>';

        return $fout;
    }
}




if(!function_exists('shortcode_checkout')){
    function shortcode_checkout($pargs=array(),$content=''){

        global $dzsap_portal, $dzsap_config;;

        $fout = '';

        $margs = array(
            'style' => 'auto', // -- auto or default or list or slider ...tbc
            'type' => 'auto', // -- auto or explore or mytracks or playlist or playlists or stream or
            'pagination' => 'auto', // -- auto or none or ajax or pages or pagesajax
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }


//        print_r($_POST);

//        print_r($margs);


        $purchase_confirmed = false;
        foreach($dzsap_portal->notices_array as $notice){

            if($notice['notice_for']=='checkout'){
                $fout.= '<div class="alert alert-'.$notice['notice_type'].'">'.$notice['notice_html'].'</div>';

                if($notice['notice_type']=='purchaseconfirmation'){
                    $purchase_confirmed = true;
                }
            }

        }


        $fout.='<div class="shortcode-checkout" style="">';

//        $fout.=$dzsap_portal->get_query($margs);


//        $fout.='<h4>'.__('checkout').'</h4>';


        $paypal_link = 'https://www.paypal.com/cgi-bin/webscr';

        if($dzsap_portal->main_settings['developer_paypal_sandbox_mode']=='on'){
            $paypal_link='https://www.sandbox.paypal.com/cgi-bin/webscr';
        }


        if($purchase_confirmed){

        }else{

            $fout.='<form class="checkout-form" name="checkout-form" action="'.$paypal_link.'" method="POST">';
//        $fout.='<form class="checkout-form" name="checkout-form" action="send_ipn.php" method="POST">';
//        $fout.='<form class="checkout-form" name="checkout-form" action="http://localhost/tests/paypalipn/paypal_ipn.php" method="POST">';
//        $fout.='<form class="checkout-form" name="checkout-form" action="http://zoomthe.me/paypalipn/paypal_ipn.php" method="POST">';
//        $fout.='<form class="checkout-form" name="checkout-form" action="'.$dzsap_portal->url_base.'payment.php" method="POST">';


            $fout.='<ul class="notices-box">'.$dzsap_portal->notices_html.'</ul>';


            $user_meta = $dzsap_portal->get_user_meta_all($dzsap_portal->currUserId);

            $user_credit = 0;
//        print_r($user_meta);


            $fields = array(
                'first_name'=>'',
                'last_name'=>'',
                'user_address'=>'',
                'user_country'=>'',
                'user_telephone'=>'',
                'user_credit'=>0,
            );


            $fields = array_merge($fields, $user_meta);


            $fout.='<div class="'.$dzsap_config['front_dzspgb_row_class'].'">';

            $fout.='<div class="'.$dzsap_config['front_dzspgb_row_part_2.3'].'">';

            $fout.='<h2>'.__('Order Details').'</h2>';

            $fout.='<div class="setting">';

            $fout.='<div class="setting-label">'.__('').'</div>';
            $fout.='<input type="text" name="first_name" value="'.$fields['first_name'].'" placeholder="'.__('First Name').'..."/>';

            $fout.='</div>';

            $fout.='<div class="setting">';

            $fout.='<div class="setting-label">'.__('').'</div>';
            $fout.='<input type="text" name="last_name" value="'.$fields['last_name'].'" placeholder="'.__('Last Name').'..."/>';

            $fout.='</div>';


            $fout.='<div class="setting">';

            $fout.='<div class="setting-label">'.__('').'</div>';
            $fout.='<input type="text" name="user_address" value="'.$fields['user_address'].'" placeholder="'.__('Address').'..."/>';

            $fout.='</div>';

            $fout.='<div class="setting">';

            $fout.='<div class="setting-label">'.__('').'</div>';
            $fout.='<input type="text" name="user_country" value="'.$fields['user_country'].'" placeholder="'.__('Country').'..."/>';

            $fout.='</div>';




            $fout.='<div class="setting">';
            $fout.='<div class="setting-label">'.__('').'</div>';
            $fout.='<input type="text" name="user_telephone" value="'.$fields['user_telephone'].'" placeholder="'.__('Telephone').'..."/>';

            $fout.='</div>';



            if($dzsap_portal->main_settings['enable_user_credit']=='on'){
                $lab = 'pay_with';
                $fout.='<div class="setting">';
                $fout.='<div class="setting-label">'.__('Pay With').'</div>';
                $fout.='<p><input id="opt1" type="radio" name="'.$lab.'" value="paypal" checked/><label for="opt1">'.__("PayPal").'</label></p>';
                $fout.='<p><input id="opt2" type="radio" name="'.$lab.'" value="user_credit"/><label for="opt2">'.__("User Credit").' ( '.$fields['user_credit'].' )&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="'.$dzsap_portal->optional_url_base.'index.php?page=depositinfo">'.__("How to deposit?").'</a></label></p>';
                $fout.='</div>';
            }






            $fout.='<div>';
            $fout.='
        <button name="submit" class="button-primary button-primary-for-checkout" style="width: auto; ">'.__('Place Order').'</button>
        ';
            $fout.='</div>';
            $fout.='</div><!--end .part1.1-->';



            $fout.='<div class="'.$dzsap_config['front_dzspgb_row_part_1.3'].' checkout-cart-details">';

            $fout.='<div class="sidebar-fullbg"></div>';
            $fout.='<h2>'.__('Cart Contents').'</h2>';


            $fout.=$dzsap_portal->show_cart(array(
                'include_checkout_link'=>false
            ));


//            print_r($dzsap_config);

            if($dzsap_config['is_preview']=='on'){
                $fout.='<br><div style="color: #fff; position:relative;">';
                $fout.='<p>'.__("Sandbox Mode / Use these credentials to login:").'</p>';
                $fout.='<pre style="text-align: left;  display: block; width: auto; margin: 0 auto; padding: 15px; background-color: #ccc;"><strong>user</strong>: soundportal-buyer-1@gmail.com
<strong>pass</strong>: soundportal</pre>';

                $fout.='</div>';
            }


            $fout.='</div><!--end .part1.3-->';


            $fout.='</div><!--end .row-->';


            $aux_email = $dzsap_portal->get_user_field($dzsap_portal->currUserId, 'email');
//        $aux_email = 'zoomitflash-buyer-1@gmail.com';
//        echo $aux;


            $total_price=0;
            $ids = '';
            $descs = '';

            $i=0;

            if($dzsap_portal->cart_arr && is_array($dzsap_portal->cart_arr) && count($dzsap_portal->cart_arr)>0){


                $fout.=__('');


                foreach($dzsap_portal->cart_arr as $lab=>$cart_arr_item){

                    $aux_arr = $dzsap_portal->get_page($lab, array(
                        'post_type'=>'track',
                    ));


                    $price = '100';


//                print_r($lab);

                    $desc = $aux_arr['title'];


                    if($aux_arr['price']){
                        $price = $aux_arr['price'];
                    }

                    $quantifier = 1;

                    if(intval($dzsap_portal->cart_arr[$lab])>0){
                        $quantifier = intval($dzsap_portal->cart_arr[$lab]);
                        $price = $quantifier*doubleval($price);
                    }

                    if($price==0.123){
                        $price = 0;
                    }

//                print_r($dzsap_portal->cart_arr);

                    if($lab==='proaccount'){
                        $desc = 'Pro Account One Month';

                        $price = $dzsap_portal->main_settings['pro_account_price'];
                    }
                    if($lab==='proaccount_90'){
                        $desc = 'Pro Account Three Months';

                        $price = $dzsap_portal->main_settings['pro_account_price_90'];
                    }
                    if($lab==='proaccount_year'){
                        $desc = 'Pro Account One Year';

                        $price = $dzsap_portal->main_settings['pro_account_price_year'];
                    }

                    $total_price+=$price;

                    if($desc){

                        if($i>0){
                            $descs.=',';
                        }

                        $descs.=$desc;
                    }
                    if($i>0){
                        $ids.=',';
                    }

                    $ids.=$lab;

                    $i++;
                }



            }else{

                $fout.=__('Cart is empty. ');
            }





            $fout.='<input TYPE="hidden" name="cmd" value="_xclick">';
//        $fout.='<INPUT TYPE="hidden" name="cmd" value="_notify-validate">';

//        $fout.='<INPUT TYPE="hidden" NAME="return" value="'.$dzsap_portal->url_base.'index.php?page=checkout">';
            $fout.='<input TYPE="hidden" NAME="return" value="'.$dzsap_portal->url_base.'paypal_ipn.php">
        ';
//        $fout.='<input TYPE="hidden" NAME="notify_url" value="http://zoomthe.me/paypalipn/paypal_ipn.php">
//        ';
//            $fout.='<input TYPE="hidden" NAME="notify_url" value="'.$dzsap_portal->url_base.'paypal_ipn.php">
//        ';
            $fout.='<input TYPE="hidden" NAME="notify_url" value="'.$dzsap_portal->url_base.'paypal_ipn.php">
        ';
            $fout.='<input type="hidden" name="cancel_return" value="'.$dzsap_portal->url_base.'paypal_cancel">
        ';



            $fout.='<input type="hidden" name="quantity" value="1">
<input type="hidden" name="no_shipping" value="1">
';

            $fout.='<input TYPE="hidden" name="currency_code" value="'.$dzsap_portal->main_settings['paypal_currency_code'].'">
        ';
            $fout.='<input type="hidden" name="amount" value="'.$total_price.'">
        ';
            $fout.='<input type="hidden" name="custom" value="'.$ids.'">
        ';
            $fout.='<input type="hidden" name="email" value="'.$aux_email.'">
        ';

            $paypal_receiver_account =$dzsap_portal->main_settings['paypal_receiver_account'] ;
            if($dzsap_portal->main_settings['paypal_use_author_email']=='on'){
                if(strpos($ids, 'proaccount')==false){

                    $ids_arr = explode(',',$ids);

//                    print_r($ids_arr);
                    $paypal_receiver_account_id = $dzsap_portal->get_track_field($ids_arr[0],'author_id');
                    $aux = $dzsap_portal->get_user_field($paypal_receiver_account_id, 'email');

                    if($dzsap_portal->get_user_field($paypal_receiver_account_id, 'paypal_email')){
                        $aux = $dzsap_portal->get_user_field($paypal_receiver_account_id, 'paypal_email');
                    }

//                    print_r($paypal_receiver_account_us);

                    if($aux){
                        $paypal_receiver_account = $aux;
                    }



//                    echo '$paypal_receiver_account - '; print_r($paypal_receiver_account_id);
//                    echo '$paypal_receiver_account - '; print_r($paypal_receiver_account);
//                    $paypal_receiver_account =
                }
            }

            $fout.='<input type="hidden" name="business" value="'.$paypal_receiver_account.'">
        ';

            $fout.='
<input type="hidden" name="item_name" value="'.$descs.'">
<input type="hidden" name="item_number" value="'.$ids.'">';

            $fout.='</form>';

            $fout.='<div class="clear"></div>';

        }

        $fout.='</div>';


        return $fout;
    }
}
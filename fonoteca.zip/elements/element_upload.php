<?php
$id = 'upload';

$dzspgb_templates[$id] = array(
    'id' => $id,
    'admin_str_function' => 'admin_str_function_upload',
);


if(!function_exists('admin_str_function_upload')){
    function admin_str_function_upload($pargs=array()){

        $id = 'upload';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'element_index' => '0',
            'type' => 'element',
            'type_element' => $id,
            'type_pb' => "Full",
            'txt_choose' => __("Choose"),
            'type_elements' => "newelement", // -- newelement (js) or dzspgb (php) ( legit )
            'text' => "",
            'upload_style' => "style_default",
            'item' => array(),
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }

//        print_r($margs);

        $fout = '';
        $ind='';
        $element_edit_str='';



        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']['.$margs['element_index'].']';

//        echo 'alceva'.$ind;


        $element_edit_str .= '<span class="setting">
        <span class="setting-label">'.__('The Text').'</span>
<textarea class="formstyle" name="'.$margs['type_elements'].$ind.'[text]">'.$margs['text'].'</textarea>
</span>';



        $lab = 'upload_style';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';
        $arr_opts = array(
            array(
                'label'=>__("Default Style"),
                'value'=>'style_default',
            ),
            array(
                'label'=>__("New Style"),
                'value'=>'style_new',
            ),

        );





        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Style').'</span>
'.DZSHelpers::generate_select($nam, array('class'=>'dzs-style-me skin-beige ','options'=>$arr_opts,'seekval'=>$margs[$lab],)).'
</span>';










        $element_edit_str.='<p class="buttons-con"><button class="button-primary btn-delete-itm btn-delete-element">'.__('Delete Element').'</button> <button class="button-secondary btn-done-editing">'.__('Done Editing').'</button> </p>
        ';





        // -- screen in editor
        $fout.='<span class="dzspgb-element-con"><span class="hidden-content">'.$element_edit_str.'</span><span class="dzspgb-element-type the-type-text" data-type="'.$id.'"><span class="icon-con"><i class="fa fa-upload"></i></span><h5>'.__('Upload Screen').'</h5><div class="the-excerpt-real">'.__("Query Style - ").'<strong>{{style}}</strong></div><p class="the-excerpt">'.__("Use this element for breaking out to a full width container.").'</p><span class="dzspgb-button dzspgb-button-choose">'.$margs['txt_choose'].'</span></span><input type="hidden" name="'.$margs['type_elements'].$ind.'[type_element]" value="'.$id.'"/></span>';

        return $fout;
    }
}




if(!function_exists('shortcode_upload')){
    function shortcode_upload($pargs=array(),$content=''){

        global $dzsap_portal;

        $fout = '';

        $margs = array(
            'type_element' => 'upload',
            'upload_style' => 'style_default',
            'is_buyable' => 'off',
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }


//        die(); why this is s

//        print_r($margs);

        if($margs['upload_style']=='style_default'){


            $fout.='<div class="shortcode-upload">';
            $fout.='<ul class="notices-box">';

            $fout.='</ul>';


//                                    $fout.= '<span class="login-login menu-right-block dzstooltip-con for-hover"><span class="login-signup--label">Log In</span>'
//                                        . '<span class="menu-right-block-inmenu dzstooltip arrow-top align-right skin-black "><ul class="notices-box">' . $dzsap_portal->notices_html . '</ul>
//                    <a class="facebook-box">Sign in with Facebook</a>
//                    <div class="table-separator light">
//                        <span class="table-cell"><span class="the-line"></span></span>
//                        <span class="table-center">or</span>
//                        <span class="table-cell"><span class="the-line"></span></span>
//
//                    </div>
//                    <h5 class="input-label">Sign in with email</h5>
//
//                    <form class="login-form" method="POST">
//                        <input type="hidden" name="action" value="login"/>
//                        <input type="email" class="fullwidth simple-input-field" name="email"/>
//                        <h5 class="input-label">Password</h5>
//                        <input type="password" class="fullwidth simple-input-field" name="pass"/>
//                        <br>
//                        <br>
//                        <button class="button-primary register-btn">Login</button>
//                    </form>
//                    </span>
//                    </span>' . '';
//                                } else {
//                                    $fout.= ''
//                                        . '<span class="user-menu-con">'
//                                        . '<span class="user-avatar" style="background-image: url(' . $dzsap_portal->get_avatar($dzsap_portal->currUserId) . ');"></span>'
//                                        . '<ul class="user-menu--options">'
//                                        . '<li><a href="' . $dzsap_portal->url_portalphp . '?page=usersettings"><i class="fa fa-gear"></i> &nbsp;Settings</a></li>'
//                                        . '<li><a href="' . $dzsap_portal->url_portalphp . '?page=uservideos&id_user=' . $dzsap_portal->currUserId . '"><i class="fa fa-video-camera"></i> &nbsp;'.__('My Tracks').'</a></li>'
//                                        . '<li><a style="display:inline-block; vertical-align:middle;" class="anchor-page-upload" href="' . $dzsap_portal->url_portalphp . '?page=upload"><i class="fa fa-upload"></i> &nbsp;'.__('Upload').'</a></li>'
//                                        . '<li><a href="' . $dzsap_portal->url_portalphp . '?page=userplaylists"><i class="fa fa-reorder"></i> &nbsp;Playlists</a></li>'
//                                        . '<li><form style="display:block;"  class="logout-form" method="post"><button name="action" value="logout" class="btn-nostyling"><i class="fa fa-plug"></i> &nbsp;Log Out</button></form></li>'
//                                        . '</ul>'
//                                        . '</span>';
//                                }



            if ($dzsap_portal->currUserId ) {
                $fout .= '<form class="submit-track-form" action="index.php"><div id="upload-tabs" class="dzs-tabs auto-init-from-dzsapp skin-blue tab-menu-content-con---no-padding" style="overflow:visible; " data-options=\'{ "design_tabsposition" : "top"
                                         ,design_transition: "slide"
                                         ,design_tabswidth: "default"
                                         ,toggle_breakpoint : "400"
                                         ,design_tabswidth: "fullwidth"
                                         ,settings_appendWholeContent: true
                                         ,refresh_tab_height:"1000"
                                         ,toggle_type: "accordion"}\'>

                                        <div class="dzs-tab-tobe">
                                            <div class="tab-menu ">
                                                '.__("Step").' 01
                                            </div>
                                            <div class="tab-content">
                                                <div style="padding: 10px; text-align: center;">
                                                    <h5 class="input-label">Upload the .mp3</h5>
                                                    <div class="dzs-upload-con">
                                                        <input type="text" class="simple-input-field target-field id-upload-mp3" name="source"/>
                                                        <span class="dzs-single-upload">
                                                            <input class="" name="file_field" type="file" accept=".mp3,.m4a,.wav">
                                                            <div class="dzs-upload--progress dzs-upload--progress__full">
        <div class="dzs-upload--progress--bar">
            <div class="dzs-upload--progress--barbg"></div>
            <div class="dzs-upload--progress--barprog"></div>
        </div>
    </div>
                                                        </span>
                                                        <div class="table-separator">
                                                            <span class="table-cell"><span class="the-line"></span></span>
                                                            <span class="table-center">or</span>
                                                            <span class="table-cell"><span class="the-line"></span></span>

                                                        </div>
                                                        <div class="dzs-single-upload drag-drop">
                                                            <div class="dzs-single-upload--areadrop">
                                                                <input class="" name="file_field" type="file">
                                                                <div class="instructions">'.$dzsap_portal->translate_drag_drop.'</div>
                                                                <div class="dzs-upload--progress dzs-upload--progress__full">
        <div class="dzs-upload--progress--bar">
            <div class="dzs-upload--progress--barbg"></div>
            <div class="dzs-upload--progress--barprog"></div>
        </div>
    </div>
                                                            </div>

                                                        </div>
                                                        <div class="feedback"></div>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>

<!-- tab-disabled -->
                                        <div class="dzs-tab-tobe">
                                            <div class="tab-menu ">
                                                '.__("Step").' 02
                                            </div>
                                            <div class="tab-content">
                                                <div style="padding: 0px; text-align: left;">

                                                    <div class="dzs-upload-con preview-thumb-con-con">
                                                            <input class="" type="hidden" name="thumbnail"  >
                                                <div class="preview-thumb-con">


<i class="fa fa-picture-o"></i>

                                                </div>


                                                        <span class="dzs-single-upload">
                                                            <input class="" name="file_field" type="file" >
                                                        </span>

                                                </div>

                                                <div id="tabs-box-in-2" class="dzs-tabs auto-init skin-default " style="overflow:hidden; width: auto; " data-options=\'{ "design_tabsposition" : "top"
                ,design_transition: "fade"
                ,design_tabswidth: "default"
                ,toggle_breakpoint : "400"
                ,design_tabswidth: "auto"
             ,settings_appendWholeContent: true
                 ,toggle_type: "accordion"}\'>

                                    <div class="dzs-tab-tobe">
                                        <div class="tab-menu ">
                                            <i class="fa fa-circle-thin"></i> '.__("General").'
                                        </div>
                                        <div class="tab-content">
                                                    <h5 class="input-label">'.__("Title").' *</h5>
                                                    <input type="text" class="simple-input-field" name="title"/>
                                                    <h5 class="input-label">'.__("Description").'</h5>
                                                    <textarea type="text" class="simple-input-field with-tinymce" name="description"></textarea>';



                ob_start();

                $dzsap_portal->do_action('upload_above_can_be_bought');
                $fout.=ob_get_clean();

                $fout.='<h5 class="input-label">'.__("Can be bought ?").'</h5>';


                $lab = 'is_buyable';
                $nam = $lab;


                $fout .= '<div class="dzscheckbox skin-nova">
' . DZSHelpers::generate_input_checkbox($nam, array('id' => $lab, 'val' => 'on', 'seekval' => $margs[$lab])) . '
<label for="' . $nam . '"></label>

                        </div>
                        <div class="price-conglomerate">
                                                    <h5 class="input-label">' . __("Price") . '</h5>
                                                    <input type="text" class="simple-input-field" name="price"/>
                                                    <h5 class="input-label">' . __("Download Link") . '</h5>
                                                    <input type="text" class="simple-input-field" name="download_link"/>

                                                    </div>

                                        </div>
                                    </div>

                                    <div class="dzs-tab-tobe">
                                        <div class="tab-menu ">
                                            <i class="fa fa-camera"></i> '.__("Graphics").'
                                        </div>
                                        <div class="tab-content">

                                                    <h5 class="input-label">'.__("Waveform Static").'</h5>
                                                    <div class="dzs-upload-con">
                                                        <input type="text" class="simple-input-field upload-prev" name="waveform_bg"/> <span class="aux-wave-generator"> <button class="btn-autogenerate-waveform-bg button button--secondary"><span class="button-label">' . __('Auto Generate') . '</span></button></span><span class="dzs-single-upload dzs-single-upload--for-wavegeneration">
                                                            <input class="" name="file_field" type="file">
                                                        </span>
                                                    </div>
                                                    <h5 class="input-label">'.__("Waveform Progress").'</h5>
                                                    <div class="dzs-upload-con">
                                                        <input type="text" class="simple-input-field upload-prev" name="waveform_prog"/> <span class="aux-wave-generator"> <button class="btn-autogenerate-waveform-prog button button--secondary"><span class="button-label">' . __('Auto Generate') . '</span></button></span><span class="dzs-single-upload dzs-single-upload--for-wavegeneration">
                                                            <input class="" name="file_field" type="file">
                                                        </span>
                                                    </div>

                                                    <h5 class="input-label">'.__("Cover Image").'</h5>
                                                    <div class="dzs-upload-con">
                                                        <input type="text" class="simple-input-field" name="cover_image"/> <span class="dzs-single-upload">
                                                            <input class="" name="file_field" type="file">
                                                        </span>
                                                    </div>
                                        </div>
                                    </div>

                                    <div class="dzs-tab-tobe">
                                        <div class="tab-menu with-tooltip">
                                            <i class="fa fa-paperclip"></i> '.__("Miscellaneous").'
                                        </div>
                                        <div class="tab-content">
                                                    <h5 class="input-label">'.__("Tags").'</h5>
                                                    <input type="text" class="simple-input-field" name="tags"/>

                                                    <h5 class="input-label">'.__("Backup OGG").'</h5>
                                                    <div class="dzs-upload-con">
                                                        <input type="text" class="simple-input-field" name="source_ogg"/> <span class="dzs-single-upload">
                                                            <input class="" name="file_field" type="file">
                                                        </span>
                                                    </div>




                                        </div>
                                    </div><!-- end dzs-tab-tobe -->';




                ob_start();

                $dzsap_portal->do_action('upload_add_subuploader_fields');
                $fout.=ob_get_clean();

                $fout.='</div>


<div class="clear"></div>
                                                    <br><br>
                                                    <input class="" type="hidden" name="filesize" value="1000000">
                                                    <div class="dzstooltip-con active"><span class=" dzstooltip arrow-bottom align-left active skin-black " style=" width: auto; ">'.__("Please wait while waveforms generate").'</span><button class="btn-primary upload-btn upload-track-btn disabled">Submit</button></div>
                                                </div>
                                            </div>
                                        </div><!-- end dzs-tab-tobe -->';


                ob_start();

                $dzsap_portal->do_action('upload_add_uploader_fields');
                $fout.=ob_get_clean();

                $fout.='</div>';

                $fout .= '<div class="clear"></div>';


                $fout .= '<input type="hidden" action="submit_track"/>';

                $fout.='
';


                $fout .= '</form>';
            }else{
                $fout.=__("You need to be logged in to use this form");
            }

            $fout.='</div>';


        }else{
            // -- style_new



            $fout.='<div class="shortcode-upload style-new">';
            $fout.='<ul class="notices-box">';

            $fout.='</ul>';



            $allowed = false;

            $caps = $dzsap_portal->get_user_capabilities($dzsap_portal->currUserId);

//            print_r($caps);

            if($dzsap_portal->currUserId){



//                print_r($caps);

                if(in_array('upload_tracks', $caps)){
                    $allowed = true;
                }else{

                    $fout.=__("You don't have permission to upload.");
                }


                $limit = intval($dzsap_portal->main_settings['upload_nr_limit_normal']);

                $caps = $dzsap_portal->get_user_capabilities($dzsap_portal->currUserId);

                if(in_array('proaccount',$caps)){
                    $limit = intval($dzsap_portal->main_settings['upload_nr_limit_pro']);
                }
                if(in_array('admin',$caps)){
                    $limit = 1000;
                }

                $user_tracks_nr = intval($dzsap_portal->get_user_total_nr_uploaded($dzsap_portal->currUserId));

//                echo  $user_tracks_nr. ' - '.$limit;

                if($user_tracks_nr<$limit){

//                    echo 'ceva23';
                }else{

                    $allowed = false;
                    $fout.=__("You have to many tracks - upgrade to PRO for more track limit").'<br><br><br>';
                }

            }else{
                $fout.=__("You need to be logged in to use this form");
                $fout.='<br>';
                $fout.='<br>';
            }




            if ($allowed) {
                $fout .= '<form class="submit-track-form" action="index.php">';


                $fout.='<h3>'.__("Upload to ").'<strong>'.$dzsap_portal->main_settings["site_title"].'</strong></h3>';


                $fout.='

                        <select class="dzs-style-me opener-listbuttons skin-nova " name="type">
                            <option value="track" selected>track</option>
                            <option value="soundcloud">soundcloud</option>
                            <option value="album" >album</option>
                        </select>
                        <ul class="dzs-style-me-feeder">
                            <li ><span class="">'.__("Track").'</span></li>
                            <li ><span class="">'.__("Soundcloud").'</span></li>
                            <li ><span class="">'.__("Album").'</span></li>
                        </ul>';



                $fout .= '<div class="clear"></div>';



                $fout.='<div class="parameters-con">';
                $fout.='
<div class="dzs-upload-con">
                                                        <input type="text" class="simple-input-field target-field id-upload-mp3 hmm-from-dzs" data-upload_from="main-mp3" name="source" multiple/>
                                                        <span class="dzs-single-upload">
                                                            <input class="the-real-uploader" name="file_field" type="file" accept=".mp3,.m4a,.wav" multiple>
                                                            
                                                        </span>
                                                        <div class="table-separator or-table-separator">
                                                            <span class="table-cell"><span class="the-line"></span></span>
                                                            <span class="table-center">or</span>
                                                            <span class="table-cell"><span class="the-line"></span></span>

                                                        </div>
                                                        <div class="dzs-single-upload drag-drop">
                                                            <div class="dzs-single-upload--areadrop">
                                                                <input class="" name="file_field" type="file">
                                                                <div class="instructions">'.$dzsap_portal->translate_drag_drop.'</div>
                                                                
                                                            </div>

                                                        </div>';

                // -- test typing slow




                $fout.='</div><!-- end .dzs-upload-con-->';


                $fout.='<div class="main-upload-options-con">';
                $fout.='<div class="main-upload-options" style="">';

                $fout.='<div class="preloader-bar dzs-upload--progress--barprog"></div>';


                $fout.='<div id="tabs-box-in-2" class="dzs-tabs auto-init skin-default " style="overflow:hidden; width: auto; " data-options=\'{ "design_tabsposition" : "top"
                ,design_transition: "fade"
                ,design_tabswidth: "default"
                ,toggle_breakpoint : "400"
                ,refresh_tab_height : "1000"
                ,design_tabswidth: "auto"
             ,settings_appendWholeContent: true
                 ,toggle_type: "accordion"}\'>

                                    <div class="dzs-tab-tobe">
                                        <div class="tab-menu ">
                                            <i class="fa fa-circle-thin"></i> '.__("General").'
                                        </div>
                                        <div class="tab-content">
                                        ';




                $fout.='<div class="thumb-con">';


                $fout.='<div class="dzs-upload-con">
    <input type="hidden" class="simple-input-field target-field" name="thumbnail" value=""/>
    <span class="dzs-single-upload only-image debug-target" data-buttonextraclass="border-button">
        <input class="" name="file_field" type="file">
    </span>
    <div class="dzs-single-upload-preview-img" style="background-image: url('.$dzsap_portal->main_settings['default_thumb'].')"></div>

    <div class="feed-option feed-translate-upload">'.__("Upload Image").'</div>
    <div class="feed-option feed-upload-btn-location"></div>
    <div class="feedback"></div>
</div>';


                $fout.='</div>';





                $fout.='


<div class="overflow-it"><div class="row"><div class="col-md-6">
<h5 class="input-label">'.__("Title").' *</h5>
<input type="text" class="simple-input-field" name="title"/>';



// -- test



                $fout.='</div><!-- e.col-md-6-->';

                $fout.='<div class="col-md-6">';
                ob_start();

                $dzsap_portal->do_action('upload_above_can_be_bought');
                $fout.=ob_get_clean();



                $allowed_set_download = 'off';

                if(in_array('sell_track', $caps)){
                    $allowed_set_download = 'custom_price';
                }else{
                    if(in_array('place_track_free_download', $caps)){
                        $allowed_set_download = 'free_download';
                    }
                }

//                print_r($caps);
                if(in_array('force_submit_free_download', $caps)){
                    $allowed_set_download = 'force_free_download';
                }

                if($allowed_set_download=='custom_price'){

                $fout.='<h5 class="input-label">'.__("Can be bought ?").'</h5>';


                $lab = 'is_buyable';
                $nam = $lab;


                $fout .= '<div class="dzscheckbox skin-nova">
' . DZSHelpers::generate_input_checkbox($nam, array('id' => $lab, 'val' => 'on', 'seekval' => $margs[$lab])) . '
<label for="' . $nam . '"></label>  

                        </div>
                        <div class="price-conglomerate">
                                                    <h5 class="input-label">' . __("Price") . '</h5>
                                                    <input type="text" class="simple-input-field" name="price"/>
                                                    <h5 class="input-label">' . __("Download Link") . '</h5>
                                                    <input type="text" class="simple-input-field" name="download_link"/>

<div class="sidenote">'.__("If nothing is placed inside download link, then the download button will trigger the downloading of the main mp3").'</div>
                                                    </div>
';
                }

                if($allowed_set_download=='free_download'){

                $fout.='<h5 class="input-label">'.__("Can be downloaded free ?").'</h5>';


                $lab = 'is_buyable';
                $nam = $lab;


                $fout .= '<div class="dzscheckbox skin-nova">
' . DZSHelpers::generate_input_checkbox($nam, array('id' => $lab, 'val' => 'on', 'seekval' => $margs[$lab])) . '
<label for="' . $nam . '"></label>  
</div>
<div class="price-conglomerate">
                        <input type="hidden" class="" name="price" value="0"/>
                        <h5 class="input-label">' . __("Download Link") . '</h5>
                        <input type="text" class="simple-input-field" name="download_link"/>
<div class="sidenote">'.__("If nothing is placed inside download link, then the download button will trigger the downloading of the main mp3").'</div>
                        </div>
';
                }

                if($allowed_set_download=='force_free_download'){

                    $fout.='
                        <input type="hidden" class="" name="is_buyable" value="on"/>
                        <input type="hidden" class="" name="price" value="0"/>
                        <h5 class="input-label always-visible">' . __("Download Link") . '</h5>
                        <input type="text" class="simple-input-field always-visible" name="download_link"/>
<div class="sidenote  always-visible">'.__("If nothing is placed inside download link, then the download button will trigger the downloading of the main mp3").'</div>
';
                }


                $fout.='</div><div class="clear" style="clear:both; "></div> <!-- e.col-md-6-->';

                $fout.='<br><div class="col-md-12">';
                $fout.='
<h5 class="input-label">'.__("Description").'</h5>
<textarea type="text" class="simple-input-field with-tinymce" name="description"></textarea>';
                $fout.='</div>';

                $fout.='</div><!-- e.row-->';
                $fout.='</div>';

                $fout.='
                                        </div><!-- end .tab-content-->
                                    </div><!-- end .dzs-tab-tobe-->

                                    <div class="dzs-tab-tobe">
                                        <div class="tab-menu ">
                                            <i class="fa fa-camera"></i> '.__("Graphics").'
                                        </div>
                                        <div class="tab-content">
';
                if($dzsap_portal->main_settings['skinwave_wave_mode']!='canvas'){
                    $fout.='<h5 class="input-label">'.__("Waveform Static").'</h5>
                                                    <div class="dzs-upload-con">
                                                        <input type="text" class="simple-input-field upload-prev" name="waveform_bg"/> <span class="aux-wave-generator"> <button class="btn-autogenerate-waveform-bg button button--secondary"><span class="button-label">' . __('Auto Generate') . '</span></button></span><span class="dzs-single-upload dzs-single-upload--for-wavegeneration">
                                                            <input class="" name="file_field" type="file">
                                                        </span>
                                                    </div>
                                                    <h5 class="input-label">'.__("Waveform Progress").'</h5>
                                                    <div class="dzs-upload-con">
                                                        <input type="text" class="simple-input-field upload-prev" name="waveform_prog"/> <span class="aux-wave-generator"> <button class="btn-autogenerate-waveform-prog button button--secondary"><span class="button-label">' . __('Auto Generate') . '</span></button></span><span class="dzs-single-upload dzs-single-upload--for-wavegeneration">
                                                            <input class="" name="file_field" type="file">
                                                        </span>
                                                    </div>';
                }


                                                    $fout.='<h5 class="input-label">'.__("Cover Image").'</h5>
                                                    <div class="dzs-upload-con">
                                                        <input type="text" class="simple-input-field" name="cover_image"/> <span class="dzs-single-upload">
                                                            <input class="" name="file_field" type="file">
                                                        </span>
                                                    </div>
                                        </div>
                                    </div>

                                    <div class="dzs-tab-tobe">
                                        <div class="tab-menu with-tooltip">
                                            <i class="fa fa-paperclip"></i> '.__("Miscellaneous").'
                                        </div>
                                        <div class="tab-content">
                                                    <h5 class="input-label">'.__("Tags").'</h5>
                                                    <textarea type="text" class="tagify-me simple-input-field" name="tags"></textarea>
                                                    <h5 class="input-label">'.__("iTunes Link").'</h5>
                                                    <input type="text" class="simple-input-field" name="itunes_link"/>

                                                    <h5 class="input-label">'.__("Backup OGG").'</h5>
                                                    <div class="dzs-upload-con">
                                                        <input type="text" class="simple-input-field" name="source_ogg"/> <span class="dzs-single-upload">
                                                            <input class="" name="file_field" type="file">
                                                        </span>
                                                    </div>




                                        </div>
                                    </div><!-- end dzs-tab-tobe -->';




                ob_start();

                $dzsap_portal->do_action('upload_add_subuploader_fields');
                $fout.=ob_get_clean();

                $fout.='';


                ob_start();

                $dzsap_portal->do_action('upload_add_uploader_fields');
                $fout.=ob_get_clean();

                $fout.='</div><!-- end zoomtabsandaccordions -->';


                $fout.='</div><!-- end .main-upload-options -->';




                $fout.='<div class="upload-track-options-con">';
//$fout.='<div class="upload-track-options"><input type="hidden" name="track_source[]"/>';
//
//$fout.='<div class="preloader-bar dzs-upload--progress--barprog"></div>';
//
//$fout.='<div class="handle-con"><i class="fa fa-bars"></i></div>';
//$fout.='<div class="input-con"><input type="text" name="title[]"/> </div>';
//
//$fout.='</div>';

                $fout.='</div>';








                $fout.='</div><!-- end .main-upload-options-con -->';

                $fout.='<div class="upload-more-con">';




                $fout.='<div class="dzs-upload-con">
                                                        
                                                        <span class="dzs-single-upload">
                                                            <input class="the-real-uploader" name="file_field" type="file" accept=".mp3,.m4a,.wav" multiple>
                                                            
                                                        </span></div>';


                $fout.='</div>';


                $fout.='<div class="submit-con">';

                if($dzsap_portal->main_settings['skinwave_wave_mode']=='canvas'){

                    $fout.='<button class="btn-transparent cancel-upload-btn  ">'.__("Cancel").'</button>';
                    $fout.='<div class="dzstooltip-con "><span class=" dzstooltip dzstooltip-upload-text arrow-bottom align-left skin-black " style=" width: auto; ">'.__("You need to set an title").'</span><button class="btn-primary upload-btn upload-track-btn disabled">'.__("Submit").'</button></div>';
                }else{

                    $fout.='<div class="dzstooltip-con active"><span class=" dzstooltip arrow-bottom align-left active skin-black " style=" width: auto; ">'.__("Please wait while waveforms generate").'</span><button class="btn-primary upload-btn upload-track-btn disabled">'.__("Submit").'</button></div>';
                }



                $fout.='</div>';

                $fout.='<div class="clear"></div>';

                $fout.='</div><!-- end parameters-con -->';



                $fout .= '<input type="hidden" action="submit_track"/>';
                $fout .= '</form>';



                enqueue_script('jqueryui', $dzsap_portal->optional_url_base.'jqueryui/jquery-ui.min.js');
                enqueue_style('jqueryui', '//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css');

            }

            $fout.='</div>';

        }





//        echo 'ceva';
        if(function_exists('enqueue_script')) {

            enqueue_script('dzs.tabsandaccordions', $dzsap_portal->optional_url_base.'libs/dzstabsandaccordions/dzstabsandaccordions.js');
            enqueue_style('dzs.tabsandaccordions', $dzsap_portal->optional_url_base.'libs/dzstabsandaccordions/dzstabsandaccordions.css');

            enqueue_script('dzs.selector', $dzsap_portal->optional_url_base.'libs/dzsselector/dzsselector.js');
            enqueue_style('dzs.selector', $dzsap_portal->optional_url_base.'libs/dzsselector/dzsselector.css');
            enqueue_script('dzs.upload', $dzsap_portal->optional_url_base.'libs/dzsuploader/upload.js');
            enqueue_style('dzs.upload', $dzsap_portal->optional_url_base.'libs/dzsuploader/upload.css');
            enqueue_style('dzs.checkbox', $dzsap_portal->optional_url_base.'libs/dzscheckbox/dzscheckbox.css');
        }
        return $fout;
    }
}


<?php
$id = 'widget_track_stats';

$dzspgb_templates[$id] = array(
    'id' => $id,
    'admin_str_function' => 'admin_str_function_'.$id,
);


if(!function_exists('admin_str_function_widget_track_stats')){
    function admin_str_function_widget_track_stats($pargs=array()){
        global $dzspgb_forportal, $dzsap_portal;

        $id = 'widget_track_stats';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'element_index' => '0',
            'type' => 'element',
            'type_element' => $id,
            'type_pb' => "Full",
            'txt_choose' => __("Choose"),
            'type_elements' => "newelement", // -- newelement (js) or dzspgb (php) ( legit )

            'id_user' => "auto",
            'show_title' => "off",

            'item' => array(),
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }

//        print_r($margs);

        $fout = '';
        $ind='';
        $element_edit_str='';



        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']['.$margs['element_index'].']';

//        echo 'alceva'.$ind;




        $lab = 'id_user';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';


        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('User Id').'</span>
'.DZSHelpers::generate_input_text($nam, array('class'=>'simple-input-text ','seekval'=>$margs[$lab],)).'
<span class="sidenote">'.__("leave auto for the user id to be get depending on the current page").'</span>
</span>';






        $lab = 'type';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';


//        print_r($apconfigs);

        $arr_opts = array(
            array(
                'lab' => __('Plays'),
                'val' => 'played',
            ),
            array(
                'lab' => __('Liked'),
                'val' => 'liked',
            ),
            array(
                'lab' => __('Downloads'),
                'val' => 'downloaded',
            ),
        );





        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Style').'</span>
'.DZSHelpers::generate_select($nam, array('class'=>'dzs-style-me skin-beige style-changer ','options'=>$arr_opts,'seekval'=>$margs[$lab],)).'
</span>';



        $lab = 'show_title';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';






        $arr_opts = array(
            array(
                'lab' => __('Off'),
                'val' => 'off',
            ),
            array(
                'lab' => __('On'),
                'val' => 'on',
            ),
        );



        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Show Title').'</span>
'.DZSHelpers::generate_select($nam, array('class'=>'dzs-style-me skin-beige style-changer ','options'=>$arr_opts,'seekval'=>$margs[$lab],)).'
</span>';







        $element_edit_str.='';

        $element_edit_str.='<p class="buttons-con"><button class="button-primary btn-delete-itm btn-delete-element">'.__('Delete Element').'</button> <button class="button--secondary button btn-done-editing"><span class="button-label">'.__('Done Editing').'</span></button> </p>
        ';





        // -- screen in editor
        $fout.='<div class="dzspgb-element-con" data-type="widget_track_stats">
        <div class="hidden-content"><br>'.$element_edit_str.'</div>
        <span class="dzspgb-element-type the-type-'.$id.'" data-type="'.$id.'">
            <span class="move-handler-for-elements"><i class="fa fa-arrows"></i></span>
            <span class="clone-handler-for-elements"><i class="fa fa-clone"></i></span>
            <span class="icon-con"><i class="fa fa-users"></i></span><h5>'.__('Widget Track Stats').'</h5><div class="the-excerpt-real">'.__("Query Type - ").'<strong>{{type}}</strong></div><p class="the-excerpt">'.__("This outputs the pages widget_track_stats.").'</p><span class="dzspgb-button dzspgb-button-choose">'.$margs['txt_choose'].'
            </span>
        </span>
        <input type="hidden" name="'.$margs['type_elements'].$ind.'[type_element]" value="'.$id.'"/>
        </div><!-- END dzspgb-element-con -->';

//        $fout.='</div>';

        return $fout;
    }
}




if(!function_exists('shortcode_widget_track_stats')){
    function shortcode_widget_track_stats($pargs=array(),$content=''){

        global $dzsap_portal;

        $fout = '';

        $margs = array(
            'id_track' => "",
            'type' => "liked",
            'show_title' => "on",
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }



//        print_r($margs);

$fout.='<div class="shortcode-widget_track_stats type-'.$margs['type'].'" style="">';

        $id_track = $margs['id_track'];
        if($margs['id_track']=='' || $margs['id_track']=='auto'){

            if(isset($_GET['track_id'])){

                $id_track=$_GET['track_id'];
            }

//            print_r($_GET);
        }

        if($dzsap_portal->query2_processed){
            $id_track = $dzsap_portal->query2_processed;
        }

        $dzsap_portal->target_track_id = $id_track;




        if($margs['type']=='liked'){



            $args = array(

                'id'=>$id_track,
                'get_last'=>'off',
                'interval'=>'24',
                'type'=>'like',
                'table'=>'views',
                'day_start'=>'3',
                'day_end'=>'2',
                'get_count'=>'off',
            );

//            print_r($args);



            $users_followers = $dzsap_portal->mysql_get_track_activity($id_track, $args);

            if($margs['show_title']=='on'){


                //<span class="title-left"><i class="fa fa-heart"></i> '.__("Liked by ").'</span><span class="title-right">'.count($users_followers).' '.__('people').'</span>
                $fout.='<h3 class="widget-title"><i class="fa fa-heart" style="font-size: 13px; margin-right: 3px;"></i> <span class="the-label">'.count($users_followers).' '.__('likes').'</span></h3><div class="clear"></div>';
            }



//        print_r($users_followers);

            if(is_array($users_followers) && count($users_followers)){



                $count = 0;
                foreach($users_followers as $pl){

                    if(isset($pl['post_type']) && $pl['post_type']=='repost'){
                        continue;
                    }

                    $l = $dzsap_portal->get_permalink($pl['id'], array(
                        'type'=>'user',
                    ));
                    $fout.='<a  href="'.$l.'" class="col-md-2 ajax-link user-round-view user-round-view--mini">';



                    $fout.='<div class="js-height-as-width the-avatar" style="background-image:url('.$dzsap_portal->sanitize_source($dzsap_portal->get_avatar($pl['id'])).'); " >';


                    $fout .= '</div>';






                    //                    print_r($pl);

                    $fout.='</a>';

                    $count++;

                    if($count>5){
                        break;
                    }
                }

            }else{
                $fout.='<p>'.__("No Likes").'</p>';
            }

        }

        if($margs['type']=='played'){



            $args = array(

                'id'=>$id_track,
                'get_last'=>'off',
                'interval'=>'24',
                'type'=>'view',
                'table'=>'views',
                'day_start'=>'3',
                'day_end'=>'2',
                'get_count'=>'off',
            );

//            print_r($args);


            $user_arr = array();

            $users_followers = $dzsap_portal->mysql_get_track_activity($id_track, $args);

            if($margs['show_title']=='on'){


                //<span class="title-left"><i class="fa fa-heart"></i> '.__("Liked by ").'</span><span class="title-right">'.count($users_followers).' '.__('people').'</span>
                $fout.='<h3 class="widget-title"><i class="fa fa-play" style="font-size: 13px; margin-right: 3px;"></i> <span class="the-label">'.count($users_followers).' '.__('plays').'</span></h3><div class="clear"></div>';
            }



//        print_r($users_followers);

            if(is_array($users_followers) && count($users_followers)){


                $count = 0;

                foreach($users_followers as $pl){

                    if(isset($pl['post_type']) && $pl['post_type']=='repost'){
                        continue;
                    }

                    if(in_array($pl['id'], $user_arr)){
                        continue;
                    }
                    array_push($user_arr, $pl['id']);

                    $l = $dzsap_portal->get_permalink($pl['id'], array(
                        'type'=>'user',
                    ));
                    $fout.='<a  href="'.$l.'" class="col-md-2 ajax-link user-round-view user-round-view--mini">';



                    $fout.='<div class="js-height-as-width the-avatar" style="background-image:url('.$dzsap_portal->sanitize_source($dzsap_portal->get_avatar($pl['id'])).'); " >';


                    $fout .= '</div>';






                    //                    print_r($pl);

                    $fout.='</a>';
                    $count++;

                    if($count>5){
                        break;
                    }
                }

            }else{
                $fout.='<p>'.__("No Likes").'</p>';
            }

        }

        if($margs['type']=='downloaded'){



            $args = array(

                'id'=>$id_track,
                'get_last'=>'off',
                'interval'=>'24',
                'type'=>'download',
                'table'=>'activity',
                'day_start'=>'3',
                'day_end'=>'2',
                'get_count'=>'off',
                'show_title'=>'off',
            );

//            print_r($args);



            $users_followers = $dzsap_portal->mysql_get_track_activity($id_track, $args);

            if($margs['show_title']=='on'){


                //<span class="title-left"><i class="fa fa-heart"></i> '.__("Liked by ").'</span><span class="title-right">'.count($users_followers).' '.__('people').'</span>
                $fout.='<h3 class="widget-title"><i class="fa fa-download" style="font-size: 13px; margin-right: 3px;"></i> <span class="the-label">'.count($users_followers).' '.__('downloads').'</span></h3><div class="clear"></div>';
            }



//        print_r($users_followers);

            if(is_array($users_followers) && count($users_followers)){



                foreach($users_followers as $pl){

                    if(isset($pl['post_type']) && $pl['post_type']=='repost'){
                        continue;
                    }

                    $l = $dzsap_portal->get_permalink($pl['id'], array(
                        'type'=>'user',
                    ));
                    $fout.='<a  href="'.$l.'" class="col-md-2 ajax-link user-round-view user-round-view--mini">';



                    $fout.='<div class="js-height-as-width the-avatar" style="background-image:url('.$dzsap_portal->sanitize_source($dzsap_portal->get_avatar($pl['id'])).'); " >';


                    $fout .= '</div>';






                    //                    print_r($pl);

                    $fout.='</a>';
                }

            }else{
                $fout.='<p>'.__("No Downloads").'</p>';
            }

        }


//        echo $id_user;


//        print_r($_GET);


//        print_r($margs);
//        print_r($_GET);
//        $tr = $dzsap_portal->get_user($id_user);

//        print_r($tr);


//        $dzsap_portal->site_encryption_key = 'aaaabbbbccccdddd';
//        echo 'site_encryption_key -'.$dzsap_portal->site_encryption_key;
//        echo "\n".'mail_encrypted -'.simple_encrypt('ceva',$dzsap_portal->site_encryption_key);



        $fout.='<div class="clear"></div>';
        $fout.='</div>';


            return $fout;
    }
}
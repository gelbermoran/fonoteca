<?php
$id = 'cover_image';

$dzspgb_templates[$id] = array(
    'id' => $id,
    'admin_str_function' => 'admin_str_function_'.$id,
);


if(!function_exists('admin_str_function_cover_image')){
    function admin_str_function_cover_image($pargs=array()){
        global $dzspgb_forportal, $dzsap_portal;

        $id = 'cover_image';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'element_index' => '0',
            'type' => 'element',
            'type_element' => $id,
            'type_pb' => "Full",
            'txt_choose' => __("Choose"),
            'type_elements' => "newelement", // -- newelement (js) or dzspgb (php) ( legit )

            'track_id' => "",

            'item' => array(),
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }

//        print_r($margs);

        $fout = '';
        $ind='';
        $element_edit_str='';



        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']['.$margs['element_index'].']';

//        echo 'alceva'.$ind;




        $lab = 'track_id';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';


        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Track Id').'</span>
'.DZSHelpers::generate_input_text($nam, array('class'=>'simple-input-text ','seekval'=>$margs[$lab],)).'
<span class="sidenote">'.__("The track id, leave blank for the current track page.").'</span>
</span>';





        $element_edit_str.='';

        $element_edit_str.='<p class="buttons-con"><button class="button-primary btn-delete-itm btn-delete-element">'.__('Delete Element').'</button> <button class="button--secondary button btn-done-editing"><span class="button-label">'.__('Done Editing').'</span></button> </p>
        ';





        // -- screen in editor
        $fout.='<div class="dzspgb-element-con" data-type="cover_image">
        <div class="hidden-content"><br>'.$element_edit_str.'</div>
        <span class="dzspgb-element-type the-type-'.$id.'" data-type="'.$id.'">
            <span class="move-handler-for-elements"><i class="fa fa-arrows-v"></i>
            </span>
            <span class="icon-con"><i class="fa fa-television"></i></span><h5>'.__('Cover Image').'</h5><p class="the-excerpt">'.__("This outputs the pages cover_image.").'</p><span class="dzspgb-button dzspgb-button-choose">'.$margs['txt_choose'].'
            </span>
        </span>
        <input type="hidden" name="'.$margs['type_elements'].$ind.'[type_element]" value="'.$id.'"/>
        </div><!-- END dzspgb-element-con -->';

//        $fout.='</div>';

        return $fout;
    }
}




if(!function_exists('shortcode_cover_image')){
    function shortcode_cover_image($pargs=array(),$content=''){

        global $dzsap_portal;

        $fout = '';

        $margs = array(
            'track_id' => "",
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }



//        print_r($margs);

$fout.='<div class="shortcode-cover_image" style="">';

        $track_id = $margs['track_id'];
        if($margs['track_id']==''){

            if(isset($_GET['track_id'])){

                $track_id=$_GET['track_id'];
            }
        }

        if($dzsap_portal->query2_processed){
            $track_id = $dzsap_portal->query2_processed;
        }

//        echo $track_id;


//        print_r($margs);
//        print_r($_GET);
        $tr = $dzsap_portal->get_track($track_id);

        if(isset($tr['cover_image']) && $tr['cover_image']){

//            print_r($tr);


            if($dzsap_portal->main_settings['use_parallaxer']=='on'){

                $fout.='<div class=" dzsparallaxer auto-init dzsparallaxer-for-track-cover-image " style="position: absolute; width: 100%; height: 180px;" data-options=\'{  settings_mode: "scroll",  mode_scroll: "fromtop" ,  direction: "normal" }\'>';


                $fout.='<div class="dzsparallaxer--target">';
            }

            $src_cover_image = $dzsap_portal->sanitize_source($tr['cover_image']);

            $fout.='<div class="coverimage" style="';


            if($track_id){
//                $fout.=' height: 130%;';
            }

            $fout.='background-image: url('.$src_cover_image.')"></div>';

            $fout.='<div class="the-overlay"></div>';
            if($dzsap_portal->main_settings['use_parallaxer']=='on'){

                $fout.='</div>';


                $fout.='</div>';
            }
        }


        $fout.='<div class="clear"></div>
</div>';



            return $fout;
    }
}
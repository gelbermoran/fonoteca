<?php
$id = 'comments';

$dzspgb_templates[$id] = array(
    'id' => $id,
    'admin_str_function' => 'admin_str_function_comments',
);


if(!function_exists('admin_str_function_comments')){
    function admin_str_function_comments($pargs=array()){
        global $dzspgb_forportal, $dzsap_portal;

        $id = 'comments';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'element_index' => '0',
            'type' => 'element',
            'type_element' => $id,
            'type_pb' => "Full",
            'txt_choose' => __("Choose"),
            'type_elements' => "newelement", // -- newelement (js) or dzspgb (php) ( legit )

            'track_id' => "",

            'item' => array(),
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }

//        print_r($margs);

        $fout = '';
        $ind='';
        $element_edit_str='';



        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']['.$margs['element_index'].']';

//        echo 'alceva'.$ind;




        $lab = 'track_id';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';


        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Track Id').'</span>
'.DZSHelpers::generate_input_text($nam, array('class'=>'simple-input-text ','seekval'=>$margs[$lab],)).'
<span class="sidenote">'.__("The track id, leave blank for the current track page.").'</span>
</span>';





        $element_edit_str.='';

        $element_edit_str.='<p class="buttons-con"><button class="button-primary btn-delete-itm btn-delete-element">'.__('Delete Element').'</button> <button class="button--secondary button btn-done-editing"><span class="button-label">'.__('Done Editing').'</span></button> </p>
        ';





        // -- screen in editor
        $fout.='<div class="dzspgb-element-con" data-type="comments">
        <div class="hidden-content"><br>'.$element_edit_str.'</div>
        <span class="dzspgb-element-type the-type-'.$id.'" data-type="'.$id.'">
            <span class="move-handler-for-elements"><i class="fa fa-arrows-v"></i>
            </span>
            <span class="icon-con"><i class="fa fa-comments"></i></span><h5>'.__('Comments').'</h5><p class="the-excerpt">'.__("This outputs the pages comments.").'</p><span class="dzspgb-button dzspgb-button-choose">'.$margs['txt_choose'].'
            </span>
        </span>
        <input type="hidden" name="'.$margs['type_elements'].$ind.'[type_element]" value="'.$id.'"/>
        </div><!-- END dzspgb-element-con -->';

//        $fout.='</div>';

        return $fout;
    }
}




if(!function_exists('shortcode_comments')){
    function shortcode_comments($pargs=array(),$content=''){

        global $dzsap_portal;

        $fout = '';

        $margs = array(
            'track_id' => "",
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }



//        print_r($margs);

$fout.='<div id="comments" class="shortcode-comments" style="">';

        $track_id = $margs['track_id'];
        if($margs['track_id']==''){

            if(isset($_GET['track_id'])){

                $track_id=$_GET['track_id'];
            }
        }


        $post_type = 'track';

        if(isset($_GET['page']) && $_GET['page']=='post'){
            $post_type = 'post';
            $track_id = $_GET['post_id'];
        }

        $comms = $dzsap_portal->get_comments_array($track_id, array(
            'type'=>'comments'
        ));
//                    echo 'ceva'; print_r($comms);
        foreach ($comms as $comm) {
            $fout.= $comm;
        }

        $fout.='';


        if($dzsap_portal->main_settings['comments_allow_post_if_not_logged_in']=='on' || ($dzsap_portal->main_settings['comments_allow_post_if_not_logged_in']=='off' && $dzsap_portal->currUserId) ){
            $fout.='<form class="comment-form-con">';

            $fout.='<h3>'.__("Post Comment").'</h3>';


            if($dzsap_portal->currUserId>0){

            }else{

                $fout.='<div class="row">';
                $fout.='<div class="col-md-6">';

                $fout.='<input type="" class="input-ujarak-style" placeholder="'.__("Name").'" name="name"></input>';
                $fout.='</div>';


                $fout.='<div class="col-md-6">';
                $fout.='<input type="" class="input-ujarak-style" placeholder="'.__("Email").'" name="email"></input>';
                $fout.='</div>';

                $fout.='</div>';

                $fout.='<br>';
                $fout.='<br>';
            }
//        $fout.='<h5></h5>';

            $fout.='<textarea class="input-ujarak-style" name="comment_text" placeholder="'.__("Comment").'"></textarea>';



            if($dzsap_portal->currUserId>0){

                $fout.='<input type="hidden" name="user_logged_in" value="on"/>';
            }else {

//            echo 'alceva';
                if ($dzsap_portal->main_settings['api_google_recapcha_sitekey']) {

                    $fout .= '<br>';
                    $fout .= '<br>';
                    $fout .= '<div class="setting">';
                    $fout .= '<div class="setting-label">' . __('') . '</div>';
                    $fout .= '<div class="g-recaptcha" data-sitekey="' . $dzsap_portal->main_settings['api_google_recapcha_sitekey'] . '"></div>';

                    $fout .= '</div>';
                    $fout.='<input type="hidden" name="user_logged_in" value="off"/>';
                }
            }


            $fout.='<input type="hidden" name="form_source" value="form"/>';
            $fout.='<input type="hidden" name="for_type" value="'.$post_type.'"/>';
            $fout.='<input type="hidden" name="playerid" value="'.$track_id.'"/>';

            $fout.='<br>';
            $fout.='<br>';
            $fout.='<button class="button button--secondary btn-comment-submit"><span class="button-label">'.__("Submit").'</span></button>';

            $fout.='</form>';
        }



        $fout.='<div class="clear"></div>
</div>';

        if(function_exists('enqueue_script')){
            //<script src='https://www.google.com/recaptcha/api.js'></script>
            enqueue_script('recaptcha', 'https://www.google.com/recaptcha/api.js');
        }



            return $fout;
    }
}
<?php
$id = 'videoplayer';

$dzspgb_templates[$id] = array(
    'id' => $id,
    'admin_str_function' => 'admin_str_function_'.$id,
);


if(!function_exists('admin_str_function_'.$id)){
    function admin_str_function_videoplayer($pargs=array()){

        $id = 'videoplayer';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'element_index' => '0',
            'type' => 'element',
            'type_element' => $id,
            'type_pb' => "Full",
            'txt_choose' => __("Choose"),
            'type_elements' => "newelement", // -- newelement (js) or dzspgb (php) ( legit )
            'text' => "",
            'extra_classes' => "",
            'cover_image' => "",
            'extra_text' => '',
            'video' => "",
            'item' => array(),
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }

//        print_r($margs);

        $fout = '';
        $ind='';
        $element_edit_str='';



        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']['.$margs['element_index'].']';

//        echo 'alceva'.$ind;






        $lab = 'cover_image';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';

        $element_edit_str .= '<div class="setting">
        <div class="setting-label">'.__('Cover Image').'</div>';

        $element_edit_str.='<div class=" dzs-upload-con';


        $element_edit_str.='"><div class="float-left">
    <input type="text" class="simple-input-field target-field exclude-from-row-part-atts" name="'.$nam.'" value="'.$margs[$lab].'"/>
    <div class="dzs-single-upload';


        $element_edit_str.='">
        <input class="" type="file">
        </div>


<div class="feedback"></div>
</div>
        </div>
<div class="clear"></div>
        </div>';




        $lab = 'video';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';

        $element_edit_str .= '<div class="setting">
        <div class="setting-label">'.__('The Video').'</div>';

        $element_edit_str.='<div class=" dzs-upload-con';


        $element_edit_str.='"><div class="float-left">
    <input type="text" class="simple-input-field target-field exclude-from-row-part-atts" name="'.$nam.'" value="'.$margs[$lab].'"/>
    <div class="dzs-single-upload';


        $element_edit_str.='">
        <input class="" type="file">
        </div>


<div class="feedback"></div>
</div>
        </div>
<div class="clear"></div>
        </div>';




//        $lab = 'video';
//        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';
//
//        $element_edit_str .= '<br><div class="setting">
//        <div class="setting-label">'.__('Extra Classes').'</div>
//<input type="text" class="simple-input-field target-field exclude-from-row-part-atts" name="'.$nam.'" value="'.$margs[$lab].'"/>';
//        $element_edit_str.='</div>';




        $lab = 'extra_classes';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';

        $element_edit_str .= '<br><div class="setting">
        <div class="setting-label">'.__('Extra Classes').'</div>
<textarea class="textarea-extra-css formstyle" name="'.$nam.'">'.$margs[$lab].'</textarea>';
        $element_edit_str.='</div>';




        $lab = 'extra_text';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';

        $element_edit_str .= '<br><div class="setting">
        <div class="setting-label">'.__('Extra Text').'</div>
<textarea class="textarea-extra-css formstyle" name="'.$nam.'">'.$margs[$lab].'</textarea>';
        $element_edit_str.='</div>';







        $element_edit_str.='<p class="buttons-con"><button class="button-primary btn-delete-itm btn-delete-element">'.__('Delete Element').'</button> <button class="button--secondary button btn-done-editing"><span class="button-label">'.__('Done Editing').'</span></button> </p>
        ';





        // -- screen in editor
        $fout.='<span class="dzspgb-element-con"><span class="hidden-content">'.$element_edit_str.'</span><span class="dzspgb-element-type the-type-text" data-type="'.$id.'">
        <span class="move-handler-for-elements"><i class="fa fa-arrows-v"></i></span>
        <span class="clone-handler-for-elements"><i class="fa fa-clone"></i></span>
        <span class="icon-con"><i class="fa fa-video-camera"></i></span><h5>'.__('Video Player ').'</h5><p class="the-excerpt">'.__("Insert a video player - youtube / self hosted or vimeo.").'</p><span class="dzspgb-button dzspgb-button-choose">'.$margs['txt_choose'].'</span></span><input type="hidden" name="'.$margs['type_elements'].$ind.'[type_element]" value="'.$id.'"/></span>';

        return $fout;
    }
}




if(!function_exists('shortcode_videoplayer')){
    function shortcode_videoplayer($pargs=array(),$content=''){

        global $dzsap_portal;

        $fout = '';

        $margs = array(
            'type_element' => 'videoplayer',
            'videoplayer_style' => 'style_default',
            'cover_image' => '',
            'video' => '',
            'extra_classes' => '',
            'extra_text' => '',
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }



//        print_r($margs);

$fout.='<div class="shortcode-videoplayer">';


$fout.='<div class="zoomvideoplayer skin-avanti auto-init-from-dzsapp '.$margs['extra_classes'].'" data-source="'.$margs['video'].'"  data-options=\'{ cue: "on", autoplay: "off", settings_otherSocialIcons:"", settings_suggestedQuality: "large", settings_enableAutoHide:"off",
design_attachTotalTimeAfterScrub: "off"
,design_specialContainer: "off"}\'
>';
        if($dzsap_portal->main_settings['use_parallaxer']=='on') {
                $fout.='<div class="cover-image dzsparallaxer auto-init do-not-set-js-height " data-options=\'{
mode_scroll: "fromtop"
,direction: "reverse"
}\'  style="width: 100%; height:100%; position:absolute; top:0; left:0;" >';
            $fout .= '<div class=" dzsparallaxer--target position-absolute divimage " style="width: 100%; height: 120%; background-image: url(' . $margs['cover_image'] . '); ">

</div>';



            $fout.='<svg class="cover-play-btn" version="1.1" baseProfile="tiny" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
	 x="0px" y="0px" width="120px" height="120px" viewBox="0 0 120 120" overflow="auto" xml:space="preserve">
<path fill-rule="evenodd" fill="#ffffff" d="M79.295,56.914c2.45,1.705,2.45,4.468,0,6.172l-24.58,17.103
	c-2.45,1.704-4.436,0.667-4.436-2.317V42.129c0-2.984,1.986-4.022,4.436-2.318L79.295,56.914z M0.199,54.604
	c-0.265,2.971-0.265,7.821,0,10.792c2.57,28.854,25.551,51.835,54.405,54.405c2.971,0.265,7.821,0.265,10.792,0
	c28.854-2.57,51.835-25.551,54.405-54.405c0.265-2.971,0.265-7.821,0-10.792C117.231,25.75,94.25,2.769,65.396,0.198
	c-2.971-0.265-7.821-0.265-10.792,0C25.75,2.769,2.769,25.75,0.199,54.604z M8.816,65.394c-0.309-2.967-0.309-7.82,0-10.787
	c2.512-24.115,21.675-43.279,45.79-45.791c2.967-0.309,7.821-0.309,10.788,0c24.115,2.512,43.278,21.675,45.79,45.79
	c0.309,2.967,0.309,7.821,0,10.788c-2.512,24.115-21.675,43.279-45.79,45.791c-2.967,0.309-7.821,0.309-10.788,0
	C30.491,108.672,11.328,89.508,8.816,65.394z"/>
</svg>';

            if($margs['extra_text']){
                $fout.=$dzsap_portal->sanitize_for_front_end($margs['extra_text']);
            }
            $fout.='<div class="dzsparallaxer--blackoverlay">  </div>';



            $fout.='</div>';



        }else{

            $fout .= '<div class="cover-image" style="background-image: url(' . $margs['cover_image'] . '); ">
                        <svg class="cover-play-btn" version="1.1" baseProfile="tiny" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
	 x="0px" y="0px" width="120px" height="120px" viewBox="0 0 120 120" overflow="auto" xml:space="preserve">
<path fill-rule="evenodd" fill="#ffffff" d="M79.295,56.914c2.45,1.705,2.45,4.468,0,6.172l-24.58,17.103
	c-2.45,1.704-4.436,0.667-4.436-2.317V42.129c0-2.984,1.986-4.022,4.436-2.318L79.295,56.914z M0.199,54.604
	c-0.265,2.971-0.265,7.821,0,10.792c2.57,28.854,25.551,51.835,54.405,54.405c2.971,0.265,7.821,0.265,10.792,0
	c28.854-2.57,51.835-25.551,54.405-54.405c0.265-2.971,0.265-7.821,0-10.792C117.231,25.75,94.25,2.769,65.396,0.198
	c-2.971-0.265-7.821-0.265-10.792,0C25.75,2.769,2.769,25.75,0.199,54.604z M8.816,65.394c-0.309-2.967-0.309-7.82,0-10.787
	c2.512-24.115,21.675-43.279,45.79-45.791c2.967-0.309,7.821-0.309,10.788,0c24.115,2.512,43.278,21.675,45.79,45.79
	c0.309,2.967,0.309,7.821,0,10.788c-2.512,24.115-21.675,43.279-45.79,45.791c-2.967,0.309-7.821,0.309-10.788,0
	C30.491,108.672,11.328,89.508,8.816,65.394z"/>
</svg>
                    </div>';
            if($margs['extra_text']){
                $fout.=$dzsap_portal->sanitize_for_front_end($margs['extra_text']);
            }
        }
                    $fout.='
                </div>';


        $fout.='</div>';



        if(function_exists('enqueue_script')) {

            enqueue_script('dzs.zoomplayer', 'libs/zoomplayer/zoomplayer.js');
            enqueue_style('dzs.zoomplayer', 'libs/zoomplayer/zoomplayer.css');
        }





        return $fout;



    }
}
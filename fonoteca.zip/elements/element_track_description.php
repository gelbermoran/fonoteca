<?php
$id = 'track_description';

$dzspgb_templates[$id] = array(
    'id' => $id,
    'admin_str_function' => 'admin_str_function_track_description',
);

if(isset($default_opts)==false){
    $default_opts = array();
}

$default_opts[$id]=array(
    'call_from_lab'=>''
);


if(!function_exists('admin_str_function_track_description')){
    function admin_str_function_track_description($pargs=array()){
        global $dzspgb_forportal, $dzsap_portal,$default_opts;

        $id = 'track_description';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'element_index' => '0',
            'type' => 'element',
            'track_description_type' => 'auto',
            'type_element' => $id,
            'type_pb' => "Full",
            'txt_choose' => __("Choose"),
            'type_elements' => "newelement", // -- newelement (js) or dzspgb (php) ( legit )


            'the_id' => '',

        );


        $margs=array_merge($margs,$default_opts[$id]);

        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }


//        print_r($margs);

        $fout = '';
        $ind='';
        $element_edit_str='';



        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']['.$margs['element_index'].']';

//        echo 'alceva'.$ind;






        $lab = 'the_id';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';


        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Custom ID').'</span>
'.DZSHelpers::generate_input_text($nam, array('class'=>'simple-input-text ','seekval'=>$margs[$lab],)).'
<span class="sidenote">'.__("Leave blank to take the id from the current page").'</span>
</span>';



//        print_r($apconfigs);






        $element_edit_str.='';

        $element_edit_str.='<p class="buttons-con"><button class="button-primary btn-delete-itm btn-delete-element">'.__('Delete Element').'</button> <button class="button--secondary button btn-done-editing"><span class="button-label">'.__('Done Editing').'</span></button> </p>
        ';





        // -- screen in editor
        $fout.='<div class="dzspgb-element-con" data-type="track_description">
        <div class="hidden-content style-update-holder type-update-holder"><br>'.$element_edit_str.'</div>
        <div class="dzspgb-element-type the-type-track_description" data-type="'.$id.'">
            
            <span class="move-handler-for-elements"><i class="fa fa-arrows-v"></i></span>
            <span class="clone-handler-for-elements"><i class="fa fa-clone"></i></span>
            
            <span class="icon-con"><i class="fa fa-cubes"></i></span><h5>'.__('Track Description').'</h5><p class="the-excerpt">'.__("This outputs the track description").'</p><span class="dzspgb-button dzspgb-button-choose">'.$margs['txt_choose'].'
            </span>
        </div>
        <input type="hidden" name="'.$margs['type_elements'].$ind.'[type_element]" value="'.$id.'"/>
        </div><!-- END dzspgb-element-con -->';

//        $fout.='</div>';






        return $fout;



    }
}




if(!function_exists('shortcode_track_description')){
    function shortcode_track_description($pargs=array(),$content=''){

        $id = 'track_description';

        global $dzsap_portal;
        global $default_opts;

        $fout = '';

        $margs = array(
            'call_from' => "",
            'type' => $id, // -- auto or default or list or slider ...tbc
            'extra_classes' => '', // -- the audio player configuration

            'the_id' => "",
        );

        $margs=array_merge($margs,$default_opts[$id]);

        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }




        if(($margs['call_from_lab'])){
            $margs['call_from'] = ($margs['call_from_lab']);
        }

//        echo ' track_description margs - ';print_r($margs);


$fout.='<div class="shortcode-track_description-main  '.$margs['extra_classes'].'  shortcode-track_description-type-'.$margs['type'].' " style="">';

        $id = '';
        if($margs['the_id']){


        }else{

            $id = $dzsap_portal->track_id;
        }

        if($id){
            $tr = $dzsap_portal->get_track($id);

//            print_r($tr);

            $fout.=$tr['description'];
        }



//        print_r($dzsap_portal);

        $fout.='<div class="clear"></div>
</div>';



            return $fout;
    }
}
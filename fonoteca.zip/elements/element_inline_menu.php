<?php
$id = 'inline_menu';

$dzspgb_templates[$id] = array(
    'id' => $id,
    'admin_str_function' => 'admin_str_function_inline_menu',
);

if(isset($default_opts)==false){
    $default_opts = array();
}

$default_opts[$id]=array(
    'call_from_lab'=>''
);


if(!function_exists('admin_str_function_inline_menu')){
    function admin_str_function_inline_menu($pargs=array()){
        global $dzspgb_forportal, $dzsap_portal,$default_opts;

        $id = 'inline_menu';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'element_index' => '0',
            'type' => 'element',
            'inline_menu_type' => 'auto',
            'type_element' => $id,
            'type_pb' => "Full",
            'txt_choose' => __("Choose"),
            'type_elements' => "newelement", // -- newelement (js) or dzspgb (php) ( legit )


            'menu_select' => 'none',

        );


        $margs=array_merge($margs,$default_opts[$id]);

        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }


//        print_r($margs);

        $fout = '';
        $ind='';
        $element_edit_str='';



        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']['.$margs['element_index'].']';

//        echo 'alceva'.$ind;


        $lab = ''.$margs['type_elements'].$ind.'[inline_menu_height]';

        $element_edit_str.='';



        $lab = 'menu_select';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';
        $arr_opts2 = array(
            array('val'=>'none',
                'lab'=>__('No menu'),
            )
        );

        $aux_arr = json_decode($dzspgb_forportal->ajax_select_pages_array(array(
            'for_ajax'=>false,
            'post_type'=>'menu',
        )));

        foreach($aux_arr as $menuarr){
//            print_r($menuarr);
            $auxer = array(
                'val'=>$menuarr->id,
                'lab'=>$menuarr->title,
            );

            array_push($arr_opts2, $auxer);
        }

        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Menu').'</span>
'.DZSHelpers::generate_select($nam, array('class'=>'dzs-style-me skin-beige ','options'=>$arr_opts2,'seekval'=>$margs[$lab],)).'
</span>';



//        print_r($apconfigs);






        $element_edit_str.='';

        $element_edit_str.='<p class="buttons-con"><button class="button-primary btn-delete-itm btn-delete-element">'.__('Delete Element').'</button> <button class="button--secondary button btn-done-editing"><span class="button-label">'.__('Done Editing').'</span></button> </p>
        ';





        // -- screen in editor
        $fout.='<div class="dzspgb-element-con" data-type="inline_menu">
        <div class="hidden-content style-update-holder type-update-holder"><br>'.$element_edit_str.'</div>
        <div class="dzspgb-element-type the-type-inline_menu" data-type="'.$id.'">
            
            <span class="move-handler-for-elements"><i class="fa fa-arrows-v"></i></span>
            <span class="clone-handler-for-elements"><i class="fa fa-clone"></i></span>
            
            <span class="icon-con"><i class="fa fa-cubes"></i></span><h5>'.__('inline_menu').'</h5><div class="the-excerpt-real">'.__("menu id - ").'<strong>{{menu_select}}</strong></div><p class="the-excerpt">'.__("This outputs the current special page inline_menu. For example, for a Explore page, it outputs all the tracks uploaded, and for a Likes page it outputs the user s liked pages.").'</p><span class="dzspgb-button dzspgb-button-choose">'.$margs['txt_choose'].'
            </span>
        </div>
        <input type="hidden" name="'.$margs['type_elements'].$ind.'[type_element]" value="'.$id.'"/>
        </div><!-- END dzspgb-element-con -->';

//        $fout.='</div>';






        return $fout;



    }
}




if(!function_exists('shortcode_inline_menu')){
    function shortcode_inline_menu($pargs=array(),$content=''){

        $id = 'inline_menu';

        global $dzsap_portal;
        global $default_opts;

        $fout = '';

        $margs = array(
            'type' => '', // -- auto or default or list or slider ...tbc
            'style' => 'auto', // -- auto or default or list or slider ...tbc
            'inline_menu_type' => 'auto', // -- auto or explore or mytracks or playlist or playlists or stream or
            'pagination' => 'auto', // -- auto or none or ajax or pages or pagesajax
            'apconfig' => '', // -- the audio player configuration
            'extra_classes' => '', // -- the audio player configuration
            'paged' => '', // -- the displayed page
            'interval' => '', // -- the displayed page
            'post_type' => '', // -- the post type - only for specific inline_menu_type
            'thumbs_disable_arrows' => "off",
            'thumbs_see_all_text' => "",
            'design_bulletspos' => "",
            'thumbs_bullets_position' => "bottom",
            'menu_select' => "default",
        );

        $margs=array_merge($margs,$default_opts[$id]);

        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }




        if(intval($margs['paged'])){
            $margs['paged'] = intval($margs['paged']) - 1;
        }

        if(($margs['call_from_lab'])){
            $margs['call_from'] = ($margs['call_from_lab']);
        }

//        echo ' inline_menu margs - ';print_r($margs);


$fout.='<div class="shortcode-inline_menu-main  '.$margs['extra_classes'].'  shortcode-inline_menu-type-'.$margs['type'].' style-'.$margs['style'].' pagination-'.$margs['pagination'].'" style="">';


        $men_arr = array();

        if($margs['menu_select'] && $margs['menu_select']!=='none'){

            $men = $dzsap_portal->get_page($margs['menu_select'], array(
                'post_type'=>'menu'
            ));


//            $men['content'] = str_replace('"content"', "'content'", $men['content']);
//            print_r($men);

            if(isset($men['content'])){

                $men_arr = json_decode($men['content']);
            }







//            print_r($men_arr);
        }





        $menu_li_str = '';

        foreach($men_arr as $menuitem){


//            print_r($menuitem);

            if(isset($menuitem->visibility_type)){
                if($menuitem->visibility_type=='logged'){
                    if($dzsap_portal->currUserId<1){
                        continue;
                    }
                }
                if($menuitem->visibility_type=='not_logged'){
                    if($dzsap_portal->currUserId>0){
                        continue;
                    }
                }
            }

            if($menuitem->type==='menupage'){
                $aux = $dzsap_portal->get_page($menuitem->id, array(
                    'post_type'=>'page'
                ));



//                print_r($aux);



                $menu_li_str.= '<li data-id="'.$menuitem->id.'" class="menu-item ';

                if($menuitem->id == $dzsap_portal->currPageId){
                    $menu_li_str.=' current-menu-item';
                }



                if(isset($menuitem->extra_classes) && ($menuitem->extra_classes)){

                    $menu_li_str.=' '.$menuitem->extra_classes;
                }

//                echo 'ceva'.'alceva'.$dzsap_portal->currPageId.$menuitem->id;
//                echo 'wha'.$dzsap_portal->currPageId. ' / '.$menuitem->id. ' / '.($menuitem->id == $dzsap_portal->currPageId).' /// ';


                $menu_li_str.='"><a class="';




                if($dzsap_portal->main_settings['use_ajax']==='on'){
                    $menu_li_str.=' ajax-link ajax-link-inline-menu';
                }


//                print_r($menuitem);

                $title = '';

                if(isset($aux['title'])){

                    $title = $aux['title'];
                }

                if($menuitem->content){
                    $title = $menuitem->content;
                    $title=$dzsap_portal->sanitize_for_front_end($title);
                }



                $link = $dzsap_portal->get_permalink($menuitem->id, array(
                    'type'=>'page'
                ,'get_full_link'=>true
                ));


                if($link==''){
                    $aux = $dzsap_portal->get_page($menuitem->id);
                    $link = $dzsap_portal->sanitize_for_pretty($menuitem->id, array(
                        'type'=>'page'
                    ));
                    if($link==''){
                        $link = $dzsap_portal->optional_url_base.$dzsap_portal->sanitize_title_for_pretty($aux['title']);
                    }
                }

//                print_r($menuitem);


                $menu_li_str.='" href="'.$link.'">'.$title.'</a>';




                if(isset($menuitem->children) && is_array($menuitem->children)){

                    $menu_li_str.='<ul>';




                    $menu_li_str.= '<li class="menu-item ';

                    if($menuitem->id == $dzsap_portal->currPageId){
                        $menu_li_str.=' current-menu-item';
                    }



                    $cont = $dzsap_portal->sanitize_for_front_end($aux['title']);



                    $link = $dzsap_portal->get_permalink($menuitem->id, array(
                        'type'=>'page'
                    ));


                    $menu_li_str.='"><a href="'.$link.'">'.$cont.'</a>';


                    $menu_li_str.='</li>';


                    $menu_li_str.='</ul>';

                }

                $menu_li_str.='</li>';

//                print_r($aux);
            }

            if($menuitem->type==='customhtml'){

                $menu_li_str.= '<li class="menu-item extra-html-item ';




                if(isset($menuitem->extra_classes) && ($menuitem->extra_classes)){

                    $menu_li_str.=' '.$menuitem->extra_classes;
                }



                $menuitem->content = str_replace('{replacequotquot}', '"', $menuitem->content);

                $menu_li_str.='">'.$menuitem->content.'</li>';




//                print_r($aux);
            }
        }

        $fout.=$menu_li_str;

        $fout.='<div class="clear"></div>
</div>';



            return $fout;
    }
}
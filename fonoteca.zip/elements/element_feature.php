<?php
$id = 'feature';

global $dzspgb_templates;

$dzspgb_templates[$id] = array(
    'id' => $id,
    'admin_str_function' => 'admin_str_function_feature',
);

//print_r($dzspgb_templates);

if(!function_exists('admin_str_function_feature')){
    function admin_str_function_feature($pargs=array()){

        $id = 'feature';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'element_index' => '0',
            'type' => 'element',
            'type_element' => $id,
            'type_pb' => "Full",
            'txt_choose' => __("Choose"),
            'type_elements' => "newelement", // -- newelement (js) or dzspgb (php) ( legit )
            'feature' => "",
            'kill_tinymce' => "off",
            'title' => '',
            'icon' => '',
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }


        $fout = '';
        $ind='';
        $element_edit_str='';



        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']['.$margs['element_index'].']';

//        echo 'alceva'.$ind;




        $lab = 'icon';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';

        $element_edit_str .= '<span class="setting">
        <span class="setting-label">'.__('The Icon').'</span>
</span>

<span class="iconselector">
                <p><span class="iconselector-preview"></span>'.DZSHelpers::generate_input_text($nam, array('class'=>'style-iconselector iconselector-waiter ','seekval'=>$margs[$lab],)).'<span
                        class="iconselector-btn"><i class="fa fa-caret-down"></i></span></p>

                <span class="iconselector-clip">

                    <span class="icon-select" data-theicon="bars fa-lg"><i class="fa fa-bars fa-lg"></i></span><span
                        class="icon-select" data-theicon="flag"><i class="fa fa-flag"></i></span><span
                        class="icon-select" data-theicon="caret-down"><i class="fa fa-caret-down"></i></span><span
                        class="icon-select" data-theicon="flag "><i class="fa fa-flag "></i></span><span
                        class="icon-select" data-theicon="cube fa-fw"><i class="fa fa-cube fa-fw"></i></span><span
                        class="icon-select" data-theicon="camera-retro fa-fw"><i
                            class="fa fa-camera-retro fa-fw"></i></span><span class="icon-select"
                                                                              data-theicon="file-image-o fa-fw"><i
                            class="fa fa-file-image-o fa-fw"></i></span><span class="icon-select"
                                                                              data-theicon="spinner fa-fw"><i
                            class="fa fa-spinner fa-fw"></i></span><span class="icon-select"
                                                                         data-theicon="check-square fa-fw"><i
                            class="fa fa-check-square fa-fw"></i></span><span class="icon-select"
                                                                              data-theicon="credit-card fa-fw"><i
                            class="fa fa-credit-card fa-fw"></i></span><span class="icon-select"
                                                                             data-theicon="pie-chart fa-fw"><i
                            class="fa fa-pie-chart fa-fw"></i></span><span class="icon-select" data-theicon="won fa-fw"><i
                            class="fa fa-won fa-fw"></i></span><span class="icon-select"
                                                                     data-theicon="file-text-o fa-fw"><i
                            class="fa fa-file-text-o fa-fw"></i></span><span class="icon-select"
                                                                             data-theicon="hand-o-right fa-fw"><i
                            class="fa fa-hand-o-right fa-fw"></i></span><span class="icon-select"
                                                                              data-theicon="play-circle fa-fw"><i
                            class="fa fa-play-circle fa-fw"></i></span><span class="icon-select"
                                                                             data-theicon="github fa-fw"><i
                            class="fa fa-github fa-fw"></i></span><span class="icon-select" data-theicon="medkit fa-fw"><i
                            class="fa fa-medkit fa-fw"></i></span><span class="icon-select" data-theicon="caret-down"><i
                            class="fa fa-caret-down"></i></span><span class="icon-select" data-theicon="flag"><i
                            class="fa fa-flag"></i></span><span class="icon-select" data-theicon="angellist"><i
                            class="fa fa-angellist"></i></span><span class="icon-select" data-theicon="area-chart"><i
                            class="fa fa-area-chart"></i></span><span class="icon-select" data-theicon="at"><i
                            class="fa fa-at"></i></span><span class="icon-select" data-theicon="bell-slash"><i
                            class="fa fa-bell-slash"></i></span><span class="icon-select" data-theicon="bell-slash-o"><i
                            class="fa fa-bell-slash-o"></i></span><span class="icon-select" data-theicon="bicycle"><i
                            class="fa fa-bicycle"></i></span><span class="icon-select" data-theicon="binoculars"><i
                            class="fa fa-binoculars"></i></span><span class="icon-select"
                                                                      data-theicon="birthday-cake"><i
                            class="fa fa-birthday-cake"></i></span><span class="icon-select" data-theicon="bus"><i
                            class="fa fa-bus"></i></span><span class="icon-select" data-theicon="calculator"><i
                            class="fa fa-calculator"></i></span><span class="icon-select" data-theicon="cc"><i
                            class="fa fa-cc"></i></span><span class="icon-select" data-theicon="cc-amex"><i
                            class="fa fa-cc-amex"></i></span><span class="icon-select" data-theicon="cc-discover"><i
                            class="fa fa-cc-discover"></i></span><span class="icon-select" data-theicon="cc-mastercard"><i
                            class="fa fa-cc-mastercard"></i></span><span class="icon-select" data-theicon="cc-paypal"><i
                            class="fa fa-cc-paypal"></i></span><span class="icon-select" data-theicon="cc-stripe"><i
                            class="fa fa-cc-stripe"></i></span><span class="icon-select" data-theicon="cc-visa"><i
                            class="fa fa-cc-visa"></i></span><span class="icon-select" data-theicon="copyright"><i
                            class="fa fa-copyright"></i></span><span class="icon-select" data-theicon="eyedropper"><i
                            class="fa fa-eyedropper"></i></span><span class="icon-select" data-theicon="futbol-o"><i
                            class="fa fa-futbol-o"></i></span><span class="icon-select" data-theicon="google-wallet"><i
                            class="fa fa-google-wallet"></i></span><span class="icon-select" data-theicon="ils"><i
                            class="fa fa-ils"></i></span><span class="icon-select" data-theicon="ioxhost"><i
                            class="fa fa-ioxhost"></i></span><span class="icon-select" data-theicon="lastfm"><i
                            class="fa fa-lastfm"></i></span><span class="icon-select" data-theicon="lastfm-square"><i
                            class="fa fa-lastfm-square"></i></span><span class="icon-select"
                                                                         data-theicon="line-chart"><i
                            class="fa fa-line-chart"></i></span><span class="icon-select" data-theicon="meanpath"><i
                            class="fa fa-meanpath"></i></span><span class="icon-select" data-theicon="newspaper-o"><i
                            class="fa fa-newspaper-o"></i></span><span class="icon-select" data-theicon="paint-brush"><i
                            class="fa fa-paint-brush"></i></span><span class="icon-select" data-theicon="paypal"><i
                            class="fa fa-paypal"></i></span><span class="icon-select" data-theicon="pie-chart"><i
                            class="fa fa-pie-chart"></i></span><span class="icon-select" data-theicon="plug"><i
                            class="fa fa-plug"></i></span><span class="icon-select" data-theicon="shekel"><i
                            class="fa fa-shekel"></i></span><span class="icon-select" data-theicon="sheqel"><i
                            class="fa fa-sheqel"></i></span><span class="icon-select" data-theicon="slideshare"><i
                            class="fa fa-slideshare"></i></span><span class="icon-select"
                                                                      data-theicon="soccer-ball-o"><i
                            class="fa fa-soccer-ball-o"></i></span><span class="icon-select"
                                                                         data-theicon="toggle-off"><i
                            class="fa fa-toggle-off"></i></span><span class="icon-select" data-theicon="toggle-on"><i
                            class="fa fa-toggle-on"></i></span><span class="icon-select" data-theicon="trash"><i
                            class="fa fa-trash"></i></span><span class="icon-select" data-theicon="tty"><i
                            class="fa fa-tty"></i></span><span class="icon-select" data-theicon="twitch"><i
                            class="fa fa-twitch"></i></span><span class="icon-select" data-theicon="wifi"><i
                            class="fa fa-wifi"></i></span><span class="icon-select" data-theicon="yelp"><i
                            class="fa fa-yelp"></i></span><span class="icon-select" data-theicon="adjust"><i
                            class="fa fa-adjust"></i></span><span class="icon-select" data-theicon="anchor"><i
                            class="fa fa-anchor"></i></span><span class="icon-select" data-theicon="archive"><i
                            class="fa fa-archive"></i></span><span class="icon-select" data-theicon="area-chart"><i
                            class="fa fa-area-chart"></i></span><span class="icon-select" data-theicon="arrows"><i
                            class="fa fa-arrows"></i></span><span class="icon-select" data-theicon="arrows-h"><i
                            class="fa fa-arrows-h"></i></span><span class="icon-select" data-theicon="arrows-v"><i
                            class="fa fa-arrows-v"></i></span><span class="icon-select" data-theicon="asterisk"><i
                            class="fa fa-asterisk"></i></span><span class="icon-select" data-theicon="at"><i
                            class="fa fa-at"></i></span><span class="icon-select" data-theicon="automobile"><i
                            class="fa fa-automobile"></i></span><span class="icon-select" data-theicon="ban"><i
                            class="fa fa-ban"></i></span><span class="icon-select" data-theicon="bank"><i
                            class="fa fa-bank"></i></span><span class="icon-select" data-theicon="bar-chart"><i
                            class="fa fa-bar-chart"></i></span><span class="icon-select" data-theicon="bar-chart-o"><i
                            class="fa fa-bar-chart-o"></i></span><span class="icon-select" data-theicon="barcode"><i
                            class="fa fa-barcode"></i></span><span class="icon-select" data-theicon="bars"><i
                            class="fa fa-bars"></i></span><span class="icon-select" data-theicon="beer"><i
                            class="fa fa-beer"></i></span><span class="icon-select" data-theicon="bell"><i
                            class="fa fa-bell"></i></span><span class="icon-select" data-theicon="bell-o"><i
                            class="fa fa-bell-o"></i></span><span class="icon-select" data-theicon="bell-slash"><i
                            class="fa fa-bell-slash"></i></span><span class="icon-select" data-theicon="bell-slash-o"><i
                            class="fa fa-bell-slash-o"></i></span><span class="icon-select" data-theicon="bicycle"><i
                            class="fa fa-bicycle"></i></span><span class="icon-select" data-theicon="binoculars"><i
                            class="fa fa-binoculars"></i></span><span class="icon-select"
                                                                      data-theicon="birthday-cake"><i
                            class="fa fa-birthday-cake"></i></span><span class="icon-select" data-theicon="bolt"><i
                            class="fa fa-bolt"></i></span><span class="icon-select" data-theicon="bomb"><i
                            class="fa fa-bomb"></i></span><span class="icon-select" data-theicon="book"><i
                            class="fa fa-book"></i></span><span class="icon-select" data-theicon="bookmark"><i
                            class="fa fa-bookmark"></i></span><span class="icon-select" data-theicon="bookmark-o"><i
                            class="fa fa-bookmark-o"></i></span><span class="icon-select" data-theicon="briefcase"><i
                            class="fa fa-briefcase"></i></span><span class="icon-select" data-theicon="bug"><i
                            class="fa fa-bug"></i></span><span class="icon-select" data-theicon="building"><i
                            class="fa fa-building"></i></span><span class="icon-select" data-theicon="building-o"><i
                            class="fa fa-building-o"></i></span><span class="icon-select" data-theicon="bullhorn"><i
                            class="fa fa-bullhorn"></i></span><span class="icon-select" data-theicon="bullseye"><i
                            class="fa fa-bullseye"></i></span><span class="icon-select" data-theicon="bus"><i
                            class="fa fa-bus"></i></span><span class="icon-select" data-theicon="cab"><i
                            class="fa fa-cab"></i></span><span class="icon-select" data-theicon="calculator"><i
                            class="fa fa-calculator"></i></span><span class="icon-select" data-theicon="calendar"><i
                            class="fa fa-calendar"></i></span><span class="icon-select" data-theicon="calendar-o"><i
                            class="fa fa-calendar-o"></i></span><span class="icon-select" data-theicon="camera"><i
                            class="fa fa-camera"></i></span><span class="icon-select" data-theicon="camera-retro"><i
                            class="fa fa-camera-retro"></i></span><span class="icon-select" data-theicon="car"><i
                            class="fa fa-car"></i></span><span class="icon-select" data-theicon="caret-square-o-down"><i
                            class="fa fa-caret-square-o-down"></i></span><span class="icon-select"
                                                                               data-theicon="caret-square-o-left"><i
                            class="fa fa-caret-square-o-left"></i></span><span class="icon-select"
                                                                               data-theicon="caret-square-o-right"><i
                            class="fa fa-caret-square-o-right"></i></span><span class="icon-select"
                                                                                data-theicon="caret-square-o-up"><i
                            class="fa fa-caret-square-o-up"></i></span><span class="icon-select" data-theicon="cc"><i
                            class="fa fa-cc"></i></span><span class="icon-select" data-theicon="certificate"><i
                            class="fa fa-certificate"></i></span><span class="icon-select" data-theicon="check"><i
                            class="fa fa-check"></i></span><span class="icon-select" data-theicon="check-circle"><i
                            class="fa fa-check-circle"></i></span><span class="icon-select"
                                                                        data-theicon="check-circle-o"><i
                            class="fa fa-check-circle-o"></i></span><span class="icon-select"
                                                                          data-theicon="check-square"><i
                            class="fa fa-check-square"></i></span><span class="icon-select"
                                                                        data-theicon="check-square-o"><i
                            class="fa fa-check-square-o"></i></span><span class="icon-select" data-theicon="child"><i
                            class="fa fa-child"></i></span><span class="icon-select" data-theicon="circle"><i
                            class="fa fa-circle"></i></span><span class="icon-select" data-theicon="circle-o"><i
                            class="fa fa-circle-o"></i></span><span class="icon-select" data-theicon="circle-o-notch"><i
                            class="fa fa-circle-o-notch"></i></span><span class="icon-select"
                                                                          data-theicon="circle-thin"><i
                            class="fa fa-circle-thin"></i></span><span class="icon-select" data-theicon="clock-o"><i
                            class="fa fa-clock-o"></i></span><span class="icon-select" data-theicon="close"><i
                            class="fa fa-close"></i></span><span class="icon-select" data-theicon="cloud"><i
                            class="fa fa-cloud"></i></span><span class="icon-select" data-theicon="cloud-download"><i
                            class="fa fa-cloud-download"></i></span><span class="icon-select"
                                                                          data-theicon="cloud-upload"><i
                            class="fa fa-cloud-upload"></i></span><span class="icon-select" data-theicon="code"><i
                            class="fa fa-code"></i></span><span class="icon-select" data-theicon="code-fork"><i
                            class="fa fa-code-fork"></i></span><span class="icon-select" data-theicon="coffee"><i
                            class="fa fa-coffee"></i></span><span class="icon-select" data-theicon="cog"><i
                            class="fa fa-cog"></i></span><span class="icon-select" data-theicon="cogs"><i
                            class="fa fa-cogs"></i></span><span class="icon-select" data-theicon="comment"><i
                            class="fa fa-comment"></i></span><span class="icon-select" data-theicon="comment-o"><i
                            class="fa fa-comment-o"></i></span><span class="icon-select" data-theicon="comments"><i
                            class="fa fa-comments"></i></span><span class="icon-select" data-theicon="comments-o"><i
                            class="fa fa-comments-o"></i></span><span class="icon-select" data-theicon="compass"><i
                            class="fa fa-compass"></i></span><span class="icon-select" data-theicon="copyright"><i
                            class="fa fa-copyright"></i></span><span class="icon-select" data-theicon="credit-card"><i
                            class="fa fa-credit-card"></i></span><span class="icon-select" data-theicon="crop"><i
                            class="fa fa-crop"></i></span><span class="icon-select" data-theicon="crosshairs"><i
                            class="fa fa-crosshairs"></i></span><span class="icon-select" data-theicon="cube"><i
                            class="fa fa-cube"></i></span><span class="icon-select" data-theicon="cubes"><i
                            class="fa fa-cubes"></i></span><span class="icon-select" data-theicon="cutlery"><i
                            class="fa fa-cutlery"></i></span><span class="icon-select" data-theicon="dashboard"><i
                            class="fa fa-dashboard"></i></span><span class="icon-select" data-theicon="database"><i
                            class="fa fa-database"></i></span><span class="icon-select" data-theicon="desktop"><i
                            class="fa fa-desktop"></i></span><span class="icon-select" data-theicon="dot-circle-o"><i
                            class="fa fa-dot-circle-o"></i></span><span class="icon-select" data-theicon="download"><i
                            class="fa fa-download"></i></span><span class="icon-select" data-theicon="edit"><i
                            class="fa fa-edit"></i></span><span class="icon-select" data-theicon="ellipsis-h"><i
                            class="fa fa-ellipsis-h"></i></span><span class="icon-select" data-theicon="ellipsis-v"><i
                            class="fa fa-ellipsis-v"></i></span><span class="icon-select" data-theicon="envelope"><i
                            class="fa fa-envelope"></i></span><span class="icon-select" data-theicon="envelope-o"><i
                            class="fa fa-envelope-o"></i></span><span class="icon-select"
                                                                      data-theicon="envelope-square"><i
                            class="fa fa-envelope-square"></i></span><span class="icon-select" data-theicon="eraser"><i
                            class="fa fa-eraser"></i></span><span class="icon-select" data-theicon="exchange"><i
                            class="fa fa-exchange"></i></span><span class="icon-select" data-theicon="exclamation"><i
                            class="fa fa-exclamation"></i></span><span class="icon-select"
                                                                       data-theicon="exclamation-circle"><i
                            class="fa fa-exclamation-circle"></i></span><span class="icon-select"
                                                                              data-theicon="exclamation-triangle"><i
                            class="fa fa-exclamation-triangle"></i></span><span class="icon-select"
                                                                                data-theicon="external-link"><i
                            class="fa fa-external-link"></i></span><span class="icon-select"
                                                                         data-theicon="external-link-square"><i
                            class="fa fa-external-link-square"></i></span><span class="icon-select"
                                                                                data-theicon="eye"><i
                            class="fa fa-eye"></i></span><span class="icon-select" data-theicon="eye-slash"><i
                            class="fa fa-eye-slash"></i></span><span class="icon-select" data-theicon="eyedropper"><i
                            class="fa fa-eyedropper"></i></span><span class="icon-select" data-theicon="fax"><i
                            class="fa fa-fax"></i></span><span class="icon-select" data-theicon="female"><i
                            class="fa fa-female"></i></span><span class="icon-select" data-theicon="fighter-jet"><i
                            class="fa fa-fighter-jet"></i></span><span class="icon-select"
                                                                       data-theicon="file-archive-o"><i
                            class="fa fa-file-archive-o"></i></span><span class="icon-select"
                                                                          data-theicon="file-audio-o"><i
                            class="fa fa-file-audio-o"></i></span><span class="icon-select"
                                                                        data-theicon="file-code-o"><i
                            class="fa fa-file-code-o"></i></span><span class="icon-select"
                                                                       data-theicon="file-excel-o"><i
                            class="fa fa-file-excel-o"></i></span><span class="icon-select" data-theicon="file-image-o"><i
                            class="fa fa-file-image-o"></i></span><span class="icon-select" data-theicon="file-movie-o"><i
                            class="fa fa-file-movie-o"></i></span><span class="icon-select" data-theicon="file-pdf-o"><i
                            class="fa fa-file-pdf-o"></i></span><span class="icon-select" data-theicon="file-photo-o"><i
                            class="fa fa-file-photo-o"></i></span><span class="icon-select"
                                                                        data-theicon="file-picture-o"><i
                            class="fa fa-file-picture-o"></i></span><span class="icon-select"
                                                                          data-theicon="file-powerpoint-o"><i
                            class="fa fa-file-powerpoint-o"></i></span><span class="icon-select"
                                                                             data-theicon="file-sound-o"><i
                            class="fa fa-file-sound-o"></i></span><span class="icon-select" data-theicon="file-video-o"><i
                            class="fa fa-file-video-o"></i></span><span class="icon-select"
                                                                        data-theicon="file-word-o"><i
                            class="fa fa-file-word-o"></i></span><span class="icon-select" data-theicon="file-zip-o"><i
                            class="fa fa-file-zip-o"></i></span><span class="icon-select" data-theicon="film"><i
                            class="fa fa-film"></i></span><span class="icon-select" data-theicon="filter"><i
                            class="fa fa-filter"></i></span><span class="icon-select" data-theicon="fire"><i
                            class="fa fa-fire"></i></span><span class="icon-select" data-theicon="fire-extinguisher"><i
                            class="fa fa-fire-extinguisher"></i></span><span class="icon-select" data-theicon="flag"><i
                            class="fa fa-flag"></i></span><span class="icon-select" data-theicon="flag-checkered"><i
                            class="fa fa-flag-checkered"></i></span><span class="icon-select" data-theicon="flag-o"><i
                            class="fa fa-flag-o"></i></span><span class="icon-select" data-theicon="flash"><i
                            class="fa fa-flash"></i></span><span class="icon-select" data-theicon="flask"><i
                            class="fa fa-flask"></i></span><span class="icon-select" data-theicon="folder"><i
                            class="fa fa-folder"></i></span><span class="icon-select" data-theicon="folder-o"><i
                            class="fa fa-folder-o"></i></span><span class="icon-select" data-theicon="folder-open"><i
                            class="fa fa-folder-open"></i></span><span class="icon-select" data-theicon="folder-open-o"><i
                            class="fa fa-folder-open-o"></i></span><span class="icon-select" data-theicon="frown-o"><i
                            class="fa fa-frown-o"></i></span><span class="icon-select" data-theicon="futbol-o"><i
                            class="fa fa-futbol-o"></i></span><span class="icon-select" data-theicon="gamepad"><i
                            class="fa fa-gamepad"></i></span><span class="icon-select" data-theicon="gavel"><i
                            class="fa fa-gavel"></i></span><span class="icon-select" data-theicon="gear"><i
                            class="fa fa-gear"></i></span><span class="icon-select" data-theicon="gears"><i
                            class="fa fa-gears"></i></span><span class="icon-select" data-theicon="gift"><i
                            class="fa fa-gift"></i></span><span class="icon-select" data-theicon="glass"><i
                            class="fa fa-glass"></i></span><span class="icon-select" data-theicon="globe"><i
                            class="fa fa-globe"></i></span><span class="icon-select" data-theicon="graduation-cap"><i
                            class="fa fa-graduation-cap"></i></span><span class="icon-select" data-theicon="group"><i
                            class="fa fa-group"></i></span><span class="icon-select" data-theicon="hdd-o"><i
                            class="fa fa-hdd-o"></i></span><span class="icon-select" data-theicon="headphones"><i
                            class="fa fa-headphones"></i></span><span class="icon-select" data-theicon="heart"><i
                            class="fa fa-heart"></i></span><span class="icon-select" data-theicon="heart-o"><i
                            class="fa fa-heart-o"></i></span><span class="icon-select" data-theicon="history"><i
                            class="fa fa-history"></i></span><span class="icon-select" data-theicon="home"><i
                            class="fa fa-home"></i></span><span class="icon-select" data-theicon="image"><i
                            class="fa fa-image"></i></span><span class="icon-select" data-theicon="inbox"><i
                            class="fa fa-inbox"></i></span><span class="icon-select" data-theicon="info"><i
                            class="fa fa-info"></i></span><span class="icon-select" data-theicon="info-circle"><i
                            class="fa fa-info-circle"></i></span><span class="icon-select" data-theicon="institution"><i
                            class="fa fa-institution"></i></span><span class="icon-select" data-theicon="key"><i
                            class="fa fa-key"></i></span><span class="icon-select" data-theicon="keyboard-o"><i
                            class="fa fa-keyboard-o"></i></span><span class="icon-select" data-theicon="language"><i
                            class="fa fa-language"></i></span><span class="icon-select" data-theicon="laptop"><i
                            class="fa fa-laptop"></i></span><span class="icon-select" data-theicon="leaf"><i
                            class="fa fa-leaf"></i></span><span class="icon-select" data-theicon="legal"><i
                            class="fa fa-legal"></i></span><span class="icon-select" data-theicon="lemon-o"><i
                            class="fa fa-lemon-o"></i></span><span class="icon-select" data-theicon="level-down"><i
                            class="fa fa-level-down"></i></span><span class="icon-select" data-theicon="level-up"><i
                            class="fa fa-level-up"></i></span><span class="icon-select" data-theicon="life-bouy"><i
                            class="fa fa-life-bouy"></i></span><span class="icon-select" data-theicon="life-buoy"><i
                            class="fa fa-life-buoy"></i></span><span class="icon-select" data-theicon="life-ring"><i
                            class="fa fa-life-ring"></i></span><span class="icon-select" data-theicon="life-saver"><i
                            class="fa fa-life-saver"></i></span><span class="icon-select" data-theicon="lightbulb-o"><i
                            class="fa fa-lightbulb-o"></i></span><span class="icon-select" data-theicon="line-chart"><i
                            class="fa fa-line-chart"></i></span><span class="icon-select" data-theicon="location-arrow"><i
                            class="fa fa-location-arrow"></i></span><span class="icon-select" data-theicon="lock"><i
                            class="fa fa-lock"></i></span><span class="icon-select" data-theicon="magic"><i
                            class="fa fa-magic"></i></span><span class="icon-select" data-theicon="magnet"><i
                            class="fa fa-magnet"></i></span><span class="icon-select" data-theicon="mail-forward"><i
                            class="fa fa-mail-forward"></i></span><span class="icon-select" data-theicon="mail-reply"><i
                            class="fa fa-mail-reply"></i></span><span class="icon-select" data-theicon="mail-reply-all"><i
                            class="fa fa-mail-reply-all"></i></span><span class="icon-select" data-theicon="male"><i
                            class="fa fa-male"></i></span><span class="icon-select" data-theicon="map-marker"><i
                            class="fa fa-map-marker"></i></span><span class="icon-select" data-theicon="meh-o"><i
                            class="fa fa-meh-o"></i></span><span class="icon-select" data-theicon="microphone"><i
                            class="fa fa-microphone"></i></span><span class="icon-select"
                                                                      data-theicon="microphone-slash"><i
                            class="fa fa-microphone-slash"></i></span><span class="icon-select" data-theicon="minus"><i
                            class="fa fa-minus"></i></span><span class="icon-select" data-theicon="minus-circle"><i
                            class="fa fa-minus-circle"></i></span><span class="icon-select" data-theicon="minus-square"><i
                            class="fa fa-minus-square"></i></span><span class="icon-select"
                                                                        data-theicon="minus-square-o"><i
                            class="fa fa-minus-square-o"></i></span><span class="icon-select" data-theicon="mobile"><i
                            class="fa fa-mobile"></i></span><span class="icon-select" data-theicon="mobile-phone"><i
                            class="fa fa-mobile-phone"></i></span><span class="icon-select" data-theicon="money"><i
                            class="fa fa-money"></i></span><span class="icon-select" data-theicon="moon-o"><i
                            class="fa fa-moon-o"></i></span><span class="icon-select" data-theicon="mortar-board"><i
                            class="fa fa-mortar-board"></i></span><span class="icon-select" data-theicon="music"><i
                            class="fa fa-music"></i></span><span class="icon-select" data-theicon="navicon"><i
                            class="fa fa-navicon"></i></span><span class="icon-select" data-theicon="newspaper-o"><i
                            class="fa fa-newspaper-o"></i></span><span class="icon-select" data-theicon="paint-brush"><i
                            class="fa fa-paint-brush"></i></span><span class="icon-select" data-theicon="paper-plane"><i
                            class="fa fa-paper-plane"></i></span><span class="icon-select" data-theicon="paper-plane-o"><i
                            class="fa fa-paper-plane-o"></i></span><span class="icon-select" data-theicon="paw"><i
                            class="fa fa-paw"></i></span><span class="icon-select" data-theicon="pencil"><i
                            class="fa fa-pencil"></i></span><span class="icon-select" data-theicon="pencil-square"><i
                            class="fa fa-pencil-square"></i></span><span class="icon-select"
                                                                         data-theicon="pencil-square-o"><i
                            class="fa fa-pencil-square-o"></i></span><span class="icon-select" data-theicon="phone"><i
                            class="fa fa-phone"></i></span><span class="icon-select" data-theicon="phone-square"><i
                            class="fa fa-phone-square"></i></span><span class="icon-select" data-theicon="photo"><i
                            class="fa fa-photo"></i></span><span class="icon-select" data-theicon="picture-o"><i
                            class="fa fa-picture-o"></i></span><span class="icon-select" data-theicon="pie-chart"><i
                            class="fa fa-pie-chart"></i></span><span class="icon-select" data-theicon="plane"><i
                            class="fa fa-plane"></i></span><span class="icon-select" data-theicon="plug"><i
                            class="fa fa-plug"></i></span><span class="icon-select" data-theicon="plus"><i
                            class="fa fa-plus"></i></span><span class="icon-select" data-theicon="plus-circle"><i
                            class="fa fa-plus-circle"></i></span><span class="icon-select" data-theicon="plus-square"><i
                            class="fa fa-plus-square"></i></span><span class="icon-select" data-theicon="plus-square-o"><i
                            class="fa fa-plus-square-o"></i></span><span class="icon-select" data-theicon="power-off"><i
                            class="fa fa-power-off"></i></span><span class="icon-select" data-theicon="print"><i
                            class="fa fa-print"></i></span><span class="icon-select" data-theicon="puzzle-piece"><i
                            class="fa fa-puzzle-piece"></i></span><span class="icon-select" data-theicon="qrcode"><i
                            class="fa fa-qrcode"></i></span><span class="icon-select" data-theicon="question"><i
                            class="fa fa-question"></i></span><span class="icon-select"
                                                                    data-theicon="question-circle"><i
                            class="fa fa-question-circle"></i></span><span class="icon-select"
                                                                           data-theicon="quote-left"><i
                            class="fa fa-quote-left"></i></span><span class="icon-select" data-theicon="quote-right"><i
                            class="fa fa-quote-right"></i></span><span class="icon-select" data-theicon="random"><i
                            class="fa fa-random"></i></span><span class="icon-select" data-theicon="recycle"><i
                            class="fa fa-recycle"></i></span><span class="icon-select" data-theicon="refresh"><i
                            class="fa fa-refresh"></i></span><span class="icon-select" data-theicon="remove"><i
                            class="fa fa-remove"></i></span><span class="icon-select" data-theicon="reorder"><i
                            class="fa fa-reorder"></i></span><span class="icon-select" data-theicon="reply"><i
                            class="fa fa-reply"></i></span><span class="icon-select" data-theicon="reply-all"><i
                            class="fa fa-reply-all"></i></span><span class="icon-select" data-theicon="retweet"><i
                            class="fa fa-retweet"></i></span><span class="icon-select" data-theicon="road"><i
                            class="fa fa-road"></i></span><span class="icon-select" data-theicon="rocket"><i
                            class="fa fa-rocket"></i></span><span class="icon-select" data-theicon="rss"><i
                            class="fa fa-rss"></i></span><span class="icon-select" data-theicon="rss-square"><i
                            class="fa fa-rss-square"></i></span><span class="icon-select" data-theicon="search"><i
                            class="fa fa-search"></i></span><span class="icon-select" data-theicon="search-minus"><i
                            class="fa fa-search-minus"></i></span><span class="icon-select"
                                                                        data-theicon="search-plus"><i
                            class="fa fa-search-plus"></i></span><span class="icon-select" data-theicon="send"><i
                            class="fa fa-send"></i></span><span class="icon-select" data-theicon="send-o"><i
                            class="fa fa-send-o"></i></span><span class="icon-select" data-theicon="share"><i
                            class="fa fa-share"></i></span><span class="icon-select" data-theicon="share-alt"><i
                            class="fa fa-share-alt"></i></span><span class="icon-select"
                                                                     data-theicon="share-alt-square"><i
                            class="fa fa-share-alt-square"></i></span><span class="icon-select"
                                                                            data-theicon="share-square"><i
                            class="fa fa-share-square"></i></span><span class="icon-select"
                                                                        data-theicon="share-square-o"><i
                            class="fa fa-share-square-o"></i></span><span class="icon-select" data-theicon="shield"><i
                            class="fa fa-shield"></i></span><span class="icon-select" data-theicon="shopping-cart"><i
                            class="fa fa-shopping-cart"></i></span><span class="icon-select" data-theicon="sign-in"><i
                            class="fa fa-sign-in"></i></span><span class="icon-select" data-theicon="sign-out"><i
                            class="fa fa-sign-out"></i></span><span class="icon-select" data-theicon="signal"><i
                            class="fa fa-signal"></i></span><span class="icon-select" data-theicon="sitemap"><i
                            class="fa fa-sitemap"></i></span><span class="icon-select" data-theicon="sliders"><i
                            class="fa fa-sliders"></i></span><span class="icon-select" data-theicon="smile-o"><i
                            class="fa fa-smile-o"></i></span><span class="icon-select" data-theicon="soccer-ball-o"><i
                            class="fa fa-soccer-ball-o"></i></span><span class="icon-select" data-theicon="sort"><i
                            class="fa fa-sort"></i></span><span class="icon-select" data-theicon="sort-alpha-asc"><i
                            class="fa fa-sort-alpha-asc"></i></span><span class="icon-select"
                                                                          data-theicon="sort-alpha-desc"><i
                            class="fa fa-sort-alpha-desc"></i></span><span class="icon-select"
                                                                           data-theicon="sort-amount-asc"><i
                            class="fa fa-sort-amount-asc"></i></span><span class="icon-select"
                                                                           data-theicon="sort-amount-desc"><i
                            class="fa fa-sort-amount-desc"></i></span><span class="icon-select" data-theicon="sort-asc"><i
                            class="fa fa-sort-asc"></i></span><span class="icon-select" data-theicon="sort-desc"><i
                            class="fa fa-sort-desc"></i></span><span class="icon-select" data-theicon="sort-down"><i
                            class="fa fa-sort-down"></i></span><span class="icon-select"
                                                                     data-theicon="sort-numeric-asc"><i
                            class="fa fa-sort-numeric-asc"></i></span><span class="icon-select"
                                                                            data-theicon="sort-numeric-desc"><i
                            class="fa fa-sort-numeric-desc"></i></span><span class="icon-select" data-theicon="sort-up"><i
                            class="fa fa-sort-up"></i></span><span class="icon-select" data-theicon="space-shuttle"><i
                            class="fa fa-space-shuttle"></i></span><span class="icon-select" data-theicon="spinner"><i
                            class="fa fa-spinner"></i></span><span class="icon-select" data-theicon="spoon"><i
                            class="fa fa-spoon"></i></span><span class="icon-select" data-theicon="square"><i
                            class="fa fa-square"></i></span><span class="icon-select" data-theicon="square-o"><i
                            class="fa fa-square-o"></i></span><span class="icon-select" data-theicon="star"><i
                            class="fa fa-star"></i></span><span class="icon-select" data-theicon="star-half"><i
                            class="fa fa-star-half"></i></span><span class="icon-select" data-theicon="star-half-empty"><i
                            class="fa fa-star-half-empty"></i></span><span class="icon-select"
                                                                           data-theicon="star-half-full"><i
                            class="fa fa-star-half-full"></i></span><span class="icon-select"
                                                                          data-theicon="star-half-o"><i
                            class="fa fa-star-half-o"></i></span><span class="icon-select" data-theicon="star-o"><i
                            class="fa fa-star-o"></i></span><span class="icon-select" data-theicon="suitcase"><i
                            class="fa fa-suitcase"></i></span><span class="icon-select" data-theicon="sun-o"><i
                            class="fa fa-sun-o"></i></span><span class="icon-select" data-theicon="support"><i
                            class="fa fa-support"></i></span><span class="icon-select" data-theicon="tablet"><i
                            class="fa fa-tablet"></i></span><span class="icon-select" data-theicon="tachometer"><i
                            class="fa fa-tachometer"></i></span><span class="icon-select" data-theicon="tag"><i
                            class="fa fa-tag"></i></span><span class="icon-select" data-theicon="tags"><i
                            class="fa fa-tags"></i></span><span class="icon-select" data-theicon="tasks"><i
                            class="fa fa-tasks"></i></span><span class="icon-select" data-theicon="taxi"><i
                            class="fa fa-taxi"></i></span><span class="icon-select" data-theicon="terminal"><i
                            class="fa fa-terminal"></i></span><span class="icon-select" data-theicon="thumb-tack"><i
                            class="fa fa-thumb-tack"></i></span><span class="icon-select" data-theicon="thumbs-down"><i
                            class="fa fa-thumbs-down"></i></span><span class="icon-select" data-theicon="thumbs-o-down"><i
                            class="fa fa-thumbs-o-down"></i></span><span class="icon-select" data-theicon="thumbs-o-up"><i
                            class="fa fa-thumbs-o-up"></i></span><span class="icon-select" data-theicon="thumbs-up"><i
                            class="fa fa-thumbs-up"></i></span><span class="icon-select" data-theicon="ticket"><i
                            class="fa fa-ticket"></i></span><span class="icon-select" data-theicon="times"><i
                            class="fa fa-times"></i></span><span class="icon-select" data-theicon="times-circle"><i
                            class="fa fa-times-circle"></i></span><span class="icon-select"
                                                                        data-theicon="times-circle-o"><i
                            class="fa fa-times-circle-o"></i></span><span class="icon-select" data-theicon="tint"><i
                            class="fa fa-tint"></i></span><span class="icon-select" data-theicon="toggle-down"><i
                            class="fa fa-toggle-down"></i></span><span class="icon-select" data-theicon="toggle-left"><i
                            class="fa fa-toggle-left"></i></span><span class="icon-select" data-theicon="toggle-off"><i
                            class="fa fa-toggle-off"></i></span><span class="icon-select" data-theicon="toggle-on"><i
                            class="fa fa-toggle-on"></i></span><span class="icon-select" data-theicon="toggle-right"><i
                            class="fa fa-toggle-right"></i></span><span class="icon-select" data-theicon="toggle-up"><i
                            class="fa fa-toggle-up"></i></span><span class="icon-select" data-theicon="trash"><i
                            class="fa fa-trash"></i></span><span class="icon-select" data-theicon="trash-o"><i
                            class="fa fa-trash-o"></i></span><span class="icon-select" data-theicon="tree"><i
                            class="fa fa-tree"></i></span><span class="icon-select" data-theicon="trophy"><i
                            class="fa fa-trophy"></i></span><span class="icon-select" data-theicon="truck"><i
                            class="fa fa-truck"></i></span><span class="icon-select" data-theicon="tty"><i
                            class="fa fa-tty"></i></span><span class="icon-select" data-theicon="umbrella"><i
                            class="fa fa-umbrella"></i></span><span class="icon-select" data-theicon="university"><i
                            class="fa fa-university"></i></span><span class="icon-select" data-theicon="unlock"><i
                            class="fa fa-unlock"></i></span><span class="icon-select" data-theicon="unlock-alt"><i
                            class="fa fa-unlock-alt"></i></span><span class="icon-select" data-theicon="unsorted"><i
                            class="fa fa-unsorted"></i></span><span class="icon-select" data-theicon="upload"><i
                            class="fa fa-upload"></i></span><span class="icon-select" data-theicon="user"><i
                            class="fa fa-user"></i></span><span class="icon-select" data-theicon="users"><i
                            class="fa fa-users"></i></span><span class="icon-select" data-theicon="video-camera"><i
                            class="fa fa-video-camera"></i></span><span class="icon-select"
                                                                        data-theicon="volume-down"><i
                            class="fa fa-volume-down"></i></span><span class="icon-select" data-theicon="volume-off"><i
                            class="fa fa-volume-off"></i></span><span class="icon-select" data-theicon="volume-up"><i
                            class="fa fa-volume-up"></i></span><span class="icon-select" data-theicon="warning"><i
                            class="fa fa-warning"></i></span><span class="icon-select" data-theicon="wheelchair"><i
                            class="fa fa-wheelchair"></i></span><span class="icon-select" data-theicon="wifi"><i
                            class="fa fa-wifi"></i></span><span class="icon-select" data-theicon="wrench"><i
                            class="fa fa-wrench"></i></span><span class="icon-select" data-theicon="file"><i
                            class="fa fa-file"></i></span><span class="icon-select" data-theicon="file-archive-o"><i
                            class="fa fa-file-archive-o"></i></span><span class="icon-select"
                                                                          data-theicon="file-audio-o"><i
                            class="fa fa-file-audio-o"></i></span><span class="icon-select"
                                                                        data-theicon="file-code-o"><i
                            class="fa fa-file-code-o"></i></span><span class="icon-select"
                                                                       data-theicon="file-excel-o"><i
                            class="fa fa-file-excel-o"></i></span><span class="icon-select" data-theicon="file-image-o"><i
                            class="fa fa-file-image-o"></i></span><span class="icon-select" data-theicon="file-movie-o"><i
                            class="fa fa-file-movie-o"></i></span><span class="icon-select" data-theicon="file-o"><i
                            class="fa fa-file-o"></i></span><span class="icon-select" data-theicon="file-pdf-o"><i
                            class="fa fa-file-pdf-o"></i></span><span class="icon-select" data-theicon="file-photo-o"><i
                            class="fa fa-file-photo-o"></i></span><span class="icon-select"
                                                                        data-theicon="file-picture-o"><i
                            class="fa fa-file-picture-o"></i></span><span class="icon-select"
                                                                          data-theicon="file-powerpoint-o"><i
                            class="fa fa-file-powerpoint-o"></i></span><span class="icon-select"
                                                                             data-theicon="file-sound-o"><i
                            class="fa fa-file-sound-o"></i></span><span class="icon-select" data-theicon="file-text"><i
                            class="fa fa-file-text"></i></span><span class="icon-select" data-theicon="file-text-o"><i
                            class="fa fa-file-text-o"></i></span><span class="icon-select"
                                                                       data-theicon="file-video-o"><i
                            class="fa fa-file-video-o"></i></span><span class="icon-select"
                                                                        data-theicon="file-word-o"><i
                            class="fa fa-file-word-o"></i></span><span class="icon-select" data-theicon="file-zip-o"><i
                            class="fa fa-file-zip-o"></i></span><span class="icon-select" data-theicon="info-circle"><i
                            class="fa fa-info-circle"></i></span><span class="icon-select"
                                                                       data-theicon="circle-o-notch"><i
                            class="fa fa-circle-o-notch"></i></span><span class="icon-select" data-theicon="cog"><i
                            class="fa fa-cog"></i></span><span class="icon-select" data-theicon="gear"><i
                            class="fa fa-gear"></i></span><span class="icon-select" data-theicon="refresh"><i
                            class="fa fa-refresh"></i></span><span class="icon-select" data-theicon="spinner"><i
                            class="fa fa-spinner"></i></span><span class="icon-select" data-theicon="check-square"><i
                            class="fa fa-check-square"></i></span><span class="icon-select"
                                                                        data-theicon="check-square-o"><i
                            class="fa fa-check-square-o"></i></span><span class="icon-select" data-theicon="circle"><i
                            class="fa fa-circle"></i></span><span class="icon-select" data-theicon="circle-o"><i
                            class="fa fa-circle-o"></i></span><span class="icon-select" data-theicon="dot-circle-o"><i
                            class="fa fa-dot-circle-o"></i></span><span class="icon-select" data-theicon="minus-square"><i
                            class="fa fa-minus-square"></i></span><span class="icon-select"
                                                                        data-theicon="minus-square-o"><i
                            class="fa fa-minus-square-o"></i></span><span class="icon-select"
                                                                          data-theicon="plus-square"><i
                            class="fa fa-plus-square"></i></span><span class="icon-select" data-theicon="plus-square-o"><i
                            class="fa fa-plus-square-o"></i></span><span class="icon-select" data-theicon="square"><i
                            class="fa fa-square"></i></span><span class="icon-select" data-theicon="square-o"><i
                            class="fa fa-square-o"></i></span><span class="icon-select" data-theicon="cc-amex"><i
                            class="fa fa-cc-amex"></i></span><span class="icon-select" data-theicon="cc-discover"><i
                            class="fa fa-cc-discover"></i></span><span class="icon-select" data-theicon="cc-mastercard"><i
                            class="fa fa-cc-mastercard"></i></span><span class="icon-select" data-theicon="cc-paypal"><i
                            class="fa fa-cc-paypal"></i></span><span class="icon-select" data-theicon="cc-stripe"><i
                            class="fa fa-cc-stripe"></i></span><span class="icon-select" data-theicon="cc-visa"><i
                            class="fa fa-cc-visa"></i></span><span class="icon-select" data-theicon="credit-card"><i
                            class="fa fa-credit-card"></i></span><span class="icon-select" data-theicon="google-wallet"><i
                            class="fa fa-google-wallet"></i></span><span class="icon-select" data-theicon="paypal"><i
                            class="fa fa-paypal"></i></span><span class="icon-select" data-theicon="area-chart"><i
                            class="fa fa-area-chart"></i></span><span class="icon-select" data-theicon="bar-chart"><i
                            class="fa fa-bar-chart"></i></span><span class="icon-select" data-theicon="bar-chart-o"><i
                            class="fa fa-bar-chart-o"></i></span><span class="icon-select" data-theicon="line-chart"><i
                            class="fa fa-line-chart"></i></span><span class="icon-select" data-theicon="pie-chart"><i
                            class="fa fa-pie-chart"></i></span><span class="icon-select" data-theicon="bitcoin"><i
                            class="fa fa-bitcoin"></i></span><span class="icon-select" data-theicon="btc"><i
                            class="fa fa-btc"></i></span><span class="icon-select" data-theicon="cny"><i
                            class="fa fa-cny"></i></span><span class="icon-select" data-theicon="dollar"><i
                            class="fa fa-dollar"></i></span><span class="icon-select" data-theicon="eur"><i
                            class="fa fa-eur"></i></span><span class="icon-select" data-theicon="euro"><i
                            class="fa fa-euro"></i></span><span class="icon-select" data-theicon="gbp"><i
                            class="fa fa-gbp"></i></span><span class="icon-select" data-theicon="ils"><i
                            class="fa fa-ils"></i></span><span class="icon-select" data-theicon="inr"><i
                            class="fa fa-inr"></i></span><span class="icon-select" data-theicon="jpy"><i
                            class="fa fa-jpy"></i></span><span class="icon-select" data-theicon="krw"><i
                            class="fa fa-krw"></i></span><span class="icon-select" data-theicon="money"><i
                            class="fa fa-money"></i></span><span class="icon-select" data-theicon="rmb"><i
                            class="fa fa-rmb"></i></span><span class="icon-select" data-theicon="rouble"><i
                            class="fa fa-rouble"></i></span><span class="icon-select" data-theicon="rub"><i
                            class="fa fa-rub"></i></span><span class="icon-select" data-theicon="ruble"><i
                            class="fa fa-ruble"></i></span><span class="icon-select" data-theicon="rupee"><i
                            class="fa fa-rupee"></i></span><span class="icon-select" data-theicon="shekel"><i
                            class="fa fa-shekel"></i></span><span class="icon-select" data-theicon="sheqel"><i
                            class="fa fa-sheqel"></i></span><span class="icon-select" data-theicon="try"><i
                            class="fa fa-try"></i></span><span class="icon-select" data-theicon="turkish-lira"><i
                            class="fa fa-turkish-lira"></i></span><span class="icon-select" data-theicon="usd"><i
                            class="fa fa-usd"></i></span><span class="icon-select" data-theicon="won"><i
                            class="fa fa-won"></i></span><span class="icon-select" data-theicon="yen"><i
                            class="fa fa-yen"></i></span><span class="icon-select" data-theicon="align-center"><i
                            class="fa fa-align-center"></i></span><span class="icon-select"
                                                                        data-theicon="align-justify"><i
                            class="fa fa-align-justify"></i></span><span class="icon-select"
                                                                         data-theicon="align-left"><i
                            class="fa fa-align-left"></i></span><span class="icon-select" data-theicon="align-right"><i
                            class="fa fa-align-right"></i></span><span class="icon-select" data-theicon="bold"><i
                            class="fa fa-bold"></i></span><span class="icon-select" data-theicon="chain"><i
                            class="fa fa-chain"></i></span><span class="icon-select" data-theicon="chain-broken"><i
                            class="fa fa-chain-broken"></i></span><span class="icon-select" data-theicon="clipboard"><i
                            class="fa fa-clipboard"></i></span><span class="icon-select" data-theicon="columns"><i
                            class="fa fa-columns"></i></span><span class="icon-select" data-theicon="copy"><i
                            class="fa fa-copy"></i></span><span class="icon-select" data-theicon="cut"><i
                            class="fa fa-cut"></i></span><span class="icon-select" data-theicon="dedent"><i
                            class="fa fa-dedent"></i></span><span class="icon-select" data-theicon="eraser"><i
                            class="fa fa-eraser"></i></span><span class="icon-select" data-theicon="file"><i
                            class="fa fa-file"></i></span><span class="icon-select" data-theicon="file-o"><i
                            class="fa fa-file-o"></i></span><span class="icon-select" data-theicon="file-text"><i
                            class="fa fa-file-text"></i></span><span class="icon-select" data-theicon="file-text-o"><i
                            class="fa fa-file-text-o"></i></span><span class="icon-select" data-theicon="files-o"><i
                            class="fa fa-files-o"></i></span><span class="icon-select" data-theicon="floppy-o"><i
                            class="fa fa-floppy-o"></i></span><span class="icon-select" data-theicon="font"><i
                            class="fa fa-font"></i></span><span class="icon-select" data-theicon="header"><i
                            class="fa fa-header"></i></span><span class="icon-select" data-theicon="indent"><i
                            class="fa fa-indent"></i></span><span class="icon-select" data-theicon="italic"><i
                            class="fa fa-italic"></i></span><span class="icon-select" data-theicon="link"><i
                            class="fa fa-link"></i></span><span class="icon-select" data-theicon="list"><i
                            class="fa fa-list"></i></span><span class="icon-select" data-theicon="list-alt"><i
                            class="fa fa-list-alt"></i></span><span class="icon-select" data-theicon="list-ol"><i
                            class="fa fa-list-ol"></i></span><span class="icon-select" data-theicon="list-ul"><i
                            class="fa fa-list-ul"></i></span><span class="icon-select" data-theicon="outdent"><i
                            class="fa fa-outdent"></i></span><span class="icon-select" data-theicon="paperclip"><i
                            class="fa fa-paperclip"></i></span><span class="icon-select" data-theicon="paragraph"><i
                            class="fa fa-paragraph"></i></span><span class="icon-select" data-theicon="paste"><i
                            class="fa fa-paste"></i></span><span class="icon-select" data-theicon="repeat"><i
                            class="fa fa-repeat"></i></span><span class="icon-select" data-theicon="rotate-left"><i
                            class="fa fa-rotate-left"></i></span><span class="icon-select"
                                                                       data-theicon="rotate-right"><i
                            class="fa fa-rotate-right"></i></span><span class="icon-select" data-theicon="save"><i
                            class="fa fa-save"></i></span><span class="icon-select" data-theicon="scissors"><i
                            class="fa fa-scissors"></i></span><span class="icon-select" data-theicon="strikethrough"><i
                            class="fa fa-strikethrough"></i></span><span class="icon-select" data-theicon="subscript"><i
                            class="fa fa-subscript"></i></span><span class="icon-select" data-theicon="superscript"><i
                            class="fa fa-superscript"></i></span><span class="icon-select" data-theicon="table"><i
                            class="fa fa-table"></i></span><span class="icon-select" data-theicon="text-height"><i
                            class="fa fa-text-height"></i></span><span class="icon-select" data-theicon="text-width"><i
                            class="fa fa-text-width"></i></span><span class="icon-select" data-theicon="th"><i
                            class="fa fa-th"></i></span><span class="icon-select" data-theicon="th-large"><i
                            class="fa fa-th-large"></i></span><span class="icon-select" data-theicon="th-list"><i
                            class="fa fa-th-list"></i></span><span class="icon-select" data-theicon="underline"><i
                            class="fa fa-underline"></i></span><span class="icon-select" data-theicon="undo"><i
                            class="fa fa-undo"></i></span><span class="icon-select" data-theicon="unlink"><i
                            class="fa fa-unlink"></i></span><span class="icon-select"
                                                                  data-theicon="angle-double-down"><i
                            class="fa fa-angle-double-down"></i></span><span class="icon-select"
                                                                             data-theicon="angle-double-left"><i
                            class="fa fa-angle-double-left"></i></span><span class="icon-select"
                                                                             data-theicon="angle-double-right"><i
                            class="fa fa-angle-double-right"></i></span><span class="icon-select"
                                                                              data-theicon="angle-double-up"><i
                            class="fa fa-angle-double-up"></i></span><span class="icon-select"
                                                                           data-theicon="angle-down"><i
                            class="fa fa-angle-down"></i></span><span class="icon-select" data-theicon="angle-left"><i
                            class="fa fa-angle-left"></i></span><span class="icon-select" data-theicon="angle-right"><i
                            class="fa fa-angle-right"></i></span><span class="icon-select" data-theicon="angle-up"><i
                            class="fa fa-angle-up"></i></span><span class="icon-select"
                                                                    data-theicon="arrow-circle-down"><i
                            class="fa fa-arrow-circle-down"></i></span><span class="icon-select"
                                                                             data-theicon="arrow-circle-left"><i
                            class="fa fa-arrow-circle-left"></i></span><span class="icon-select"
                                                                             data-theicon="arrow-circle-o-down"><i
                            class="fa fa-arrow-circle-o-down"></i></span><span class="icon-select"
                                                                               data-theicon="arrow-circle-o-left"><i
                            class="fa fa-arrow-circle-o-left"></i></span><span class="icon-select"
                                                                               data-theicon="arrow-circle-o-right"><i
                            class="fa fa-arrow-circle-o-right"></i></span><span class="icon-select"
                                                                                data-theicon="arrow-circle-o-up"><i
                            class="fa fa-arrow-circle-o-up"></i></span><span class="icon-select"
                                                                             data-theicon="arrow-circle-right"><i
                            class="fa fa-arrow-circle-right"></i></span><span class="icon-select"
                                                                              data-theicon="arrow-circle-up"><i
                            class="fa fa-arrow-circle-up"></i></span><span class="icon-select"
                                                                           data-theicon="arrow-down"><i
                            class="fa fa-arrow-down"></i></span><span class="icon-select" data-theicon="arrow-left"><i
                            class="fa fa-arrow-left"></i></span><span class="icon-select" data-theicon="arrow-right"><i
                            class="fa fa-arrow-right"></i></span><span class="icon-select" data-theicon="arrow-up"><i
                            class="fa fa-arrow-up"></i></span><span class="icon-select" data-theicon="arrows"><i
                            class="fa fa-arrows"></i></span><span class="icon-select" data-theicon="arrows-alt"><i
                            class="fa fa-arrows-alt"></i></span><span class="icon-select" data-theicon="arrows-h"><i
                            class="fa fa-arrows-h"></i></span><span class="icon-select" data-theicon="arrows-v"><i
                            class="fa fa-arrows-v"></i></span><span class="icon-select" data-theicon="caret-down"><i
                            class="fa fa-caret-down"></i></span><span class="icon-select" data-theicon="caret-left"><i
                            class="fa fa-caret-left"></i></span><span class="icon-select" data-theicon="caret-right"><i
                            class="fa fa-caret-right"></i></span><span class="icon-select"
                                                                       data-theicon="caret-square-o-down"><i
                            class="fa fa-caret-square-o-down"></i></span><span class="icon-select"
                                                                               data-theicon="caret-square-o-left"><i
                            class="fa fa-caret-square-o-left"></i></span><span class="icon-select"
                                                                               data-theicon="caret-square-o-right"><i
                            class="fa fa-caret-square-o-right"></i></span><span class="icon-select"
                                                                                data-theicon="caret-square-o-up"><i
                            class="fa fa-caret-square-o-up"></i></span><span class="icon-select"
                                                                             data-theicon="caret-up"><i
                            class="fa fa-caret-up"></i></span><span class="icon-select"
                                                                    data-theicon="chevron-circle-down"><i
                            class="fa fa-chevron-circle-down"></i></span><span class="icon-select"
                                                                               data-theicon="chevron-circle-left"><i
                            class="fa fa-chevron-circle-left"></i></span><span class="icon-select"
                                                                               data-theicon="chevron-circle-right"><i
                            class="fa fa-chevron-circle-right"></i></span><span class="icon-select"
                                                                                data-theicon="chevron-circle-up"><i
                            class="fa fa-chevron-circle-up"></i></span><span class="icon-select"
                                                                             data-theicon="chevron-down"><i
                            class="fa fa-chevron-down"></i></span><span class="icon-select" data-theicon="chevron-left"><i
                            class="fa fa-chevron-left"></i></span><span class="icon-select"
                                                                        data-theicon="chevron-right"><i
                            class="fa fa-chevron-right"></i></span><span class="icon-select"
                                                                         data-theicon="chevron-up"><i
                            class="fa fa-chevron-up"></i></span><span class="icon-select" data-theicon="hand-o-down"><i
                            class="fa fa-hand-o-down"></i></span><span class="icon-select" data-theicon="hand-o-left"><i
                            class="fa fa-hand-o-left"></i></span><span class="icon-select"
                                                                       data-theicon="hand-o-right"><i
                            class="fa fa-hand-o-right"></i></span><span class="icon-select" data-theicon="hand-o-up"><i
                            class="fa fa-hand-o-up"></i></span><span class="icon-select" data-theicon="long-arrow-down"><i
                            class="fa fa-long-arrow-down"></i></span><span class="icon-select"
                                                                           data-theicon="long-arrow-left"><i
                            class="fa fa-long-arrow-left"></i></span><span class="icon-select"
                                                                           data-theicon="long-arrow-right"><i
                            class="fa fa-long-arrow-right"></i></span><span class="icon-select"
                                                                            data-theicon="long-arrow-up"><i
                            class="fa fa-long-arrow-up"></i></span><span class="icon-select" data-theicon="toggle-down"><i
                            class="fa fa-toggle-down"></i></span><span class="icon-select" data-theicon="toggle-left"><i
                            class="fa fa-toggle-left"></i></span><span class="icon-select"
                                                                       data-theicon="toggle-right"><i
                            class="fa fa-toggle-right"></i></span><span class="icon-select" data-theicon="toggle-up"><i
                            class="fa fa-toggle-up"></i></span><span class="icon-select" data-theicon="arrows-alt"><i
                            class="fa fa-arrows-alt"></i></span><span class="icon-select" data-theicon="backward"><i
                            class="fa fa-backward"></i></span><span class="icon-select" data-theicon="compress"><i
                            class="fa fa-compress"></i></span><span class="icon-select" data-theicon="eject"><i
                            class="fa fa-eject"></i></span><span class="icon-select" data-theicon="expand"><i
                            class="fa fa-expand"></i></span><span class="icon-select" data-theicon="fast-backward"><i
                            class="fa fa-fast-backward"></i></span><span class="icon-select"
                                                                         data-theicon="fast-forward"><i
                            class="fa fa-fast-forward"></i></span><span class="icon-select" data-theicon="forward"><i
                            class="fa fa-forward"></i></span><span class="icon-select" data-theicon="pause"><i
                            class="fa fa-pause"></i></span><span class="icon-select" data-theicon="play"><i
                            class="fa fa-play"></i></span><span class="icon-select" data-theicon="play-circle"><i
                            class="fa fa-play-circle"></i></span><span class="icon-select" data-theicon="play-circle-o"><i
                            class="fa fa-play-circle-o"></i></span><span class="icon-select"
                                                                         data-theicon="step-backward"><i
                            class="fa fa-step-backward"></i></span><span class="icon-select"
                                                                         data-theicon="step-forward"><i
                            class="fa fa-step-forward"></i></span><span class="icon-select" data-theicon="stop"><i
                            class="fa fa-stop"></i></span><span class="icon-select" data-theicon="youtube-play"><i
                            class="fa fa-youtube-play"></i></span><span class="icon-select" data-theicon="warning"><i
                            class="fa fa-warning"></i></span><span class="icon-select" data-theicon="adn"><i
                            class="fa fa-adn"></i></span><span class="icon-select" data-theicon="android"><i
                            class="fa fa-android"></i></span><span class="icon-select" data-theicon="angellist"><i
                            class="fa fa-angellist"></i></span><span class="icon-select" data-theicon="apple"><i
                            class="fa fa-apple"></i></span><span class="icon-select" data-theicon="behance"><i
                            class="fa fa-behance"></i></span><span class="icon-select" data-theicon="behance-square"><i
                            class="fa fa-behance-square"></i></span><span class="icon-select"
                                                                          data-theicon="bitbucket"><i
                            class="fa fa-bitbucket"></i></span><span class="icon-select"
                                                                     data-theicon="bitbucket-square"><i
                            class="fa fa-bitbucket-square"></i></span><span class="icon-select"
                                                                            data-theicon="bitcoin"><i
                            class="fa fa-bitcoin"></i></span><span class="icon-select" data-theicon="btc"><i
                            class="fa fa-btc"></i></span><span class="icon-select" data-theicon="cc-amex"><i
                            class="fa fa-cc-amex"></i></span><span class="icon-select" data-theicon="cc-discover"><i
                            class="fa fa-cc-discover"></i></span><span class="icon-select" data-theicon="cc-mastercard"><i
                            class="fa fa-cc-mastercard"></i></span><span class="icon-select" data-theicon="cc-paypal"><i
                            class="fa fa-cc-paypal"></i></span><span class="icon-select" data-theicon="cc-stripe"><i
                            class="fa fa-cc-stripe"></i></span><span class="icon-select" data-theicon="cc-visa"><i
                            class="fa fa-cc-visa"></i></span><span class="icon-select" data-theicon="codepen"><i
                            class="fa fa-codepen"></i></span><span class="icon-select" data-theicon="css3"><i
                            class="fa fa-css3"></i></span><span class="icon-select" data-theicon="delicious"><i
                            class="fa fa-delicious"></i></span><span class="icon-select" data-theicon="deviantart"><i
                            class="fa fa-deviantart"></i></span><span class="icon-select" data-theicon="digg"><i
                            class="fa fa-digg"></i></span><span class="icon-select" data-theicon="dribbble"><i
                            class="fa fa-dribbble"></i></span><span class="icon-select" data-theicon="dropbox"><i
                            class="fa fa-dropbox"></i></span><span class="icon-select" data-theicon="drupal"><i
                            class="fa fa-drupal"></i></span><span class="icon-select" data-theicon="empire"><i
                            class="fa fa-empire"></i></span><span class="icon-select" data-theicon="facebook"><i
                            class="fa fa-facebook"></i></span><span class="icon-select"
                                                                    data-theicon="facebook-square"><i
                            class="fa fa-facebook-square"></i></span><span class="icon-select" data-theicon="flickr"><i
                            class="fa fa-flickr"></i></span><span class="icon-select" data-theicon="foursquare"><i
                            class="fa fa-foursquare"></i></span><span class="icon-select" data-theicon="ge"><i
                            class="fa fa-ge"></i></span><span class="icon-select" data-theicon="git"><i
                            class="fa fa-git"></i></span><span class="icon-select" data-theicon="git-square"><i
                            class="fa fa-git-square"></i></span><span class="icon-select" data-theicon="github"><i
                            class="fa fa-github"></i></span><span class="icon-select" data-theicon="github-alt"><i
                            class="fa fa-github-alt"></i></span><span class="icon-select"
                                                                      data-theicon="github-square"><i
                            class="fa fa-github-square"></i></span><span class="icon-select" data-theicon="gittip"><i
                            class="fa fa-gittip"></i></span><span class="icon-select" data-theicon="google"><i
                            class="fa fa-google"></i></span><span class="icon-select" data-theicon="google-plus"><i
                            class="fa fa-google-plus"></i></span><span class="icon-select"
                                                                       data-theicon="google-plus-square"><i
                            class="fa fa-google-plus-square"></i></span><span class="icon-select"
                                                                              data-theicon="google-wallet"><i
                            class="fa fa-google-wallet"></i></span><span class="icon-select" data-theicon="hacker-news"><i
                            class="fa fa-hacker-news"></i></span><span class="icon-select" data-theicon="html5"><i
                            class="fa fa-html5"></i></span><span class="icon-select" data-theicon="instagram"><i
                            class="fa fa-instagram"></i></span><span class="icon-select" data-theicon="ioxhost"><i
                            class="fa fa-ioxhost"></i></span><span class="icon-select" data-theicon="joomla"><i
                            class="fa fa-joomla"></i></span><span class="icon-select" data-theicon="jsfiddle"><i
                            class="fa fa-jsfiddle"></i></span><span class="icon-select" data-theicon="lastfm"><i
                            class="fa fa-lastfm"></i></span><span class="icon-select" data-theicon="lastfm-square"><i
                            class="fa fa-lastfm-square"></i></span><span class="icon-select" data-theicon="linkedin"><i
                            class="fa fa-linkedin"></i></span><span class="icon-select"
                                                                    data-theicon="linkedin-square"><i
                            class="fa fa-linkedin-square"></i></span><span class="icon-select" data-theicon="linux"><i
                            class="fa fa-linux"></i></span><span class="icon-select" data-theicon="maxcdn"><i
                            class="fa fa-maxcdn"></i></span><span class="icon-select" data-theicon="meanpath"><i
                            class="fa fa-meanpath"></i></span><span class="icon-select" data-theicon="openid"><i
                            class="fa fa-openid"></i></span><span class="icon-select" data-theicon="pagelines"><i
                            class="fa fa-pagelines"></i></span><span class="icon-select" data-theicon="paypal"><i
                            class="fa fa-paypal"></i></span><span class="icon-select" data-theicon="pied-piper"><i
                            class="fa fa-pied-piper"></i></span><span class="icon-select" data-theicon="pied-piper-alt"><i
                            class="fa fa-pied-piper-alt"></i></span><span class="icon-select"
                                                                          data-theicon="pinterest"><i
                            class="fa fa-pinterest"></i></span><span class="icon-select"
                                                                     data-theicon="pinterest-square"><i
                            class="fa fa-pinterest-square"></i></span><span class="icon-select" data-theicon="qq"><i
                            class="fa fa-qq"></i></span><span class="icon-select" data-theicon="ra"><i
                            class="fa fa-ra"></i></span><span class="icon-select" data-theicon="rebel"><i
                            class="fa fa-rebel"></i></span><span class="icon-select" data-theicon="reddit"><i
                            class="fa fa-reddit"></i></span><span class="icon-select" data-theicon="reddit-square"><i
                            class="fa fa-reddit-square"></i></span><span class="icon-select" data-theicon="renren"><i
                            class="fa fa-renren"></i></span><span class="icon-select" data-theicon="share-alt"><i
                            class="fa fa-share-alt"></i></span><span class="icon-select"
                                                                     data-theicon="share-alt-square"><i
                            class="fa fa-share-alt-square"></i></span><span class="icon-select" data-theicon="skype"><i
                            class="fa fa-skype"></i></span><span class="icon-select" data-theicon="slack"><i
                            class="fa fa-slack"></i></span><span class="icon-select" data-theicon="slideshare"><i
                            class="fa fa-slideshare"></i></span><span class="icon-select" data-theicon="soundcloud"><i
                            class="fa fa-soundcloud"></i></span><span class="icon-select" data-theicon="spotify"><i
                            class="fa fa-spotify"></i></span><span class="icon-select" data-theicon="stack-exchange"><i
                            class="fa fa-stack-exchange"></i></span><span class="icon-select"
                                                                          data-theicon="stack-overflow"><i
                            class="fa fa-stack-overflow"></i></span><span class="icon-select" data-theicon="steam"><i
                            class="fa fa-steam"></i></span><span class="icon-select" data-theicon="steam-square"><i
                            class="fa fa-steam-square"></i></span><span class="icon-select"
                                                                        data-theicon="stumbleupon"><i
                            class="fa fa-stumbleupon"></i></span><span class="icon-select"
                                                                       data-theicon="stumbleupon-circle"><i
                            class="fa fa-stumbleupon-circle"></i></span><span class="icon-select"
                                                                              data-theicon="tencent-weibo"><i
                            class="fa fa-tencent-weibo"></i></span><span class="icon-select" data-theicon="trello"><i
                            class="fa fa-trello"></i></span><span class="icon-select" data-theicon="tumblr"><i
                            class="fa fa-tumblr"></i></span><span class="icon-select" data-theicon="tumblr-square"><i
                            class="fa fa-tumblr-square"></i></span><span class="icon-select" data-theicon="twitch"><i
                            class="fa fa-twitch"></i></span><span class="icon-select" data-theicon="twitter"><i
                            class="fa fa-twitter"></i></span><span class="icon-select" data-theicon="twitter-square"><i
                            class="fa fa-twitter-square"></i></span><span class="icon-select"
                                                                          data-theicon="vimeo-square"><i
                            class="fa fa-vimeo-square"></i></span><span class="icon-select" data-theicon="vine"><i
                            class="fa fa-vine"></i></span><span class="icon-select" data-theicon="vk"><i
                            class="fa fa-vk"></i></span><span class="icon-select" data-theicon="wechat"><i
                            class="fa fa-wechat"></i></span><span class="icon-select" data-theicon="weibo"><i
                            class="fa fa-weibo"></i></span><span class="icon-select" data-theicon="weixin"><i
                            class="fa fa-weixin"></i></span><span class="icon-select" data-theicon="windows"><i
                            class="fa fa-windows"></i></span><span class="icon-select" data-theicon="wordpress"><i
                            class="fa fa-wordpress"></i></span><span class="icon-select" data-theicon="xing"><i
                            class="fa fa-xing"></i></span><span class="icon-select" data-theicon="xing-square"><i
                            class="fa fa-xing-square"></i></span><span class="icon-select" data-theicon="yahoo"><i
                            class="fa fa-yahoo"></i></span><span class="icon-select" data-theicon="yelp"><i
                            class="fa fa-yelp"></i></span><span class="icon-select" data-theicon="youtube"><i
                            class="fa fa-youtube"></i></span><span class="icon-select" data-theicon="youtube-play"><i
                            class="fa fa-youtube-play"></i></span><span class="icon-select"
                                                                        data-theicon="youtube-square"><i
                            class="fa fa-youtube-square"></i></span><span class="icon-select"
                                                                          data-theicon="ambulance"><i
                            class="fa fa-ambulance"></i></span><span class="icon-select" data-theicon="h-square"><i
                            class="fa fa-h-square"></i></span><span class="icon-select" data-theicon="hospital-o"><i
                            class="fa fa-hospital-o"></i></span><span class="icon-select" data-theicon="medkit"><i
                            class="fa fa-medkit"></i></span><span class="icon-select" data-theicon="plus-square"><i
                            class="fa fa-plus-square"></i></span><span class="icon-select" data-theicon="stethoscope"><i
                            class="fa fa-stethoscope"></i></span><span class="icon-select" data-theicon="user-md"><i
                            class="fa fa-user-md"></i></span><span class="icon-select" data-theicon="wheelchair"><i
                            class="fa fa-wheelchair"></i></span><span class="icon-select" data-theicon="flag"><i
                            class="fa fa-flag"></i></span><span class="icon-select" data-theicon="maxcdn"><i
                            class="fa fa-maxcdn"></i></span>
                </span>
            </span>
        ';




        $lab = 'title';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';

        $element_edit_str .= '<span class="setting">
        <span class="setting-label">'.__('Title').'</span>
'.DZSHelpers::generate_input_text($nam, array('class'=>'simple-input-text ','seekval'=>$margs[$lab],)).'
<span class="sidenote">'.__('set the title').'</span>
</span>
        ';




        $class_tinymce_me = 'tinymce-me';

        if($margs['kill_tinymce']=='on'){
            $class_tinymce_me = '';
        }

        $lab = 'feature';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';
        $lab2 = 'kill_tinymce';
        $nam2 = ''.$margs['type_elements'].$ind.'['.$lab2.']';


        $element_edit_str .= '<span class="setting">
        <span class="setting-label">'.__('Feature Text').'</span>
<textarea class="'.$class_tinymce_me.'" name="'.$nam.'">'.$margs['feature'].'</textarea>
<span class="sidenote">'.__('Input here feature. You can optionally <a href="#" class="kill-prev-tinymce">kill</a> the tinymce editor and leave a normal input if you want to enter more advanced html feature.').'</span>
<input type="hidden" name="'.$nam2.'" value="'.$margs['kill_tinymce'].'"/>
</span>
        ';



        $element_edit_str.='<p class="buttons-con"><button class="button-primary btn-delete-itm btn-delete-element">'.__('Delete Element').'</button> <button class="button button--secondary btn-done-editing"><span class="button-label">'.__('Done Editing').'</span></button> </p>';


        $margs = array_merge($margs, $pargs);


        // -- how it appears in the editor
        $fout.='<span class="dzspgb-element-con"><span class="hidden-content">'.$element_edit_str.'</span><span class="dzspgb-element-type the-type-'.$id.'" data-type="'.$id.'">
            <span class="move-handler-for-elements"><i class="fa fa-arrows-v"></i></span>
            <span class="clone-handler-for-elements"><i class="fa fa-clone"></i></span>
            <span class="icon-con"><i class="fa fa-star"></i></span><h5>'.__('Feature Element').'</h5><p class="the-excerpt">'.__("Insert a text block. Write in a WYSIWYG editor, even custom HTML can go here ").'</p><span class="dzspgb-button dzspgb-button-choose">'.$margs['txt_choose'].'</span></span><input type="hidden" name="'.$margs['type_elements'].$ind.'[type_element]" value="'.$id.'"/></span>';

        return $fout;
    }
}




if(!function_exists('shortcode_feature')){
    function shortcode_feature($pargs=array(),$content=''){

        global $dzsap_portal;

        $fout = '';

        $margs = array(
            'image_height' => '10',
            'image' => '',
            'extra_classes' => '',
            'feature' => '',
            'style' => '',
            'title' => '',
            'icon' => '',
        );

        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }





        $fout.='<div class="dzs-feat-1">';

        $fout.='<div class="the-icon"><i class="fa fa-'.$margs['icon'].'"></i>';
        $fout.='</div>';

        $fout.='<div class="the-meta">
<h4 class="the-title">'.__($margs['title']).'</h4>
<p class="the-desc">
'.__($margs['feature']).'
</p>';
        $fout.='</div>';



        $fout.='</div>';
//        print_r($margs);


        return $fout;
    }
}
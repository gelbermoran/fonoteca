<?php
$id = 'audio_playlist';

$dzspgb_templates[$id] = array(
    'id' => $id,
    'admin_str_function' => 'admin_str_function_audio_playlist',
);

if(!function_exists('generate_item_audio_track')){
    function generate_item_audio_track($pargs = array()){

        $margs = array(
            'is_clone' => false,
            'source' => '',
            'thumb' => '',
            'artist' => '',
            'song_name' => '',
            'extra_classes' => '',
        );

        if($pargs){
            $margs = array_merge($margs,$pargs);
        }

        $fout = '';

        $margs['imgsource'] = str_replace('{replacequotquot}','"', $margs['imgsource']);

        // -- name= '.$margs['type_elements'].$ind.'['.$multiple_items_lab.']

        // -- clone element, we need this for the others to replicate based on this
        $fout.='<div class="dzspgb-item ';

        if($margs['is_clone']){
            $fout.='  for-clone-item';
        }
        $fout.='">';

        $lab = 'source';
        $fout.='<div class="setting">
        <h4>'.__('Media').'</h4>
        <div class="float-left">
    <input type="text" class="simple-input-field target-field dzspgb-item--field exclude-from-row-part-atts"  data-actuallabel="'.$lab.'" name="" value="'.$margs[$lab].'"/>
    <div class="dzs-single-upload';

        if($margs['is_clone']){
            $fout.=' do-not-treat';
        }

        $fout.='">
        <input class="" type="file">
        <div class="feedback"></div>
        </div>
        </div>
        <div class="clear"></div>

        </div>';

        $lab = 'thumb';
        $fout.='<div class="setting">
        <h4>'.__('Thumbnail').'</h4>
        <div class="float-left">
    <input type="text" class="simple-input-field target-field dzspgb-item--field exclude-from-row-part-atts"  data-actuallabel="'.$lab.'" name="" value="'.$margs[$lab].'"/>
    <div class="dzs-single-upload';

        if($margs['is_clone']){
            $fout.=' do-not-treat';
        }

        $fout.='">
        <input class="" type="file">
        <div class="feedback"></div>
        </div>
        </div>
        <div class="clear"></div>

        </div>';




        $lab = 'artist';
        $fout.='<div class="setting">
        <h4>'.__('Artist').'</h4>
        <input type="text" class="simple-input-field target-field dzspgb-item--field exclude-from-row-part-atts"  data-actuallabel="'.$lab.'" name="" value="'.$margs[$lab].'"/>
        </div>';


        $lab = 'song_name';
        $fout.='<div class="setting">
        <h4>'.__('Song Name').'</h4>
        <input type="text" class="simple-input-field target-field dzspgb-item--field exclude-from-row-part-atts"  data-actuallabel="'.$lab.'" name="" value="'.$margs[$lab].'"/>
        </div>';



        $fout.='<span class="move-handler-for-multiple-items"><i class="fa fa-arrows-v"></i></span><span class="delete-handler-for-multiple-items"><i class="fa fa-trash-o"></i></span>


</div>';


        return $fout;

    }
}

if(!function_exists('admin_str_function_audio_playlist')){
    function admin_str_function_audio_playlist($pargs=array()){

        $id = 'audio_playlist';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'element_index' => '0',
            'type' => 'element',
            'type_element' => $id,
            'type_pb' => "Full",
            'txt_choose' => __("Choose"),
            'type_elements' => "newelement", // -- newelement (js) or dzspgb (php) ( legit )
            'text' => "",
            'extra_classes' => "",
            'nr_columns' => "2",
            'audio_track' => array(),
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }

//        print_r($margs);

        $fout = '';
        $ind='';
        $element_edit_str='';



        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']['.$margs['element_index'].']';

//        echo 'alceva'.$ind;


//        $element_edit_str .= '<span class="setting">
//        <span class="setting-label">'.__('The Text').'</span>
//<textarea class="tinymce-me" name="'.$margs['type_elements'].$ind.'[text]">'.$margs['text'].'</textarea>';
//        $element_edit_str.='</span>';



        $lab = 'nr_columns';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';

        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Number of Columns').'</span>
'.DZSHelpers::generate_input_text($nam, array('class'=>'simple-input-text ','seekval'=>$margs[$lab],)).'
<span class="sidenote">'.__("The track id, leave blank for the current track page.").'</span>
</span>';




        $lab = 'extra_classes';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';

        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Extra Classes').'</span>
'.DZSHelpers::generate_input_text($nam, array('class'=>'simple-input-text ','seekval'=>$margs[$lab],)).'
<span class="sidenote">'.__("The track id, leave blank for the current track page.").'</span>
</span>';




        // -- repeater con
        $multiple_items_lab = 'audio_track';

        $element_edit_str.='<span class="setting dzspgb-multiple-items-con" data-actuallabelcon="'.$multiple_items_lab.'" data-startname="'.$margs['type_elements'].$ind.'['.$multiple_items_lab.']">';

        $element_edit_str.='<input type="hidden" class="dzspgb-item--field--typer" name="'.$margs['type_elements'].$ind.'['.$multiple_items_lab.'][type]" value="multipleitems"/>';

        $element_edit_str.='<span class="setting-label">'.__('Items').'</span>';

        // -- name= '.$margs['type_elements'].$ind.'['.$multiple_items_lab.']




        $args = array(
            'is_clone' => true,
            'imgsource' => '',
        );

        $element_edit_str.=generate_item_audio_track($args);

//        print_r($margs['multiple_items']);


        $multiple_items = array();


        if(isset($margs['multiple_items'])){
            $multiple_items = $margs['multiple_items'];
        }

        if(isset($multiple_items[$multiple_items_lab])){
//            print_r($multiple_items[$multiple_items_lab]);

            foreach($multiple_items[$multiple_items_lab] as $lab => $val){
                if($lab==='type'){
                    continue;
                }

                $args = array(
                    'is_clone' => false,
                    'source' => $val['source'],
                    'artist' => $val['artist'],
                );
                $element_edit_str.=generate_item_audio_track($args);

            }
        }



        $element_edit_str.='<button class="button button--secondary btn-add-item"><span class="button-label">'.__('Add Item').'</span></button>';
        $element_edit_str.='</span>';





        // -- repeater con END















        $element_edit_str.='<p class="buttons-con"><button class="button-primary btn-delete-itm btn-delete-element">'.__('Delete Element').'</button> <button class="button button--secondary btn-done-editing"><span class="button-label">'.__('Done Editing').'</span></button> </p>
        ';


//        $margs = array_merge($margs, $pargs);


        // -- how it appears in the editor
        $fout.='<span class="dzspgb-element-con"><span class="hidden-content  the-type-'.$id.'">'.$element_edit_str.'</span><span class="dzspgb-element-type the-type-'.$id.'" data-type="'.$id.'"><span class="move-handler-for-elements"><i class="fa fa-arrows-v"></i></span>
        <span class="icon-con"><i class="fa fa-music"></i></span><h5>'.__('Audio Playlist').'</h5><p class="the-excerpt">'.__("Add a audio tracks playlist with a skin of your choosing").'</p><span class="dzspgb-button dzspgb-button-choose">'.$margs['txt_choose'].'</span></span><input type="hidden" name="'.$margs['type_elements'].$ind.'[type_element]" value="'.$id.'"/></span>';

        return $fout;
    }
}




if(!function_exists('shortcode_audio_playlist')){
    function shortcode_audio_playlist($pargs=array(),$content=''){

        global $dzsap_portal;

        $fout = '';

        $margs = array(
            'type_element' => 'audio_playlist',
            'nr_columns' => '2',
            'audio_track' => array(),
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }

//        print_r($margs);

//        echo 'content is -->'.$content.'<-- end content';

//        echo 'hmmdada2';
//        print_r($margs); print_r($content);
//        echo 'hmmdada2END';



        preg_match_all("/\[dzspgb_item([\s|\S]*?)\]([\s|\S]*?)\[\/dzspgb_item]/", $content, $output_array);

//        print_r($output_array);

        if($output_array && count($output_array[0])>0){

            $fout.='<div class="audiogallery skin-default auto-init-from-dzsapp '.$margs['extra_classes'].'" style="opacity:0; "
                 data-options=\'{
                autoplayNext:"off"
                ,design_menu_position: "none"
}\'>
                <div class="items">';






            for($i=0;$i<count($output_array[0]);$i++){

                $margs_item = array(
                    'source'=>'',
                    'thumb'=>'',
                    'artist'=>'',
                    'song_name'=>'',
                );
                $pargs_item = ($dzsap_portal->get_shortcode_atts($output_array[1][$i]));

                $margs_item = array_merge($margs_item, $pargs_item);

//                print_r($margs_item);

                $fout.='<div  data-type="audio" class="audioplayer-tobe skin-steel " data-source="'.$margs_item['source'].'" ';

                if($margs_item['thumb']){
                    $fout.=' data-thumb="'.$margs_item['thumb'].'"';
                }

                        $fout.='><div class="meta-artist">
                            <span class="the-artist">'.$margs_item['artist'].'</span><span class="the-name">'.$margs_item['song_name'].'</span>
                        </div>

                    </div>';

            }




            $fout.='</div>';
            $fout.='</div>';
        }








        return $fout;
    }
}
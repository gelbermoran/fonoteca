<?php
$id = 'slider';

$dzspgb_templates[$id] = array(
    'id' => $id,
    'admin_str_function' => 'admin_str_function_slider',
);

if(!function_exists('generate_item_item')) {
    function generate_item_item($pargs = array()){

        $margs = array(
            'is_clone' => false,
            'imgsource' => '',
            'extra_html' => '',
        );

        if($pargs){
            $margs = array_merge($margs,$pargs);
        }

        $fout = '';

        // -- name= '.$margs['type_elements'].$ind.'['.$multiple_items_lab.']

        // -- clone element, we need this for the others to replicate based on this
        $fout.='<div class="dzspgb-item dzs-upload-con';

        if($margs['is_clone']){
            $fout.='  for-clone-item';
        }

        $fout.='"><div class="float-left">
    <input type="text" class="simple-input-field target-field dzspgb-item--field exclude-from-row-part-atts"  data-actuallabel="imgsource" name="" value="'.$margs['imgsource'].'"/>
    <div class="dzs-single-upload';

        if($margs['is_clone']){
            $fout.=' do-not-treat';
        }

        $fout.='">
        <input class="" type="file">
        </div>
        </div>
        <div class="clear"></div><br>
';

        $lab = 'extra_html';

        $fout.='<textarea class="simple-input-field target-field dzspgb-item--field exclude-from-row-part-atts"  data-actuallabel="'.$lab.'" name="" placeholder="'.__("Extra HTML").'">'.$margs[$lab].'</textarea>';



        $fout.='
        <span class="move-handler-for-multiple-items"><i class="fa fa-arrows-v"></i></span><span class="delete-handler-for-multiple-items"><i class="fa fa-trash-o"></i></span>

    <div class="feedback"></div>
</div>';


        return $fout;

    }
}

if(!function_exists('admin_str_function_slider')){
    function admin_str_function_slider($pargs=array()){

        $id = 'slider';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'element_index' => '0',
            'type' => 'element',
            'type_element' => $id,
            'type_pb' => "Full",
            'txt_choose' => __("Choose"),
            'type_elements' => "newelement", // -- newelement (js) or dzspgb (php) ( legit )
            'text' => "",
            'extra_classes' => "",
            'skin' => "skin-default",
            'transition' => "fade",
            'multiple_items' => array(),
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }

//        print_r($margs);

        $fout = '';
        $ind='';
        $element_edit_str='';



        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']['.$margs['element_index'].']';

//        echo 'alceva'.$ind;


//        $element_edit_str .= '<span class="setting">
//        <span class="setting-label">'.__('The Text').'</span>
//<textarea class="tinymce-me" name="'.$margs['type_elements'].$ind.'[text]">'.$margs['text'].'</textarea>';
//        $element_edit_str.='</span>';


        $lab = 'extra_classes';
        $element_edit_str .= '<span class="setting">
        <span class="setting-label">'.__('Extra Classes').'</span>
<textarea class="textarea-extra-css formstyle" name="'.$margs['type_elements'].$ind.'['.$lab.']">'.$margs[$lab].'</textarea>';
        $element_edit_str.='</span>';







        $arr_opts = array(
            array(
                'lab' => __('Default'),
                'val' => 'skin-default',
            ),
            array(
                'lab' => __('Regen'),
                'val' => 'skin-regen',
            ),
            array(
                'lab' => __('Agata'),
                'val' => 'skin-agata',
            ),
        );



        $lab = 'skin';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';


        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Skin').'</span>
'.DZSHelpers::generate_select($nam, array('class'=>'dzs-style-me skin-beige ','options'=>$arr_opts,'seekval'=>$margs[$lab],)).'
<span class="sidenote">'.__("Set <strong>Automatic</strong> for no pagination. Set <strong>Button</strong> for a Load More button that loads more tracks.").'</span></span>';



        $lab = 'transition';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';


        $arr_opts = array(
            array(
                'label' => __('Fade'),
                'value' => 'fade',
            ),
            array(
                'label' => __('Fly Out'),
                'value' => 'flyout',
            ),
        );


        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Transition').'</span>
'.DZSHelpers::generate_select($nam, array('class'=>'dzs-style-me skin-beige ','options'=>$arr_opts,'seekval'=>$margs[$lab],)).'
<span class="sidenote">'.__("Set <strong>fade</strong> for fading.").'</span></span>';



        // -- repeater con
        $multiple_items_lab = 'item';

        $element_edit_str.='<span class="setting dzspgb-multiple-items-con" data-actuallabelcon="'.$multiple_items_lab.'" data-startname="'.$margs['type_elements'].$ind.'['.$multiple_items_lab.']">';

        $element_edit_str.='<input type="hidden" class="dzspgb-item--field--typer" name="'.$margs['type_elements'].$ind.'['.$multiple_items_lab.'][type]" value="multipleitems"/>';

        $element_edit_str.='<span class="setting-label">'.__('Items').'</span>';

        // -- name= '.$margs['type_elements'].$ind.'['.$multiple_items_lab.']

        $actual_label = 'imgsource';



        $args = array(
            'is_clone' => true,
            'imgsource' => '',
        );

        $element_edit_str.=generate_item_item($args);

//        print_r($margs['multiple_items']);


        $multiple_items = $margs['multiple_items'];

//        print_r($multiple_items);
        if(isset($multiple_items[$multiple_items_lab])){
//            print_r($multiple_items[$multiple_items_lab]);

            foreach($multiple_items[$multiple_items_lab] as $lab => $val){
                if($lab==='type'){
                    continue;
                }

                $args = array(
                    'is_clone' => false,
                    'imgsource' => $val['imgsource'],
                );
                $element_edit_str.=generate_item_item($args);

            }
        }



        $element_edit_str.='<button class="button button--secondary btn-add-item"><span class="button-label">'.__('Add Item').'</span></button>';
        $element_edit_str.='</span>';



        // -- repeater con END

        $element_edit_str.='<p class="buttons-con"><button class="button-primary btn-delete-itm btn-delete-element">'.__('Delete Element').'</button> <button class="button button--secondary btn-done-editing"><span class="button-label">'.__('Done Editing').'</span></button> </p>
        ';


//        $margs = array_merge($margs, $pargs);


        // -- how it appears in the editor
        $fout.='<span class="dzspgb-element-con"><span class="hidden-content">'.$element_edit_str.'</span><span class="dzspgb-element-type the-type-'.$id.'" data-type="'.$id.'"><span class="move-handler-for-elements"><i class="fa fa-arrows-v"></i></span>
        <span class="icon-con"><i class="fa fa-ellipsis-h"></i></span><h5>'.__('Slider Element').'</h5><p class="the-excerpt">Lorem ipsum dolor amet a...</p><span class="dzspgb-button dzspgb-button-choose">'.$margs['txt_choose'].'</span></span><input type="hidden" name="'.$margs['type_elements'].$ind.'[type_element]" value="'.$id.'"/></span>';

        return $fout;
    }
}
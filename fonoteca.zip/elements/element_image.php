<?php
$id = 'image';

global $dzspgb_templates;

$dzspgb_templates[$id] = array(
    'id' => $id,
    'admin_str_function' => 'admin_str_function_image',
);

if(isset($default_opts)==false){
    $default_opts = array();
}

$default_opts[$id]=array(
    'link_extra_attr'=>''
);
//print_r($dzspgb_templates);

if(!function_exists('admin_str_function_image')){
    function admin_str_function_image($pargs=array()){
        global $default_opts;

        $id = 'image';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'element_index' => '0',
            'type' => 'element',
            'type_element' => $id,
            'type_pb' => "Full",
            'txt_choose' => __("Choose"),
            'type_elements' => "newelement", // -- newelement (js) or dzspgb (php) ( legit )


            'image' => "",
            'extra_html' => '',
            'extra_classes' => '',
            'is_parallax' => 'off',
            'link' => '',
            'link_target' => '',
        );


        $margs=array_merge($margs,$default_opts[$id]);

        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }


        $fout = '';
        $ind='';
        $element_edit_str='';



        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']['.$margs['element_index'].']';




        $lab = 'image';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';

//        echo 'alceva'.$ind;


        $element_edit_str .= '<div class="setting">
        <div class="setting-label">'.__('The image').'</div>';

        $element_edit_str.='<div class=" dzs-upload-con';


        $element_edit_str.='"><div class="float-left">
    <input type="text" class="simple-input-field target-field exclude-from-row-part-atts" name="'.$nam.'" value="'.$margs[$lab].'"/>
    <div class="dzs-single-upload';


        $element_edit_str.='">
        <input class="" type="file">
        </div>


<div class="feedback"></div>
</div>
        </div>
<div class="clear"></div>
        </div>';







        $lab = 'is_parallax';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';

        $element_edit_str.='<div class="setting ">
        <span class="setting-label">'.__('Parallax?').'</span>
        <div class="dzscheckbox skin-nova">
            '.DZSHelpers::generate_input_checkbox($nam,array('id' => $lab, 'val' => 'on','seekval' => $margs[$lab])).'
                            <label for="'.$nam.'"></label>
        </div>
        <span class="sidenote">'.__("this will become a parallax section if set to on").'</span>

</div>';







        $lab = 'extra_html';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';
        $element_edit_str .= '<br><div class="setting">
        <div class="setting-label">'.__('Extra HTML').'</div>
<textarea class="textarea-extra-css formstyle" name="'.$nam.'">'.$margs[$lab].'</textarea>';
        $element_edit_str.='</div>';


        $lab = 'extra_classes';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';
        $element_edit_str .= '<br><div class="setting">
        <div class="setting-label">'.__('Extra Classes').'</div>
<textarea class="textarea-extra-css formstyle" name="'.$nam.'">'.$margs[$lab].'</textarea>';
        $element_edit_str.='</div>';





        $lab = 'link';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';


        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Link').'</span>
'.DZSHelpers::generate_input_text($nam, array('class'=>'simple-input-text ','seekval'=>$margs[$lab],)).'
<span class="sidenote">'.__("specify a url on click").'</span>
</span>';



        $lab = 'link_extra_attr';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';


        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Link Extra HTML').'</span>
'.DZSHelpers::generate_input_textarea($nam, array('class'=>'simple-input-text ','seekval'=>$margs[$lab],)).'
<span class="sidenote">'.__("* developers only ").__("some custom html in the anchor tag").'</span>
</span>';




        $arr_opts = array(
            array(
                'lab' => __('Same Window'),
                'val' => '_self',
            ),
            array(
                'lab' => __('New Window'),
                'val' => '_blank',
            ),
        );




        $lab = 'link_target';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';


        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Open In..').'</span>
'.DZSHelpers::generate_select($nam, array('class'=>'dzs-style-me skin-beige ','options'=>$arr_opts,'seekval'=>$arr_opts,)).'
<span class="sidenote">'.__("open in new tab or current tab").'</span></span>';







        $element_edit_str.='<p class="buttons-con"><button class="button-primary btn-delete-itm btn-delete-element">'.__('Delete Element').'</button> <button class="button button--secondary btn-done-editing"><span class="button-label">'.__('Done Editing').'</span></button> </p>
        ';


        $margs = array_merge($margs, $pargs);


        // -- how it appears in the editor
        $fout.='<div class="dzspgb-element-con"><div class="hidden-content">'.$element_edit_str.'</div><span class="dzspgb-element-type the-type-'.$id.'" data-type="'.$id.'">
            <span class="move-handler-for-elements"><i class="fa fa-arrows-v"></i></span>
            <span class="clone-handler-for-elements"><i class="fa fa-clone"></i></span>
            <span class="icon-con"><i class="fa fa-picture-o"></i></span><h5>'.__('Image Element').'</h5><p class="the-excerpt">'.__("Insert a image block. Write in a WYSIWYG editor, even custom HTML can go here ").'</p><span class="dzspgb-button dzspgb-button-choose">'.$margs['txt_choose'].'</span></span><input type="hidden" name="'.$margs['type_elements'].$ind.'[type_element]" value="'.$id.'"/></div>';

        return $fout;
    }
}



if(!function_exists('shortcode_image')){
    function shortcode_image($pargs=array(),$content=''){

        global $dzsap_portal;
        global $default_opts;

        $id='image';

        $fout = '';

        $margs = array(
            'image_height' => '10',
            'image' => '',
            'extra_classes' => '',
            'extra_html' => '',
            'style' => 'style-default',
            'is_parallax' => 'off',
            'link' => '',
            'link_target' => '',
        );


        $margs=array_merge($margs,$default_opts[$id]);
        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }


//        print_r($margs);

        $src = $dzsap_portal->sanitize_source($margs['image']);


        $fout.='<div class="shortcode-image element-image">';

        if($margs['link']){
            $fout.='<a href="'.$margs['link'].'" target="'.$margs['link_target'].'" '.$dzsap_portal->sanitize_for_front_end($margs['link_extra_attr']).'>';
        }


        if($margs['is_parallax']=='on'){

            $fout.='<div class="dzsparallaxer auto-init  simple-parallax  use-loading" data-options=\'{ }\' style="height: 350px;">';


            $fout.='<div class="divimage dzsparallaxer--target " data-src="'.$src.'" style=" ">
        </div>
    <div class="semi-black-overlay"></div>';

            $fout.=''.$dzsap_portal->sanitize_for_front_end($margs['extra_html']).'';
            $fout.='<div class="preloader-semicircles"></div>';

            $fout.='</div>';
        }else{

            $fout.='<img src="'.$src.'" class="fullwidth"/>';
            $fout.=''.$dzsap_portal->sanitize_for_front_end($margs['extra_html']).'';
        }

        if($margs['link']){
            $fout.='</a>';
        }


        $fout.='</div>';


//        return '';
        return $fout;
    }
}
<?php
$id = 'breakout_final';

$dzspgb_templates[$id] = array(
    'id' => $id,
    'admin_str_function' => 'admin_str_function_breakout_final',
);


if(!function_exists('admin_str_function_breakout_final')){
    function admin_str_function_breakout_final($pargs=array()){

        $id = 'breakout_final';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'element_index' => '0',
            'type' => 'element',
            'type_element' => $id,
            'type_pb' => "Full",
            'txt_choose' => __("Choose"),
            'type_elements' => "newelement", // -- newelement (js) or dzspgb (php) ( legit )
            'text' => "",
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }


        $fout = '';
        $ind='';
        $element_edit_str='';



        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']['.$margs['element_index'].']';

//        echo 'alceva'.$ind;


        $element_edit_str .= '<span class="setting">
        <span class="setting-label">'.__('The Text').'</span>
<textarea class="tinymce-me" name="'.$margs['type_elements'].$ind.'[text]">'.$margs['text'].'</textarea>
        <p class="buttons-con"><button class="button-primary btn-delete-itm btn-delete-element">'.__('Delete Element').'</button> <button class="button-secondary btn-done-editing">'.__('Done Editing').'</button> </p>
        </span>
        ';


        $margs = array_merge($margs, $pargs);



        // -- screen in editor
        $fout.='<span class="dzspgb-element-con"><span class="hidden-content">'.$element_edit_str.'</span><span class="dzspgb-element-type the-type-text" data-type="'.$id.'"><span class="icon-con"><i class="fa fa-angle-right"></i></span><h5>'.__('Breakout Final').'</h5><p class="the-excerpt">'.__("Use this element for breaking out to a full width container.").'</p><span class="dzspgb-button dzspgb-button-choose">'.$margs['txt_choose'].'</span></span><input type="hidden" name="'.$margs['type_elements'].$ind.'[type_element]" value="'.$id.'"/></span>';

        return $fout;
    }
}
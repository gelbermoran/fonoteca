<?php
$id = 'new_section';

$dzspgb_templates[$id] = array(
    'id' => $id,
    'admin_str_function' => 'admin_str_function_new_section',
);


if(!function_exists('admin_str_function_new_section')){
    function admin_str_function_new_section($pargs=array()){

        $id = 'new_section';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'element_index' => '0',
            'type' => 'element',
            'type_element' => $id,
            'type_pb' => "Full",
            'txt_choose' => __("Choose"),
            'type_elements' => "newelement", // -- newelement (js) or dzspgb (php) ( legit )
            'text' => "",
            'extra_classes' => '',
            'new_row_follows' => 'off',
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }


        $fout = '';
        $ind='';
        $element_edit_str='';



        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']['.$margs['element_index'].']';

//        echo 'alceva'.$ind;





        $lab = 'extra_classes';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';

        $element_edit_str.='<span class="setting">
        <span class="setting-label">'.__('Extra Classes').'</span>
'.DZSHelpers::generate_input_text($nam, array('class'=>'simple-input-text ','seekval'=>$margs[$lab],)).'
<span class="sidenote">'.__("The track id, leave blank for the current track page.").'</span>
</span>';




        $lab = 'new_row_follows';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';

        $element_edit_str.='<div class="setting ">
        <span class="setting-label">'.__('New Row Follows').'</span>
        <div class="dzscheckbox skin-nova">
            '.DZSHelpers::generate_input_checkbox($nam,array('id' => $lab, 'val' => 'on','seekval' => $margs[$lab])).'
                            <label for="'.$nam.'"></label>
        </div>
        <span class="sidenote">'.__("Warning: If you activate this, the element must be followed by a new ROW, or else the entire layout will break!").'</span>

</div>';





        $element_edit_str.='<p class="buttons-con"><button class="button-primary btn-delete-itm btn-delete-element">'.__('Delete Element').'</button> <button class="button--secondary button btn-done-editing"><span class="button-label">'.__('Done Editing').'</span></button> </p>';

        // -- screen in editor
        $fout.='<div class="dzspgb-element-con"><div class="hidden-content">'.$element_edit_str.'</div><span class="dzspgb-element-type the-type-'.$id.'" data-type="'.$id.'">
        <span class="move-handler-for-elements"><i class="fa fa-arrows-v"></i></span>
        <span class="clone-handler-for-elements"><i class="fa fa-clone"></i></span>
        <span class="icon-con"><i class="fa fa-cube"></i></span><h5>'.__('New Section').'</h5><p class="the-excerpt">'.__("Use this element for breaking out to a full width container.").'</p><span class="dzspgb-button dzspgb-button-choose">'.$margs['txt_choose'].'</span></span><input type="hidden" name="'.$margs['type_elements'].$ind.'[type_element]" value="'.$id.'"/></div>';

        return $fout;
    }
}





$dzspgb_shortcodes[$id] = array(
    'id' => $id,
    'str_function' => ''.$id,
);



if(!function_exists('shortcode_new_section')){
    function shortcode_new_section($pargs=array(),$content=null){

        global $dzsap_portal,$dzsap_config;


        $margs = array(
            'extra_classes' => '',
            'new_row_follows' => 'off',
        );

        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }


//        echo 'hmmdada2';

        $fout = '';

        $fout.='<!--start new section here-->';

        $fout.='</div></div></div></section>';

        $fout.='<section class="new-section '.$margs['extra_classes'].'">';



        if($margs['extra_classes']=='calendar-con'){


            if($dzsap_portal->main_settings['use_parallaxer']=='on'){
                $fout.='<div class="google-maps-me-con dzsparallaxer auto-init do-not-set-js-height"  style=" position: absolute; top:0; left:0; width: 100%; height: 100%;">';
                $fout.='<div class="google-maps-me dzsparallaxer--target" style=" position: absolute; top:0; left:0; width: 100%; height: 120%;"></div>';
                $fout.='<div class="google-maps-overlay" style=" "></div>';

                $fout.='</div>';


            }else{
                $fout.='<div class="google-maps-me" style=" position: absolute; top:0; left:0; width: 100%; height: 100%;"></div>';
                $fout.='<div class="google-maps-overlay" style=" "></div>';
            }



            if(function_exists('enqueue_script')) {

                enqueue_script('google.maps', 'http://maps.googleapis.com/maps/api/js');
            }
        }


        $fout.='<div class="'.$dzsap_config['front_dzspgb_container_class'].'">';

        if($margs['new_row_follows']!='on'){
            $fout.='<div class="'.$dzsap_config['front_dzspgb_row_class'].'"><div class="'.$dzsap_config['front_dzspgb_row_part_1.1'].' from-new-section">';
        }else{
            $fout.='<div><div>';
        }






        return $fout;
    }
}
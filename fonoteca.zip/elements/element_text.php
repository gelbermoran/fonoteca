<?php
$id = 'text';

global $dzspgb_templates;

$dzspgb_templates[$id] = array(
    'id' => $id,
    'admin_str_function' => 'admin_str_function_text',
);

//print_r($dzspgb_templates);

if(!function_exists('admin_str_function_text')){
    function admin_str_function_text($pargs=array()){

        $id = 'text';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'element_index' => '0',
            'type' => 'element',
            'type_element' => $id,
            'type_pb' => "Full",
            'txt_choose' => __("Choose"),
            'type_elements' => "newelement", // -- newelement (js) or dzspgb (php) ( legit )
            'text' => "",
            'kill_tinymce' => "off",
            'is_translatable' => "off",
        );


        if(is_array($pargs)){
            $margs = array_merge($margs,$pargs);
        }


        $fout = '';
        $ind='';
        $element_edit_str='';



        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']['.$margs['element_index'].']';

//        echo 'alceva'.$ind;



        $class_tinymce_me = 'tinymce-me';

        if($margs['kill_tinymce']=='on'){
            $class_tinymce_me = '';
        }

        $lab = 'text';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';
        $lab2 = 'kill_tinymce';
        $nam2 = ''.$margs['type_elements'].$ind.'['.$lab2.']';


        $element_edit_str .= '<span class="setting">
        <span class="setting-label">'.__('Text').'</span>
<textarea class="'.$class_tinymce_me.'" name="'.$nam.'">'.$margs['text'].'</textarea>
<span class="sidenote">'.sprintf(__("add %s before the string you want to translate and %s after %s"),'%starttrans%','%endtrans%',' / ').__('Input here text. You can optionally <a href="#" class="kill-prev-tinymce">kill</a> the tinymce editor and leave a normal input if you want to enter more advanced html text.').'</span>
<input type="hidden" name="'.$nam2.'" value="'.$margs['kill_tinymce'].'"/>
</span>
        ';


        // TBC not feasible --> just use %%trans%% string to translate %%trans%% and detect it with regex


        $lab = 'is_translatable';
        $nam = ''.$margs['type_elements'].$ind.'['.$lab.']';
        $element_edit_str.='<div class="setting ">
        <span class="setting-label">'.__('Is Translatable').'</span>
        <div class="dzscheckbox skin-nova">
                            '.DZSHelpers::generate_input_checkbox($nam,array('id' => $lab, 'val' => 'on','seekval' => $margs[$lab])).'
                            <label for="'.$nam.'"></label>
        </div>

</div>';




        $element_edit_str.='<p class="buttons-con"><button class="button-primary btn-delete-itm btn-delete-element">'.__('Delete Element').'</button> <button class="button button--secondary btn-done-editing"><span class="button-label">'.__('Done Editing').'</span></button> </p>';


        $margs = array_merge($margs, $pargs);


        // -- how it appears in the editor
        $fout.='<div class="dzspgb-element-con"><span class="hidden-content">'.$element_edit_str.'</span><span class="dzspgb-element-type the-type-text" data-type="'.$id.'">
            <span class="move-handler-for-elements"><i class="fa fa-arrows"></i></span>
            <span class="clone-handler-for-elements"><i class="fa fa-clone"></i></span>
            <div class="icon-con"><i class="fa fa-pencil"></i></div><h5>'.__('Text Element').'</h5><div class="the-excerpt-real"><h4>{{text}}</h4></div><p class="the-excerpt">'.__("Insert a text block. Write in a WYSIWYG editor, even custom HTML can go here ").'</p><span class="dzspgb-button dzspgb-button-choose">'.$margs['txt_choose'].'</span></span><input type="hidden" name="'.$margs['type_elements'].$ind.'[type_element]" value="'.$id.'"/></div>';

        return $fout;
    }
}
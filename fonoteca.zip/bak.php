<?php

$matches=array();

preg_match_all("/\[dzspgb_section\]([\S\s]*?)\[\/dzspgb_section\]/", $text_home, $matches);

//            print_r($matches);

$fout.='';
foreach($matches[1] as $section){
    $fout.='<section>';


    if($section){

        $matches2=array();

        preg_match_all("/\[dzspgb_container(.*?)\]([\S\s]*?)\[\/dzspgb_container\]/", $section, $matches2);

//                    print_r($matches2);





        $i1=0;
        foreach($matches2[2] as $container){


//                        print_r($container);



            $fout.='<div class="';


            $fout.=$dzsap_config['front_dzspgb_container_class'];

            $aux = $dzsap_portal->regex_get_attr($matches2[1][$i1],'extra_classes');
            if(isset($aux[1])){
                $fout.=' '.$aux[1];
            }


            $fout.='">';



            $matches3=array();

            preg_match_all("/\[dzspgb_row(.*?)\]([\S\s]*?)\[\/dzspgb_row\]/", $container, $matches3);

//                    print_r($matches2);


            $i2=0;




            foreach($matches3[2] as $row){


                $fout.='<div class="';



//                    print_r($aux);

                $fout.=$dzsap_config['front_dzspgb_row_class'];

                $aux = $dzsap_portal->regex_get_attr($matches3[1][$i2],'extra_classes');
                if(isset($aux[1])){
                    $fout.=' '.$aux[1];
                }


                $fout.='">';

//                            echo 'hmmdada'; print_r($row);echo 'hmmdadaEND';





                $matches4=array();

                preg_match_all("/\[dzspgb_row_part(.*?)\]([\S\s]*?)\[\/dzspgb_row_part\]/", $row, $matches4);

//                    print_r($matches4);




                $i3=0;

                foreach($matches4[2] as $row_part){



                    $fout.='<div class="';



                    $part_full = 'front_dzspgb_row_part_';

                    $aux = $dzsap_portal->regex_get_attr($matches4[1][$i3],'part');
                    if(isset($aux[1])){
                        $part_full.=''.$aux[1];
                    }

                    $fout.=$dzsap_config[$part_full];



                    $fout.='">';


//                            echo 'hmmdada'; print_r($row_part);echo 'hmmdadaEND';






                    $matches5=array();

                    preg_match_all("/\[dzspgb_element(.*?)\]([\S\s]*?)\[\/dzspgb_element\]/", $row_part, $matches5);

//                                print_r($matches5);

                    $i5=0;

                    foreach($matches5[2] as $element){



//                                    print_r($element);

                        $fout.='<div class="dzspgb-element ';




                        $aux = $dzsap_portal->regex_get_attr($matches5[1][$i5],'type_element');
                        if(isset($aux[1])){
                            $fout.=' type-'.$aux[1];
                        }




                        $fout.='">';


//                            echo 'hmmdada'; print_r($element);echo 'hmmdadaEND';



                        $fout.='</div>';
                        $i5++;

                    }


                    $fout.='</div>';
                    $i3++;

                }



                $fout.='</div>';
                $i2++;
            }



            $fout.='</div>';
            $i1++;
        }

    }


    $fout.='</section>';
}

<?php

//require_once(dirname(__FILE__).'/dzs_functions.php');

if(function_exists('__')==false){
	function __($arg='', $arg2=''){

		return _($arg);
	}
}



class DZS_PageBuilder {


    private $main_config_options=array();
    private $dblink=array();
    private $config = array();





    function __construct($pargs = array()) {



        $margs = array(
            'connect_to_db'=>true,
            'is_wp'=>false,
        );

        $margs = array_merge($margs, $pargs);




        global  $dzsap_config;

        $this->main_config_options = $dzsap_config;

        if(is_array($this->main_config_options)==false){
            $this->main_config_options = array();
        }


        $this->main_config_options = array_merge($margs, $this->main_config_options);


//        print_r($this->main_config_options);





        if($margs['connect_to_db']){

            $this->connect_database();
        }



//        print_r($_POST);


        if(isset($_POST['action']) && $_POST['action']=='ajax_select_pages_array'){
            $this->ajax_select_pages_array();
        }

        if(isset($_POST['action']) && $_POST['action']=='ajax_select_templates_array'){
            $this->select_templates_array(array(
                'for_ajax' => true
            ));
        }
        if(isset($_POST['action']) && $_POST['action']=='ajax_update_page_attr'){
            $this->ajax_update_page_attr();
        }
        if(isset($_POST['action']) && $_POST['action']=='ajax_update_post_meta'){


            $this->update_post_meta($_POST['post_id'],$_POST['arglab'],$_POST['argval']);
            die();
        }
        if(isset($_POST['action']) && $_POST['action']=='ajax_update_post_meta_all'){

//            print_r($_POST);

            $post_arr = array();
            parse_str($_POST['postdata'], $post_arr);
//            $this->update_post();


//            print_r($post_arr);;
            foreach($post_arr as $lab => $val){

                if($lab==='post_id'){
                    continue;
                }

                $this->update_post_meta($post_arr['post_id'], $lab, $val, array(
                    'for_ajax'=>false,
                ));

            }

//            $this->update_post($post_arr['post_id'],$post_arr);
            die();
        }
        if(isset($_POST['action']) && $_POST['action']=='ajax_update_user_meta_all'){

//            print_r($_POST);

            $post_arr = array();
            parse_str($_POST['postdata'], $post_arr);
//            $this->update_post();


//            print_r($post_arr);;
            foreach($post_arr as $lab => $val){

                if($lab==='post_id'){
                    continue;
                }

                global $dzsap_portal;

                $dzsap_portal->update_user_meta($post_arr['post_id'], $lab, $val, array(
                    'for_ajax'=>false,
                ));

            }

//            $this->update_post($post_arr['post_id'],$post_arr);
            die();
        }
        if(isset($_POST['action']) && $_POST['action']=='ajax_update_post'){

//            print_r($_POST);

            $post_arr = array();
            parse_str($_POST['postdata'], $post_arr);
//            $this->update_post();

            $this->update_post($post_arr['post_id'],$post_arr);
            die();
        }
        if(isset($_POST['action']) && $_POST['action']=='ajax_update_page_meta'){
            $this->ajax_update_page_meta();
        }
        if(isset($_POST['action']) && $_POST['action']=='ajax_create_page'){
            $this->ajax_create_page();
        }
        if(isset($_POST['action']) && $_POST['action']=='ajax_create_template'){
            $this->ajax_create_template();
        }
        if(isset($_POST['action']) && $_POST['action']=='ajax_delete_page'){

            $args = array();



            $this->ajax_delete_page($_POST);
        }
        if(isset($_POST['action']) && $_POST['action']=='ajax_delete_template'){
            $this->ajax_delete_template();
        }
        if(isset($_POST['action']) && $_POST['action']=='save_template'){
            $this->post_save_template();
        }
        if(isset($_POST['action']) && $_POST['action']=='save_template_by_id'){
            $this->post_save_template_by_id();
        }
        if(isset($_POST['action']) && $_POST['action']=='save_template_already_serialized'){
            $this->post_save_template_by_id();
        }
        if(isset($_POST['action']) && $_POST['action']=='ajax_save_mainsettings'){
            $this->ajax_save_mainsettings();
        }



    }

    function ajax_create_page(){




        $table_name = 'pages';


        if(isset($_POST['post_type']) && $_POST['post_type']){
            $table_name = $_POST['post_type'].'s';
        }


        if(isset($_POST['post_type']) && $_POST['post_type']=='menu'){
            $table_name = 'menus';
        }
        if(isset($_POST['post_type']) && $_POST['post_type']=='widget_stack'){
            $table_name = 'widget_stacks';
        }
        if(isset($_POST['post_type']) && $_POST['post_type']=='vpconfig'){
            $table_name = 'vpconfigs';
        }
        if(isset($_POST['post_type']) && $_POST['post_type']=='apconfig'){
            $table_name = 'apconfigs';
        }
        if(isset($_POST['post_type']) && $_POST['post_type']=='track'){
            $table_name = 'tracks';
        }
        if(isset($_POST['post_type']) && $_POST['post_type']=='user'){
            $table_name = 'users';


            global $dzsap_portal;

            $dzsap_portal->mysql_try_to_create_user($_POST['title']);

        }
//        if(isset($_POST['post_type']) && $_POST['post_type']=='post'){
//            $table_name = 'posts';
//        }




        $query = "SELECT `id` FROM `".$table_name."` WHERE `title` = '".$_POST['title']."'";


        $aux = $this->dblink->query($query);

        if($aux){

            if($aux->num_rows==0){

                global $dzsap_portal;

                $author_id = '1';

                if($dzsap_portal->currUserId){

                    $author_id = $dzsap_portal->currUserId;
                }

                $extra_labs = '';

                $extra_vals = '';

                if(isset($_POST['post_type_type']) && $_POST['post_type_type']){
                    $extra_labs.=',post_type';
                    $extra_vals.=",'".$_POST['post_type_type']."'";
                }


                $query="INSERT INTO `".$table_name."` (`title`, published_date, author_id".$extra_labs.") VALUES ('".$_POST['title']."','".$_POST['date']."','".$author_id."'".$extra_vals.")";


//                echo $query;

                $aux = $this->dblink->query($query);


                $pageid = mysqli_insert_id($this->dblink);


                $query = "SELECT * FROM `dzspgb_templates` WHERE `template_name` = 'general_template'";


                $aux2 = $this->dblink->query($query);

                if($aux2) {

                    if ($aux2->num_rows == 1) {

                        $row = $aux2->fetch_assoc();
                        error_log(print_rr($row, array('echo'=>false)));

                        $query = 'INSERT INTO `post_meta` ( `post_id`, `post_type`, `lab`, `val`, `date`) VALUES ( \''.$pageid.'\', \'page\', \'use_template\', \''.$row['id'].'\', \'2017-01-04\');';
                        $aux3 = $this->dblink->query($query);
                    }
                }


                if($aux){
                    echo 'success - '.sprintf(__("page %s inserted"), $pageid);

                }else{
                    echo 'error - '.mysqli_error($this->dblink);
                }

//                print_r($dzsap_portal);
            }else{


                echo 'error - page title already exists';
            }
        }else{
        }


        die();
    }


    function ajax_create_template(){



        $query = "SELECT `id` FROM `dzspgb_templates` WHERE `template_name` = '".$_POST['title']."'";


        $aux = $this->dblink->query($query);

        if($aux){

            if($aux->num_rows==0){


                $query="INSERT INTO `dzspgb_templates` (`template_name`) VALUES ('".$_POST['title']."')";
                $aux = $this->dblink->query($query);

//                echo $query;

                echo 'success - template inserted';

//                print_r($dzsap_portal);
            }else{


                echo 'error - template title already exists';
            }
        }else{
        }


        die();
    }

    function ajax_delete_page($pargs = array()){




        $margs = array(
            'for_ajax'=>true,
            'table'=>'pages',
        );


        $margs = array_merge($margs,$pargs);



//        print_r($margs);



        $query = "SELECT `id` FROM `".$margs['table']."` WHERE `id` = '".$_POST['id']."'";


        $aux = $this->dblink->query($query);

        if($aux){

            if($aux->num_rows==0){
                echo 'error - page id does not exist';

            }else{

                if($margs['table']=='tracks'){

                    global $dzsap_portal;
                    if($dzsap_portal->main_settings['delete_track_on_track_removal']=='on'){



                    $query = "SELECT * FROM `".$margs['table']."` WHERE `id` = '".$_POST['id']."'";


                    $aux = $this->dblink->query($query);

                    if($aux){

                        $row = mysqli_fetch_assoc($aux);

//                        print_r($row);
                        $path = $row['content'];

                        unlink($path);
                    }


                    }
                }
//                die( 'error - wait');

                $query="DELETE FROM `".$margs['table']."` WHERE id='".$_POST['id']."'";
                $aux = $this->dblink->query($query);


                echo 'success - page deleted';




            }
        }else{
        }


        die();
    }

    function ajax_delete_template(){



        $query = "SELECT `id` FROM `dzspgb_templates` WHERE `id` = '".$_POST['id']."'";


        $aux = $this->dblink->query($query);

        if($aux){

            if($aux->num_rows==0){
                echo 'error - template id does not exist';

            }else{


                $query="DELETE FROM `dzspgb_templates` WHERE id='".$_POST['id']."'";
                $aux = $this->dblink->query($query);


                echo 'success - template deleted';


            }
        }else{
        }


        die();
    }

    function post_save_template(){



        $query = "SELECT `id` FROM `dzspgb_templates` WHERE `template_name` = '".$_POST['template_name']."'";


        $aux = $this->dblink->query($query);

        if($aux){

            if($aux->num_rows==0){

                $query="INSERT INTO `dzspgb_templates` (`template_name`, `template_data`) VALUES ('".$_POST['template_name']."', '".$_POST['postdata']."')";
                $aux = $this->dblink->query($query);


                echo 'success - template_inserted';
            }else{


                $query="UPDATE `dzspgb_templates` SET `template_data`='".$_POST['postdata']."' WHERE `template_name`='".$_POST['template_name']."'";
                $aux = $this->dblink->query($query);



                $auxa = array();

                parse_str($_POST['postdata'], $auxa);
                echo $_POST['postdata']; print_r($auxa);

                echo 'success - template_updated';
            }
        }else{
        }


        die();
    }
    function post_save_template_by_id(){



        $query = "SELECT `id` FROM `dzspgb_templates` WHERE `id` = '".$_POST['template_id']."'";


        $aux = $this->dblink->query($query);

        if($aux){


                $query="UPDATE `dzspgb_templates` SET `template_data`='".$this->dblink->real_escape_string($_POST['postdata'])."' WHERE `id`='".$_POST['template_id']."'";
                $aux = $this->dblink->query($query);



                $auxa = array();

//                parse_str($_POST['postdata'], $auxa);
//                echo $_POST['postdata']; print_r($auxa);

            if($aux) {

                echo 'success - template_updated';
            }else{

                echo 'error - '.mysqli_error($this->dblink);
            }

        }else{
            echo 'error - template_does_not_exist';
        }


        die();
    }
    function ajax_select_pages_array($pargs=array()){

        global $dzsap_portal;


        $margs = array(
            'for_ajax'=>true,
            'post_type'=>'page',
            'post_type_type'=>'event',
            'tracks_withoutwaveform'=>'off',
        );


        $margs = array_merge($margs,$pargs);

        $argtab = 'pages';



//        if($margs['post_type']=='vpconfig'){
//
//            $argtab = 'vpconfigs';
//        }

        if(isset($_POST['post_type'])){


            if($_POST['post_type']){

                $argtab = $_POST['post_type'].'s';
            }

            if($_POST['post_type']=='apconfig'){

                $argtab = 'apconfigs';
            }

            if( $_POST['post_type']=='vpconfig'){

                $argtab = 'vpconfigs';
            }

            if($_POST['post_type']=='menu'){

                $argtab = 'menus';
            }
            if($_POST['post_type']=='widget_stack'){

                $argtab = 'widget_stacks';
            }
            if($_POST['post_type']=='post'){

                $argtab = 'posts';
            }
            if($_POST['post_type']=='purchase'){

                $argtab = 'activity';
            }
            if($_POST['post_type']=='report'){

                $argtab = 'activity';
            }
            if($_POST['post_type']=='track'){

                $argtab = 'tracks';

                if(isset($_POST['tracks_withoutwaveform']) && $_POST['tracks_withoutwaveform']=='on'){
                    $margs['tracks_withoutwaveform']='on';
                }
            }

        }


        if($margs['post_type']=='apconfig'){

            $argtab = 'apconfigs';
        }
        if($margs['post_type']=='menu'){

            $argtab = 'menus';
        }
//        print_r($_POST);
//        print_r($margs);

        $query = "SELECT * FROM `$argtab`";
//        echo $query;



        if(isset($_POST['post_type']) && $_POST['post_type']=='purchase'){

//            $query .= " WHERE type='purchase'";
            $query .= " WHERE type IN ('purchase','purchase_paypal')";
        }
        if(isset($_POST['post_type']) && $_POST['post_type']=='report'){

            $query .= " WHERE type='report'";
        }
        if(isset($_POST['post_type_type']) && $_POST['post_type_type']){

            $query .= " WHERE post_type='".$_POST['post_type_type']."'";
        }

//        echo $query;

        if($margs['tracks_withoutwaveform']=='on'){
//            $query.=" WHERE waveform_bg='' OR waveform_prog=''";
        }


        $auxa = array();

        $aux = $this->dblink->query($query);


        if ($aux && $aux->num_rows > 0) {

            while($row = mysqli_fetch_assoc($aux)){


//                print_r($row);


                if(isset($_POST['post_type']) && ( $_POST['post_type']=='purchase'||$_POST['post_type']=='report' )){

                    $user = $dzsap_portal->get_user($row['id_user']);


                    $username = 'anonim';

                    if(isset($user['username']) && $user['username']){
                        $username = $user['username'];
                    };

                    $dets = unserialize($row['details']);

//                    if($dets['item'])

                    $track_name = '';

                    $author_name = '';

                    $track = 'proaccount';
                    if($dets['item_number']!='proaccount'){
                        $track = $dzsap_portal->get_track($dets['item_number']);


                        $author_id = $track['author_id'];

                        $track_name = $track['title'];
                        if($author_id){
                            $author_name = $dzsap_portal->get_username($author_id);
                        }

                    }else{
                        $track_name = 'Pro Account';
                        $author_name = 'Admin';
                    }


                    if($_POST['post_type']=='report'){
                        $arr = array(

                            'username'=>$username,
                            'report'=>$dets['report'],
                            'id'=>$row['id'],
                            'track_id'=>$dets['track_id'],
                            'date'=>$row['date'],
                        );
                    }
                    if($_POST['post_type']=='purchase'){
                        $arr = array(

                            'username'=>$username,
                            'track_name'=>$track_name,
                            'author_name'=>$author_name,
                            'amount'=>$dets['mc_gross'],
                            'date'=>$row['date'],
                        );
                    }

                    array_push($auxa, $arr);

                }else{
                    if($margs['tracks_withoutwaveform']=='on'){


                        $scrubbg_path = $row['waveform_bg'];
                        $scrubbg_path = str_replace($dzsap_portal->url_base, '',$scrubbg_path);

//                    error_log($scrubbg_path);
                        if($scrubbg_path && file_exists($scrubbg_path)){

                        }else{

                            array_push($auxa, $row);
                        }


                    }else{

                        
                        array_push($auxa, $row);
                    }
                }




            }


        }

//        print_r($auxa);

        if(isset($_POST['post_type']) && $_POST['post_type']=='purchase') {

            usort($auxa, "cmp_author_name");
        }else{
            usort($auxa, "cmp_title");
        }


        if($margs['for_ajax']===true){

            echo json_encode($auxa);
        }else{

            return json_encode($auxa);

        }


        die();
    }
    function select_templates_array($pargs = array()){


        $margs = array(
            'for_ajax'=>false
        );

        if($pargs){
            $margs = array_merge($margs,$pargs);
        }

        $query = "SELECT * FROM `dzspgb_templates`";

        $auxa = array();



        if($this->dblink){
            $aux = $this->dblink->query($query);

            if ($aux && $aux->num_rows > 0) {

                while($row = mysqli_fetch_assoc($aux)){

                    array_push($auxa, $row);
                }


            }


            if($margs['for_ajax']===true){

                echo json_encode($auxa);

                die();
            }else{

                return $auxa;

            }
        }else{
            return array();
        }



    }
    function select_template_array($arg){

        $query = "SELECT * FROM `dzspgb_templates` WHERE id='$arg'";

        $auxa = array();

        $aux = $this->dblink->query($query);

        if ($aux && $aux->num_rows > 0) {

            while($row = mysqli_fetch_assoc($aux)){

                array_push($auxa, $row);
            }


        }

        return $auxa;
    }
    function select_page($arg, $pargs=array()){

        $margs = array(
            'post_type' => 'page',
            'post_type_type' => 'event', // -- no use for it ATM
        );


        if($pargs){
            $margs = array_merge($margs,$pargs);
        }

        $table2 = 'pages';
        if($margs['post_type']!=='page'){

            $table2 = $margs['post_type'].'s';
        }

        if($margs['post_type']==='menu'){
            $table2 = 'menus';
        }

        if($margs['post_type']==='apconfig'){
            $table2 = 'apconfigs';
        }



        $query = "SELECT * FROM `$table2` WHERE id='$arg'";

        if($table2=='posts'){
            if($margs['post_type_type']){
//                $query
            }
        }

//        $auxa = array();

//        echo $query;

        $aux_str = '';

        $aux = $this->dblink->query($query);
        if ($aux && $aux->num_rows > 0) {

            while($row = mysqli_fetch_assoc($aux)){

                $aux_str = $row;
            }


        }

        return $aux_str;
    }

    function ajax_update_page_attr(){


        $the_id = $_POST['id'];
        $arglab = $_POST['arglab'];
        $argval = $_POST['argval'];

        $table2 = 'pages';

        if(isset($_POST['post_type']) && $_POST['post_type']=='menu'){
            $table2 = 'menus';
//            $argval = htmlentities($argval);
        }
        if(isset($_POST['post_type']) && $_POST['post_type']=='apconfig'){
            $table2 = 'apconfigs';
        }

        $argval = $this->dblink->real_escape_string($argval);



        $query = "UPDATE `$table2` SET ".$arglab."='".$argval."' WHERE id='$the_id'";

//        $auxa = array();

        $aux = $this->dblink->query($query);


        if($aux){






            echo 'success - '.__("content saved");

        }else{
            echo 'error - '.mysqli_error($this->dblink);
        }


        die();
    }

    function ajax_update_page_meta(){


        $page_id = $_POST['page_id'];
        $arglab = $_POST['arglab'];
        $argval = $_POST['argval'];



        $query = "SELECT `id` FROM `post_meta` WHERE `lab` = '$arglab' AND post_id='$page_id'  AND post_type='page'";


        $aux = $this->dblink->query($query);

        if($aux){






            if($aux->num_rows > 0){

                $query="UPDATE `post_meta` SET `val`='".$argval."' WHERE `lab` = '$arglab' AND post_id='$page_id' AND post_type='page'";
                $aux2 = $this->dblink->query($query);



                echo 'success - settings updated';
            }else{




                $query="INSERT INTO `post_meta` (post_id,lab, val,post_type) VALUES ('$page_id', '".$arglab."', '".$argval."','page')";
                $aux2 = $this->dblink->query($query);


                echo 'success - settings added';
            }

            $auxa = array();

//                parse_str($_POST['postdata'], $auxa);
//                echo $_POST['postdata']; print_r($auxa);


        }else{
            echo 'error - sql error';
        }





        die();
    }




    function update_post_meta($post_id,$arglab,$argval,$pargs=array()){

        $margs = array(
            'post_type'=>'post',
            'for_ajax'=>true,
        );

        if($pargs){
            $margs = array_merge($margs,$pargs);
        }





        $query = "SELECT `id` FROM `post_meta` WHERE `lab` = '$arglab' AND post_id='$post_id'  AND post_type='".$margs['post_type']."'";

//        echo $query;


        $aux = $this->dblink->query($query);

        if($aux){




//            print_r($aux);


            if($aux->num_rows > 0){

                $query="UPDATE `post_meta` SET `val`='".$argval."' WHERE `lab` = '$arglab' AND post_id='$post_id' AND post_type='".$margs['post_type']."'";
                $aux2 = $this->dblink->query($query);



                if($margs['for_ajax']) {
                    echo 'success - settings updated';
                }
            }else{




                $query="INSERT INTO `post_meta` (post_id,lab, val,post_type) VALUES ('$post_id', '".$arglab."', '".$argval."','".$margs['post_type']."')";
                $aux2 = $this->dblink->query($query);


//                echo $query;
                if($margs['for_ajax']) {
                    echo 'success - settings added';
                }
            }

            $auxa = array();

//                parse_str($_POST['postdata'], $auxa);
//                echo $_POST['postdata']; print_r($auxa);


        }else{
            if($margs['for_ajax']) {
                echo 'error - sql error';
            }
        }


        if($margs['for_ajax']){
            die();
        }else{
            return 1;
        }



    }


    function update_post($post_id,$pargs=array()){

        $margs = array(

            'for_ajax'=>true,
            'table_name'=>'posts',
        );

        if($pargs){
            $margs = array_merge($margs,$pargs);
        }





        $query = "SELECT `id` FROM `".$margs['table_name']."` WHERE id='$post_id' ";


        $aux = $this->dblink->query($query);


        $i=0;
        $str_sets = '';

//        print_r($margs);
        foreach($margs as $lab=>$val){
            
            if($margs['table_name']=='users' && $lab==='capabilities'){
                if(is_array($val)==false){
                    if($val){
                        
                    $val = array($val);
                    }else{
                        
                    $val = array();
                    }
                }
                $val = serialize($val);
            }

            if($lab==='for_ajax'||$lab==='post_id'||$lab==='table_name'){
                continue;
            }else{

                if($lab!=='new_password'){

                    $val=$this->dblink->real_escape_string($val);
                }
            }



            if($lab==='new_password'){
                if($val){
                    $val = MD5($val);
                    $lab = 'password';
                }else{
                    continue;
                }
            }

            if($i>0){
                $str_sets.=',';
            }



            $str_sets.=$lab.'='."'".$val."'";

            $i++;

        }



//        echo $query;



        if($aux){






            if($aux->num_rows > 0){

                $query="UPDATE `".$margs['table_name']."` SET ".$str_sets." WHERE id='$post_id' ";
//                echo $query;

                $aux2 = $this->dblink->query($query);



                if($margs['for_ajax']) {

                    if($aux2){

                        echo 'success - '.__("settings updated ");
                    }else{

                        echo 'error - str_sets ( '.$str_sets.' ) query ( '.$query.' )';
                    }
                }
            }else{




//                $query="INSERT INTO `post_meta` (post_id,lab, val,post_type) VALUES ('$post_id', '".$arglab."', '".$argval."','".$margs['post_type']."')";
//                $aux2 = $this->dblink->query($query);
//
//
//                if($margs['for_ajax']) {
//                    echo 'success - settings added';
//                }
            }

            $auxa = array();

//                parse_str($_POST['postdata'], $auxa);
//                echo $_POST['postdata']; print_r($auxa);


        }else{
            if($margs['for_ajax']) {
                echo 'error - sql error';
            }
        }


        if($margs['for_ajax']){
            die();
        }else{
            return 1;
        }



    }

    function ajax_update_post_meta(){


        $post_id = $_POST['post_id'];
        $arglab = $_POST['arglab'];
        $argval = $_POST['argval'];
        $post_type = $_POST['post_type'];



        $query = "SELECT `id` FROM `post_meta` WHERE `lab` = '$arglab' AND post_id='$post_id'  AND post_type='$post_type'";


        $aux = $this->dblink->query($query);

        if($aux){






            if($aux->num_rows > 0){

                $query="UPDATE `post_meta` SET `val`='".$argval."' WHERE `lab` = '$arglab' AND post_id='$page_id' AND post_type='$post_type'";
                $aux2 = $this->dblink->query($query);



                echo 'success - settings updated';
            }else{




                $query="INSERT INTO `post_meta` (post_id,lab, val,post_type) VALUES ('$page_id', '".$arglab."', '".$argval."','$post_type')";
                $aux2 = $this->dblink->query($query);


                echo 'success - settings added';
            }

            $auxa = array();

//                parse_str($_POST['postdata'], $auxa);
//                echo $_POST['postdata']; print_r($auxa);


        }else{
            echo 'error - sql error';
        }





        die();
    }
    function ajax_save_mainsettings(){



        global $dzsap_portal;


        $postdata = $_POST['postdata'];





        $query = "SELECT `setting_name` FROM `settings` WHERE `setting_name` = 'mainsettings'";


        $aux = $this->dblink->query($query);

        if($aux){







            if($aux->num_rows > 0){




                parse_str($_POST['postdata'],$post_arr);


                $post_arr = array_merge($dzsap_portal->main_settings, $post_arr);

                $query="UPDATE `settings` SET `setting_value`='".http_build_query($post_arr)."' WHERE `setting_name`='mainsettings'";
                $aux2 = $this->dblink->query($query);




                if($post_arr['use_pretty_links']=='on'){
                    $file = '.htaccess';
                    $current = "Options +FollowSymLinks
RewriteEngine On

RewriteCond %{SCRIPT_FILENAME} !-d
RewriteCond %{SCRIPT_FILENAME} !-f

Options +Indexes
IndexIgnore *

RewriteRule ^.*$ ./index.php";

                    if($post_arr['www_handle']=='force_www'){
                        $current.='';
                    }
                    if($post_arr['www_handle']=='force_no_www'){
                        $current.='
                        
RewriteCond %{HTTP_HOST} ^www\.(.*)$ [NC]
RewriteRule ^(.*)$ '.$post_arr['url_base'].'/$1 [R=301,L]
';
                    }
                    file_put_contents($file, $current);
                }else{

                    $file = '.htaccess';
                    $current = "";
                    if($post_arr['www_handle']=='force_www'){
                        $current.='';
                    }
                    if($post_arr['www_handle']=='force_no_www'){
                        $current.='
                        
RewriteCond %{HTTP_HOST} ^www\.(.*)$ [NC]
RewriteRule ^(.*)$ '.$post_arr['url_base'].'/$1 [R=301,L]
';
                    }
                    file_put_contents($file, $current);
                }

                echo 'success - '.__('settings updated');
            }else{




                $query="INSERT INTO `settings` (setting_name, setting_value) VALUES ('mainsettings', '".$_POST['postdata']."')";
                $aux2 = $this->dblink->query($query);


                echo 'success - settings added';
            }

            $auxa = array();

//                parse_str($_POST['postdata'], $auxa);
//                echo $_POST['postdata']; print_r($auxa);


        }else{
            echo 'error - template_does_not_exist';
        }






        die();

    }


    function generate_element_types($pargs = array()){

        global $dzspgb_templates;
        $fout = '';

        $margs = array(
            'index' => '0',
            'type' => 'section',
        );

        $margs = array_merge($margs, $pargs);


//        echo ' dzspgb_templates - '; print_r($dzspgb_templates);
        foreach($dzspgb_templates as $template){
            $fout.=call_user_func($template['admin_str_function']);
        }



//        print_r($dzspgb_templates);
//        $fout.='<span class="dzspgb-element-con"><span class="dzspgb-element-type the-type-text" data-type="text"><span class="icon-con"><i class="fa fa-pencil"></i></span><h5>'.__('Text Element').'</h5><p class="the-excerpt">Lorem ipsum dolor amet a...</p><span class="dzspgb-button dzspgb-button-choose">'.__('Choose').'</span></span></span>';
//        $fout.='<span class="dzspgb-element-con"><span class="dzspgb-element-type the-type-text"><span class="icon-con"><i class="fa fa-pencil"></i></span><h5>'.__('Template Element').'</h5><p class="the-excerpt">'.__('Choose a template from your defined ones here.').'</p><span class="dzspgb-button">'.__('Choose').'</span></span></span>';
//        $fout.='<span class="dzspgb-element-con"><span class="dzspgb-element-type the-type-text"><span class="icon-con"><i class="fa fa-pencil"></i></span><h5>'.__('Text Element').'</h5><p class="the-excerpt">Lorem ipsum dolor amet a...</p></span></span>';
//        $fout.='<span class="dzspgb-element-con"><span class="dzspgb-element-type the-type-text"><span class="icon-con"><i class="fa fa-pencil"></i></span><h5>'.__('Slider Element').'</h5><p class="the-excerpt">Lorem ipsum dolor amet a...</p></span></span>';
        $fout.='<br><span class="close-element-type-label"><i class="fa fa-close"></i> <span>'.__("Close").'</span></span>';

        return $fout;
    }

    function connect_database() {


//        print_r($this->main_config_options);
        $this->dblink = mysqli_connect($this->main_config_options['mysql_server'],$this->main_config_options['mysql_user'],$this->main_config_options['mysql_password']);
        if (!$this->dblink) {
            die('Could not connect: '.mysql_error());
        }
        $this->dblink->select_db($this->main_config_options['mysql_database']);

        $val = $this->dblink->query('select 1 from `dzspgb_templates`');

//        echo 'ceva';

        if($val !== FALSE){
        }else{
            $val2 = $this->dblink->query('CREATE TABLE IF NOT EXISTS `dzspgb_templates` (
`id` int(10) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `template_name` varchar(255) NOT NULL,
  `template_data` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;');


            if ($this->dblink->errno) {
                die('Error : '. $this->dblink->error);
            }
        }






    }


    function generate_layout_types($pargs = array()){

        $fout = '';

        $margs = array(
            'index' => '0',
            'type' => 'section',
        );

        $margs = array_merge($margs, $pargs);


        $fout.='<span class="layout-type-con" data-layout="1.1"><span class="layout-type" ><span class="layout-type--block"></span></span></span><span class="layout-type-con" data-layout="1.2+1.2"><span class="layout-type" ><span class="layout-type--block"></span><span class="layout-type--block"></span></span></span><span class="layout-type-con" data-layout="2.3+1.3"><span class="layout-type" ><span class="layout-type--block"></span><span class="layout-type--block"></span></span></span><span class="layout-type-con" data-layout="3.4+1.4"><span class="layout-type" ><span class="layout-type--block"></span><span class="layout-type--block"></span></span></span><span class="layout-type-con" data-layout="1.3+2.3"><span class="layout-type" ><span class="layout-type--block"></span><span class="layout-type--block"></span></span></span><span class="layout-type-con" data-layout="1.3+1.3+1.3"><span class="layout-type" ><span class="layout-type--block"></span><span class="layout-type--block"></span><span class="layout-type--block"></span></span></span><span class="layout-type-con" data-layout="1.2+1.4+1.4"><span class="layout-type" ><span class="layout-type--block"></span><span class="layout-type--block"></span><span class="layout-type--block"></span></span></span><span class="layout-type-con" data-layout="1.4+1.2+1.4"><span class="layout-type" ><span class="layout-type--block"></span><span class="layout-type--block"></span><span class="layout-type--block"></span></span></span><span class="layout-type-con" data-layout="1.4+1.4+1.2"><span class="layout-type" ><span class="layout-type--block"></span><span class="layout-type--block"></span><span class="layout-type--block"></span></span></span><span class="layout-type-con" data-layout="1.4+1.4+1.4+1.4"><span class="layout-type" ><span class="layout-type--block"></span><span class="layout-type--block"></span><span class="layout-type--block"></span><span class="layout-type--block"></span></span></span>';

        return $fout;
    }



    function generate_admin_section_part1($pargs = array()){

        $struct_item = '';


        $margs = array(
            'section_index' => '0',
            'type' => 'section',
            'extra_classes' => '',
        );

        $margs = array_merge($margs, $pargs);

//        print_r($margs);


        $struct_item .= '<div class="admin-dzspgb-section"><div class="hidden-content" id=""><div class="setting"><div class="setting-label">'.__('Extra Classes').'</div><input type="text" name="dzspgb['.$margs['section_index'].'][extra_classes]" value="'.$margs['extra_classes'].'"/></div><br><p class="buttons-con"><button class="button-primary btn-delete-itm btn-delete-section">'.__('Delete Section').'</button> <button class="button-secondary btn-done-editing">'.__('Done Editing').'</button> </p></div>';


        return $struct_item;

    }



    function generate_admin_container_part1($pargs = array()){


        $struct_item = '';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'type' => 'container',
            'extra_classes' => '',
            'use_template' => 'none',
            'is_content' => 'off',
            'admin_args' => array(
                'this_is_template_admin'=>false
            )
        );

        $margs = array_merge($margs, $pargs);



        $ind = '';

        if($margs['section_index']!==''){
            $ind.='['.$margs['section_index'].']';
        }
        if($margs['container_index']!==''){
            $ind.='['.$margs['container_index'].']';
        }

//        print_r($dzspgb_templates);

        $struct_item .= '<div class="admin-dzspgb-container"><div class="admin-dzspgb-label-con"><span class="admin-dzspgb-label">CONTAINER</span><div class="extra-settings-chooser dzstooltip-con js"><i class="fa fa-gear"></i><div class="dzstooltip arrow-top align-left skin-white " style="">
        <div class="dzspb_lay_con">
        <div class="dzspb_layb_one_half">
        <div class="setting"><div class="setting-label">'.__('Extra Classes').'</div><input class="dzspgb-text-changer" type="text" name="dzspgb'.$ind.'[extra_classes]" value="'.$margs['extra_classes'].'"/></div>
        </div><!-- .dzspb_layb_one_half END -->
        <div class="dzspb_layb_one_half">
        ';

//        print_r($margs);


        if($margs['admin_args']['this_is_template_admin']){

$lab = 'is_content';


            $nam = 'dzspgb'.$ind.'['.$lab.']';

//            echo 'this its content - '.$margs[$lab];

            $struct_item.='<div class="setting">
                        <div class="setting-label">'.__('Content Container','dzsprx').'</div>
                        <div class="dzscheckbox skin-nova">
                            '.DZSHelpers::generate_input_checkbox($nam,array('id' => $lab, 'val' => 'on','seekval' => $margs[$lab])).'
                            <label for="'.$nam.'"></label>
                        </div>
                        <div class="sidenote">'.__('this is where the main content of the page would come, if this option is enabled').'</div>
</div>';

        }else{
            $struct_item.='<div class="setting"><div class="setting-label">'.__('Template').'</div>';


            $arr_opts = array(
                0=>array('lab'=> 'No template', 'val'=>'none'),
            );

            $auxa = $this->select_templates_array();

//        print_r($auxa);

//        $struct_item.= '<div class="dzspb_layb_layout">';
            foreach($auxa as $template){
                $auxb = array();
                parse_str($template['template_data'], $auxb);
//            print_r($auxb);

                if(isset($auxb['dzspgb']['type']) && $auxb['dzspgb']['type']==='Row'){

                    array_push($arr_opts, array('lab'=> $template['template_name'], 'val'=>$template['id']));
                }

            }
//        print_r($arr_opts);

            $nam = 'dzspgb'.$ind.'[use_template]';

            $struct_item.= DZSHelpers::generate_select($nam, array('class'=>'dzs-style-me skin-beige dzspgb-text-changer', 'options'=>$arr_opts, 'seekval'=>$margs['use_template']));






            $struct_item.='</div>';
        }






        $struct_item.='</div><!-- .dzspb_layb_one_half END -->
        </div><!-- end dzspb_lay_con -->
        <div><button class="button-primary btn-delete-itm btn-delete-container" data-index="dzspgb'.$ind.'[index]">'.__('Delete Container').'</button></div></div></div><span class="mover-container-handler-con"><i class="fa fa-arrows-v"></i></span></div>
        <div class="is-content-placeholder" style="height:0;overflow:hidden;padding:0;">'.__('This is where the content from the page comes.').'</div>
        <div class="area-rows">';


        return $struct_item;

    }






    function generate_admin_row_part1($pargs = array()){

        $struct_item = '';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'type' => 'row',
            'empty' => true,
            'extra_classes' => '',
            'hide_when_logged_in' => '',
            'hide_when_not_logged_in' => '',
            'type_pb' => "Full",
            'column_padding' => "default",
        );

        $margs = array_merge($margs, $pargs);


//        print_r($margs);

        $ind = '';

        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        if($margs['row_index']!==''){
            $ind.='['.$margs['row_index'].']';
        }





        $struct_item .= '<div class="admin-dzspgb-row"><div class="admin-dzspgb-label-con"><span class="admin-dzspgb-label">ROW</span>
        <div class="extra-settings-chooser dzstooltip-con js">
        <i class="fa fa-gear"></i>
        <div class="dzstooltip arrow-top align-left skin-white " style="">
        <div class="dzspb_lay_con">
            <div class="dzspb_layb_one_half">
                <span class="setting"><span class="setting-label">'.__('Extra Classes').'</span><input class="dzspgb-text-changer" type="text" name="dzspgb'.$ind.'[extra_classes]" value="'.$margs['extra_classes'].'"/></span></span>
            </div><!-- .dzspb_layb_one_half END -->
            <div class="dzspb_layb_one_half">
            ';




        if($this->main_config_options['is_wp']==false){
            $lab = 'hide_when_logged_in';


            $nam = 'dzspgb'.$ind.'['.$lab.']';
            $struct_item.='<div class="setting">
                        <div class="setting-label">'.__('Hide When Logged In','dzsprx').'</div>
                        <div class="dzscheckbox skin-nova">
                            '.DZSHelpers::generate_input_checkbox($nam,array('id' => $lab, 'val' => 'on','seekval' => $margs[$lab])).'
                            <label for="'.$nam.'"></label>
                        </div>
                        </div>';


            $lab = 'hide_when_not_logged_in';


            $nam = 'dzspgb'.$ind.'['.$lab.']';

            $struct_item.='<div class="setting">
                        <div class="setting-label">'.__('Hide When Not Logged In','dzsprx').'</div>
                        <div class="dzscheckbox skin-nova">
                            '.DZSHelpers::generate_input_checkbox($nam,array('id' => $lab, 'val' => 'on','seekval' => $margs[$lab])).'
                            <label for="'.$nam.'"></label>
                        </div>
                        <div class="sidenote">'.__('this is where the main content of the page would come, if this option is enabled').'</div>
</div>';

        }




        $lab = 'column_padding';


//        print_r($margs);


        $nam = 'dzspgb'.$ind.'['.$lab.']';



        $struct_item.='<div class="setting">
                        <div class="setting-label">'.__('Column Padding','dzsprx').'</div>
                            ';



        $val = 'default';
        $struct_item.='<label>'.DZSHelpers::generate_input_checkbox($nam,
                array('id' => $lab,
                    'type' => 'radio',
                    'val' => $val,
                    'class' => 'dzspgb-text-changer val-'.$val,
                    'seekval' => $margs[$lab]
                )
            ).' '.__("Default").'</label><br>';


        $val = '10';

                            $struct_item.='<label>'.DZSHelpers::generate_input_checkbox($nam,
                array('id' => $lab,
                    'type' => 'radio',
                    'val' => $val,
                    'class' => 'dzspgb-text-changer val-'.$val,
                    'seekval' => $margs[$lab]
                )
            ).' '.__("10 Pixels").'</label><br>
                        <div class="sidenote">'.__('this is where the main content of the page would come, if this option is enabled').'</div>
</div>';





        $struct_item.='</div><!-- .dzspb_layb_one_half END -->
            </div><!-- end dzspblay_con -->

        <div><button class="button-primary btn-delete-itm btn-delete-row" data-index="dzspgb'.$ind.'[index]">'.__('Delete Row').'</button></div>
        </div>
        </div>
        <span class="layout-chooser dzstooltip-con js"><i class="fa fa-th"></i><span class="dzstooltip arrow-top align-left skin-white " style="padding-bottom:0; "><span class="layout-chooser-blocks-row">'.$this->generate_layout_types().'</span></span></span><span class="mover-row-handler-con"><i class="fa fa-arrows-v"></i></span></div>
<div class="area-row-parts">';


        if($margs['empty']===true){
//            echo 'hmm';
            $struct_item.=$this->generate_admin_row_part_part1().$this->generate_admin_row_part_part2();
            $struct_item.=$this->generate_admin_row_part_part1(array('part'=>'nonactive')).$this->generate_admin_row_part_part2(array('part'=>'nonactive'));
            $struct_item.=$this->generate_admin_row_part_part1(array('part'=>'nonactive')).$this->generate_admin_row_part_part2(array('part'=>'nonactive'));
            $struct_item.=$this->generate_admin_row_part_part1(array('part'=>'nonactive')).$this->generate_admin_row_part_part2(array('part'=>'nonactive'));
        }

//        $struct_item.='</div>';


        return $struct_item;

    }

    function generate_admin_row_part_part1($pargs = array()){

        $struct_item = '';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'row_part_index' => '0',
            'type' => 'row_part',
            'part' => '1.1',
            'type_pb' => "Full",
        );

        $margs = array_merge($margs, $pargs);


        $struct_item.='<div class="admin-dzspgb-row-part-con';

//        print_r($margs);

//        $struct_item.=' '.$margs['part'].' ';
        if($margs['part']==='1.1'){
            $struct_item.=' dzspb_layb_one_full';
        }
        if($margs['part']==='1.2'){
            $struct_item.=' dzspb_layb_one_half';
        }
        if($margs['part']==='1.3'){
            $struct_item.=' dzspb_layb_one_third';
        }
        if($margs['part']==='1.4'){
            $struct_item.=' dzspb_layb_one_fourth';
        }
        if($margs['part']==='3.4'){
            $struct_item.=' dzspb_layb_three_fourth';
        }
        if($margs['part']==='nonactive'){
            $struct_item.=' nonactive';
        }
        $struct_item.='">';
        $struct_item .= '<div class="admin-dzspgb-row-part';


        $struct_item.='">
        <div class="admin-dzspgb-label-con"><span class="admin-dzspgb-label">'.$margs['part'].'</span><span class="mover-row-part-handler-con"><i class="fa fa-arrows-h"></i></span>
        </div>';


        $ind = '';

        if($margs['type_pb']==='Full'){
            if($margs['section_index']!==''){
                $ind.='['.$margs['section_index'].']';
            }
            if($margs['container_index']!==''){
                $ind.='['.$margs['container_index'].']';
            }
        }

        $ind.='['.$margs['row_index'].']['.$margs['row_part_index'].']';


        $struct_item.='<input type="hidden" name="dzspgb';
        $struct_item.=''.$ind.'[type]" value="'.$margs['type'].'"/>';
        $struct_item.='<input type="hidden" name="dzspgb';
        $struct_item.=''.$ind.'[part]" value="'.$margs['part'].'"/>';
        $struct_item.='<div class="elements-area">';

        return $struct_item;

        // -- 2 divs to close in part 2

    }




    function generate_admin_row_part_part2($pargs = array()){

        $struct_item = '';


        $margs = array(
            'container_index' => '0',
            'section_index' => '0',
            'type' => 'row_part',
            'part' => 'one_full',
        );

        $margs = array_merge($margs, $pargs);


        $struct_item .= '</div>
        <div class="dzspgb-button-con">
            <div class="dzspgb-button dzspgb-add-element">
                <span class="add-element-label"><i class="fa fa-plus-square"></i> <span>Add Element</span></span>
                <div class="element-type-selector-con">'.$this->generate_element_types().'</div>
            </div>
        </div><!-- END dzspgb-button-con -->';




        $struct_item.='</div>';
        $struct_item.='</div>';


        return $struct_item;

    }

    function generate_admin_row_part2($pargs = array()){

        $struct_item = '';


        $margs = array(
            'section_index' => '0',
            'container_index' => '0',
            'row_index' => '0',
            'type' => 'row',
            'empty' => true,
        );

        $margs = array_merge($margs, $pargs);


        $struct_item .= '</div>';


        $ind = '';

        if($margs['section_index']!==''){
            $ind.='['.$margs['section_index'].']';
        }
        if($margs['container_index']!==''){
            $ind.='['.$margs['container_index'].']';
        }
        $ind.='['.$margs['row_index'].']';


        $struct_item.='<input type="hidden" name="dzspgb';
        $struct_item.=''.$ind.'[type]" value="'.$margs['type'].'"/>';



        $struct_item .= '</div>';


        return $struct_item;

    }



    function generate_admin_container_part2($pargs = array()){

        $struct_item = '';


        $margs = array(
            'container_index' => '0',
            'section_index' => '0',
            'type' => 'container',
        );


        $margs['type'] = 'container'; // -- we'll force this as a container is always a container :)

        $margs = array_merge($margs, $pargs);


        $struct_item .= '</div><div class="dzspgb-button-con"><span class="dzspgb-button dzspgb-add-row"><i class="fa fa-plus-square"></i><span>Add Row</span></span></div>';




        $ind = '';

        if($margs['section_index']!==''){
            $ind.='['.$margs['section_index'].']';
        }
        if($margs['container_index']!==''){
            $ind.='['.$margs['container_index'].']';
        }


        $struct_item.='<input type="hidden" name="dzspgb';
        $struct_item.=''.$ind.'[type]" value="'.$margs['type'].'"/>';

        $struct_item.='</div>';

        return $struct_item;

    }




    function generate_admin_section_part2($pargs = array()){

        $struct_item = '';


        $margs = array(
            'section_index' => '0',
            'type' => 'section',
            'extra_classes' => '',
        );

        $margs = array_merge($margs, $pargs);

        $margs['type'] = 'section'; // -- we'll force this as a section is always a section :)

        $ind = '';
        if($margs['section_index']!==''){
            $ind.='['.$margs['section_index'].']';
        }

        $struct_item .= '<div class="area-containers"></div><div class="dzspgb-button-con"><span class="dzspgb-button dzspgb-add-container"><i class="fa fa-plus-square"></i><span>Add Container</span></span></div><div class="mover-handler-con"><i class="fa fa-arrows-v"></i></div><div class="settings-button-con"><i class="fa fa-gears"></i></div>';


//        print_r($margs);

        $struct_item.='<input type="hidden" name="dzspgb';
        $struct_item.='['.$margs['section_index'].'][type]" value="'.$margs['type'].'"/>';

        $struct_item.='</div>';


        return $struct_item;

    }


}

//print_r($_POST);
//
//$re = "/\\[(\\w*)(.*?)](.*?)\\[\\/\\w*\\](?!\\s*\\[\\/)/m";



/**
 * Retrieve a modified URL query string.
 *
 * You can rebuild the URL and append a new query variable to the URL query by
 * using this function. You can also retrieve the full URL with query data.
 *
 * Adding a single key & value or an associative array. Setting a key value to
 * an empty string removes the key. Omitting oldquery_or_uri uses the $_SERVER
 * value. Additional values provided are expected to be encoded appropriately
 * with urlencode() or rawurlencode().
 *
 * @since 1.5.0
 *
 * @param mixed $param1 Either newkey or an associative_array
 * @param mixed $param2 Either newvalue or oldquery or uri
 * @param mixed $param3 Optional. Old query or uri
 * @return string New URL query string.
 */
if(!function_exists('add_query_arg')){
    function add_query_arg() {
        $ret = '';
        $args = func_get_args();
        if ( is_array( $args[0] ) ) {
            if ( count( $args ) < 2 || false === $args[1] )
                $uri = $_SERVER['REQUEST_URI'];
            else
                $uri = $args[1];
        } else {
            if ( count( $args ) < 3 || false === $args[2] )
                $uri = $_SERVER['REQUEST_URI'];
            else
                $uri = $args[2];
        }

        if ( $frag = strstr( $uri, '#' ) )
            $uri = substr( $uri, 0, -strlen( $frag ) );
        else
            $frag = '';

        if ( 0 === stripos( $uri, 'http://' ) ) {
            $protocol = 'http://';
            $uri = substr( $uri, 7 );
        } elseif ( 0 === stripos( $uri, 'https://' ) ) {
            $protocol = 'https://';
            $uri = substr( $uri, 8 );
        } else {
            $protocol = '';
        }

        if ( strpos( $uri, '?' ) !== false ) {
            list( $base, $query ) = explode( '?', $uri, 2 );
            $base .= '?';
        } elseif ( $protocol || strpos( $uri, '=' ) === false ) {
            $base = $uri . '?';
            $query = '';
        } else {
            $base = '';
            $query = $uri;
        }

        wp_parse_str( $query, $qs );
        $qs = urlencode_deep( $qs ); // this re-URL-encodes things that were already in the query string
        if ( is_array( $args[0] ) ) {
            $kayvees = $args[0];
            $qs = array_merge( $qs, $kayvees );
        } else {
            $qs[ $args[0] ] = $args[1];
        }

        foreach ( $qs as $k => $v ) {
            if ( $v === false )
                unset( $qs[$k] );
        }

        $ret = build_query( $qs );
        $ret = trim( $ret, '?' );
        $ret = preg_replace( '#=(&|$)#', '$1', $ret );
        $ret = $protocol . $base . $ret . $frag;
        $ret = rtrim( $ret, '?' );
        return $ret;
    }
}

/**
 * Removes an item or list from the query string.
 *
 * @since 1.5.0
 *
 * @param string|array $key Query key or keys to remove.
 * @param bool $query When false uses the $_SERVER value.
 * @return string New URL query string.
 */
if(!function_exists('remove_query_arg')){
    function remove_query_arg( $key, $query=false ) {
        if ( is_array( $key ) ) { // removing multiple keys
            foreach ( $key as $k )
                $query = add_query_arg( $k, false, $query );
            return $query;
        }
        return add_query_arg( $key, false, $query );
    }
}




/**
 * Parses a string into variables to be stored in an array.
 *
 * Uses {@link http://www.php.net/parse_str parse_str()} and stripslashes if
 * {@link http://www.php.net/magic_quotes magic_quotes_gpc} is on.
 *
 * @since 2.2.1
 *
 * @param string $string The string to be parsed.
 * @param array $array Variables will be stored in this array.
 */


if(function_exists('stripslashes_deep')==false){
    function stripslashes_deep($value) {
        if ( is_array($value) ) {
            $value = array_map('stripslashes_deep', $value);
        } elseif ( is_object($value) ) {
            $vars = get_object_vars( $value );
            foreach ($vars as $key=>$data) {
                $value->{$key} = stripslashes_deep( $data );
            }
        } elseif ( is_string( $value ) ) {
            $value = stripslashes($value);
        }

        return $value;
    }
}
if(!function_exists('wp_parse_str')){
    function wp_parse_str( $string, &$array ) {
        parse_str( $string, $array );
        if(function_exists('stripslashes_deep')){
            if ( get_magic_quotes_gpc() ){
                $array = stripslashes_deep( $array );
            }
        }


        /**
         * Filter the array of variables derived from a parsed string.
         *
         * @since 2.3.0
         *
         * @param array $array The array populated with variables.
         */
        $array = apply_filters( 'wp_parse_str', $array );
    }
}


/**
 * Call the functions added to a filter hook.
 *
 * The callback functions attached to filter hook $tag are invoked by calling
 * this function. This function can be used to create a new filter hook by
 * simply calling this function with the name of the new hook specified using
 * the $tag parameter.
 *
 * The function allows for additional arguments to be added and passed to hooks.
 * <code>
 * // Our filter callback function
 * function example_callback( $string, $arg1, $arg2 ) {
 *	// (maybe) modify $string
 *	return $string;
 * }
 * add_filter( 'example_filter', 'example_callback', 10, 3 );
 *
 * // Apply the filters by calling the 'example_callback' function we
 * // "hooked" to 'example_filter' using the add_filter() function above.
 * // - 'example_filter' is the filter hook $tag
 * // - 'filter me' is the value being filtered
 * // - $arg1 and $arg2 are the additional arguments passed to the callback.
 * $value = apply_filters( 'example_filter', 'filter me', $arg1, $arg2 );
 * </code>
 *
 * @global array $wp_filter         Stores all of the filters
 * @global array $merged_filters    Merges the filter hooks using this function.
 * @global array $wp_current_filter stores the list of current filters with the current one last
 *
 * @since 0.71
 *
 * @param string $tag  The name of the filter hook.
 * @param mixed $value The value on which the filters hooked to <tt>$tag</tt> are applied on.
 * @param mixed $var   Additional variables passed to the functions hooked to <tt>$tag</tt>.
 * @return mixed The filtered value after all hooked functions are applied to it.
 */

if(function_exists('apply_filters')==false){
    function apply_filters( $tag, $value ) {
        global $wp_filter, $merged_filters, $wp_current_filter;

        $args = array();

        // Do 'all' actions first
        if ( isset($wp_filter['all']) ) {
            $wp_current_filter[] = $tag;
            $args = func_get_args();
            _wp_call_all_hook($args);
        }

        if ( !isset($wp_filter[$tag]) ) {
            if ( isset($wp_filter['all']) )
                array_pop($wp_current_filter);
            return $value;
        }

        if ( !isset($wp_filter['all']) )
            $wp_current_filter[] = $tag;

        // Sort
        if ( !isset( $merged_filters[ $tag ] ) ) {
            ksort($wp_filter[$tag]);
            $merged_filters[ $tag ] = true;
        }

        reset( $wp_filter[ $tag ] );

        if ( empty($args) )
            $args = func_get_args();

        do {
            foreach( (array) current($wp_filter[$tag]) as $the_ )
                if ( !is_null($the_['function']) ){
                    $args[1] = $value;
                    $value = call_user_func_array($the_['function'], array_slice($args, 1, (int) $the_['accepted_args']));
                }

        } while ( next($wp_filter[$tag]) !== false );

        array_pop( $wp_current_filter );

        return $value;
    }

}

/**
 * Navigates through an array and encodes the values to be used in a URL.
 *
 *
 * @since 2.2.0
 *
 * @param array|string $value The array or string to be encoded.
 * @return array|string $value The encoded array (or string from the callback).
 */
if(function_exists('urlencode_deep')==false) {
    function urlencode_deep($value) {
        $value = is_array($value) ? array_map('urlencode_deep', $value) : urlencode($value);
        return $value;
    }
}

if(function_exists('cmp_author_name')==false) {
    function cmp_author_name($a, $b) {

        if (isset($a['author_name'])) {
            return strcmp($a["author_name"], $b["author_name"]);
        }
        if (isset($a['username'])) {
            return strcmp($a["username"], $b["username"]);
        }

    }
}

if(function_exists('cmp_title')==false) {
    function cmp_title($a, $b) {

        if (isset($a['title'])) {
            return strcmp($a["title"], $b["title"]);
        }
        if (isset($a['username'])) {
            return strcmp($a["username"], $b["username"]);
        }

    }
}

/**
 * Build URL query based on an associative and, or indexed array.
 *
 * This is a convenient function for easily building url queries. It sets the
 * separator to '&' and uses _http_build_query() function.
 *
 * @see _http_build_query() Used to build the query
 * @link http://us2.php.net/manual/en/function.http-build-query.php more on what
 *		http_build_query() does.
 *
 * @since 2.3.0
 *
 * @param array $data URL-encode key/value pairs.
 * @return string URL encoded string
 */
if(function_exists('build_query')==false) {
    function build_query($data) {
        return _http_build_query($data, null, '&', '', false);
    }
}


// from php.net (modified by Mark Jaquith to behave like the native PHP5 function)
if(function_exists('_http_build_query')==false) {
    function _http_build_query($data, $prefix = null, $sep = null, $key = '', $urlencode = true) {
        $ret = array();

        foreach ((array)$data as $k => $v) {
            if ($urlencode) $k = urlencode($k);
            if (is_int($k) && $prefix != null) $k = $prefix . $k;
            if (!empty($key)) $k = $key . '%5B' . $k . '%5D';
            if ($v === null) continue; elseif ($v === FALSE) $v = '0';

            if (is_array($v) || is_object($v)) array_push($ret, _http_build_query($v, '', $sep, $k, $urlencode)); elseif ($urlencode) array_push($ret, $k . '=' . urlencode($v));
            else
                array_push($ret, $k . '=' . $v);
        }

        if (null === $sep) $sep = ini_get('arg_separator.output');

        return implode($sep, $ret);
    }
}
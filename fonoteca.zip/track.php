<?php
date_default_timezone_set('America/Los_Angeles');
ini_set("log_errors", 1);
ini_set('display_errors', '0');
error_reporting(E_ALL);
ini_set("error_log", "soundportal.log");



    if(isset($_GET['debug_display_errors']) && $_GET['debug_display_errors']=='on'){

        ini_set('display_errors', 1);
    }


include_once(dirname(__FILE__).'/dzs_functions.php');
include_once(dirname(__FILE__).'/class-portal.php');



//ini_set("display_startup_errors", 1);
//ini_set("display_errors", 1);

/* Reports for either E_ERROR | E_WARNING | E_NOTICE  | Any Error*/
//error_reporting(E_ERROR);

//    echo abc;


//
//    echo $lang;
$dzsap_portal = new DZSAP_Portal();

$meta_title = $dzsap_portal->main_settings['site_title'];
$meta_desc = '';
$meta_image = '';


dzsap_load_plugins();
$dzsap_portal->check_post();


if(isset($_GET['accesstoken']) && $_GET['accesstoken']){


    $at = simple_decrypt($_GET['accesstoken'], $dzsap_portal->main_settings['site_encryption_key']);



    if(time() - intval($at) > 5){
//        echo ' time - '.time();
//        echo ' at - '.$at;
//        echo ' |||  diff - '.(time() - intval($at));
        die('access token invalid');
    }
}


if(isset($_GET['id']) && $_GET['id']){


    $tr = $dzsap_portal->get_track($_GET['id']);

//    print_r($tr);

//    header('Content-type: audio/mpeg');
//    header('Content-Disposition: filename="'.$dzsap_portal->clean($tr['title']).'"');
//    header('Content-length: '.filesize($tr['content']));
//    header("Content-Transfer-Encoding: binary");
//    echo file_get_contents($tr['content']);
//    readfile($tr['content']);

    $extension = "mp3";
    $mime_type = "audio/mpeg";
    $file_name = $tr['content'];


    stream($file_name, 'audio/mpeg');


}



/**
 * Stream-able file handler
 *
 * @param String $file_location
 * @param Header|String $content_type
 * @return content
 */
function stream($file, $content_type = 'application/octet-stream') {
    @error_reporting(0);

    // Make sure the files exists, otherwise we are wasting our time
    if (!file_exists($file)) {
        header("HTTP/1.1 404 Not Found");
        exit;
    }

    // Get file size
    $filesize = sprintf("%u", filesize($file));

    // Handle 'Range' header
    if(isset($_SERVER['HTTP_RANGE'])){
        $range = $_SERVER['HTTP_RANGE'];
    }elseif($apache = apache_request_headers()){
        $headers = array();
        foreach ($apache as $header => $val){
            $headers[strtolower($header)] = $val;
        }
        if(isset($headers['range'])){
            $range = $headers['range'];
        }
        else $range = FALSE;
    } else $range = FALSE;

    //Is range
    if($range){
        $partial = true;
        list($param, $range) = explode('=',$range);
        // Bad request - range unit is not 'bytes'
        if(strtolower(trim($param)) != 'bytes'){
            header("HTTP/1.1 400 Invalid Request");
            exit;
        }
        // Get range values
        $range = explode(',',$range);
        $range = explode('-',$range[0]);
        // Deal with range values
        if ($range[0] === ''){
            $end = $filesize - 1;
            $start = $end - intval($range[0]);
        } else if ($range[1] === '') {
            $start = intval($range[0]);
            $end = $filesize - 1;
        }else{
            // Both numbers present, return specific range
            $start = intval($range[0]);
            $end = intval($range[1]);
            if ($end >= $filesize || (!$start && (!$end || $end == ($filesize - 1)))) $partial = false; // Invalid range/whole file specified, return whole file
        }
        $length = $end - $start + 1;
    }
    // No range requested
    else $partial = false;

    // Send standard headers
    header("Content-Type: $content_type");
    header("Content-Length: $filesize");
    header('Accept-Ranges: bytes');

    // send extra headers for range handling...
    if ($partial) {
        header('HTTP/1.1 206 Partial Content');
        header("Content-Range: bytes $start-$end/$filesize");
        if (!$fp = fopen($file, 'rb')) {
            header("HTTP/1.1 500 Internal Server Error");
            exit;
        }
        if ($start) fseek($fp,$start);
        while($length){
            set_time_limit(0);
            $read = ($length > 8192) ? 8192 : $length;
            $length -= $read;
            print(fread($fp,$read));
        }
        fclose($fp);
    }
    //just send the whole file
    else readfile($file);
    exit;
}


<?php
$dzsap_config = array(
    'type' => 'portal',
    'url_portalphp' => 'index.php',
    'mysql_server' => '{{replace_mysql_server}}',
    'mysql_user' => '{{replace_mysql_user}}',
    'mysql_password' => '{{replace_mysql_password}}',
    'mysql_database' => '{{replace_mysql_database}}',
    'admin_user' => '{{replace_admin_user}}',
    'admin_password' => '{{replace_admin_password}}',
    'admin_email' => '{{replace_admin_email}}',
    'front_dzspgb_container_class' => 'container',
    'front_dzspgb_row_class' => 'row',
    'front_dzspgb_row_part_1.1' => 'col-md-12',
    'front_dzspgb_row_part_1.2' => 'col-md-6',
    'front_dzspgb_row_part_1.4' => 'col-md-3',
    'front_dzspgb_row_part_3.4' => 'col-md-9',
    'front_dzspgb_row_part_2.3' => 'col-md-8',
    'front_dzspgb_row_part_1.3' => 'col-md-4',
    'enable_likes' => 'on',
    'enable_views' => 'on',
    'enable_rates' => 'on',
    'str_likes_part1' => '<div class="btn-like skin-simple"><i class="fa fa-heart-o"></i><span class="btn-label">Like</span></div>',
    'str_views' => '<div class="counter-comments"><i class="fa fa-comments"></i><span class="the-number">{{get_comments_nr}}</span></div><div class="counter-hits"><i class="fa fa-play"></i><span class="the-number">{{get_plays}}</span></div>',
    'str_likes_part2' => '<div class="counter-likes"><i class="fa fa-heart"></i><span class="the-number">{{get_likes}}</span></div>',
    'str_rates' => '<div class="counter-rates"><span class="the-number">{{get_rates}}</span> rates</div>',
    'soundcloud_api_key' => '',
    'dzsap_tab_share_content' => '<span class="share-icon-active"><iframe src="//www.facebook.com/plugins/like.php?href={{currurl}}&amp;width&amp;layout=button_count&amp;action=like&amp;show_faces=false&amp;share=false&amp;height=21&amp;appId=569360426428348" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:120px; height:21px;" allowTransparency="true"></iframe></span>
<span class="share-icon-active"><div class="g-plusone" data-size="medium"></div></span>
<span class="share-icon-active"><a href="https://twitter.com/share" class="twitter-share-button" data-via="ZoomItFlash">Tweet</a></span><br><br><h5>Embed</h5><div class="dzs-code">{{embedcode}}</div>
<script type="text/javascript">
  (function() {
    var po = document.createElement("script"); po.type = "text/javascript"; po.async = true;
    po.src = "https://apis.google.com/js/platform.js";
    var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(po, s);
  })();
!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?"http":"https";if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document, "script", "twitter-wjs");</script>',
            
);
<?php

// CONFIG: Enable debug mode. This means we'll log requests into 'ipn.log' in the same directory.
// Especially useful if you encounter network errors or other intermittent problems with IPN (validation).
// Set this to 0 once you go live or don't require logging.




include_once(dirname(__FILE__).'/dzs_functions.php');
include_once(dirname(__FILE__).'/class-portal.php');



$dzsap_portal = new DZSAP_Portal();

//print_r($dzsap_portal);
$page = $dzsap_portal->currPage;


define("DEBUG", 1);




ini_set("log_errors", 1);
ini_set('display_errors', '0');
error_reporting(E_ALL);
ini_set("error_log", "soundportal.log");

// Set to 0 once you're ready to go live




$sw_use_sandbox = 1;

if($dzsap_portal->main_settings['developer_paypal_sandbox_mode']!='on'){
	$sw_use_sandbox = 0;
}

define("USE_SANDBOX", $sw_use_sandbox);


define("LOG_FILE", "./ipn.log");


// Read POST data
// reading posted data directly from $_POST causes serialization
// issues with array data in POST. Reading raw POST data from input stream instead.
$raw_post_data = file_get_contents('php://input');
$raw_post_array = explode('&', $raw_post_data);



//echo $raw_post_data.'-'; print_r($raw_post_array);

$myPost = array();
foreach ($raw_post_array as $keyval) {
	$keyval = explode ('=', $keyval);
	if (count($keyval) == 2)
		$myPost[$keyval[0]] = urldecode($keyval[1]);
}
// read the post from PayPal system and add 'cmd'
$req = 'cmd=_notify-validate';
if(function_exists('get_magic_quotes_gpc')) {
	$get_magic_quotes_exists = true;
}
foreach ($myPost as $key => $value) {
	if($get_magic_quotes_exists == true && get_magic_quotes_gpc() == 1) {
		$value = urlencode(stripslashes($value));
	} else {
		$value = urlencode($value);
	}
	$req .= "&$key=$value";
}

// Post IPN data back to PayPal to validate the IPN data is genuine
// Without this step anyone can fake IPN data

if(USE_SANDBOX == true) {
	$paypal_url = "https://www.sandbox.paypal.com/cgi-bin/webscr";
} else {
	$paypal_url = "https://www.paypal.com/cgi-bin/webscr";
}

error_log("PAYPAL RAW DATA IS - ".$raw_post_data);
error_log("PAYPAL URL IS - ".$paypal_url);
error_log("SANDBOX IS - ".$sw_use_sandbox);
//echo $paypal_url;

$ch = curl_init($paypal_url);
if ($ch == FALSE) {
	return FALSE;
}

curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
//curl_setopt($ch, CURLOPT_SSLVERSION, 4);
curl_setopt($ch, CURLOPT_SSL_CIPHER_LIST, "TLSv1");



$tls_protocol = 'TLSv1';

if($dzsap_portal->main_settings['tls_protocol']=='TLSv1.2'){
	$tls_protocol=$dzsap_portal->main_settings['tls_protocol'];
}


curl_setopt($ch, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1);
if(strpos($dzsap_portal->main_settings['ssl_protocol'], 'NSS/')===false){

	curl_setopt($ch, CURLOPT_SSL_CIPHER_LIST, $tls_protocol);
}




if(DEBUG == true) {
	curl_setopt($ch, CURLOPT_HEADER, 1);
	curl_setopt($ch, CURLINFO_HEADER_OUT, 1);
}

// CONFIG: Optional proxy configuration
//curl_setopt($ch, CURLOPT_PROXY, $proxy);
//curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 1);

// Set TCP timeout to 30 seconds
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Connection: Close'));

// CONFIG: Please download 'cacert.pem' from "http://curl.haxx.se/docs/caextract.html" and set the directory path
// of the certificate as shown below. Ensure the file is readable by the webserver.
// This is mandatory for some environments.

//$cert = __DIR__ . "./cacert.pem";
//curl_setopt($ch, CURLOPT_CAINFO, $cert);



//$fp = fsockopen ('tls://www.sandbox.paypal.com', 443, $errno, $errstr, 30);
////$fp = fsockopen ('ssl://www.paypal.com', 443, $errno, $errstr, 30);
//
//if (!$fp) {
//	echo "HTTP Error";
//}
//else {
//	fputs($fp, $header . $req);
//	$res = stream_get_contents($fp, 2048);
//	if (strpos(trim($res), "VERIFIED") !== false) {
//		// update transaction --> paid status
//	}
//	else if (strpos (trim($res), "INVALID") !== false) {
//	}
//	else{
//	}
//	fclose ($fp);
//}







$res = curl_exec($ch);

//echo 'ceva'; print_r($res);


// cURL error
if (curl_errno($ch) != 0) {
	if(DEBUG == true) {
		error_log(date('[Y-m-d H:i e] '). "Can't connect to PayPal to validate IPN message: " . curl_error($ch) . PHP_EOL, 3, LOG_FILE);
		echo date('[Y-m-d H:i e] '). "Can't connect to PayPal to validate IPN message: " . curl_error($ch);
	}
	curl_close($ch);
	exit;

} else {
	// Log the entire HTTP response if debug is switched on.
	if(DEBUG == true) {
//		error_log(date('[Y-m-d H:i e] '). "HTTP request of validation request:". curl_getinfo($ch, CURLINFO_HEADER_OUT) ." for IPN payload: $req" . PHP_EOL, 3, LOG_FILE);
//		error_log(date('[Y-m-d H:i e] '). "HTTP response of validation request: $res" . PHP_EOL, 3, LOG_FILE);
	}
	curl_close($ch);
}





// Inspect IPN validation result and act accordingly

// Split response headers and payload, a better way for strcmp
$tokens = explode("\r\n\r\n", trim($res));
$res = trim(end($tokens));

//if (strcmp ($res, "VERIFIED") == 0) {
//	// check whether the payment_status is Completed
//	// check that txn_id has not been previously processed
//	// check that receiver_email is your PayPal email
//	// check that payment_amount/payment_currency are correct
//	// process payment and mark item as paid.
//
//	// assign posted variables to local variables
//	//$item_name = $_POST['item_name'];
//	//$item_number = $_POST['item_number'];
//	//$payment_status = $_POST['payment_status'];
//	//$payment_amount = $_POST['mc_gross'];
//	//$payment_currency = $_POST['mc_currency'];
//	//$txn_id = $_POST['txn_id'];
//	//$receiver_email = $_POST['receiver_email'];
//	//$payer_email = $_POST['payer_email'];
//
//	if(DEBUG == true) {
//		error_log(date('[Y-m-d H:i e] '). "Verified IPN: $req ". PHP_EOL, 3, LOG_FILE);
//	}
//} else if (strcmp ($res, "INVALID") == 0) {
//	// log for manual investigation
//	// Add business logic here which deals with invalid IPN messages
//	if(DEBUG == true) {
//		error_log(date('[Y-m-d H:i e] '). "Invalid IPN: $req" . PHP_EOL, 3, LOG_FILE);
//	}
//}


if (strcmp ($res, "VERIFIED") == 0) {
	// The IPN is verified, process it:
	// check whether the payment_status is Completed
	// check that txn_id has not been previously processed
	// check that receiver_email is your Primary PayPal email
	// check that payment_amount/payment_currency are correct
	// process the notification
	// assign posted variables to local variables
	$item_name = $_POST['item_name'];
	$item_number = $_POST['item_number'];
	$payment_status = $_POST['payment_status'];
	$payment_amount = $_POST['mc_gross'];
	$payment_currency = $_POST['mc_currency'];
	$txn_id = $_POST['txn_id'];
	$receiver_email = $_POST['receiver_email'];
	$payer_email = $_POST['payer_email'];
	// IPN message values depend upon the type of notification sent.
	// To loop through the &_POST array and print the NV pairs to the screen:
	foreach($_POST as $key => $value) {
//		echo $key." = ". $value."<br>";
	}


	$deta = array();

	$lab = 'mc_gross';
	if(isset($_POST[$lab])){
		$deta[$lab] = $_POST[$lab];
	}

	$lab = 'item_name';
	if(isset($_POST[$lab])){
		$deta[$lab] = $_POST[$lab];
	}

	$lab = 'item_number';
	if(isset($_POST[$lab])){
		$deta[$lab] = $_POST[$lab];
	}
	$lab = 'payer_email';
	if(isset($_POST[$lab])){
		$deta[$lab] = $_POST[$lab];
	}
	$lab = 'receiver_email';
	if(isset($_POST[$lab])){
		$deta[$lab] = $_POST[$lab];
	}

	$dets = serialize($deta);

	$args = array(
		'type'=>'purchase',
		'details'=>$dets,
	);

	$dzsap_portal->validate_purchase($_POST,$args);

	// -- we insert activity in validate_purchase but we insert another activity full paypal log

	$args['type']='purchase_paypal';
	$dzsap_portal->mysql_insert_activity($args);


	setcookie('dzspor_cart', '', time()-3600);
	header("Location:index.php");





} else if (strcmp ($res, "INVALID") == 0) {
	// IPN invalid, log for manual investigation
	echo "The response from IPN was: <b>" .$res ."</b>";
}


